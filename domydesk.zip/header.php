<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$domycoHeartbeatFile = __DIR__ . '/data/domyco_heartbeat.php';
if (is_file($domycoHeartbeatFile)) {
    require_once $domycoHeartbeatFile;
}


if (!defined('DMD_CACHE_READY')) {
    define('DMD_CACHE_READY', true);
    define('CACHE_ROOT', __DIR__ . '/data/cache/');
    if (!is_dir(CACHE_ROOT)) @mkdir(CACHE_ROOT, 0775, true);
    $rootHt = CACHE_ROOT . '.htaccess';
    if (!file_exists($rootHt)) {
        @file_put_contents($rootHt, "Require all denied\nOrder allow,deny\nDeny from all\nOptions -Indexes\n");
    }
    $userId = !empty($_SESSION['user']['email'])
        ? $_SESSION['user']['email']
        : (!empty($_SESSION['user']['id']) ? (string)$_SESSION['user']['id'] : '_public');
    define('USER_CACHE_DIR', CACHE_ROOT . $userId . '/');
    if (!is_dir(USER_CACHE_DIR)) @mkdir(USER_CACHE_DIR, 0775, true);
    $uHt = USER_CACHE_DIR . '.htaccess';
    if (!file_exists($uHt)) {
        @file_put_contents($uHt, "Require all denied\nOrder allow,deny\nDeny from all\nOptions -Indexes\n");
    }
    function dmd_cache_user_path(string $key): string {
        $safe = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $key);
        return USER_CACHE_DIR . $safe . '.json';
    }
    function dmd_cache_get(string $key, int $ttl): mixed {
        $f = dmd_cache_user_path($key);
        if (!is_file($f)) return null;
        if ((time() - filemtime($f)) > $ttl) return null;
        $j = @file_get_contents($f);
        if ($j === false) return null;
        $d = json_decode($j, true);
        return (json_last_error() === JSON_ERROR_NONE) ? $d : null;
    }
    function dmd_cache_set(string $key, mixed $data): bool {
        $f = dmd_cache_user_path($key);
        $j = json_encode($data, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        return ($j !== false) ? (@file_put_contents($f, $j) !== false) : false;
    }
    function dmd_cache_del(string $key): void {
        $f = dmd_cache_user_path($key);
        if (is_file($f)) @unlink($f);
    }
    function dmd_cache_clear_user(): bool {
        if (!is_dir(USER_CACHE_DIR)) return true;
        $ok = true;
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator(USER_CACHE_DIR, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($it as $path) {
            $ok = $ok && (@($path->isDir() ? rmdir($path->getPathname()) : unlink($path->getPathname())));
        }
        $ok = $ok && @rmdir(USER_CACHE_DIR);
        @mkdir(USER_CACHE_DIR, 0775, true);
        $uHt = USER_CACHE_DIR . '.htaccess';
        if (!file_exists($uHt)) {
            @file_put_contents($uHt, "Require all denied\nOrder allow,deny\nDeny from all\nOptions -Indexes\n");
        }
        return $ok;
    }
    if (empty($_SESSION['csrf_cache'])) {
        $_SESSION['csrf_cache'] = bin2hex(random_bytes(16));
    }
if (isset($_GET['clear_cache'], $_GET['token']) && hash_equals($_SESSION['csrf_cache'], (string)$_GET['token'])) {
    $done = dmd_cache_clear_user();
    $_SESSION['flash_cache'] = $done ? 'Cache utilisateur vidé.' : 'Échec du vidage du cache.';

    $target = strtok((string)($_SERVER['REQUEST_URI'] ?? ''), '?');
    if (!headers_sent()) {
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Location: '.$target, true, 303);
    } else {
        echo '<script>location.replace('.json_encode($target).');</script>';
        echo '<noscript><meta http-equiv="refresh" content="0;url='.htmlspecialchars($target, ENT_QUOTES).'"></noscript>';
    }
    exit;
}

}
$userEmail     = $_SESSION['user']['email']  ?? null;
$userFirstName = $_SESSION['user']['prenom'] ?? 'Invité';
$userRole      = $_SESSION['user']['role']   ?? null;
$menu          = [];
$theme = 'default';
if ($userEmail) {
    $themePath = __DIR__ . "/users/profiles/$userEmail/theme.json";
    if (file_exists($themePath)) {
        $themeData = json_decode(file_get_contents($themePath), true);
        if (!empty($themeData['theme']) && file_exists(__DIR__ . "/theme/" . $themeData['theme'] . "/style.css")) {
            $theme = basename($themeData['theme']);
        }
    }
    $menuFilePath = __DIR__ . "/users/profiles/$userEmail/menu.json";
    if (file_exists($menuFilePath)) {
        $menu = json_decode(file_get_contents($menuFilePath), true);
        if (!is_array($menu)) $menu = [];
    }
}
$settingsFile = __DIR__ . '/adm/settings.json';

function dmd_header_default_horizontal_menu(): array {
    return [
        ['title' => 'Dashboard', 'icon' => '🖥️', 'url' => '/domydesk/dashboard.php', 'type' => 'page'],
        ['title' => 'DoMyDesk public', 'icon' => '🌎', 'url' => 'https://domydesk.com/', 'type' => 'external'],
        ['title' => 'Votre DoMySocial', 'icon' => '🔅', 'url' => '/domysocial/index.php', 'type' => 'page'],
        ['title' => 'Accueil', 'icon' => '⭐', 'url' => '/domydesk/index.php', 'type' => 'page'],
        ['title' => 'Profil', 'icon' => '🏃', 'url' => '/domydesk/profile_view.php', 'type' => 'page'],
        ['title' => 'Se connecter', 'icon' => '✅', 'url' => '/domydesk/login.php', 'type' => 'page'],
        ['title' => 'Déconnexion', 'icon' => '❌', 'url' => '/domydesk/logout.php', 'type' => 'page'],
        ['title' => 'Aide', 'icon' => '📜', 'url' => '/domydesk/data/procedures/procedures_list.php', 'type' => 'page'],
        ['title' => 'Administration', 'icon' => '🛠️', 'url' => '/domydesk/adm/site_settings.php', 'type' => 'page'],
    ];
}

function dmd_header_render_horizontal_menu(array $items): string {
    $html = '';

    foreach ($items as $item) {
        if (!is_array($item)) continue;

        $title = trim((string)($item['title'] ?? ''));
        $icon  = trim((string)($item['icon'] ?? ''));
        $url   = trim((string)($item['url'] ?? ''));
        $type  = ((string)($item['type'] ?? 'page')) === 'external' ? 'external' : 'page';

        if ($title === '' || $icon === '' || $url === '') continue;
        if ($type === 'external') {
            if (!filter_var($url, FILTER_VALIDATE_URL)) continue;
            $scheme = strtolower((string)parse_url($url, PHP_URL_SCHEME));
            if (!in_array($scheme, ['http', 'https'], true)) continue;
        } else {
            $url = str_replace('\\', '/', $url);
            if (str_contains($url, '..')) continue;
            if (preg_match('~^https?://~i', $url)) continue;
            if (!str_starts_with($url, '/')) $url = '/domydesk/' . ltrim($url, '/');
        }

        $target = $type === 'external' ? ' target="_blank" rel="noopener noreferrer"' : '';
        $html .= '<a href="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '" class="icon-link" title="' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '"' . $target . '>' . htmlspecialchars($icon, ENT_QUOTES, 'UTF-8') . '</a>' . "
";
    }

    return $html;
}

$settings = [
    'site_name'       => 'DoMyDesk',
    'logo_path'       => 'adm/uploads/logo.png',
    'menu_horizontal' => dmd_header_default_horizontal_menu(),
];

if (is_file($settingsFile)) {
    $json = file_get_contents($settingsFile);
    $loadedSettings = json_decode($json, true);
    if (is_array($loadedSettings)) {
        $settings = array_merge($settings, $loadedSettings);
    }
}

if (empty($settings['menu_horizontal']) || !is_array($settings['menu_horizontal'])) {
    $settings['menu_horizontal'] = dmd_header_default_horizontal_menu();
}

$settings['menu_vertical'] = dmd_header_render_horizontal_menu($settings['menu_horizontal']);

function renderMenuItems(array $items) {
    echo '<ul>';
    foreach ($items as $item) {
        $label   = $item['label']   ?? '';
        $link    = $item['link']    ?? '#';
        $submenu = $item['submenu'] ?? [];
        if (!$label) continue;

        if (!empty($submenu)) {
            echo '<li class="has-submenu">';
            echo '<a href="' . htmlspecialchars($link) . '">' . htmlspecialchars($label) . '</a>';
            renderMenuItems($submenu);
            echo '</li>';
        } else {
            echo '<li><a href="' . htmlspecialchars($link) . '">' . htmlspecialchars($label) . '</a></li>';
        }
    }
    echo '</ul>';
}
function dmd_read_unique_id(): string {
    $candidates = [
        __DIR__ . '/data/id_domydesk.txt',
        __DIR__ . '/id_domydesk.txt',
        __DIR__ . '/adm/data/id_domydesk.txt',
    ];
    foreach ($candidates as $p) {
        if (is_file($p)) {
            $id = trim((string)@file_get_contents($p));
            if ($id !== '') return $id;
        }
    }
    return 'ID non défini';
}
$domydeskId = dmd_read_unique_id();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <title><?= htmlspecialchars($settings['site_name']) ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="/domydesk/theme/<?= htmlspecialchars($theme) ?>/style.css">



<style>
<link rel="stylesheet" href="/domydesk/theme/<?= htmlspecialchars($theme) ?>/style.css">
</style>
<script>
(function () {
  const tb = document.getElementById('top-bar');
  if (!tb) return;
  const candidates = [
    '#workspace', '#dashboard', '#dashboard-canvas', '#modules-area',
    '#board', '#area', '.workspace', '.dashboard', '.modules', '.canvas', '.workarea'
  ];
  let scroller = null;
  for (const sel of candidates) {
    const el = document.querySelector(sel);
    if (el && el.scrollWidth > el.clientWidth + 1) { scroller = el; break; }
  }
  if (!scroller) scroller = window;
  tb.style.position = 'fixed';
  tb.style.right    = 'auto';
  tb.style.width    = '100vw';
  tb.style.willChange = 'left';
  tb.style.transform  = 'translateZ(0)';
  function getScrollLeft(){
    return (scroller === window) ? window.scrollX : scroller.scrollLeft;
  }
  function getViewportLeft(){
    if (scroller === window) return 0;
    return scroller.getBoundingClientRect().left;
  }
  function sync(){
    const sl   = getScrollLeft();
    const left = getViewportLeft();
    tb.style.left = (left - sl) + 'px';
  }
  (scroller === window ? window : scroller).addEventListener('scroll', sync, {passive:true});
  window.addEventListener('resize', sync);
  window.addEventListener('load', sync);
  sync();
  setTimeout(sync, 150);
  setTimeout(sync, 500);
  setTimeout(sync, 1200);
})();
</script>
</head>
<body>
<header>
    <div id="top-bar">
        <div class="left">
            <span id="user-name"><?= htmlspecialchars($userFirstName) ?></span>
            <span id="date">--.--.----</span>
            <span id="time">--:--:--</span>
            <?php if ($userRole): ?>
                <span id="role"><?= htmlspecialchars($userRole) ?></span>
            <?php endif; ?>
        </div>
        <div class="center">ID : <?= htmlspecialchars($domydeskId) ?></div>
        <div class="right"><?= $settings['menu_vertical'] ?></div>
    </div>
    <div class="menu-toggle" onclick="toggleMenu()">☰</div>
    <div class="right-menu-wrapper" id="right-menu-wrapper" aria-hidden="true">
        <nav class="right-menu">
            <ul>
                <li><a href="/domydesk/modules/modules.php">🎫 Modules</a></li>
                <li>
                   <a href="?clear_cache=1&token=<?= htmlspecialchars($_SESSION['csrf_cache']) ?>"
   class="menu-action" title="Vider mon cache">♻️ Vider mon cache</a>
                </li>
                <li><a href="/domydesk/members.php">👨‍👨‍👦‍👦 Membres</a></li>
                <li><a href="/domydesk/profile_edit.php">🧰 Modifier le profil</a></li>

                <?php if (!empty($_SESSION['flash_cache'])): ?>
                    <li id="flash-cache" class="flash notice" role="status" aria-live="polite">
                        <?= htmlspecialchars($_SESSION['flash_cache']); ?>
                    </li>
                    <?php unset($_SESSION['flash_cache']); ?>
                <?php endif; ?>
                <hr>
                <?php
                if (!empty($menu['items']['items']) && is_array($menu['items']['items'])) {
                    renderMenuItems($menu['items']['items']);
                } else {
                    echo '<li style="padding:10px; color:orange;">Aucun menu personnalisé trouvé.</li>';
                }
                ?>
                <hr>
            </ul>
        </nav>
    </div>
</header>
<script>
function updateDateTime() {
    const d = document.getElementById('date');
    const t = document.getElementById('time');
    if (!d || !t) return;
    const now = new Date();
    d.textContent = `${String(now.getDate()).padStart(2,'0')}.${String(now.getMonth()+1).padStart(2,'0')}.${now.getFullYear()}`;
    t.textContent = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}:${String(now.getSeconds()).padStart(2,'0')}`;
}
function toggleMenu() {
    const menu = document.getElementById('right-menu-wrapper');
    const toggleBtn = document.querySelector('.menu-toggle');
    const isVisible = getComputedStyle(menu).transform === 'matrix(1, 0, 0, 1, 0, 0)';
    menu.style.transform = isVisible ? 'translateX(100%)' : 'translateX(0)';
    menu.setAttribute('aria-hidden', isVisible ? 'true' : 'false');
    toggleBtn.setAttribute('aria-expanded', (!isVisible).toString());
}
document.addEventListener("DOMContentLoaded", () => {
    updateDateTime();
    setInterval(updateDateTime, 1000);
    const menuWrapper = document.getElementById('right-menu-wrapper');
    const toggleBtn = document.querySelector('.menu-toggle');
    menuWrapper.addEventListener('mouseover', () => {
        menuWrapper.style.transform = 'translateX(0)';
        menuWrapper.setAttribute('aria-hidden', 'false');
        toggleBtn.setAttribute('aria-expanded', 'true');
    });
    menuWrapper.addEventListener('mouseout', () => {
        menuWrapper.style.transform = 'translateX(100%)';
        menuWrapper.setAttribute('aria-hidden', 'true');
        toggleBtn.setAttribute('aria-expanded', 'false');
    });
});
setTimeout(() => {
  const el = document.getElementById('flash-cache');
  if (el) { el.style.transition='opacity .3s'; el.style.opacity='0';
    setTimeout(()=>el.remove(), 320);
  }
}, 1800);
</script>
