<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!defined('DMD_CACHE_READY')) {
    define('DMD_CACHE_READY', true);
    define('CACHE_ROOT', __DIR__ . '/data/cache/');
    if (!is_dir(CACHE_ROOT)) @mkdir(CACHE_ROOT, 0775, true);
    $rootHt = CACHE_ROOT . '.htaccess';
    if (!file_exists($rootHt)) {
        @file_put_contents($rootHt, "Require all denied\nOrder allow,deny\nDeny from all\nOptions -Indexes\n");
    }
    $userId = !empty($_SESSION['user']['email'])
        ? $_SESSION['user']['email']
        : (!empty($_SESSION['user']['id']) ? (string)$_SESSION['user']['id'] : '_public');
    define('USER_CACHE_DIR', CACHE_ROOT . $userId . '/');
    if (!is_dir(USER_CACHE_DIR)) @mkdir(USER_CACHE_DIR, 0775, true);
    $uHt = USER_CACHE_DIR . '.htaccess';
    if (!file_exists($uHt)) {
        @file_put_contents($uHt, "Require all denied\nOrder allow,deny\nDeny from all\nOptions -Indexes\n");
    }
    function dmd_cache_user_path(string $key): string {
        $safe = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $key);
        return USER_CACHE_DIR . $safe . '.json';
    }
    function dmd_cache_get(string $key, int $ttl): mixed {
        $f = dmd_cache_user_path($key);
        if (!is_file($f)) return null;
        if ((time() - filemtime($f)) > $ttl) return null;
        $j = @file_get_contents($f);
        if ($j === false) return null;
        $d = json_decode($j, true);
        return (json_last_error() === JSON_ERROR_NONE) ? $d : null;
    }
    function dmd_cache_set(string $key, mixed $data): bool {
        $f = dmd_cache_user_path($key);
        $j = json_encode($data, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        return ($j !== false) ? (@file_put_contents($f, $j) !== false) : false;
    }
    function dmd_cache_del(string $key): void {
        $f = dmd_cache_user_path($key);
        if (is_file($f)) @unlink($f);
    }
    function dmd_cache_clear_user(): bool {
        if (!is_dir(USER_CACHE_DIR)) return true;
        $ok = true;
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator(USER_CACHE_DIR, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($it as $path) {
            $ok = $ok && (@($path->isDir() ? rmdir($path->getPathname()) : unlink($path->getPathname())));
        }
        $ok = $ok && @rmdir(USER_CACHE_DIR);
        @mkdir(USER_CACHE_DIR, 0775, true);
        $uHt = USER_CACHE_DIR . '.htaccess';
        if (!file_exists($uHt)) {
            @file_put_contents($uHt, "Require all denied\nOrder allow,deny\nDeny from all\nOptions -Indexes\n");
        }
        return $ok;
    }
    if (empty($_SESSION['csrf_cache'])) {
        $_SESSION['csrf_cache'] = bin2hex(random_bytes(16));
    }
if (isset($_GET['clear_cache'], $_GET['token']) && hash_equals($_SESSION['csrf_cache'], (string)$_GET['token'])) {
    $done = dmd_cache_clear_user(); // retourne bool
    $_SESSION['flash_cache'] = $done ? 'Cache utilisateur vidé.' : 'Échec du vidage du cache.';

    $target = strtok((string)($_SERVER['REQUEST_URI'] ?? ''), '?');
    if (!headers_sent()) {
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Location: '.$target, true, 303);
    } else {
        echo '<script>location.replace('.json_encode($target).');</script>';
        echo '<noscript><meta http-equiv="refresh" content="0;url='.htmlspecialchars($target, ENT_QUOTES).'"></noscript>';
    }
    exit;
}
}
$userEmail     = $_SESSION['user']['email']  ?? null;
$userFirstName = $_SESSION['user']['prenom'] ?? 'Invité';
$userRole      = $_SESSION['user']['role']   ?? null;
$menu          = [];
$theme = 'default';
if ($userEmail) {
    $themePath = __DIR__ . "/users/profiles/$userEmail/theme.json";
    if (file_exists($themePath)) {
        $themeData = json_decode(file_get_contents($themePath), true);
        if (!empty($themeData['theme']) && file_exists(__DIR__ . "/theme/" . $themeData['theme'] . "/style.css")) {
            $theme = basename($themeData['theme']);
        }
    }
    $menuFilePath = __DIR__ . "/users/profiles/$userEmail/menu.json";
    if (file_exists($menuFilePath)) {
        $menu = json_decode(file_get_contents($menuFilePath), true);
        if (!is_array($menu)) $menu = [];
    }
}
$settingsFile = __DIR__ . '/adm/data/settings.json';
$settings = [
    'site_name'     => 'Mon super site',
    'logo_path'     => 'adm/uploads/logo.png',
    'menu_vertical' => '',
];
if (file_exists($settingsFile)) {
    $json = file_get_contents($settingsFile);
    $loadedSettings = json_decode($json, true);
    if ($loadedSettings !== null) {
        $settings = array_merge($settings, $loadedSettings);
    }
}
$baseMenu = [
    ['link' => '/domydesk/dashboard.php',                'icon' => '🖥️', 'title' => 'Dashboard'],
    ['link' => 'https://domydesk.com/domysocial',        'icon' => '🌎', 'title' => 'DoMySocial publique'],
    ['link' => '/domydesk/index.php',                    'icon' => '⭐', 'title' => 'Accueil'],
    ['link' => '/domydesk/profile_view.php',             'icon' => '🏃', 'title' => 'Profil'],
    ['link' => '/domydesk/logout.php',                   'icon' => '🔑', 'title' => 'Déconnexion'],
    ['link' => '/domydesk/data/procedures/procedures_list.php', 'icon' => '📜', 'title' => 'Aide'],
];
if (!empty($_SESSION['user']['role_system']) && $_SESSION['user']['role_system'] === 'admin') {
    $baseMenu[] = ['link' => '/domydesk/adm/site_settings.php', 'icon' => '<span class="icon-admin">🛠</span>', 'title' => 'Administration'];
} else {
    $baseMenu[] = ['link' => '/domydesk/adm/site_settings.php', 'icon' => '🛠', 'title' => 'Paramètres'];
}
$menuHtml = '';
foreach ($baseMenu as $item) {
    $menuHtml .= '<a href="' . htmlspecialchars($item['link']) . '" class="icon-link" title="' . htmlspecialchars($item['title']) . '">' . $item['icon'] . '</a>' . "\n";
}
$settings['menu_vertical'] = $menuHtml;
function renderMenuItems(array $items) {
    echo '<ul>';
    foreach ($items as $item) {
        $label   = $item['label']   ?? '';
        $link    = $item['link']    ?? '#';
        $submenu = $item['submenu'] ?? [];
        if (!$label) continue;

        if (!empty($submenu)) {
            echo '<li class="has-submenu">';
            echo '<a href="' . htmlspecialchars($link) . '">' . htmlspecialchars($label) . '</a>';
            renderMenuItems($submenu);
            echo '</li>';
        } else {
            echo '<li><a href="' . htmlspecialchars($link) . '">' . htmlspecialchars($label) . '</a></li>';
        }
    }
    echo '</ul>';
}
function dmd_read_unique_id(): string {
    $candidates = [
        __DIR__ . '/data/id_domydesk.txt',
        __DIR__ . '/id_domydesk.txt',
        __DIR__ . '/adm/data/id_domydesk.txt',
    ];
    foreach ($candidates as $p) {
        if (is_file($p)) {
            $id = trim((string)@file_get_contents($p));
            if ($id !== '') return $id;
        }
    }
    return 'ID non défini';
}
$domydeskId = dmd_read_unique_id();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <title><?= htmlspecialchars($settings['site_name']) ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="/domydesk/theme/<?= htmlspecialchars($theme) ?>/style.css">
    <style>
#top-bar {
    position: fixed; top: 0; left: 0; width: 100%;
    background-color: transparent; color: inherit;
    font-family: inherit; font-size: 10px;
    height: 15px; display: flex; justify-content: space-between;
    align-items: center; padding: 0 15px; box-sizing: border-box;
    z-index: 1100; user-select: none;
}
#top-bar .left, #top-bar .right { display: flex; gap: 15px; align-items: center; }
#top-bar .center {
    position: absolute; left: 50%; transform: translateX(-50%);
    font-weight: 600; font-size: 10px; letter-spacing: .2px; opacity:.95;
    white-space: nowrap;
}
#top-bar .icon-link {
    color: inherit; text-decoration: none; font-size: 18px;
    cursor: pointer; display: flex; align-items: center;
    justify-content: center; width: 24px; height: 24px;
    transition: opacity .2s;
}
#top-bar .icon-link:hover { opacity: .85; }
body { padding-top: 20px; margin: 0; color: inherit; background: transparent; }


.right-menu-wrapper {
    position: fixed; top: 65px; right: 0;
    z-index: 1000; transform: translateX(100%);
    transition: transform .3s ease-in-out; background-color: transparent;
}
.right-menu {
    background-color: transparent; color: inherit;
    height: 100%; overflow-y: auto; min-width: 200px;
    box-shadow: -2px 0 5px rgba(0,0,0,0.5);
}
.menu-toggle {
    position: fixed; bottom: 20px; right: 20px;
    width: 50px; height: 50px;
    background-color: transparent; color: inherit;
    border-radius: 50%; display: flex;
    justify-content: center; align-items: center;
    cursor: pointer; box-shadow: 0 0 5px rgba(0,0,0,0.3);
    z-index: 1101; user-select: none;
}
.right-menu ul { list-style: none; padding: 0; margin: 0; }
.right-menu li { margin: 0; }
.right-menu a { text-decoration: none; color: inherit; padding: 10px 15px; display: block; }
.has-submenu > a { background-color: transparent; cursor: pointer; position: relative; }
.has-submenu > a::after { content: "▸"; position: absolute; right: 15px; }
.has-submenu > ul { display: none; padding-left: 15px; background-color: transparent; }
.has-submenu:hover > ul { display: block; }

#date, #time, #role {
    margin-left: 10px; min-width: 80px;
    display: inline-block; font-variant-numeric: tabular-nums;
}

.flash.notice { padding:8px 10px; margin:8px; border-radius:8px; background:#1f1f1f80; border:1px solid var(--primary-color, #888); }
    </style>
	<script>
(function () {
  const tb = document.getElementById('top-bar');
  if (!tb) return;
  const candidates = [
    '#workspace', '#dashboard', '#dashboard-canvas', '#modules-area',
    '#board', '#area', '.workspace', '.dashboard', '.modules', '.canvas', '.workarea'
  ];
  let scroller = null;
  for (const sel of candidates) {
    const el = document.querySelector(sel);
    if (el && el.scrollWidth > el.clientWidth + 1) { scroller = el; break; }
  }
  if (!scroller) scroller = window;
  tb.style.position = 'fixed';
  tb.style.right    = 'auto';
  tb.style.width    = '100vw';
  tb.style.willChange = 'left';
  tb.style.transform  = 'translateZ(0)';
  function getScrollLeft(){
    return (scroller === window) ? window.scrollX : scroller.scrollLeft;
  }
  function getViewportLeft(){
    if (scroller === window) return 0;
    return scroller.getBoundingClientRect().left;
  }
  function sync(){
    const sl   = getScrollLeft();
    const left = getViewportLeft();
    tb.style.left = (left - sl) + 'px';
  }
  (scroller === window ? window : scroller).addEventListener('scroll', sync, {passive:true});
  window.addEventListener('resize', sync);
  window.addEventListener('load', sync);
  sync();
  setTimeout(sync, 150);
  setTimeout(sync, 500);
  setTimeout(sync, 1200);
})();
</script>
</head>
<body>
<header>
    <div id="top-bar">
        <div class="left">
            <span id="user-name"><?= htmlspecialchars($userFirstName) ?></span>
            <span id="date">--.--.----</span>
            <span id="time">--:--:--</span>
            <?php if ($userRole): ?>
                <span id="role"><?= htmlspecialchars($userRole) ?></span>
            <?php endif; ?>
        </div>
        <div class="center">ID : <?= htmlspecialchars($domydeskId) ?> </div>
        <div class="right"><?= $settings['menu_vertical'] ?></div>
    </div>

    <div class="menu-toggle" onclick="toggleMenu()">☰</div>
    <div class="right-menu-wrapper" id="right-menu-wrapper" aria-hidden="true">
        <nav class="right-menu">
            <ul>
                <li><a href="/domydesk/modules/modules.php">Modules</a></li>
                <li>
                    <a href="?clear_cache=1&token=<?= htmlspecialchars($_SESSION['csrf_cache']) ?>"
                       class="icon-link" title="Vider mon cache">Vider mon cache</a>
                </li>
                <li><a href="/domydesk/members.php">Membres</a></li>
                <li><a href="/domydesk/profile_edit.php">Modifier le profil</a></li>
                <?php if (!empty($_SESSION['flash_cache'])): ?>
                    <li id="flash-cache" class="flash notice" role="status" aria-live="polite">
                        <?= htmlspecialchars($_SESSION['flash_cache']); ?>
                    </li>
                    <?php unset($_SESSION['flash_cache']); ?>
                <?php endif; ?>
                <hr>
                <?php
                if (!empty($menu['items']['items']) && is_array($menu['items']['items'])) {
                    renderMenuItems($menu['items']['items']);
                } else {
                    echo '<li style="padding:10px; color:orange;">Aucun menu personnalisé trouvé.</li>';
                }
                ?>
                <hr>
            </ul>
        </nav>
    </div>
</header>
<script>
function updateDateTime() {
    const d = document.getElementById('date');
    const t = document.getElementById('time');
    if (!d || !t) return;
    const now = new Date();
    d.textContent = `${String(now.getDate()).padStart(2,'0')}.${String(now.getMonth()+1).padStart(2,'0')}.${now.getFullYear()}`;
    t.textContent = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}:${String(now.getSeconds()).padStart(2,'0')}`;
}
function toggleMenu() {
    const menu = document.getElementById('right-menu-wrapper');
    const toggleBtn = document.querySelector('.menu-toggle');
    const isVisible = getComputedStyle(menu).transform === 'matrix(1, 0, 0, 1, 0, 0)';
    menu.style.transform = isVisible ? 'translateX(100%)' : 'translateX(0)';
    menu.setAttribute('aria-hidden', isVisible ? 'true' : 'false');
    toggleBtn.setAttribute('aria-expanded', (!isVisible).toString());
}
document.addEventListener("DOMContentLoaded", () => {
    updateDateTime();
    setInterval(updateDateTime, 1000);
    const menuWrapper = document.getElementById('right-menu-wrapper');
    const toggleBtn = document.querySelector('.menu-toggle');
    menuWrapper.addEventListener('mouseover', () => {
        menuWrapper.style.transform = 'translateX(0)';
        menuWrapper.setAttribute('aria-hidden', 'false');
        toggleBtn.setAttribute('aria-expanded', 'true');
    });
    menuWrapper.addEventListener('mouseout', () => {
        menuWrapper.style.transform = 'translateX(100%)';
        menuWrapper.setAttribute('aria-hidden', 'true');
        toggleBtn.setAttribute('aria-expanded', 'false');
    });
});
setTimeout(() => {
  const el = document.getElementById('flash-cache');
  if (el) { el.style.transition='opacity .3s'; el.style.opacity='0';
    setTimeout(()=>el.remove(), 320);
  }
}, 1800);
</script>
