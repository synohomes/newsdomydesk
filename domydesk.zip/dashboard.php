<?php
session_start();
if (empty($_SESSION['user']['email'])) {
    header('Location: login.php');
    exit;
}
$email   = $_SESSION['user']['email'];
$userDir = __DIR__ . "/users/profiles/$email";
if (!is_dir($userDir)) { @mkdir($userDir, 0775, true); }
function json_read(string $file, $fallback) {
    if (!is_file($file)) return $fallback;
    $raw = file_get_contents($file);
    $data = json_decode($raw, true);
    return (json_last_error() === JSON_ERROR_NONE) ? $data : $fallback;
}
function json_write(string $file, $data): void {
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
}
function sanitize_name(string $s): string {
    $s = preg_replace('/[^a-zA-Z0-9_-]/', '_', $s);
    return $s === '' ? 'dashboard' : $s;
}
$listFile = "$userDir/dashboards.json";
if (!file_exists($listFile)) {
    json_write($listFile, ['dashboard']);
}
$dashboards = json_read($listFile, ['dashboard']);
$dashboards = array_values(array_unique(array_map('sanitize_name', (array)$dashboards)));
if (!$dashboards) { $dashboards = ['dashboard']; json_write($listFile, $dashboards); }
$requested = isset($_GET['dashboard']) ? sanitize_name($_GET['dashboard']) : $dashboards[0];
$currentDashboard = in_array($requested, $dashboards, true) ? $requested : $dashboards[0];
$dashboardFile = "$userDir/$currentDashboard.json";
if (!file_exists($dashboardFile)) json_write($dashboardFile, []);
$theme = 'default';
$themeJson = "$userDir/theme.json";
if (is_file($themeJson)) {
    $t = json_read($themeJson, []);
    if (!empty($t['theme']) && is_file(__DIR__."/theme/".basename($t['theme'])."/style.css")) {
        $theme = basename($t['theme']);
    }
} else {
    $profileFile = "$userDir/profile.json";
    if (is_file($profileFile)) {
        $p = json_read($profileFile, []);
        if (!empty($p['theme']) && is_file(__DIR__."/theme/".basename($p['theme'])."/style.css")) {
            $theme = basename($p['theme']);
        }
    }
}
$availableModules = [];
$modulesUserFile = "$userDir/modules.json";
if (is_file($modulesUserFile)) {
    $enabledModules = json_read($modulesUserFile, []);
    foreach ((array)$enabledModules as $m) {
        if (!empty($m['enabled']) && !empty($m['id']) && !empty($m['name'])) {
            $availableModules[$m['id']] = $m['name'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Bureau Numerique</title>
<link rel="stylesheet" href="theme/<?= htmlspecialchars($theme) ?>/style.css">
<style>
  :root{
    --topbar-left: 0px;
    --topbar-width: 100vw;
  }

 #top-bar{
    left: var(--topbar-left) !important;
    width: var(--topbar-width) !important;
    will-change: left, width;
    transform: translateZ(0);
  }
body {
  margin: 0;                 
  font-family: Arial, sans-serif;
  color: #eee;
}
.wrapper {
  display: flex;
  flex-direction: column;
  height: 100vh;
  min-height: 0;            
}
main {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-height: 0;             
}
#dashboard {
  flex: 1 1 auto;
  position: relative;
  overflow: auto;
    padding: 0;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  min-width: 0;  
  min-height: 0;  
}
#dashboard { scrollbar-gutter: stable; }
#dashboard.empty {
  overflow: hidden;
  padding: 0;
}
.module {
  position: absolute;
  border-radius: 8px;
  padding: 10px;            
  box-sizing: border-box;
}
.module.square  { border-radius: 0; }
.module.rounded { border-radius: 10px; }
.module.circle  {
  border-radius: 50%;
  justify-content: center;
  align-items: center;
  text-align: center;
}
.module-header {
  font-weight: bold;
  display: flex;
  justify-content: space-between;
  align-items: center;
  cursor: move;
  user-select: none;
  -webkit-user-select: none;
}
.module.circle .module-header {
  flex-direction: column;
  align-items: flex-end;
}
.module-content {
  overflow-y: auto;
  height: 100%;
}
.module-close {
  font-size: 14px;
  color: #f44;
  background: none;
  border: none;
  cursor: pointer;
  padding: 0;
  margin-left: 8px;
}
.shape-select {
  font-size: .8em;
  background: #222;
  border: 1px solid #444;
  color: #ccc;
  border-radius: 4px;
  margin-top: 2px;
}
.resize-handle {
  width: 12px;
  height: 12px;
  background: #666;
  position: absolute;
  right: 2px;
  bottom: 2px;
  cursor: se-resize;
}
.mod-icon {
  position: absolute;
  top: -10px;
  left: -10px;
  width: 68px;
  height: 68px;
  z-index: 2;
}
.popup {
  position: absolute;
  background: #2a2a2a;
  border: 1px solid #555;
  border-radius: 8px;
  padding: 10px;
  display: none;
  z-index: 1000;
}
.popup button {
  margin: 5px;
}
#controls {
  display: flex;
  align-items: center;
  gap: 3px;
  padding: 5px 5px;
  background-color: #121212;
  border-bottom: 1px solid #333;
  font-size: 12px;
  height: 32px;
  box-sizing: border-box;
}
#controls select,
#controls button {
  height: 24px !important;
  font-size: 10px !important;
  padding: 0 6px !important;
  min-width: 30px !important;
  max-width: 140px !important;
  background: #222 !important;
  color: #ccc !important;
  border: 1px solid #444 !important;
  border-radius: 3px !important;
  box-shadow: none !important;
  line-height: 1 !important;
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  margin: 0 2px !important;
}
body.noscroll {
  overflow: hidden;
}
</style>
<script src="https://cdn.jsdelivr.net/npm/interactjs/dist/interact.min.js"></script>
</head>
<body>
<div class="wrapper">
<?php include 'header.php'; ?>
<main>
<div id="controls">
    <select id="dashSelect" onchange="location.href='?dashboard='+this.value">
        <?php foreach ($dashboards as $d): ?>
            <option value="<?= htmlspecialchars($d) ?>" <?= $d===$currentDashboard?'selected':'' ?>>
                <?= htmlspecialchars($d) ?>
            </option>
        <?php endforeach; ?>
    </select>
    <button class="add" onclick="createDash()">➕</button>
    <button class="rename" onclick="renameDash()">✏️</button>
    <button class="delete" onclick="deleteDash()">🗑️</button>
    <select id="addModuleSelect">
        <option value="">-- Ajouter un module --</option>
        <?php foreach ($availableModules as $id=>$name): ?>
            <option value="<?= htmlspecialchars($id) ?>"><?= htmlspecialchars($name) ?></option>
        <?php endforeach; ?>
    </select>
    <button id="resetBtn">Réinitialiser</button>
</div>
<div class="popup" id="confirmPopup">
    <p>Confirmer la réinitialisation ?</p>
    <button onclick="confirmReset()">Oui</button>
    <button onclick="hidePopup()">Non</button>
</div>
<div id="dashboard"></div>
</main>
</div>
<script>
function expandCanvasLT() {
  const ws = document.getElementById('dashboard');
  const mods = ws.querySelectorAll('.module');
if (mods.length === 0) {
  ws.classList.add('empty');
  document.body.classList.add('noscroll'); 
  ws.style.minWidth  = '';
  ws.style.minHeight = '';
  ws.style.width     = '';
  ws.style.height    = '';
  ws.scrollTo(0, 0);
  return;
}
ws.classList.remove('empty');
document.body.classList.remove('noscroll'); 
  ws.classList.remove('empty');
  let maxRight = 0, maxBottom = 0;
  mods.forEach(el => {
    const left   = parseFloat(el.style.left) || 0;
    const top    = parseFloat(el.style.top)  || 0;
    const right  = left + el.offsetWidth;
    const bottom = top  + el.offsetHeight;
    if (right  > maxRight)  maxRight  = right;
    if (bottom > maxBottom) maxBottom = bottom;
  });
  const pad = 24;
  ws.style.minWidth  = (maxRight  + pad) + 'px';
  ws.style.minHeight = (maxBottom + pad) + 'px';
}
function changeShape(sel){
  const m=sel.closest('.module');
  m.classList.remove('square','rounded');
  m.classList.add(sel.value);
  saveDashboard();
}
function enableInteract(el){
  interact(el)
    .draggable({
      allowFrom: '.module-header',
      listeners: {
        move(e){
          const t = e.target;
          const x = (parseFloat(t.style.left) || 0) + e.dx;
          const y = (parseFloat(t.style.top)  || 0) + e.dy;
          t.style.left = x + 'px';
          t.style.top  = y + 'px';
          expandCanvasLT();
          saveDashboard();
        }
      }
    })
    .resizable({
      edges: { left:true, right:true, bottom:true, top:true },
      listeners: {
        move(e){
          const t = e.target;
          const x = parseFloat(t.style.left) || 0;
          const y = parseFloat(t.style.top)  || 0;
          t.style.width  = e.rect.width  + 'px';
          t.style.height = e.rect.height + 'px';
          t.style.left   = (x + e.deltaRect.left) + 'px';
          t.style.top    = (y + e.deltaRect.top)  + 'px';
          expandCanvasLT();
          saveDashboard();
        }
      }
    });
}
function loadModuleContent(modEl, id) {
  setTimeout(() => {
    modEl.style.height = modEl.scrollHeight + 'px';
  }, 100);
  fetch(`modules/${id}/${id}.php`, { cache: 'no-store' })
    .then(r => r.text())
    .then(html => {
      const container = modEl.querySelector('.module-content');
      container.innerHTML = html;
      container.querySelectorAll("script").forEach(oldScript => {
        const s = document.createElement("script");
        if (oldScript.src) s.src = oldScript.src; else s.textContent = oldScript.textContent;
        container.appendChild(s);
      });
    })
    .catch(err => console.error(`[${id}]`, err));
}
function saveDashboard(){
  const mods=[...document.querySelectorAll('.module')].map(m=>({
    id:m.dataset.id,
    title:m.querySelector('.module-title').textContent,
    content:m.querySelector('.module-content').textContent,
    x:parseInt(m.style.left)||0, y:parseInt(m.style.top)||0,
    width:parseInt(m.style.width)||200, height:parseInt(m.style.height)||200
  }));
  fetch('users/save_dashboard.php?dashboard=<?= urlencode($currentDashboard) ?>',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify(mods)
  });
}
function closeModule(btn) {
  const m = btn.closest('.module');
  if (!m) return;
  m.remove();
  expandCanvasLT();
  saveDashboard();
}
document.addEventListener('click', (e) => {
  if (e.target.classList.contains('module-close')) {
    closeModule(e.target);
  }
});
document.getElementById('addModuleSelect').addEventListener('change',function(){
  const id=this.value; if(!id) return;
  const dash=document.getElementById('dashboard');
  const mod=document.createElement('div');
  mod.className='module square'; mod.dataset.id=id;
  Object.assign(mod.style,{left:'250px',top:'280px',width:'280px',height:'280px'});
  mod.innerHTML=`<img class="mod-icon" src="modules/${id}/modicone.png" onerror="this.style.display='none'">
    <div class="module-header">
      <span class="module-title">${id}</span>
      <select class="shape-select" onchange="changeShape(this)">
        <option value="square">Carré</option>
        <option value="rounded">Arrondi</option>
      </select>
      <span class="module-close">&times;</span>
    </div>
    <div class="module-content">Contenu du module ${id}</div>
    <div class="resize-handle"></div>`;
  dash.appendChild(mod);
  expandCanvasLT();
  enableInteract(mod);
  loadModuleContent(mod, id);
  saveDashboard();
  this.value = "";
});
document.getElementById('resetBtn').addEventListener('click',e=>{
  const p=document.getElementById('confirmPopup');p.style.display='block';
  const r=e.target.getBoundingClientRect();p.style.top=r.bottom+window.scrollY+'px';p.style.left=r.left+window.scrollX+'px';
});
function confirmReset(){
  const url = 'users/reset_dashboard.php?dashboard=<?= urlencode($currentDashboard) ?>';
  fetch(url, { method:'POST', cache:'no-store' })
    .then(() => {
      hidePopup();
      const dash = document.getElementById('dashboard');
      dash.innerHTML = '';          
      expandCanvasLT();           
      saveDashboard();             
      location.replace('?dashboard=<?= urlencode($currentDashboard) ?>&r=' + Date.now()); // 4) recharge propre
    })
    .catch(() => {
      hidePopup();
      const dash = document.getElementById('dashboard');
      dash.innerHTML = '';
      expandCanvasLT();
      saveDashboard();
      location.replace('?dashboard=<?= urlencode($currentDashboard) ?>&r=' + Date.now());
    });
}
function hidePopup(){document.getElementById('confirmPopup').style.display='none';}
window.addEventListener('DOMContentLoaded',()=>{loadDash("<?= addslashes($currentDashboard) ?>");});
function loadDash(name){
  fetch('users/profiles/<?= addslashes($userEmail) ?>/'+encodeURIComponent(name)+'.json', { cache: 'no-store' })
    .then(r=>r.json())
    .then(mods=>{
      const dash=document.getElementById('dashboard');
      dash.innerHTML='';
      (mods||[]).forEach(d=>{
        const m=document.createElement('div');
        m.className=`module ${d.shape||'square'}`; m.dataset.id=d.id;
        Object.assign(m.style,{left:d.x+'px',top:d.y+'px',width:d.width+'px',height:d.height+'px'});
        m.innerHTML=`<img class="mod-icon" src="modules/${d.id}/modicone.png" onerror="this.style.display='none'">
          <div class="module-header">
            <span class="module-title">${d.title}</span>
            <select class="shape-select" onchange="changeShape(this)">
              <option value="square"${d.shape==='square'?' selected':''}>Carré</option>
              <option value="rounded"${d.shape==='rounded'?' selected':''}>Arrondi</option>
            </select>
            <span class="module-close">&times;</span>
          </div>
          <div class="module-content">${d.content}</div>
          <div class="resize-handle"></div>`;
        dash.appendChild(m);
        enableInteract(m);
        loadModuleContent(m, d.id);
      });
      expandCanvasLT();
    });
}
function createDash(){
  const n=prompt("Nom du nouveau tableau :"); if(!n) return;
  fetch('users/create_dashboard.php',{
    method:'POST', headers:{'Content-Type':'application/json'},
    body:JSON.stringify({name:n})
  }).then(()=>location.href='?dashboard='+encodeURIComponent(n));
}
function renameDash(){
  const n=prompt("Nouveau nom :", "<?= addslashes($currentDashboard) ?>"); if(!n) return;
  fetch('users/rename_dashboard.php',{
    method:'POST', headers:{'Content-Type':'application/json'},
    body:JSON.stringify({old:"<?= addslashes($currentDashboard) ?>",name:n})
  }).then(()=>location.href='?dashboard='+encodeURIComponent(n));
}
function deleteDash(){
  if(!confirm("Supprimer ce tableau ?")) return;
  fetch('users/delete_dashboard.php',{
    method:'POST', headers:{'Content-Type':'application/json'},
    body:JSON.stringify({name:"<?= addslashes($currentDashboard) ?>"})
  }).then(()=>location.href='?dashboard=<?= urlencode($dashboards[0]) ?>');
}
</script>
<script>
(function(){
  const dash = document.getElementById('dashboard');
  if(!dash) return;
  const root = document.documentElement;
  function alignTopbar(){
    const r = dash.getBoundingClientRect();   
    root.style.setProperty('--topbar-left',  r.left + 'px');
    root.style.setProperty('--topbar-width', r.width + 'px');
  }
  alignTopbar();
  window.addEventListener('resize', alignTopbar);
  window.addEventListener('scroll',  alignTopbar, {passive:true}); 
  new ResizeObserver(alignTopbar).observe(dash); 
})();
</script>
</body>
</html>
