<?php
session_start();

if (empty($_SESSION['user']['email'])) {
    header('Location: login.php');
    exit;
}

$email   = $_SESSION['user']['email'];
$userDir = __DIR__ . "/users/profiles/$email";

if (!is_dir($userDir)) {
    @mkdir($userDir, 0775, true);
}

function json_read(string $file, $fallback) {
    if (!is_file($file)) {
        return $fallback;
    }

    $raw = file_get_contents($file);
    $data = json_decode($raw, true);

    return (json_last_error() === JSON_ERROR_NONE) ? $data : $fallback;
}

function json_write(string $file, $data): void {
    file_put_contents(
        $file,
        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
    );
}

function sanitize_name(string $s): string {
    $s = preg_replace('/[^a-zA-Z0-9_-]/', '_', $s);
    return $s === '' ? 'dashboard' : $s;
}

/* ==========================================================
   Thème utilisateur
   Source : users/profiles/[email]/theme.json
   CSS chargé : theme/[theme]/style.css
   ========================================================== */

$theme = 'default';

$themeJson = $userDir . "/theme.json";

if (is_file($themeJson)) {
    $themeData = json_read($themeJson, []);

    if (
        !empty($themeData['theme']) &&
        is_file(__DIR__ . "/theme/" . basename($themeData['theme']) . "/style.css")
    ) {
        $theme = basename($themeData['theme']);
    }
} else {
    $profileFile = $userDir . "/profile.json";

    if (is_file($profileFile)) {
        $profileData = json_read($profileFile, []);

        if (
            !empty($profileData['theme']) &&
            is_file(__DIR__ . "/theme/" . basename($profileData['theme']) . "/style.css")
        ) {
            $theme = basename($profileData['theme']);
        }
    }
}

/* ==========================================================
   Dashboards utilisateur
   ========================================================== */

$listFile = "$userDir/dashboards.json";

if (!file_exists($listFile)) {
    json_write($listFile, ['dashboard']);
}

$dashboards = json_read($listFile, ['dashboard']);
$dashboards = array_values(array_unique(array_map('sanitize_name', (array)$dashboards)));

if (!$dashboards) {
    $dashboards = ['dashboard'];
    json_write($listFile, $dashboards);
}

$requested = isset($_GET['dashboard']) ? sanitize_name($_GET['dashboard']) : $dashboards[0];
$currentDashboard = in_array($requested, $dashboards, true) ? $requested : $dashboards[0];

$dashboardFile = "$userDir/$currentDashboard.json";

if (!file_exists($dashboardFile)) {
    json_write($dashboardFile, []);
}

/* ==========================================================
   Modules disponibles sur le dashboard
   ========================================================== */

$availableModules = [];
$modulesUserFile = "$userDir/modules.json";

$hiddenDashboardModules = [
    'savev.1'
];

if (is_file($modulesUserFile)) {
    $enabledModules = json_read($modulesUserFile, []);

    foreach ((array)$enabledModules as $m) {
        $mid = trim((string)($m['id'] ?? ''));

        if (empty($m['enabled']) || $mid === '' || empty($m['name'])) {
            continue;
        }

        if (in_array($mid, $hiddenDashboardModules, true)) {
            continue;
        }

        $dashboardValue = $m['dashboard'] ?? true;

        if (
            $dashboardValue === false ||
            $dashboardValue === 0 ||
            $dashboardValue === '0' ||
            strtolower((string)$dashboardValue) === 'false' ||
            strtolower((string)$dashboardValue) === 'no'
        ) {
            continue;
        }

        $availableModules[$mid] = $m['name'];
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=0.8">

    <title>Bureau Numérique</title>

    <!-- CSS du thème choisi par l'utilisateur -->
    <link rel="stylesheet" href="theme/<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>/style.css">

    <script src="https://cdn.jsdelivr.net/npm/interactjs/dist/interact.min.js"></script>
</head>

<body>
<div class="wrapper">

    <?php include 'header.php'; ?>

    <main>
        <div id="controls">
            <select id="dashSelect" onchange="location.href='?dashboard=' + encodeURIComponent(this.value)">
                <?php foreach ($dashboards as $d): ?>
                    <option value="<?= htmlspecialchars($d, ENT_QUOTES, 'UTF-8') ?>" <?= $d === $currentDashboard ? 'selected' : '' ?>>
                        <?= htmlspecialchars($d, ENT_QUOTES, 'UTF-8') ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button class="add" type="button" onclick="createDash()">➕</button>
            <button class="rename" type="button" onclick="renameDash()">✏️</button>
            <button class="delete" type="button" onclick="deleteDash()">🗑️</button>

            <select id="addModuleSelect">
                <option value="">-- Ajouter un module --</option>
                <?php foreach ($availableModules as $id => $name): ?>
                    <option value="<?= htmlspecialchars($id, ENT_QUOTES, 'UTF-8') ?>">
                        <?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button id="resetBtn" type="button">Réinitialiser</button>
        </div>

        <div class="popup" id="confirmPopup">
            <p>Confirmer la réinitialisation ?</p>
            <button type="button" onclick="confirmReset()">Oui</button>
            <button type="button" onclick="hidePopup()">Non</button>
        </div>

        <div id="dashboard"></div>
    </main>
</div>

<script>
const currentDashboard = <?= json_encode($currentDashboard, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const currentUserEmail = <?= json_encode($email, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const dashboardAllowedModules = <?= json_encode(array_keys($availableModules), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;

function expandCanvasLT() {
    const ws = document.getElementById('dashboard');
    const mods = ws.querySelectorAll('.module');

    if (mods.length === 0) {
        ws.classList.add('empty');
        document.body.classList.add('noscroll');

        ws.style.minWidth  = '';
        ws.style.minHeight = '';
        ws.style.width     = '';
        ws.style.height    = '';

        ws.scrollTo(0, 0);
        return;
    }

    ws.classList.remove('empty');
    document.body.classList.remove('noscroll');

    let maxRight = 0;
    let maxBottom = 0;

    mods.forEach(el => {
        const left   = parseFloat(el.style.left) || 0;
        const top    = parseFloat(el.style.top) || 0;
        const right  = left + el.offsetWidth;
        const bottom = top + el.offsetHeight;

        if (right > maxRight) {
            maxRight = right;
        }

        if (bottom > maxBottom) {
            maxBottom = bottom;
        }
    });

    const pad = 24;

    ws.style.minWidth  = (maxRight + pad) + 'px';
    ws.style.minHeight = (maxBottom + pad) + 'px';
}

function changeShape(sel) {
    const m = sel.closest('.module');

    if (!m) {
        return;
    }

    m.classList.remove('square', 'rounded', 'circle');
    m.classList.add(sel.value);

    saveDashboard();
}

function enableInteract(el) {
    interact(el)
        .draggable({
            allowFrom: '.module-header',
            listeners: {
                move(e) {
                    const t = e.target;

                    const x = (parseFloat(t.style.left) || 0) + e.dx;
                    const y = (parseFloat(t.style.top) || 0) + e.dy;

                    t.style.left = x + 'px';
                    t.style.top  = y + 'px';

                    expandCanvasLT();
                    saveDashboard();
                }
            }
        })
        .resizable({
            edges: {
                left: true,
                right: true,
                bottom: true,
                top: true
            },
            listeners: {
                move(e) {
                    const t = e.target;

                    const x = parseFloat(t.style.left) || 0;
                    const y = parseFloat(t.style.top) || 0;

                    t.style.width  = e.rect.width + 'px';
                    t.style.height = e.rect.height + 'px';
                    t.style.left   = (x + e.deltaRect.left) + 'px';
                    t.style.top    = (y + e.deltaRect.top) + 'px';

                    expandCanvasLT();
                    saveDashboard();
                }
            }
        });
}

function loadModuleContent(modEl, id) {
    fetch(`modules/${encodeURIComponent(id)}/${encodeURIComponent(id)}.php`, {
        cache: 'no-store'
    })
        .then(r => r.text())
        .then(html => {
            const container = modEl.querySelector('.module-content');

            if (!container) {
                return;
            }

            container.innerHTML = html;

            container.querySelectorAll('script').forEach(oldScript => {
                const s = document.createElement('script');

                if (oldScript.src) {
                    s.src = oldScript.src;
                } else {
                    s.textContent = oldScript.textContent;
                }

                container.appendChild(s);
            });
        })
        .catch(err => console.error(`[${id}]`, err));
}

function saveDashboard() {
    const mods = [...document.querySelectorAll('.module')].map(m => {
        const shape = m.classList.contains('rounded')
            ? 'rounded'
            : (m.classList.contains('circle') ? 'circle' : 'square');

        return {
            id: m.dataset.id,
            title: m.querySelector('.module-title')?.textContent || m.dataset.id,
            content: m.querySelector('.module-content')?.textContent || '',
            shape: shape,
            x: parseInt(m.style.left) || 0,
            y: parseInt(m.style.top) || 0,
            width: parseInt(m.style.width) || 200,
            height: parseInt(m.style.height) || 200
        };
    });

    fetch('users/save_dashboard.php?dashboard=' + encodeURIComponent(currentDashboard), {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(mods)
    });

    expandCanvasLT();
}

function closeModule(btn) {
    const m = btn.closest('.module');

    if (!m) {
        return;
    }

    m.remove();

    expandCanvasLT();
    saveDashboard();
}

document.addEventListener('click', e => {
    if (e.target.classList.contains('module-close')) {
        closeModule(e.target);
    }
});

document.getElementById('addModuleSelect').addEventListener('change', function () {
    const id = this.value;

    if (!id) {
        return;
    }

    const dash = document.getElementById('dashboard');
    const mod = document.createElement('div');

    mod.className = 'module square';
    mod.dataset.id = id;

    Object.assign(mod.style, {
        left: '250px',
        top: '280px',
        width: '280px',
        height: '280px'
    });

    mod.innerHTML = `
        <img class="mod-icon" src="modules/${id}/modicone.png" onerror="this.style.display='none'">

        <div class="module-header">
            <span class="module-title">${id}</span>

            <select class="shape-select" onchange="changeShape(this)">
                <option value="square">Carré</option>
                <option value="rounded">Arrondi</option>
                <option value="circle">Rond</option>
            </select>

            <span class="module-close">&times;</span>
        </div>

        <div class="module-content">Contenu du module ${id}</div>
        <div class="resize-handle"></div>
    `;

    dash.appendChild(mod);

    expandCanvasLT();
    enableInteract(mod);
    loadModuleContent(mod, id);
    saveDashboard();

    this.value = '';
});

document.getElementById('resetBtn').addEventListener('click', e => {
    const p = document.getElementById('confirmPopup');
    const r = e.target.getBoundingClientRect();

    p.style.display = 'block';
    p.style.top = (r.bottom + window.scrollY) + 'px';
    p.style.left = (r.left + window.scrollX) + 'px';
});

function confirmReset() {
    const url = 'users/reset_dashboard.php?dashboard=' + encodeURIComponent(currentDashboard);

    fetch(url, {
        method: 'POST',
        cache: 'no-store'
    })
        .then(() => {
            hidePopup();

            const dash = document.getElementById('dashboard');
            dash.innerHTML = '';

            expandCanvasLT();

            location.replace('?dashboard=' + encodeURIComponent(currentDashboard) + '&r=' + Date.now());
        })
        .catch(() => {
            hidePopup();

            const dash = document.getElementById('dashboard');
            dash.innerHTML = '';

            expandCanvasLT();

            location.replace('?dashboard=' + encodeURIComponent(currentDashboard) + '&r=' + Date.now());
        });
}

function hidePopup() {
    document.getElementById('confirmPopup').style.display = 'none';
}

function loadDash(name) {
    fetch(
        'users/profiles/' + encodeURIComponent(currentUserEmail) + '/' + encodeURIComponent(name) + '.json',
        {
            cache: 'no-store'
        }
    )
        .then(r => r.json())
        .then(mods => {
            const dash = document.getElementById('dashboard');
            dash.innerHTML = '';

            (mods || []).forEach(d => {
                if (!dashboardAllowedModules.includes(d.id)) {
                    return;
                }

                const m = document.createElement('div');

                m.className = `module ${d.shape || 'square'}`;
                m.dataset.id = d.id;

                Object.assign(m.style, {
                    left: (d.x || 0) + 'px',
                    top: (d.y || 0) + 'px',
                    width: (d.width || 280) + 'px',
                    height: (d.height || 280) + 'px'
                });

                m.innerHTML = `
                    <img class="mod-icon" src="modules/${d.id}/modicone.png" onerror="this.style.display='none'">

                    <div class="module-header">
                        <span class="module-title">${d.title || d.id}</span>

                        <select class="shape-select" onchange="changeShape(this)">
                            <option value="square"${d.shape === 'square' ? ' selected' : ''}>Carré</option>
                            <option value="rounded"${d.shape === 'rounded' ? ' selected' : ''}>Arrondi</option>
                            <option value="circle"${d.shape === 'circle' ? ' selected' : ''}>Rond</option>
                        </select>

                        <span class="module-close">&times;</span>
                    </div>

                    <div class="module-content">${d.content || ''}</div>
                    <div class="resize-handle"></div>
                `;

                dash.appendChild(m);

                enableInteract(m);
                loadModuleContent(m, d.id);
            });

            expandCanvasLT();
        })
        .catch(err => {
            console.error('Erreur chargement dashboard :', err);
            expandCanvasLT();
        });
}

function createDash() {
    const n = prompt('Nom du nouveau tableau :');

    if (!n) {
        return;
    }

    fetch('users/create_dashboard.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name: n })
    }).then(() => {
        location.href = '?dashboard=' + encodeURIComponent(n);
    });
}

function renameDash() {
    const n = prompt('Nouveau nom :', currentDashboard);

    if (!n) {
        return;
    }

    fetch('users/rename_dashboard.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            old: currentDashboard,
            name: n
        })
    }).then(() => {
        location.href = '?dashboard=' + encodeURIComponent(n);
    });
}

function deleteDash() {
    if (!confirm('Supprimer ce tableau ?')) {
        return;
    }

    fetch('users/delete_dashboard.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            name: currentDashboard
        })
    }).then(() => {
        location.href = '?dashboard=<?= urlencode($dashboards[0]) ?>';
    });
}

window.addEventListener('DOMContentLoaded', () => {
    loadDash(currentDashboard);
});
</script>

<script>
(function () {
    const dash = document.getElementById('dashboard');

    if (!dash) {
        return;
    }

    const root = document.documentElement;

    function alignTopbar() {
        const r = dash.getBoundingClientRect();

        root.style.setProperty('--topbar-left', r.left + 'px');
        root.style.setProperty('--topbar-width', r.width + 'px');
    }

    alignTopbar();

    window.addEventListener('resize', alignTopbar);
    window.addEventListener('scroll', alignTopbar, { passive: true });

    new ResizeObserver(alignTopbar).observe(dash);
})();
</script>

</body>
</html>