<?php
session_start();

if (!isset($_SESSION['user']['email'])) {
    header('Location: login.php');
    exit;
}

$currentEmail = $_SESSION['user']['email'];
$currentUserRole = $_SESSION['role_system'] ?? ($_SESSION['user']['role_system'] ?? 'user');
$isSystemAdmin = in_array($currentUserRole, ['admin', 'superadmin'], true);

$baseDir = __DIR__;
$profilesDir = $baseDir . '/users/profiles/';

$csrfToken = $_SESSION['members_csrf'] ?? bin2hex(random_bytes(32));
$_SESSION['members_csrf'] = $csrfToken;

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function safeUserFolderName($email) {
    $email = (string)$email;

    if (
        $email === '' ||
        strpos($email, '..') !== false ||
        strpos($email, '/') !== false ||
        strpos($email, '\\') !== false
    ) {
        return null;
    }

    return $email;
}

function readJsonFile($path, $fallback = []) {
    if (!is_file($path)) {
        return $fallback;
    }

    $raw = file_get_contents($path);

    if ($raw === false || trim($raw) === '') {
        return $fallback;
    }

    $data = json_decode($raw, true);

    return is_array($data) ? $data : $fallback;
}

function writeJsonFile($path, $data) {
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return file_put_contents($path, $json) !== false;
}

function countModules($modules) {
    $total = 0;
    $enabled = 0;
    $enabledList = [];

    if (!is_array($modules)) {
        return [
            'total' => 0,
            'enabled' => 0,
            'enabled_list' => []
        ];
    }

    foreach ($modules as $module) {
        if (!is_array($module)) {
            continue;
        }

        $total++;

        if (!empty($module['enabled'])) {
            $enabled++;
            $enabledList[] = [
                'id' => $module['id'] ?? '',
                'name' => $module['name'] ?? ($module['id'] ?? 'Module'),
                'description' => $module['description'] ?? ''
            ];
        }
    }

    return [
        'total' => $total,
        'enabled' => $enabled,
        'enabled_list' => $enabledList
    ];
}

function firstLetter($value) {
    $value = trim((string)$value);

    if ($value === '') {
        return '';
    }

    if (function_exists('mb_substr') && function_exists('mb_strtoupper')) {
        return mb_strtoupper(mb_substr($value, 0, 1));
    }

    return strtoupper(substr($value, 0, 1));
}

function userInitials($prenom, $nom, $email) {
    $letters = '';

    $letters .= firstLetter($prenom);
    $letters .= firstLetter($nom);

    if ($letters === '') {
        $letters = firstLetter($email);
    }

    return $letters;
}

function normalizeRolesMetier($rawRoles) {
    $roles = [];

    if (!is_array($rawRoles)) {
        return $roles;
    }

    foreach ($rawRoles as $key => $value) {
        if (is_string($value)) {
            $roles[] = $value;
        } elseif (is_array($value)) {
            if (!empty($value['name'])) {
                $roles[] = $value['name'];
            } elseif (!empty($value['label'])) {
                $roles[] = $value['label'];
            } elseif (is_string($key)) {
                $roles[] = $key;
            }
        } elseif (is_string($key)) {
            $roles[] = $key;
        }
    }

    $roles = array_values(array_unique(array_filter($roles)));
    sort($roles, SORT_NATURAL | SORT_FLAG_CASE);

    return $roles;
}

function formatCreatedAt($createdAt) {
    $createdAt = trim((string)$createdAt);

    if ($createdAt === '') {
        return 'Non renseignée';
    }

    $timestamp = strtotime($createdAt);

    if ($timestamp === false) {
        return $createdAt;
    }

    return date('d/m/Y à H:i', $timestamp);
}

/* ==========================================================
   Thème utilisateur
   Source : users/profiles/[email]/theme.json
   CSS chargé : theme/[theme]/style.css
   Fallback : theme/default/style.css
   ========================================================== */

$userDir = $profilesDir . $currentEmail . '/';
$themeJson = $userDir . 'theme.json';
$theme = 'default';

$themeData = readJsonFile($themeJson, []);

if (
    !empty($themeData['theme']) &&
    is_file($baseDir . '/theme/' . basename($themeData['theme']) . '/style.css')
) {
    $theme = basename($themeData['theme']);
} else {
    $profileThemeFile = $userDir . 'profile.json';
    $profileThemeData = readJsonFile($profileThemeFile, []);

    if (
        !empty($profileThemeData['theme']) &&
        is_file($baseDir . '/theme/' . basename($profileThemeData['theme']) . '/style.css')
    ) {
        $theme = basename($profileThemeData['theme']);
    }
}

/* ==========================================================
   Rôles métier dynamiques
   ========================================================== */

$rolesMetierPath = $baseDir . '/data/roles_metier.json';
$rolesMetier = normalizeRolesMetier(readJsonFile($rolesMetierPath, []));

$roleSystemOptions = ['user', 'admin', 'superadmin'];

/* ==========================================================
   Sauvegarde admin utilisateur
   ========================================================== */

$saveMessage = '';
$saveError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['members_action'] ?? '') === 'update_user') {
    if (!$isSystemAdmin) {
        $saveError = 'Action refusée.';
    } elseif (!hash_equals($csrfToken, $_POST['csrf_token'] ?? '')) {
        $saveError = 'Session expirée, veuillez réessayer.';
    } else {
        $targetEmail = safeUserFolderName($_POST['target_email'] ?? '');

        if ($targetEmail === null) {
            $saveError = 'Utilisateur invalide.';
        } else {
            $targetDir = $profilesDir . $targetEmail . '/';
            $profilePath = $targetDir . 'profile.json';

            if (!is_file($profilePath)) {
                $saveError = 'Profil introuvable.';
            } else {
                $profile = readJsonFile($profilePath, []);

                $newPrenom = trim((string)($_POST['prenom'] ?? ''));
                $newNom = trim((string)($_POST['nom'] ?? ''));
                $newRoleSystem = trim((string)($_POST['role_system'] ?? 'user'));
                $newRoleMetier = trim((string)($_POST['role_metier'] ?? ''));

                if (!in_array($newRoleSystem, $roleSystemOptions, true)) {
                    $newRoleSystem = $profile['role_system'] ?? 'user';
                }

                $profile['prenom'] = $newPrenom;
                $profile['nom'] = $newNom;
                $profile['role_system'] = $newRoleSystem;
                $profile['role_metier'] = $newRoleMetier;

                if (empty($profile['email'])) {
                    $profile['email'] = $targetEmail;
                }

                if (writeJsonFile($profilePath, $profile)) {
                    header('Location: members.php?saved=1');
                    exit;
                }

                $saveError = 'Impossible de sauvegarder le profil.';
            }
        }
    }
}

if (isset($_GET['saved'])) {
    $saveMessage = 'Utilisateur mis à jour.';
}

/* ==========================================================
   Lecture des membres
   ========================================================== */

$members = [];

if (is_dir($profilesDir)) {
    foreach (scandir($profilesDir) as $folder) {
        if ($folder === '.' || $folder === '..') {
            continue;
        }

        $safeFolder = safeUserFolderName($folder);

        if ($safeFolder === null) {
            continue;
        }

        $memberDir = $profilesDir . $safeFolder . '/';
        $profilePath = $memberDir . 'profile.json';

        if (!is_file($profilePath)) {
            continue;
        }

        $profile = readJsonFile($profilePath, []);

        if (empty($profile)) {
            continue;
        }

        $modulesData = readJsonFile($memberDir . 'modules.json', []);
        $moduleCounts = countModules($modulesData);

        $prenom = $profile['prenom'] ?? '';
        $nom = $profile['nom'] ?? '';
        $email = $profile['email'] ?? $safeFolder;
        $avatarExists = is_file($memberDir . 'avatar.png');
        $createdAt = $profile['created_at'] ?? '';

        $members[] = [
            'folder' => $safeFolder,
            'email' => $email,
            'prenom' => $prenom,
            'nom' => $nom,
            'display_name' => trim($prenom . ' ' . $nom) ?: $email,
            'role_system' => $profile['role_system'] ?? 'user',
            'role_metier' => $profile['role_metier'] ?? '',
            'created_at' => $createdAt,
            'created_at_label' => formatCreatedAt($createdAt),
            'modules_enabled' => $moduleCounts['enabled'],
            'modules_total' => $moduleCounts['total'],
            'enabled_modules' => $moduleCounts['enabled_list'],
            'avatar_exists' => $avatarExists,
            'avatar_src' => $avatarExists ? 'users/profiles/' . rawurlencode($safeFolder) . '/avatar.png?t=' . time() : '',
            'initials' => userInitials($prenom, $nom, $email),
        ];
    }
}

usort($members, function ($a, $b) {
    return strcasecmp($a['display_name'], $b['display_name']);
});

$membersJson = json_encode($members, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$rolesMetierJson = json_encode($rolesMetier, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$roleSystemOptionsJson = json_encode($roleSystemOptions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Membres</title>

    <link rel="stylesheet" href="theme/<?= e($theme) ?>/style.css">
</head>

<body>

<?php include 'header.php'; ?>

<main class="members-page">
    <div class="members-head">
        <div class="members-title-block">
            <h1>Membres</h1>
            <p>Vue rapide des utilisateurs, rôles, modules et date de création.</p>
        </div>

        <div class="members-count">
            <span id="membersVisibleCount"><?= count($members) ?></span> / <?= count($members) ?> membre<?= count($members) > 1 ? 's' : '' ?>
        </div>
    </div>

    <?php if ($saveMessage !== ''): ?>
        <div class="members-alert"><?= e($saveMessage) ?></div>
    <?php endif; ?>

    <?php if ($saveError !== ''): ?>
        <div class="members-alert error"><?= e($saveError) ?></div>
    <?php endif; ?>

    <?php if (!empty($members)): ?>
        <section class="members-toolbar">
            <input
                type="search"
                class="members-search"
                id="membersSearch"
                placeholder="Rechercher un membre, un e-mail, un rôle..."
                autocomplete="off"
            >

            <div class="members-filters" aria-label="Filtres membres">
                <button type="button" class="members-filter active" data-filter="all">Tous</button>
                <button type="button" class="members-filter" data-filter="admin">Admins</button>
                <button type="button" class="members-filter" data-filter="superadmin">Superadmins</button>
                <button type="button" class="members-filter" data-filter="user">Utilisateurs</button>
                <button type="button" class="members-filter" data-filter="with_modules">Avec modules</button>
                <button type="button" class="members-filter" data-filter="without_modules">Sans module</button>
            </div>
        </section>

        <section class="members-grid" aria-label="Liste des membres" id="membersGrid">
            <?php foreach ($members as $member): ?>
                <?php
                    $searchText = strtolower(trim(
                        ($member['display_name'] ?? '') . ' ' .
                        ($member['email'] ?? '') . ' ' .
                        ($member['role_system'] ?? '') . ' ' .
                        ($member['role_metier'] ?? '') . ' ' .
                        ($member['created_at_label'] ?? '')
                    ));
                ?>

                <article
                    class="member-card"
                    data-member-card
                    data-search="<?= e($searchText) ?>"
                    data-role-system="<?= e($member['role_system']) ?>"
                    data-modules-enabled="<?= (int)$member['modules_enabled'] ?>"
                >
                    <button
                        type="button"
                        class="member-open"
                        data-open-member="<?= e($member['folder']) ?>"
                        aria-label="Voir la fiche de <?= e($member['display_name']) ?>"
                    ></button>

                    <?php if ($member['avatar_exists']): ?>
                        <img
                            class="member-avatar"
                            src="<?= e($member['avatar_src']) ?>"
                            alt="Avatar de <?= e($member['display_name']) ?>"
                        >
                    <?php else: ?>
                        <span class="member-avatar-fallback" aria-hidden="true">
                            <?= e($member['initials']) ?>
                        </span>
                    <?php endif; ?>

                    <span class="member-info">
                        <span class="member-name-row">
                            <strong class="member-name">
                                <?= e($member['display_name']) ?>
                            </strong>

                            <span class="member-role-system">
                                <?= e($member['role_system'] ?: 'user') ?>
                            </span>
                        </span>

                        <span class="member-email">
                            <?= e($member['email']) ?>
                        </span>

                        <span class="member-meta">
                            <span class="member-pill">
                                <?= e($member['role_metier'] ?: 'Aucun rôle métier') ?>
                            </span>

                            <span class="member-pill">
                                <?= (int)$member['modules_enabled'] ?> / <?= (int)$member['modules_total'] ?> modules
                            </span>

                            <span class="member-pill">
                                Créé le <?= e($member['created_at_label']) ?>
                            </span>
                        </span>
                    </span>

                    <?php if ($isSystemAdmin): ?>
                        <span class="member-card-actions">
                            <button
                                type="button"
                                class="member-action-btn"
                                data-edit-member="<?= e($member['folder']) ?>"
                                title="Modifier"
                            >
                                ✎
                            </button>
                        </span>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
        </section>

        <div class="members-no-result" id="membersNoResult">
            Aucun membre ne correspond à la recherche.
        </div>
    <?php else: ?>
        <div class="members-empty">
            Aucun membre trouvé.
        </div>
    <?php endif; ?>
</main>

<div class="member-modal-backdrop" id="memberModal" aria-hidden="true">
    <div class="member-modal" role="dialog" aria-modal="true" aria-labelledby="memberModalTitle">
        <div class="member-modal-head">
            <h2 class="member-modal-title" id="memberModalTitle">Fiche utilisateur</h2>
            <button type="button" class="member-modal-close" data-close-member-modal>×</button>
        </div>

        <div class="member-modal-body">
            <section id="memberViewPanel">
                <div class="member-view-top">
                    <div id="memberViewAvatar"></div>

                    <div>
                        <h3 class="member-view-name" id="memberViewName"></h3>
                        <p class="member-view-email" id="memberViewEmail"></p>
                    </div>
                </div>

                <div class="member-detail-grid">
                    <div class="member-detail">
                        <span>Rôle système</span>
                        <strong id="memberViewRoleSystem"></strong>
                    </div>

                    <div class="member-detail">
                        <span>Rôle métier</span>
                        <strong id="memberViewRoleMetier"></strong>
                    </div>

                    <div class="member-detail">
                        <span>Modules activés</span>
                        <strong id="memberViewModulesCount"></strong>
                    </div>

                    <div class="member-detail">
                        <span>Date de création</span>
                        <strong id="memberViewCreatedAt"></strong>
                    </div>
                </div>

                <div>
                    <strong>Modules actifs</strong>
                    <div class="member-modules-list" id="memberViewModulesList"></div>
                </div>

                <div class="member-modal-actions">
                    <button type="button" class="member-modal-btn" id="memberCopyEmail">
                        Copier l’e-mail
                    </button>

                    <?php if ($isSystemAdmin): ?>
                        <button type="button" class="member-modal-btn" id="memberSwitchToEdit">
                            Modifier cet utilisateur
                        </button>
                    <?php endif; ?>

                    <button type="button" class="member-modal-btn" data-close-member-modal>
                        Fermer
                    </button>
                </div>

                <div class="member-copy-status" id="memberCopyStatus"></div>
            </section>

            <?php if ($isSystemAdmin): ?>
                <section id="memberEditPanel" class="member-hidden">
                    <form class="member-form" method="post" action="members.php">
                        <input type="hidden" name="members_action" value="update_user">
                        <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
                        <input type="hidden" name="target_email" id="editTargetEmail" value="">

                        <div class="member-form-note">
                            Modification directe du fichier <strong>profile.json</strong>.
                            L’adresse e-mail n’est pas modifiée ici pour ne pas casser le dossier utilisateur.
                        </div>

                        <div class="member-form-row">
                            <label for="editEmailReadonly">Email / dossier utilisateur</label>
                            <input type="text" id="editEmailReadonly" value="" readonly>
                        </div>

                        <div class="member-form-row">
                            <label for="editPrenom">Prénom</label>
                            <input type="text" name="prenom" id="editPrenom" value="">
                        </div>

                        <div class="member-form-row">
                            <label for="editNom">Nom</label>
                            <input type="text" name="nom" id="editNom" value="">
                        </div>

                        <div class="member-form-row">
                            <label for="editRoleSystem">Rôle système</label>
                            <select name="role_system" id="editRoleSystem"></select>
                        </div>

                        <div class="member-form-row">
                            <label for="editRoleMetier">Rôle métier</label>
                            <select name="role_metier" id="editRoleMetier"></select>
                        </div>

                        <div class="member-modal-actions">
                            <button type="button" class="member-modal-btn" id="memberBackToView">
                                Retour à la fiche
                            </button>

                            <button type="submit" class="member-modal-btn">
                                Enregistrer
                            </button>
                        </div>
                    </form>
                </section>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
(function () {
    const members = <?= $membersJson ?: '[]' ?>;
    const rolesMetier = <?= $rolesMetierJson ?: '[]' ?>;
    const roleSystemOptions = <?= $roleSystemOptionsJson ?: '[]' ?>;
    const isSystemAdmin = <?= $isSystemAdmin ? 'true' : 'false' ?>;

    const membersByFolder = {};

    members.forEach(member => {
        membersByFolder[member.folder] = member;
    });

    const modal = document.getElementById('memberModal');
    const viewPanel = document.getElementById('memberViewPanel');
    const editPanel = document.getElementById('memberEditPanel');

    const title = document.getElementById('memberModalTitle');
    const avatar = document.getElementById('memberViewAvatar');
    const viewName = document.getElementById('memberViewName');
    const viewEmail = document.getElementById('memberViewEmail');
    const viewRoleSystem = document.getElementById('memberViewRoleSystem');
    const viewRoleMetier = document.getElementById('memberViewRoleMetier');
    const viewModulesCount = document.getElementById('memberViewModulesCount');
    const viewCreatedAt = document.getElementById('memberViewCreatedAt');
    const viewModulesList = document.getElementById('memberViewModulesList');

    const switchToEditBtn = document.getElementById('memberSwitchToEdit');
    const backToViewBtn = document.getElementById('memberBackToView');
    const copyEmailBtn = document.getElementById('memberCopyEmail');
    const copyStatus = document.getElementById('memberCopyStatus');

    const searchInput = document.getElementById('membersSearch');
    const filterButtons = document.querySelectorAll('.members-filter');
    const cards = document.querySelectorAll('[data-member-card]');
    const noResult = document.getElementById('membersNoResult');
    const visibleCount = document.getElementById('membersVisibleCount');

    let currentMember = null;
    let currentFilter = 'all';

    function escapeHtml(value) {
        return String(value ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#039;');
    }

    function normalize(value) {
        return String(value || '')
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .trim();
    }

    function openModal() {
        modal.classList.add('active');
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('noscroll');
    }

    function closeModal() {
        modal.classList.remove('active');
        modal.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('noscroll');

        currentMember = null;

        if (copyStatus) {
            copyStatus.textContent = '';
        }
    }

    function showViewPanel() {
        if (viewPanel) {
            viewPanel.classList.remove('member-hidden');
        }

        if (editPanel) {
            editPanel.classList.add('member-hidden');
        }

        title.textContent = 'Fiche utilisateur';
    }

    function showEditPanel() {
        if (!isSystemAdmin || !currentMember || !editPanel) {
            return;
        }

        fillEditForm(currentMember);

        viewPanel.classList.add('member-hidden');
        editPanel.classList.remove('member-hidden');
        title.textContent = 'Modifier utilisateur';
    }

    function fillView(member) {
        currentMember = member;

        if (copyStatus) {
            copyStatus.textContent = '';
        }

        title.textContent = 'Fiche utilisateur';
        viewName.textContent = member.display_name || member.email || member.folder;
        viewEmail.textContent = member.email || member.folder;
        viewRoleSystem.textContent = member.role_system || 'user';
        viewRoleMetier.textContent = member.role_metier || 'Aucun rôle métier';
        viewModulesCount.textContent = `${member.modules_enabled || 0} / ${member.modules_total || 0}`;
        viewCreatedAt.textContent = member.created_at_label || 'Non renseignée';

        if (member.avatar_exists && member.avatar_src) {
            avatar.innerHTML = `<img class="member-view-avatar" src="${escapeHtml(member.avatar_src)}" alt="Avatar">`;
        } else {
            avatar.innerHTML = `<div class="member-view-avatar-fallback">${escapeHtml(member.initials || '?')}</div>`;
        }

        const enabledModules = Array.isArray(member.enabled_modules) ? member.enabled_modules : [];

        if (enabledModules.length > 0) {
            viewModulesList.innerHTML = enabledModules.map(module => {
                return `<div class="member-module-item">${escapeHtml(module.name || module.id || 'Module')}</div>`;
            }).join('');
        } else {
            viewModulesList.innerHTML = `<div class="member-module-item">Aucun module activé</div>`;
        }
    }

    function fillEditForm(member) {
        const editTargetEmail = document.getElementById('editTargetEmail');
        const editEmailReadonly = document.getElementById('editEmailReadonly');
        const editPrenom = document.getElementById('editPrenom');
        const editNom = document.getElementById('editNom');
        const editRoleSystem = document.getElementById('editRoleSystem');
        const editRoleMetier = document.getElementById('editRoleMetier');

        if (!editTargetEmail || !editEmailReadonly || !editPrenom || !editNom || !editRoleSystem || !editRoleMetier) {
            return;
        }

        editTargetEmail.value = member.folder || '';
        editEmailReadonly.value = member.email || member.folder || '';
        editPrenom.value = member.prenom || '';
        editNom.value = member.nom || '';

        const currentRoleSystem = member.role_system || 'user';
        const systemRoles = [...roleSystemOptions];

        if (!systemRoles.includes(currentRoleSystem)) {
            systemRoles.push(currentRoleSystem);
        }

        editRoleSystem.innerHTML = systemRoles.map(role => {
            const selected = role === currentRoleSystem ? 'selected' : '';
            return `<option value="${escapeHtml(role)}" ${selected}>${escapeHtml(role)}</option>`;
        }).join('');

        const currentRoleMetier = member.role_metier || '';
        const metierRoles = [''];

        rolesMetier.forEach(role => {
            if (role && !metierRoles.includes(role)) {
                metierRoles.push(role);
            }
        });

        if (currentRoleMetier && !metierRoles.includes(currentRoleMetier)) {
            metierRoles.push(currentRoleMetier);
        }

        editRoleMetier.innerHTML = metierRoles.map(role => {
            const selected = role === currentRoleMetier ? 'selected' : '';
            const label = role === '' ? 'Aucun rôle métier' : role;
            return `<option value="${escapeHtml(role)}" ${selected}>${escapeHtml(label)}</option>`;
        }).join('');
    }

    function openMember(folder, mode) {
        const member = membersByFolder[folder];

        if (!member) {
            return;
        }

        fillView(member);
        openModal();

        if (mode === 'edit') {
            showEditPanel();
        } else {
            showViewPanel();
        }
    }

    function applyFilters() {
        const query = normalize(searchInput ? searchInput.value : '');
        let shown = 0;

        cards.forEach(card => {
            const searchText = normalize(card.dataset.search || '');
            const roleSystem = card.dataset.roleSystem || 'user';
            const modulesEnabled = parseInt(card.dataset.modulesEnabled || '0', 10);

            let filterOk = true;

            if (currentFilter === 'admin') {
                filterOk = roleSystem === 'admin';
            } else if (currentFilter === 'superadmin') {
                filterOk = roleSystem === 'superadmin';
            } else if (currentFilter === 'user') {
                filterOk = roleSystem === 'user';
            } else if (currentFilter === 'with_modules') {
                filterOk = modulesEnabled > 0;
            } else if (currentFilter === 'without_modules') {
                filterOk = modulesEnabled <= 0;
            }

            const searchOk = query === '' || searchText.includes(query);

            if (filterOk && searchOk) {
                card.classList.remove('is-hidden');
                shown++;
            } else {
                card.classList.add('is-hidden');
            }
        });

        if (visibleCount) {
            visibleCount.textContent = shown;
        }

        if (noResult) {
            noResult.classList.toggle('active', shown === 0);
        }
    }

    function fallbackCopyText(text) {
        const textarea = document.createElement('textarea');

        textarea.value = text;
        textarea.setAttribute('readonly', 'readonly');
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';

        document.body.appendChild(textarea);
        textarea.select();

        let success = false;

        try {
            success = document.execCommand('copy');
        } catch (error) {
            success = false;
        }

        document.body.removeChild(textarea);

        return success;
    }

    async function copyCurrentEmail() {
        if (!currentMember || !currentMember.email) {
            return;
        }

        const email = currentMember.email;
        let copied = false;

        if (navigator.clipboard && window.isSecureContext) {
            try {
                await navigator.clipboard.writeText(email);
                copied = true;
            } catch (error) {
                copied = false;
            }
        }

        if (!copied) {
            copied = fallbackCopyText(email);
        }

        if (copyStatus) {
            copyStatus.textContent = copied ? 'E-mail copié.' : 'Impossible de copier automatiquement.';
        }
    }

    document.querySelectorAll('[data-open-member]').forEach(button => {
        button.addEventListener('click', function () {
            openMember(this.dataset.openMember, 'view');
        });
    });

    document.querySelectorAll('[data-edit-member]').forEach(button => {
        button.addEventListener('click', function (event) {
            event.preventDefault();
            event.stopPropagation();
            openMember(this.dataset.editMember, 'edit');
        });
    });

    document.querySelectorAll('[data-close-member-modal]').forEach(button => {
        button.addEventListener('click', closeModal);
    });

    modal.addEventListener('click', function (event) {
        if (event.target === modal) {
            closeModal();
        }
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && modal.classList.contains('active')) {
            closeModal();
        }
    });

    if (switchToEditBtn) {
        switchToEditBtn.addEventListener('click', showEditPanel);
    }

    if (backToViewBtn) {
        backToViewBtn.addEventListener('click', showViewPanel);
    }

    if (copyEmailBtn) {
        copyEmailBtn.addEventListener('click', copyCurrentEmail);
    }

    if (searchInput) {
        searchInput.addEventListener('input', applyFilters);
    }

    filterButtons.forEach(button => {
        button.addEventListener('click', function () {
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            currentFilter = this.dataset.filter || 'all';
            applyFilters();
        });
    });

    applyFilters();
})();
</script>

</body>
</html>