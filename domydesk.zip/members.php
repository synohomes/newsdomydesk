<?php
session_start();
if (!isset($_SESSION['user']['email'])) {
    header('Location: login.php');
    exit;
}
$currentUserRole = $_SESSION['role_system'] ?? 'guest';
$profilesDir = __DIR__ . '/users/profiles/';
$members = [];
if (is_dir($profilesDir)) {
    foreach (scandir($profilesDir) as $dir) {
        if ($dir === '.' || $dir === '..') continue;
        $profilePath = $profilesDir . $dir . '/profile.json';
        if (file_exists($profilePath)) {
            $data = json_decode(file_get_contents($profilePath), true);
            if (is_array($data)) {
                $members[] = [
                    'prenom'      => $data['prenom']      ?? '',
                    'nom'         => $data['nom']         ?? '',
                    'role_system' => $data['role_system'] ?? '',
                    'role_metier' => $data['role_metier'] ?? '',
                    'email'       => $dir,
                ];
            }
        }
    }
}
$email     = $_SESSION['user']['email'];
$userDir   = __DIR__ . '/users/profiles/' . $email . '/';
$themeJson = $userDir . 'theme.json';
$theme     = 'default';
if (file_exists($themeJson)) {
    $themeData = json_decode(file_get_contents($themeJson), true);
    if (!empty($themeData['theme']) && file_exists(__DIR__ . "/theme/" . $themeData['theme'] . "/style.css")) {
        $theme = basename($themeData['theme']);
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <title>Membres</title>
    <link rel="stylesheet" href="theme/<?php echo htmlspecialchars($theme, ENT_QUOTES); ?>/style.css">
    <style>
        .members-scope { --accent: currentColor; }
        .members-scope .section {
            max-width: 1100px;
            margin: 24px auto;
        }
        .members-scope h1 {
            margin: 0 0 12px 0;
            font-size: 1.8rem;
        }
        .members-scope .table-wrap {
            overflow: hidden; 
            border-radius: 12px;
            background: color-mix(in srgb, currentColor 6%, transparent);
            border: 1px solid var(--accent);
        }
        .members-scope table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }
        .members-scope thead th {
            text-align: left;
            padding: 12px 14px;
            font-weight: 700;
            background: color-mix(in srgb, currentColor 16%, transparent);
            color: inherit;
            border-bottom: 1px solid var(--accent);
            user-select: none;
        }
        .members-scope tbody td {
            padding: 10px 14px;
            vertical-align: middle;
            background: color-mix(in srgb, currentColor 8%, transparent);
        }
        .members-scope tbody tr + tr td {
            border-top: 1px solid var(--accent);
        }

        .members-scope tbody tr:hover td {
            background: color-mix(in srgb, currentColor 12%, transparent);
        }
        .members-scope td.actions {
            text-align: center;
            white-space: nowrap;
            font-size: 18px;
        }
        .members-scope td.actions a {
            text-decoration: none;
            margin: 0 6px;
            color: inherit;
            border: 1px solid color-mix(in srgb, var(--accent) 45%, transparent);
            border-radius: 10px;
            padding: 4px 8px;
            display: inline-block;
            background: color-mix(in srgb, var(--accent) 20%, transparent);
            transition: transform .12s ease, background .2s ease;
        }
        .members-scope td.actions a:hover {
            transform: translateY(-1px);
            background: color-mix(in srgb, var(--accent) 30%, transparent);
        }
        .members-scope .no-members {
            text-align: center;
            font-style: italic;
            padding: 16px 0 4px;
            opacity: .9;
        }
    </style>
</head>
<body>
<?php include 'header.php'; ?>
<div class="members-scope">
    <div class="section">
        <h1>Liste des membres</h1>
        <div class="table-wrap">
        <?php if (count($members) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Prénom</th>
                        <th>Nom</th>
                        <th>Rôle système</th>
                        <th>Rôle métier</th>
                        <th style="width: 180px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($members as $m): ?>
                    <tr>
                        <td><?= htmlspecialchars($m['prenom']) ?></td>
                        <td><?= htmlspecialchars($m['nom']) ?></td>
                        <td><?= htmlspecialchars($m['role_system']) ?></td>
                        <td><?= htmlspecialchars($m['role_metier']) ?></td>
                        <td class="actions">
                            <a href="profile_view.php?user=<?= urlencode($m['email']) ?>" title="Voir le profil">👁️</a>
                            <?php if ($currentUserRole === 'admin'): ?>
                                <a href="edit_profile.php?user=<?= urlencode($m['email']) ?>" title="Modifier le profil">✏️</a>
                                <a href="delete_profile.php?user=<?= urlencode($m['email']) ?>" title="Supprimer le profil" onclick="return confirm('Confirmer la suppression ?');">❌</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-members">Aucun membre.</div>
        <?php endif; ?>
        </div>
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function () {
  const scope = document.querySelector('.members-scope');
  const section = scope?.querySelector('.section');
  if (!scope || !section) return;
  const cs = getComputedStyle(section);
  const accent = cs.borderTopColor || cs.borderColor;
  if (accent) scope.style.setProperty('--accent', accent);
});
</script>
</body>
</html>
