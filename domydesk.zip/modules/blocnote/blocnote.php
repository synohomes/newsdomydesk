<?php
session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) exit;
$userDir = __DIR__ . "/../../users/profiles/{$email}";
$notesFile = $userDir . "/notes.json";
if (!file_exists($userDir)) mkdir($userDir, 0775, true);
if (!file_exists($notesFile)) file_put_contents($notesFile, json_encode([]));
$notes = json_decode(file_get_contents($notesFile), true) ?? [];
$cfgFile = $userDir . "/blocnote.json";
$cfg = file_exists($cfgFile) ? json_decode(file_get_contents($cfgFile), true) : ['max_notes' => 5];
$maxNotes = $cfg['max_notes'] ?? 5;
echo '<div class="module-content">';
echo '<div style="margin-bottom: 8px;">';
echo '<select id="noteSelect" style="padding:4px;">';
echo '<option value="">➕ Nouvelle note</option>';
foreach ($notes as $id => $note) {
    echo '<option value="' . htmlspecialchars($id) . '">' . htmlspecialchars($note['title']) . '</option>';
}
echo '</select>';
echo '</div>';
echo '<input type="text" id="noteTitle" placeholder="Titre" style="width:100%;margin-bottom:5px;padding:5px;" />';
echo '<textarea id="noteContent" placeholder="Contenu..." style="width:100%;height:120px;padding:5px;"></textarea>';
echo '<div style="text-align:right;margin-top:5px;">';
echo '<button onclick="saveNote()" style="padding:4px 8px;">💾 Enregistrer</button> ';
echo '<button onclick="deleteNote()" style="padding:4px 8px;">🗑️ Supprimer</button>';
echo '</div>';
echo '</div>';
?>
<script>
const notes = <?php echo json_encode($notes); ?>;
const select = document.getElementById("noteSelect");
const titleInput = document.getElementById("noteTitle");
const contentInput = document.getElementById("noteContent");
select.addEventListener("change", () => {
    const id = select.value;
    if (!id || !notes[id]) {
        titleInput.value = "";
        contentInput.value = "";
        return;
    }
    titleInput.value = notes[id].title || "";
    contentInput.value = notes[id].content || "";
});
function saveNote() {
    const title = titleInput.value.trim();
    const content = contentInput.value.trim();
    if (!title && !content) return alert("Note vide !");
    const id = select.value || Date.now().toString();
if (!select.value && Object.keys(notes).length >= <?= $maxNotes ?>) {
    alert("Nombre maximum de notes atteint (<?= $maxNotes ?>)");
    return;
}
    fetch("modules/blocnote/save_note.php", {
        method: "POST",
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ id, title, content })
    }).then(() => location.reload());
}
function deleteNote() {
    const id = select.value;
    if (!id) return alert("Aucune note sélectionnée");
    if (!confirm("Supprimer cette note ?")) return;
    fetch("modules/blocnote/delete_note.php", {
        method: "POST",
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ id })
    }).then(() => location.reload());
}
</script>
