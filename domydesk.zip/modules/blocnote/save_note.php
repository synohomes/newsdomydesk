<?php
session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) exit;
$data = json_decode(file_get_contents("php://input"), true);
$id = $data['id'] ?? '';
$title = trim($data['title'] ?? '');
$content = trim($data['content'] ?? '');
if (!$id) exit;
$file = __DIR__ . "/../../users/profiles/{$email}/notes.json";
$notes = file_exists($file) ? json_decode(file_get_contents($file), true) : [];
$notes[$id] = ['title' => $title, 'content' => $content];
file_put_contents($file, json_encode($notes, JSON_PRETTY_PRINT));
