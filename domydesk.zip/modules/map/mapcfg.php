<?php
/* modules/map/mapcfg.php — config avec adresse + géocodage OSM/Nominatim */
if (session_status()===PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { echo "⛔ Non connecté"; return; }

$userCfg = __DIR__ . "/../../users/profiles/$email/map.json";
@mkdir(dirname($userCfg), 0775, true);
$cfg = file_exists($userCfg) ? (json_decode(@file_get_contents($userCfg), true) ?: []) : [];

/* --- util --- */
function writeCfg($file, $arr){
  file_put_contents($file, json_encode($arr, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
}
function geocode_nominatim($query){
  // Nominatim demande un User-Agent explicite
  $url = "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=5&q=" . rawurlencode($query);
  $ua  = "DoMyDesk-MapConfig/1.0 (+https://domydesk.local)";

  // cURL si dispo
  if (function_exists('curl_init')) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_CONNECTTIMEOUT => 10,
      CURLOPT_TIMEOUT => 20,
      CURLOPT_USERAGENT => $ua,
      CURLOPT_HTTPHEADER => ['Accept: application/json']
    ]);
    $data = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $err  = curl_error($ch);
    curl_close($ch);
    if ($data === false || $code < 200 || $code >= 300) {
      return [null, "Géocodage indisponible (HTTP $code) $err"];
    }
  } else {
    // fallback file_get_contents
    $ctx = stream_context_create([
      'http' => [
        'method' => 'GET',
        'header' => "User-Agent: $ua\r\nAccept: application/json\r\n",
        'timeout' => 20
      ]
    ]);
    $data = @file_get_contents($url, false, $ctx);
    if ($data === false) return [null, "Géocodage indisponible (réseau/CSP serveur)."];
  }

  $json = json_decode($data, true);
  if (!is_array($json) || !count($json)) return [null, "Aucun résultat pour cette adresse."];
  return [$json, null];
}

$msg = ''; $err = '';

/* --- POST --- */
if ($_SERVER['REQUEST_METHOD']==='POST'){
  // sauvegarde manuelle lat/lng/zoom
  if (isset($_POST['save'])){
    $cfg['address'] = trim($_POST['address'] ?? '');
    $cfg['lat']  = floatval($_POST['lat'] ?? 0);
    $cfg['lng']  = floatval($_POST['lng'] ?? 0);
    $cfg['zoom'] = max(1, min(19, intval($_POST['zoom'] ?? 12)));
    writeCfg($userCfg, $cfg);
    $msg = "✅ Config enregistrée";
  }

  // géocoder l’adresse
  if (isset($_POST['geocode'])){
    $addr = trim($_POST['address'] ?? '');
    if ($addr === ''){
      $err = "Saisis une adresse avant de géocoder.";
    } else {
      [$res, $e] = geocode_nominatim($addr);
      if ($e){ $err = $e; }
      else {
        // on prend le 1er résultat
        $best = $res[0];
        $cfg['address'] = $addr;
        $cfg['lat']  = isset($best['lat']) ? floatval($best['lat']) : ($cfg['lat'] ?? 48.8566);
        $cfg['lng']  = isset($best['lon']) ? floatval($best['lon']) : ($cfg['lng'] ?? 2.3522);
        // zoom par défaut “rue”
        if (!isset($cfg['zoom']) || intval($cfg['zoom']) < 14) $cfg['zoom'] = 16;
        writeCfg($userCfg, $cfg);
        $disp = $best['display_name'] ?? $addr;
        $msg = "✅ Adresse trouvée : <em>" . htmlspecialchars($disp, ENT_QUOTES,'UTF-8') . "</em>";
      }
    }
  }
}

/* --- valeurs par défaut affichage --- */
$lat  = $cfg['lat']  ?? 48.8566;
$lng  = $cfg['lng']  ?? 2.3522;
$zoom = $cfg['zoom'] ?? 12;
$address = $cfg['address'] ?? '';
?>
<style>
  .mapcfg { font-size:14px; line-height:1.5; }
  .mapcfg .row { margin:8px 0; display:flex; gap:8px; flex-wrap:wrap; }
  .mapcfg label { min-width:110px; display:inline-block; opacity:.9; }
  .mapcfg input[type="text"], .mapcfg input[type="number"] {
    padding:6px 8px; border-radius:8px; border:1px solid rgba(255,255,255,.1);
    background:rgba(0,0,0,.2); color:inherit; width:260px;
  }
  .mapcfg .btn {
    padding:8px 12px; border:none; border-radius:10px; cursor:pointer;
    background:var(--primary-color,#5a5a5a); color:#fff; font-weight:600;
  }
  .mapcfg .btn.secondary { background:#444; }
  .mapcfg .note { font-size:12px; opacity:.8; }
  .mapcfg .ok { color:#4caf50; margin:6px 0; }
  .mapcfg .err{ color:#f66; margin:6px 0; }
</style>

<div class="mapcfg">
  <?php if ($msg): ?><div class="ok"><?= $msg ?></div><?php endif; ?>
  <?php if ($err): ?><div class="err">❌ <?= htmlspecialchars($err) ?></div><?php endif; ?>

  <form method="post">
    <div class="row">
      <label>Adresse postale</label>
      <input type="text" name="address" placeholder="12 rue Exemple, 75000 Paris"
             value="<?= htmlspecialchars($address) ?>" style="width:420px">
      <button class="btn" name="geocode" value="1">Géocoder</button>
    </div>

    <div class="row">
      <label>Latitude</label>
      <input type="text" name="lat" value="<?= htmlspecialchars($lat) ?>">
      <label>Longitude</label>
      <input type="text" name="lng" value="<?= htmlspecialchars($lng) ?>">
      <label>Zoom</label>
      <input type="number" min="1" max="19" name="zoom" value="<?= htmlspecialchars($zoom) ?>">
    </div>

    <div class="row">
      <button class="btn" name="save" value="1">Enregistrer</button>
      <span class="note">Astuce : clique d’abord “Géocoder” pour remplir lat/lng, ajuste le zoom si besoin, puis “Enregistrer”.</span>
    </div>
  </form>
</div>
