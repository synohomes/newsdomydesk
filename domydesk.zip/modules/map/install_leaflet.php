<?php
/* Installe Leaflet 1.9.4 en local (JS + CSS + images)
 * Cible: modules/map/lib/leaflet/
 * Utilise cURL si dispo, sinon file_get_contents.
 */
declare(strict_types=1);
$base = __DIR__ . '/lib/leaflet';
@mkdir($base . '/images', 0775, true);

$files = [
  // on télécharge les versions minifiées mais on les enregistre sous les noms attendus
  'https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.min.js'  => $base . '/leaflet.js',
  'https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.min.css' => $base . '/leaflet.css',
  // images utilisées par leaflet.css
  'https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/images/layers.png'        => $base . '/images/layers.png',
  'https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/images/layers-2x.png'     => $base . '/images/layers-2x.png',
  'https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/images/marker-icon.png'   => $base . '/images/marker-icon.png',
  'https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/images/marker-icon-2x.png'=> $base . '/images/marker-icon-2x.png',
  'https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/images/marker-shadow.png' => $base . '/images/marker-shadow.png',
];

function dl($url, $dest) {
  // cURL d’abord
  if (function_exists('curl_init')) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_CONNECTTIMEOUT => 15,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_USERAGENT => 'DoMyDesk Leaflet Installer',
    ]);
    $data = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $err  = curl_error($ch);
    curl_close($ch);
    if ($data === false || $code < 200 || $code >= 300) {
      throw new RuntimeException("HTTP $code $url ($err)");
    }
  } else {
    // fallback
    $ctx = stream_context_create([
      'http' => ['method'=>'GET','timeout'=>30,'header'=>"User-Agent: DoMyDesk Leaflet Installer\r\n"]
    ]);
    $data = @file_get_contents($url, false, $ctx);
    if ($data === false) throw new RuntimeException("GET failed: $url");
  }
  if (@file_put_contents($dest, $data) === false) {
    throw new RuntimeException("Write failed: $dest");
  }
}

header('Content-Type: text/plain; charset=utf-8');
echo "Installing Leaflet 1.9.4 into $base\n\n";

$ok = 0; $ko = 0;
foreach ($files as $url => $dest) {
  echo basename($dest) . " ... ";
  try {
    dl($url, $dest);
    // contrôle vite fait: taille non nulle
    if (filesize($dest) > 1000 || preg_match('/\\.(png)$/', $dest)) {
      echo "OK (" . filesize($dest) . " bytes)\n";
      $ok++;
    } else {
      echo "KO (size too small)\n"; $ko++;
    }
  } catch (Throwable $e) {
    echo "KO: " . $e->getMessage() . "\n"; $ko++;
  }
}

echo "\nDone. Success: $ok  Errors: $ko\n";
echo "→ Tu peux maintenant utiliser modules/map/map.php (version locale).\n";
