<?php
session_start();
if (!isset($_SESSION['user']['email'])) { die('Accès refusé'); }
$userEmail   = $_SESSION['user']['email'];
$userDir     = __DIR__ . "/../users/profiles/" . $userEmail;
$modulesFile = "$userDir/modules.json";
$themeFile   = "$userDir/theme.json";
$listFile    = __DIR__ . "/../modules/list.json";
$theme = 'default';
if (file_exists($themeFile)) {
    $themeData = json_decode(file_get_contents($themeFile), true);
    if (!empty($themeData['theme']) && file_exists(__DIR__ . "/../theme/" . $themeData['theme'] . "/style.css")) {
        $theme = basename($themeData['theme']);
    }
}
$allModules = [];
if (file_exists($listFile)) $allModules = json_decode(file_get_contents($listFile), true) ?? [];
$userModules = [];
if (file_exists($modulesFile)) $userModules = json_decode(file_get_contents($modulesFile), true) ?? [];
$userModulesById = [];
foreach ($userModules as $m) { $userModulesById[$m['id']] = $m; }
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['module_id'], $_POST['action'])) {
    $modId = $_POST['module_id'];
    foreach ($allModules as $mod) {
        if ($mod['id'] === $modId) {
            if ($_POST['action'] === 'enable') {
                $userModulesById[$modId] = [
                    'id' => $mod['id'],
                    'name' => $mod['name'],
                    'description' => $mod['description'],
                    'enabled' => true
                ];
            } elseif ($_POST['action'] === 'disable' && isset($userModulesById[$modId])) {
                $userModulesById[$modId]['enabled'] = false;
            }
            break;
        }
    }
    file_put_contents($modulesFile, json_encode(array_values($userModulesById), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    @chmod($modulesFile, 0666);
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Modules disponibles</title>
<link rel="stylesheet" href="../theme/<?php echo htmlspecialchars($theme); ?>/style.css">
<style>

.modules-scope { --accent: currentColor; } 

.modules-scope .section { max-width: 1100px; margin: 24px auto; }
.modules-scope h1 { margin: 0 0 12px 0; font-size: 1.8rem; }
.modules-scope .table-wrap{
  overflow:hidden;
  border-radius:14px;
  background: color-mix(in srgb, currentColor 6%, transparent);
  border:1px solid var(--accent);
}
.modules-scope table{ width:100%; border-collapse:collapse; }
.modules-scope thead th{
  text-align:left; padding:14px 16px; font-weight:700;
  background: color-mix(in srgb, currentColor 16%, transparent);
  color: inherit; border-bottom:1px solid var(--accent);
}
.modules-scope tbody td{
  padding:14px 16px; vertical-align:middle;
  background: color-mix(in srgb, currentColor 8%, transparent);
}
.modules-scope tbody tr + tr td{ border-top:1px solid var(--accent); }
.modules-scope tbody tr:hover td{
  background: color-mix(in srgb, currentColor 12%, transparent);
}
.modules-scope .status{display:inline-block;padding:4px 10px;border-radius:999px;font-weight:700}
.modules-scope .status.on{
  background: color-mix(in srgb, currentColor 38%, transparent);
  border:1px solid color-mix(in srgb, currentColor 55%, transparent);
}
.modules-scope .status.off{
  background: color-mix(in srgb, currentColor 10%, transparent);
  border:1px solid color-mix(in srgb, currentColor 18%, transparent);
  color: inherit;
}
.modules-scope .btn{
  appearance:none; cursor:pointer; border-radius:10px; padding:8px 14px; font-weight:700;
  border:1px solid color-mix(in srgb, currentColor 50%, transparent);
  background: color-mix(in srgb, currentColor 35%, transparent);
  color: inherit;
}
.modules-scope .btn:hover{
  background: color-mix(in srgb, currentColor 45%, transparent);
}
.modules-scope .mod-icon{ width:28px;height:28px;display:block; }
</style>
</head>
<body>
<?php include __DIR__ . '/../header.php'; ?>
<div class="modules-scope">
  <div class="section">
    <h1>Modules disponibles</h1>
    <?php
      $parPage = 50;
      $total   = count($allModules);
      $page    = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
      $start   = ($page - 1) * $parPage;
      $modulesToShow = array_slice($allModules, $start, $parPage);
    ?>
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th style="width:48px;"></th>
            <th>Nom</th>
            <th>Description</th>
            <th style="width:120px;">Statut</th>
            <th style="width:150px;">Action</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($modulesToShow as $mod):
          $id = $mod['id'];
          $enabled = isset($userModulesById[$id]) && $userModulesById[$id]['enabled'] === true;
        ?>
          <tr>
            <td><img class="mod-icon" src="../modules/<?= htmlspecialchars($id) ?>/icon.png" alt="" onerror="this.style.display='none'"></td>
            <td><?= htmlspecialchars($mod['name']) ?></td>
            <td><?= htmlspecialchars($mod['description']) ?></td>
            <td><span class="status <?= $enabled ? 'on' : 'off' ?>"><?= $enabled ? 'Activé' : 'Désactivé' ?></span></td>
            <td>
              <form method="post" style="margin:0;">
                <input type="hidden" name="module_id" value="<?= htmlspecialchars($id) ?>">
                <button class="btn" type="submit" name="action" value="<?= $enabled ? 'disable' : 'enable' ?>">
                  <?= $enabled ? 'Désactiver' : 'Activer' ?>
                </button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php if ($total > $parPage): ?>
      <div class="pagination" role="navigation" aria-label="Pagination" style="text-align:center;padding:14px 4px;">
        <?php for ($i = 1; $i <= ceil($total / $parPage); $i++): ?>
          <a href="?page=<?= $i ?>" <?= $i == $page ? 'aria-current="page"' : '' ?>><?= $i ?></a>
        <?php endfor; ?>
      </div>
    <?php endif; ?>
  </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function () {
  const scope = document.querySelector('.modules-scope');
  const section = scope?.querySelector('.section');
  if (!scope || !section) return;
  const cs = getComputedStyle(section);
  const accent = cs.borderTopColor || cs.borderColor;
  if (accent) scope.style.setProperty('--accent', accent);
});
</script>
</body>
</html>
