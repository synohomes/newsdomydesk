<?php
session_start();

if (!isset($_SESSION['user']['email'])) {
    die('Accès refusé');
}

$userEmail   = $_SESSION['user']['email'];
$userDir     = __DIR__ . "/../users/profiles/" . $userEmail;
$modulesFile = $userDir . "/modules.json";
$themeFile   = $userDir . "/theme.json";
$listFile    = __DIR__ . "/../modules/list.json";

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function dmd_initial($text) {
    $text = trim((string)$text);

    if ($text === '') {
        return '?';
    }

    if (function_exists('mb_substr') && function_exists('mb_strtoupper')) {
        return mb_strtoupper(mb_substr($text, 0, 1, 'UTF-8'), 'UTF-8');
    }

    return strtoupper(substr($text, 0, 1));
}

function dmd_icon_path($mod) {
    $id = $mod['id'] ?? '';

    if (!empty($mod['icon'])) {
        $icon = trim((string)$mod['icon']);

        if (preg_match('#^https?://#i', $icon)) {
            return $icon;
        }

        return "../" . ltrim($icon, "/");
    }

    return "../modules/" . rawurlencode($id) . "/icon.png";
}

$theme = 'default';

if (file_exists($themeFile)) {
    $themeData = json_decode(file_get_contents($themeFile), true);

    if (
        !empty($themeData['theme']) &&
        file_exists(__DIR__ . "/../theme/" . basename($themeData['theme']) . "/style.css")
    ) {
        $theme = basename($themeData['theme']);
    }
}

$allModules = [];

if (file_exists($listFile)) {
    $allModules = json_decode(file_get_contents($listFile), true) ?? [];
}

$userModules = [];

if (file_exists($modulesFile)) {
    $userModules = json_decode(file_get_contents($modulesFile), true) ?? [];
}

$userModulesById = [];

foreach ($userModules as $m) {
    if (!empty($m['id'])) {
        $userModulesById[$m['id']] = $m;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['module_id'], $_POST['action'])) {
    $modId  = trim((string)$_POST['module_id']);
    $action = trim((string)$_POST['action']);

    foreach ($allModules as $mod) {
        if (empty($mod['id'])) {
            continue;
        }

        if ((string)$mod['id'] === $modId) {
            if ($action === 'enable') {
                $userModulesById[$modId] = [
                    'id'          => $mod['id'],
                    'name'        => $mod['name'] ?? $mod['id'],
                    'description' => $mod['description'] ?? '',
                    'enabled'     => true
                ];
            }

            if ($action === 'disable' && isset($userModulesById[$modId])) {
                $userModulesById[$modId]['enabled'] = false;
            }

            break;
        }
    }

    if (!is_dir($userDir)) {
        mkdir($userDir, 0775, true);
    }

    file_put_contents(
        $modulesFile,
        json_encode(array_values($userModulesById), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
    );

    @chmod($modulesFile, 0666);

    $returnPanel = $_POST['return_panel'] ?? 'panel_all';
    $returnPanel = preg_replace('/[^a-zA-Z0-9_\-]/', '', $returnPanel);

    header('Location: ' . $_SERVER['PHP_SELF'] . '#' . $returnPanel);
    exit;
}

$allModulesClean  = [];
$enabledModules   = [];
$disabledModules  = [];

foreach ($allModules as $mod) {
    if (empty($mod['id'])) {
        continue;
    }

    $id = (string)$mod['id'];
    $enabled = isset($userModulesById[$id]) && ($userModulesById[$id]['enabled'] ?? false) === true;

    $mod['_enabled'] = $enabled;

    $allModulesClean[] = $mod;

    if ($enabled) {
        $enabledModules[] = $mod;
    } else {
        $disabledModules[] = $mod;
    }
}

$totalModules  = count($allModulesClean);
$totalEnabled  = count($enabledModules);
$totalDisabled = count($disabledModules);

$panels = [
    [
        'id'       => 'panel_all',
        'title'    => 'Tous les modules',
        'subtitle' => $totalModules . ' module' . ($totalModules > 1 ? 's' : ''),
        'icon'     => 'T',
        'modules'  => $allModulesClean
    ],
    [
        'id'       => 'panel_enabled',
        'title'    => 'Modules activés',
        'subtitle' => $totalEnabled . ' activé' . ($totalEnabled > 1 ? 's' : ''),
        'icon'     => '✓',
        'modules'  => $enabledModules
    ],
    [
        'id'       => 'panel_disabled',
        'title'    => 'Modules désactivés',
        'subtitle' => $totalDisabled . ' désactivé' . ($totalDisabled > 1 ? 's' : ''),
        'icon'     => '×',
        'modules'  => $disabledModules
    ]
];

$firstPanel = 'panel_all';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modules disponibles</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../theme/<?php echo h($theme); ?>/style.css">

    <style>
        .modules-page {
            width: min(1220px, calc(100% - 32px));
            margin: 28px auto;
        }

        .modules-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 18px;
            margin-bottom: 20px;
        }

        .modules-title-block h1 {
            margin: 0;
            color: var(--title-color, var(--text-color, inherit));
            font-size: clamp(1.35rem, 2vw, 1.85rem);
        }

        .modules-title-block p {
            margin: 6px 0 0;
            color: var(--muted-color, var(--text-color, inherit));
            font-size: .92rem;
        }

        .modules-stats {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            justify-content: flex-end;
        }

        .modules-stat {
            padding: 8px 12px;
            border-radius: var(--radius-md, 12px);
            background: var(--card-bg, var(--panel-bg, rgba(255,255,255,0.06)));
            border: 1px solid var(--border-color, rgba(255,255,255,0.14));
            color: var(--muted-color, var(--text-color, inherit));
            font-size: .84rem;
            box-shadow: var(--shadow-sm, none);
            white-space: nowrap;
        }

        .modules-tabs-zone {
            margin-bottom: 18px;
            padding: 14px;
            border-radius: var(--radius-lg, 18px);
            background: var(--section-bg, var(--panel-bg, rgba(255,255,255,0.06)));
            border: 1px solid var(--border-color, rgba(255,255,255,0.14));
            box-shadow: var(--shadow-md, none);
        }

        .modules-tabs-title {
            margin: 0 0 12px;
            color: var(--title-color, var(--text-color, inherit));
            font-size: 1rem;
            font-weight: 800;
        }

        .modules-tabs-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
            gap: 10px;
        }

        .modules-tab-card {
            width: 100%;
            text-align: left;
            appearance: none;
            cursor: pointer;
            border-radius: var(--radius-md, 14px);
            border: 1px solid var(--border-color, rgba(255,255,255,0.14));
            background: var(--card-bg, rgba(255,255,255,0.05));
            color: var(--text-color, inherit);
            padding: 12px;
            box-shadow: var(--shadow-sm, none);
            transition: transform .15s ease, border-color .15s ease, background .15s ease, opacity .15s ease;
        }

        .modules-tab-card:hover,
        .modules-tab-card.is-active {
            transform: translateY(-1px);
            border-color: var(--primary-color, var(--border-color, rgba(255,255,255,0.22)));
        }

        .modules-tab-card.is-active {
            background: color-mix(in srgb, var(--primary-color, currentColor) 13%, var(--card-bg, transparent));
        }

        .modules-tab-main {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .modules-tab-icon {
            width: 34px;
            height: 34px;
            flex: 0 0 34px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: var(--radius-sm, 10px);
            border: 1px solid var(--border-color, rgba(255,255,255,0.14));
            background: var(--panel-bg, rgba(255,255,255,0.04));
            color: var(--primary-color, var(--title-color, inherit));
            font-weight: 900;
            font-size: 1rem;
        }

        .modules-tab-name {
            display: block;
            color: var(--title-color, var(--text-color, inherit));
            font-weight: 900;
            font-size: .92rem;
            line-height: 1.2;
        }

        .modules-tab-count {
            display: block;
            margin-top: 4px;
            color: var(--muted-color, var(--text-color, inherit));
            font-size: .78rem;
            line-height: 1.25;
        }

        .modules-panel {
            display: none;
            border-radius: var(--radius-lg, 18px);
            background: var(--section-bg, var(--panel-bg, rgba(255,255,255,0.06)));
            border: 1px solid var(--border-color, rgba(255,255,255,0.14));
            box-shadow: var(--shadow-md, none);
            overflow: hidden;
            margin-bottom: 24px;
        }

        .modules-panel.is-active {
            display: block;
        }

        .modules-panel-head {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 14px;
            padding: 13px 16px;
            border-bottom: 1px solid var(--border-color, rgba(255,255,255,0.12));
            background: var(--panel-bg, transparent);
        }

        .modules-panel-title {
            margin: 0;
            color: var(--title-color, var(--text-color, inherit));
            font-size: 1rem;
            font-weight: 900;
        }

        .modules-panel-subtitle {
            color: var(--muted-color, var(--text-color, inherit));
            font-size: .82rem;
            white-space: nowrap;
        }

        .modules-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(165px, 1fr));
            gap: 10px;
            padding: 12px;
        }

        .module-card {
            display: flex;
            flex-direction: column;
            min-height: 122px;
            border-radius: var(--radius-md, 12px);
            border: 1px solid var(--border-color, rgba(255,255,255,0.14));
            background: var(--card-bg, rgba(255,255,255,0.05));
            padding: 10px;
            box-shadow: var(--shadow-sm, none);
            transition: transform .15s ease, border-color .15s ease, opacity .15s ease;
        }

        .module-card:hover {
            transform: translateY(-1px);
            border-color: var(--primary-color, var(--border-color, rgba(255,255,255,0.22)));
        }

        .module-card.is-disabled {
            opacity: .78;
        }

        .module-card-top {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 7px;
        }

        .module-icon-box {
            width: 30px;
            height: 30px;
            flex: 0 0 30px;
            border-radius: var(--radius-sm, 8px);
            border: 1px solid var(--border-color, rgba(255,255,255,0.14));
            background: var(--panel-bg, rgba(255,255,255,0.04));
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            position: relative;
        }

        .module-icon {
            width: 22px;
            height: 22px;
            object-fit: contain;
            display: block;
        }

        .module-fallback-icon {
            color: var(--primary-color, var(--title-color, inherit));
            font-size: .95rem;
            font-weight: 900;
        }

        .module-main {
            min-width: 0;
            flex: 1;
        }

        .module-name {
            margin: 0;
            color: var(--title-color, var(--text-color, inherit));
            font-weight: 900;
            font-size: .84rem;
            line-height: 1.15;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .module-desc {
            flex: 1;
            margin: 0 0 8px;
            color: var(--muted-color, var(--text-color, inherit));
            font-size: .72rem;
            line-height: 1.25;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .module-meta,
        .module-pill {
            display: none;
        }

        .module-card-bottom {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 7px;
            margin-top: auto;
        }

        .module-status {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 7px;
            border-radius: 999px;
            font-size: .67rem;
            font-weight: 900;
            white-space: nowrap;
            border: 1px solid var(--border-color, rgba(255,255,255,0.14));
            background: var(--panel-bg, rgba(255,255,255,0.04));
            color: var(--muted-color, var(--text-color, inherit));
        }

        .module-status::before {
            content: "";
            width: 6px;
            height: 6px;
            border-radius: 999px;
            background: var(--muted-color, currentColor);
            opacity: .75;
        }

        .module-status.is-on {
            color: var(--primary-color, var(--title-color, inherit));
            border-color: var(--primary-color, rgba(255,255,255,0.25));
            background: color-mix(in srgb, var(--primary-color, currentColor) 14%, transparent);
        }

        .module-status.is-on::before {
            background: var(--primary-color, currentColor);
            opacity: 1;
        }

        .module-action-form {
            margin: 0;
        }

        .module-btn {
            appearance: none;
            border: 1px solid var(--primary-color, var(--border-color, rgba(255,255,255,0.18)));
            background: var(--button-bg, var(--primary-color, transparent));
            color: var(--button-text, var(--text-color, inherit));
            border-radius: var(--radius-sm, 8px);
            padding: 5px 8px;
            cursor: pointer;
            font-weight: 900;
            font-size: .67rem;
            transition: transform .15s ease, opacity .15s ease;
            white-space: nowrap;
        }

        .module-btn:hover {
            transform: translateY(-1px);
            opacity: .92;
        }

        .module-btn.is-disable {
            background: transparent;
            color: var(--primary-color, var(--text-color, inherit));
        }

        .modules-empty {
            padding: 24px;
            color: var(--muted-color, var(--text-color, inherit));
            text-align: center;
        }

        @media (max-width: 760px) {
            .modules-page {
                width: min(100% - 20px, 1220px);
                margin: 18px auto;
            }

            .modules-header {
                display: block;
            }

            .modules-stats {
                justify-content: flex-start;
                margin-top: 12px;
            }

            .modules-tabs-grid {
                grid-template-columns: 1fr;
            }

            .modules-grid {
                grid-template-columns: repeat(auto-fill, minmax(145px, 1fr));
            }

            .modules-panel-head {
                display: block;
            }

            .modules-panel-subtitle {
                display: block;
                margin-top: 5px;
                white-space: normal;
            }

            .module-card {
                min-height: 120px;
            }

            .module-card-bottom {
                flex-direction: column;
                align-items: stretch;
            }

            .module-status {
                justify-content: center;
            }

            .module-action-form,
            .module-btn {
                width: 100%;
            }
        }
    </style>
</head>

<body>
<?php include __DIR__ . '/../header.php'; ?>

<main class="modules-page">
    <div class="modules-header">
        <div class="modules-title-block">
            <h1>Modules disponibles</h1>
            <p>Activez ou désactivez les modules DoMyDesk depuis une vue simple.</p>
        </div>

        <div class="modules-stats">
            <div class="modules-stat">
                <?= intval($totalModules) ?> module<?= $totalModules > 1 ? 's' : '' ?>
            </div>

            <div class="modules-stat">
                <?= intval($totalEnabled) ?> activé<?= $totalEnabled > 1 ? 's' : '' ?>
            </div>

            <div class="modules-stat">
                <?= intval($totalDisabled) ?> désactivé<?= $totalDisabled > 1 ? 's' : '' ?>
            </div>
        </div>
    </div>

    <section class="modules-tabs-zone">
        <h2 class="modules-tabs-title">Affichage</h2>

        <div class="modules-tabs-grid">
            <?php foreach ($panels as $panel): ?>
                <button
                    type="button"
                    class="modules-tab-card"
                    data-panel="<?= h($panel['id']) ?>"
                >
                    <span class="modules-tab-main">
                        <span class="modules-tab-icon"><?= h($panel['icon']) ?></span>

                        <span>
                            <span class="modules-tab-name"><?= h($panel['title']) ?></span>
                            <span class="modules-tab-count"><?= h($panel['subtitle']) ?></span>
                        </span>
                    </span>
                </button>
            <?php endforeach; ?>
        </div>
    </section>

    <?php foreach ($panels as $panel): ?>
        <section
            id="<?= h($panel['id']) ?>"
            class="modules-panel <?= $panel['id'] === $firstPanel ? 'is-active' : '' ?>"
            data-panel-content="<?= h($panel['id']) ?>"
        >
            <div class="modules-panel-head">
                <h2 class="modules-panel-title"><?= h($panel['title']) ?></h2>
                <div class="modules-panel-subtitle"><?= h($panel['subtitle']) ?></div>
            </div>

            <?php if (empty($panel['modules'])): ?>
                <div class="modules-empty">
                    Aucun module dans cette liste.
                </div>
            <?php else: ?>
                <div class="modules-grid">
                    <?php foreach ($panel['modules'] as $mod): ?>
                        <?php
                            $id = $mod['id'] ?? '';

                            if ($id === '') {
                                continue;
                            }

                            $name        = $mod['name'] ?? $id;
                            $description = $mod['description'] ?? '';
                            $enabled     = isset($userModulesById[$id]) && ($userModulesById[$id]['enabled'] ?? false) === true;
                            $iconPath    = dmd_icon_path($mod);
                            $fallback    = dmd_initial($name);
                        ?>

                        <article class="module-card <?= $enabled ? 'is-enabled' : 'is-disabled' ?>">
                            <div class="module-card-top">
                                <div class="module-icon-box">
                                    <span class="module-fallback-icon"><?= h($fallback) ?></span>

                                    <img
                                        class="module-icon"
                                        src="<?= h($iconPath) ?>"
                                        alt=""
                                        onload="this.previousElementSibling.style.display='none'"
                                        onerror="this.style.display='none'"
                                    >
                                </div>

                                <div class="module-main">
                                    <h3 class="module-name" title="<?= h($name) ?>">
                                        <?= h($name) ?>
                                    </h3>
                                </div>
                            </div>

                            <p class="module-desc" title="<?= h($description) ?>">
                                <?= h($description) ?>
                            </p>

                            <div class="module-card-bottom">
                                <span class="module-status <?= $enabled ? 'is-on' : 'is-off' ?>">
                                    <?= $enabled ? 'Activé' : 'Désactivé' ?>
                                </span>

                                <form method="post" class="module-action-form">
                                    <input type="hidden" name="module_id" value="<?= h($id) ?>">
                                    <input type="hidden" name="return_panel" value="<?= h($panel['id']) ?>">

                                    <button
                                        class="module-btn <?= $enabled ? 'is-disable' : 'is-enable' ?>"
                                        type="submit"
                                        name="action"
                                        value="<?= $enabled ? 'disable' : 'enable' ?>"
                                    >
                                        <?= $enabled ? 'Désactiver' : 'Activer' ?>
                                    </button>
                                </form>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    <?php endforeach; ?>
</main>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const buttons = document.querySelectorAll('.modules-tab-card[data-panel]');
    const panels = document.querySelectorAll('.modules-panel[data-panel-content]');

    function showPanel(panelId, updateHash = true) {
        buttons.forEach(function (button) {
            button.classList.toggle('is-active', button.dataset.panel === panelId);
        });

        panels.forEach(function (panel) {
            panel.classList.toggle('is-active', panel.dataset.panelContent === panelId);
        });

        if (updateHash) {
            history.replaceState(null, '', '#' + panelId);
        }
    }

    buttons.forEach(function (button) {
        button.addEventListener('click', function () {
            showPanel(button.dataset.panel);
        });
    });

    const hashPanel = window.location.hash ? window.location.hash.substring(1) : '';
    const hashExists = hashPanel && document.querySelector('[data-panel-content="' + CSS.escape(hashPanel) + '"]');

    if (hashExists) {
        showPanel(hashPanel, false);
        return;
    }

    showPanel('<?= h($firstPanel) ?>', false);
});
</script>

</body>
</html>