<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../core/dmd_permissions.php';

if (empty($_SESSION['user']['email'])) {
    $currentUrl = $_SERVER['REQUEST_URI'] ?? '/modules/modules.php';

    header('Location: /domydesk/login.php?redirect=' . rawurlencode($currentUrl));
    exit;
}

$userEmail = $_SESSION['user']['email'];
$userDir   = __DIR__ . "/../users/profiles/" . $userEmail;
$themeFile = $userDir . "/theme.json";

$profileData = dmd_read_profile($userEmail);
$roleSystem  = strtolower(trim((string)($profileData['role_system'] ?? 'user')));
$canRebuildModuleList = in_array($roleSystem, ['admin', 'superadmin'], true);

if (empty($_SESSION['csrf_modules_scan'])) {
    $_SESSION['csrf_modules_scan'] = bin2hex(random_bytes(32));
}

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function dmd_initial($text) {
    $text = trim((string)$text);

    if ($text === '') {
        return '?';
    }

    if (function_exists('mb_substr') && function_exists('mb_strtoupper')) {
        return mb_strtoupper(mb_substr($text, 0, 1, 'UTF-8'), 'UTF-8');
    }

    return strtoupper(substr($text, 0, 1));
}

function dmd_icon_path($mod) {
    $id = $mod['id'] ?? '';

    if (!empty($mod['icon'])) {
        $icon = trim((string)$mod['icon']);

        if (preg_match('#^https?://#i', $icon)) {
            return $icon;
        }

        return "../" . ltrim($icon, "/");
    }

    return "../modules/" . rawurlencode($id) . "/icon.png";
}


function dmd_rebuild_modules_list_from_disk() {
    $modulesDir = __DIR__;
    $listFile   = $modulesDir . '/list.json';
    $entries    = [];
    $items      = @scandir($modulesDir);

    if (!is_array($items)) {
        return [
            'ok' => false,
            'count' => 0,
            'error' => 'scan_failed'
        ];
    }

    foreach ($items as $folder) {
        if ($folder === '.' || $folder === '..' || substr($folder, 0, 1) === '.') {
            continue;
        }

        $moduleDir = $modulesDir . '/' . $folder;

        if (!is_dir($moduleDir) || is_link($moduleDir)) {
            continue;
        }

        $id = function_exists('dmd_safe_module_id')
            ? dmd_safe_module_id($folder)
            : (preg_match('/^[a-zA-Z0-9._-]+$/', $folder) ? $folder : '');

        if ($id === '') {
            continue;
        }

        $manifest = function_exists('dmd_module_manifest')
            ? dmd_module_manifest($id)
            : [];

        if (!is_array($manifest)) {
            $manifest = [];
        }

        $name = trim((string)($manifest['name'] ?? ''));

        if ($name === '') {
            $name = function_exists('dmd_module_display_name')
                ? dmd_module_display_name($id, $id)
                : $id;
        }

        $description = trim((string)($manifest['description'] ?? ''));
        if ($description === '') {
            $description = 'Module ' . $name . ' détecté automatiquement';
        }

        $scope = strtolower(trim((string)($manifest['storage_scope'] ?? 'legacy')));
        if (!in_array($scope, ['system', 'user', 'hybrid', 'legacy'], true)) {
            $scope = 'legacy';
        }

        $defaultAccess = strtolower(trim((string)($manifest['default_access'] ?? 'controlled')));
        if (!in_array($defaultAccess, ['controlled', 'everyone'], true)) {
            $defaultAccess = 'controlled';
        }

        $entry = [
            'id' => $id,
            'name' => $name,
            'description' => $description,
            'icon' => 'modules/' . $id . '/icon.png',
            'enabled' => false,
            'storage_scope' => $scope,
            'default_access' => $defaultAccess
        ];

        $version = trim((string)($manifest['version'] ?? ''));
        if ($version !== '') {
            $entry['version'] = $version;
        }

        $minDomydesk = trim((string)($manifest['min_domydesk'] ?? ''));
        if ($minDomydesk !== '') {
            $entry['min_domydesk'] = $minDomydesk;
        }

        $entries[] = $entry;
    }

    usort($entries, function ($a, $b) {
        return strnatcasecmp((string)$a['name'], (string)$b['name']);
    });

    $ok = function_exists('dmd_core_json_write')
        ? dmd_core_json_write($listFile, $entries)
        : (@file_put_contents(
            $listFile,
            json_encode($entries, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            LOCK_EX
        ) !== false);

    return [
        'ok' => (bool)$ok,
        'count' => count($entries),
        'error' => $ok ? '' : 'write_failed'
    ];
}

$theme = 'default';

if (file_exists($themeFile)) {
    $themeData = json_decode(file_get_contents($themeFile), true);

    if (
        !empty($themeData['theme']) &&
        file_exists(__DIR__ . "/../theme/" . basename($themeData['theme']) . "/style.css")
    ) {
        $theme = basename($themeData['theme']);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'rebuild_module_list') {
    if (!$canRebuildModuleList) {
        http_response_code(403);
        exit('Action refusée.');
    }

    $token = isset($_POST['csrf_token']) ? (string)$_POST['csrf_token'] : '';

    if ($token === '' || !hash_equals((string)($_SESSION['csrf_modules_scan'] ?? ''), $token)) {
        http_response_code(403);
        exit('Action refusée : formulaire expiré ou invalide.');
    }

    $scanResult = dmd_rebuild_modules_list_from_disk();

    if (!empty($scanResult['ok'])) {
        header(
            'Location: ' . $_SERVER['PHP_SELF']
            . '?scan=ok&count=' . (int)$scanResult['count']
            . '#panel_all'
        );
        exit;
    }

    header('Location: ' . $_SERVER['PHP_SELF'] . '?scan=error#panel_all');
    exit;
}

$allModules = array_values(dmd_effective_modules($userEmail, false));

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['module_id'], $_POST['action'])) {
    $modId  = trim((string)$_POST['module_id']);
    $action = trim((string)$_POST['action']);

    if ($action === 'enable') {
        dmd_set_user_module_enabled($userEmail, $modId, true);
    } elseif ($action === 'disable') {
        dmd_set_user_module_enabled($userEmail, $modId, false);
    }

    $returnPanel = isset($_POST['return_panel']) ? $_POST['return_panel'] : 'panel_all';
    $returnPanel = preg_replace('/[^a-zA-Z0-9_\-]/', '', $returnPanel);

    header('Location: ' . $_SERVER['PHP_SELF'] . '#' . $returnPanel);
    exit;
}

$allModulesClean  = [];
$enabledModules   = [];
$disabledModules  = [];

foreach ($allModules as $mod) {
    if (empty($mod['id'])) {
        continue;
    }

    $id = (string)$mod['id'];
    $enabled = dmd_user_module_is_enabled($userEmail, $id);

    $mod['_enabled'] = $enabled;

    $allModulesClean[] = $mod;

    if ($enabled) {
        $enabledModules[] = $mod;
    } else {
        $disabledModules[] = $mod;
    }
}

$totalModules  = count($allModulesClean);
$totalEnabled  = count($enabledModules);
$totalDisabled = count($disabledModules);

$panels = [
    [
        'id'       => 'panel_all',
        'title'    => 'Tous les modules',
        'subtitle' => $totalModules . ' module' . ($totalModules > 1 ? 's' : ''),
        'icon'     => 'T',
        'modules'  => $allModulesClean
    ],
    [
        'id'       => 'panel_enabled',
        'title'    => 'Modules activés',
        'subtitle' => $totalEnabled . ' activé' . ($totalEnabled > 1 ? 's' : ''),
        'icon'     => '✓',
        'modules'  => $enabledModules
    ],
    [
        'id'       => 'panel_disabled',
        'title'    => 'Modules désactivés',
        'subtitle' => $totalDisabled . ' désactivé' . ($totalDisabled > 1 ? 's' : ''),
        'icon'     => '×',
        'modules'  => $disabledModules
    ]
];

$firstPanel = 'panel_all';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modules disponibles</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../theme/<?php echo h($theme); ?>/style.css">

    <style>
        .modules-header-actions {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .modules-scan-form {
            margin: 0;
        }

        .modules-scan-btn {
            width: 34px;
            height: 34px;
            padding: 0;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border: 1px solid rgba(120, 90, 55, .14);
            border-radius: 11px;
            background: rgba(255, 255, 255, .38);
            color: inherit;
            cursor: pointer;
            opacity: .72;
            transition: opacity .15s ease, transform .15s ease, background .15s ease;
        }

        .modules-scan-btn:hover {
            opacity: 1;
            transform: translateY(-1px);
            background: rgba(255, 255, 255, .62);
        }

        .modules-scan-btn svg {
            width: 16px;
            height: 16px;
            display: block;
        }

        .modules-scan-notice {
            margin: 0 0 12px 0;
            padding: 8px 12px;
            border-radius: 10px;
            font-size: 12px;
            background: rgba(255, 255, 255, .42);
            border: 1px solid rgba(120, 90, 55, .12);
        }

        .modules-scan-notice.is-error {
            border-color: rgba(170, 55, 55, .22);
        }
    </style>
</head>

<body>
<?php include __DIR__ . '/../header.php'; ?>

<main class="modules-page">
    <div class="modules-header">
        <div class="modules-title-block">
            <h1>Modules disponibles</h1>
            <p>Affichez ou masquez les modules auxquels votre rôle ou un administrateur vous donne accès.</p>
        </div>

        <div class="modules-header-actions">
            <?php if ($canRebuildModuleList): ?>
                <form
                    method="post"
                    class="modules-scan-form"
                    onsubmit="return confirm('Scanner le dossier modules et reconstruire list.json ?');"
                >
                    <input type="hidden" name="action" value="rebuild_module_list">
                    <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_modules_scan']) ?>">
                    <button
                        type="submit"
                        class="modules-scan-btn"
                        title="Scanner les modules et reconstruire list.json"
                        aria-label="Scanner les modules et reconstruire list.json"
                    >
                        <svg viewBox="0 0 24 24" aria-hidden="true">
                            <path d="M4 9V5a1 1 0 0 1 1-1h4M15 4h4a1 1 0 0 1 1 1v4M20 15v4a1 1 0 0 1-1 1h-4M9 20H5a1 1 0 0 1-1-1v-4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>
                            <circle cx="12" cy="12" r="3.2" fill="none" stroke="currentColor" stroke-width="1.7"/>
                            <path d="M12 7.2v1.4M12 15.4v1.4M7.2 12h1.4M15.4 12h1.4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                        </svg>
                    </button>
                </form>
            <?php endif; ?>

            <div class="modules-stats">
                <div class="modules-stat">
                    <?= intval($totalModules) ?> module<?= $totalModules > 1 ? 's' : '' ?>
                </div>

                <div class="modules-stat">
                    <?= intval($totalEnabled) ?> activé<?= $totalEnabled > 1 ? 's' : '' ?>
                </div>

                <div class="modules-stat">
                    <?= intval($totalDisabled) ?> désactivé<?= $totalDisabled > 1 ? 's' : '' ?>
                </div>
            </div>
        </div>
    </div>

    <?php if (($_GET['scan'] ?? '') === 'ok'): ?>
        <div class="modules-scan-notice">
            Scan terminé : <?= (int)($_GET['count'] ?? 0) ?> module<?= ((int)($_GET['count'] ?? 0)) > 1 ? 's' : '' ?> détecté<?= ((int)($_GET['count'] ?? 0)) > 1 ? 's' : '' ?> et list.json reconstruit.
        </div>
    <?php elseif (($_GET['scan'] ?? '') === 'error'): ?>
        <div class="modules-scan-notice is-error">
            Impossible de reconstruire list.json. Vérifiez les droits d'écriture du dossier modules.
        </div>
    <?php endif; ?>

    <section class="modules-tabs-zone">
        <h2 class="modules-tabs-title">Affichage</h2>

        <div class="modules-tabs-grid">
            <?php foreach ($panels as $panel): ?>
                <button
                    type="button"
                    class="modules-tab-card"
                    data-panel="<?= h($panel['id']) ?>"
                >
                    <span class="modules-tab-main">
                        <span class="modules-tab-icon"><?= h($panel['icon']) ?></span>

                        <span>
                            <span class="modules-tab-name"><?= h($panel['title']) ?></span>
                            <span class="modules-tab-count"><?= h($panel['subtitle']) ?></span>
                        </span>
                    </span>
                </button>
            <?php endforeach; ?>
        </div>
    </section>

    <?php foreach ($panels as $panel): ?>
        <section
            id="<?= h($panel['id']) ?>"
            class="modules-panel <?= $panel['id'] === $firstPanel ? 'is-active' : '' ?>"
            data-panel-content="<?= h($panel['id']) ?>"
        >
            <div class="modules-panel-head">
                <h2 class="modules-panel-title"><?= h($panel['title']) ?></h2>
                <div class="modules-panel-subtitle"><?= h($panel['subtitle']) ?></div>
            </div>

            <?php if (empty($panel['modules'])): ?>
                <div class="modules-empty">
                    Aucun module dans cette liste.
                </div>
            <?php else: ?>
                <div class="modules-grid">
                    <?php foreach ($panel['modules'] as $mod): ?>
                        <?php
                            $id = $mod['id'] ?? '';

                            if ($id === '') {
                                continue;
                            }

                            $name        = $mod['name'] ?? $id;
                            $description = $mod['description'] ?? '';
                            $enabled     = dmd_user_module_is_enabled($userEmail, $id);
                            $iconPath    = dmd_icon_path($mod);
                            $fallback    = dmd_initial($name);
                        ?>

                        <article class="module-card <?= $enabled ? 'is-enabled' : 'is-disabled' ?>">
                            <div class="module-card-top">
                                <div class="module-icon-box">
                                    <span class="module-fallback-icon"><?= h($fallback) ?></span>

                                    <img
                                        class="module-icon"
                                        src="<?= h($iconPath) ?>"
                                        alt=""
                                        onload="this.previousElementSibling.style.display='none'"
                                        onerror="this.style.display='none'"
                                    >
                                </div>

                                <div class="module-main">
                                    <h3 class="module-name" title="<?= h($name) ?>">
                                        <?= h($name) ?>
                                    </h3>
                                </div>
                            </div>

                            <p class="module-desc" title="<?= h($description) ?>">
                                <?= h($description) ?>
                            </p>

                            <div class="module-card-bottom">
                                <span class="module-status <?= $enabled ? 'is-on' : 'is-off' ?>">
                                    <?= $enabled ? 'Activé' : 'Désactivé' ?>
                                </span>

                                <form method="post" class="module-action-form">
                                    <input type="hidden" name="module_id" value="<?= h($id) ?>">
                                    <input type="hidden" name="return_panel" value="<?= h($panel['id']) ?>">

                                    <button
                                        class="module-btn <?= $enabled ? 'is-disable' : 'is-enable' ?>"
                                        type="submit"
                                        name="action"
                                        value="<?= $enabled ? 'disable' : 'enable' ?>"
                                    >
                                        <?= $enabled ? 'Désactiver' : 'Activer' ?>
                                    </button>
                                </form>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    <?php endforeach; ?>
</main>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const buttons = document.querySelectorAll('.modules-tab-card[data-panel]');
    const panels = document.querySelectorAll('.modules-panel[data-panel-content]');

    function showPanel(panelId, updateHash = true) {
        buttons.forEach(function (button) {
            button.classList.toggle('is-active', button.dataset.panel === panelId);
        });

        panels.forEach(function (panel) {
            panel.classList.toggle('is-active', panel.dataset.panelContent === panelId);
        });

        if (updateHash) {
            history.replaceState(null, '', '#' + panelId);
        }
    }

    buttons.forEach(function (button) {
        button.addEventListener('click', function () {
            showPanel(button.dataset.panel);
        });
    });

    const hashPanel = window.location.hash ? window.location.hash.substring(1) : '';
    const hashExists = hashPanel && document.querySelector('[data-panel-content="' + CSS.escape(hashPanel) + '"]');

    if (hashExists) {
        showPanel(hashPanel, false);
        return;
    }

    showPanel('<?= h($firstPanel) ?>', false);
});
</script>

</body>
</html>