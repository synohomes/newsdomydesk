<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$sessionEmail = $_SESSION['user']['email'] ?? '';
if (!$sessionEmail) {
    http_response_code(403);
    exit("⛔ Accès refusé (non connecté).");
}
$baseDir = realpath(__DIR__ . '/../../');
if (!$baseDir) {
    http_response_code(500);
    exit("⛔ Impossible de localiser la racine du site.");
}
$profilesRoot = $baseDir . '/users/profiles';
$profileDir   = realpath($profilesRoot . '/' . $sessionEmail);
if (!$profileDir || strpos($profileDir, $profilesRoot) !== 0 || !is_dir($profileDir)) {
    http_response_code(404);
    exit("⛔ Dossier utilisateur introuvable.");
}
$tmpZip = sys_get_temp_dir() . "/savev.1" . uniqid() . ".zip";
$zip = new ZipArchive();
if ($zip->open($tmpZip, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
    http_response_code(500);
    exit("⛔ Impossible de créer le fichier ZIP.");
}
$files = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($profileDir, RecursiveDirectoryIterator::SKIP_DOTS),
    RecursiveIteratorIterator::LEAVES_ONLY
);
foreach ($files as $file) {
    if ($file->isFile()) {
        $filePath     = $file->getRealPath();
        $relativePath = substr($filePath, strlen($profileDir) + 1);
        $zip->addFile($filePath, $relativePath);
    }
}
$zip->close();
$filename = 'DoMyDesk_Backup_' . date('Ymd_His') . '.zip';
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . filesize($tmpZip));
readfile($tmpZip);
@unlink($tmpZip);
exit;
