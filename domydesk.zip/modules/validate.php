<?php
if (session_status()===PHP_SESSION_NONE) session_start();
header('Content-Type: text/html; charset=utf-8');
$root = dirname(__DIR__, 1);     // .../adm
$base = dirname($root);          // .../domydesk
$marketDir = $base . '/data/market/';
@mkdir($marketDir, 0775, true);
$REMOTE_JSON = 'https://github.com/synohomes/marketmodules/raw/refs/heads/main/modulesmarket.json';
$jsonCandidates = [
  $REMOTE_JSON,
  $root . '/market/modulesmarket.json',
  $base . '/data/market/modulesmarket.json',
];
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); }
function fetch_json_any($candidates){
  $lastErr = '';
  foreach ($candidates as $src){
    try{
      if (preg_match('~^https?://~i', $src)) {
        $ctx = stream_context_create([
          'http'  => ['timeout'=>10, 'ignore_errors'=>true],
          'https' => ['timeout'=>10, 'ignore_errors'=>true]
        ]);
        $raw = @file_get_contents($src, false, $ctx);
      } else {
        if (!file_exists($src)) { $lastErr = "Fichier local introuvable: $src"; continue; }
        $raw = @file_get_contents($src);
      }
      if ($raw===false || trim($raw)==='') { $lastErr = "Lecture impossible: $src"; continue; }
      $data = json_decode($raw, true);
      if (!is_array($data)) { $lastErr = "JSON invalide: $src"; continue; }
      return [$data, $src, null];
    } catch (Throwable $e){
      $lastErr = $e->getMessage();
    }
  }
  return [[], null, $lastErr ?: 'Aucune source JSON valide'];
}
function fetchZipToTmp($url, $tmpFile){
  $ctx = stream_context_create([
    'http'  => ['timeout'=>15, 'ignore_errors'=>true],
    'https' => ['timeout'=>15, 'ignore_errors'=>true]
  ]);
  $bin = @file_get_contents($url, false, $ctx);
  if ($bin===false || strlen($bin)<128) return false;
  return (bool)file_put_contents($tmpFile, $bin);
}
function validateZipStructure($zipPath, $expectedId){
  $issues = [];
  $score  = 100;
  if (!class_exists('ZipArchive')) {
    return ['ok'=>false,'score'=>0,'issues'=>['Extension PHP ZipArchive manquante'],'meta'=>[]];
  }
  $zip = new ZipArchive();
  if ($zip->open($zipPath)!==true){
    return ['ok'=>false,'score'=>0,'issues'=>['Impossible d’ouvrir le ZIP'],'meta'=>[]];
  }
  $meta = [
    'files'=> $zip->numFiles,
    'size' => @filesize($zipPath) ?: 0,
    'roots'=> [],
  ];
  $needMain = "modules/$expectedId/$expectedId.php";
  $optCfg   = "modules/$expectedId/{$expectedId}cfg.php";
  $hasMain  = false;
  $hasCfg   = false;
  $badPaths = [];
  $rootsMap = [];
  for ($i=0; $i<$zip->numFiles; $i++){
    $st = $zip->statIndex($i);
    if (!$st) continue;
    $name = $st['name'];
    $parts = explode('/', ltrim($name, '/'));
    if (!empty($parts[0])) $rootsMap[$parts[0]] = true;
    if (str_starts_with($name, '/') || strpos($name,'../')!==false) {
      $badPaths[] = $name;
    }
    if (!str_starts_with($name, "modules/$expectedId/") && $name !== "modules/$expectedId") {
      $allow = false;
      $bn = basename($name);
      if ($bn !== '') {
        if (preg_match('~^(README|LICENSE|CHANGELOG|\.DS_Store|__MACOSX)~i', $bn)) $allow = true;
      }
      if (!$allow && trim($name)!=='') $badPaths[] = $name;
    }
    if ($name === $needMain) $hasMain = true;
    if ($name === $optCfg)  $hasCfg  = true;
  }
  $zip->close();
  $meta['roots'] = array_values(array_unique(array_keys($rootsMap)));
  if (!$hasMain){ $issues[] = "Manque <code>$needMain</code>"; $score -= 40; }
  if (!$hasCfg){  $issues[] = "Optionnel mais recommandé : <code>$optCfg</code>"; $score -= 5; }
  if (!empty($badPaths)){
    $issues[] = "Chemins non conformes (déplacer sous <code>modules/$expectedId/</code>) :<br><small>".h(implode("\n", $badPaths))."</small>";
    $score -= 25;
  }
  if (!in_array('modules', $meta['roots'])){ $issues[] = "Le ZIP doit contenir un dossier racine <code>modules/</code>"; $score -= 30; }
  if ($score<0) $score=0;
  return ['ok'=>($score>=70),'score'=>$score,'issues'=>$issues,'meta'=>$meta];
}
function rowResult($res){
  if (!$res) return '<span style="color:#f66">Erreur</span>';
  $col = $res['ok'] ? '#6fdc6f' : '#ff9c66';
  return '<span style="color:'.$col.';font-weight:600">'.($res['ok']?'OK':'À corriger').'</span> ('.$res['score'].'/100)';
}
list($modulesList, $jsonSource, $jsonErr) = fetch_json_any($jsonCandidates);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8" />
<title>Validateur Modules Market — DoMyDesk</title>
<style>
  :root{ --panel:#151515; --border:#4c4c4c; --txt:#eaeaea; --muted:#9aa0a6; }
  *{ box-sizing:border-box }
  body{ margin:0; font-family:system-ui,Segoe UI,Roboto,Arial; background:#0f1115; color:var(--txt); }
  .wrap{ max-width:1150px; margin:28px auto; padding:0 16px; }
  .h1{ font-size:22px; font-weight:700; margin:0 0 12px; }
  .card{ background:var(--panel); border:1px solid var(--border); border-radius:12px; padding:14px; margin-bottom:14px; }
  .muted{ color:var(--muted); }
  table{ width:100%; border-collapse:collapse; }
  th,td{ border-bottom:1px solid rgba(255,255,255,.08); padding:10px 8px; text-align:left; vertical-align:top; }
  th{ font-weight:600; opacity:.9; }
  code{ background:rgba(255,255,255,.06); padding:1px 6px; border-radius:6px; }
  .pill{ display:inline-block; border:1px solid var(--border); border-radius:999px; padding:2px 8px; font-size:12px; margin:2px 4px 0 0; }
</style>
</head>
<body>
<div class="wrap">
  <div class="h1">Validateur des modules téléchargeables</div>
  <div class="card">
    <div><strong>Source JSON</strong> :
      <?php if ($jsonSource): ?>
        <code><?= h($jsonSource) ?></code>
      <?php else: ?>
        <span style="color:#ff9c66">introuvable</span>
      <?php endif; ?>
    </div>
    <?php if ($jsonErr): ?>
      <div style="margin-top:6px;color:#ff9c66"><?= h($jsonErr) ?></div>
    <?php endif; ?>
    <div class="muted" style="margin-top:6px">Le validateur contrôle le schéma et la structure interne des ZIP (aucune extraction, safe).</div>
  </div>
  <?php if ($modulesList): ?>
  <div class="card">
    <table>
      <thead>
        <tr>
          <th>Module</th>
          <th>Version</th>
          <th>Source ZIP</th>
          <th>Résultat</th>
          <th>Détails</th>
        </tr>
      </thead>
      <tbody>
      <?php
        foreach ($modulesList as $m):
          $id   = trim($m['id']   ?? '');
          $name = trim($m['name'] ?? $id);
          $ver  = trim($m['version'] ?? '');
          $zipUrl = $m['zip_url'] ?? $m['download_url'] ?? '';
          $local  = $m['local_zip'] ?? '';
          $res = null;
          $details = [];
          if ($id === ''){
            $res = ['ok'=>false,'score'=>0,'issues'=>['Champ "id" manquant'],'meta'=>[]];
          }
          if (!$zipUrl && !$local){
            $res = ['ok'=>false,'score'=>0,'issues'=>['Fournir "zip_url" ou "download_url" (ou "local_zip")'],'meta'=>[]];
          }
          $zipPath = '';
          $tmpPath = '';
          if (!$res){
            // Priorité au local si dispo
            if ($local && file_exists($base.'/'.$local)){
              $zipPath = $base.'/'.$local;
            } elseif ($zipUrl){
              // Cache de téléchargement 1h
              $tmpPath = $marketDir . 'tmp_' . md5($zipUrl) . '.zip';
              if (!file_exists($tmpPath) || (time()-filemtime($tmpPath))>3600){
                @unlink($tmpPath);
                if (!fetchZipToTmp($zipUrl, $tmpPath)){
                  $res = ['ok'=>false,'score'=>0,'issues'=>["Téléchargement échoué : $zipUrl"],'meta'=>[]];
                }
              }
              if (!$res) $zipPath = $tmpPath;
            } else {
              $res = ['ok'=>false,'score'=>0,'issues'=>['Aucun ZIP accessible'],'meta'=>[]];
            }
          }
          if (!$res){
            $res = validateZipStructure($zipPath, $id);
          }
          if (!empty($res['meta'])){
            $details[] = "Fichiers : <strong>".$res['meta']['files']."</strong>";
            $details[] = "Taille : <strong>".number_format(($res['meta']['size']??0)/1024,1,'.',' ')." Ko</strong>";
            if (!empty($res['meta']['roots'])){
              $details[] = "Racines : ".implode(' ', array_map(fn($x)=>'<span class=\"pill\">'.h($x).'</span>', $res['meta']['roots']));
            }
          }
          if (!empty($res['issues'])){
            foreach ($res['issues'] as $iss) $details[] = $iss;
            if ($res['ok']) $details[] = "<em class='muted'>Conseil : garder uniquement <code>modules/$id/</code> + fichiers nécessaires. Pas de <code>users/</code> ni <code>data/</code> dans le ZIP.</em>";
          } else {
            $details[] = "<span style='color:#6fdc6f'>Aucune anomalie détectée.</span>";
          }
      ?>
        <tr>
          <td><strong><?= h($name ?: $id) ?></strong><div class="muted"><code><?= h($id) ?></code></div></td>
          <td><?= h($ver) ?></td>
          <td style="max-width:300px;word-break:break-all">
            <?php if ($local): ?><div>Local : <code><?= h($local) ?></code></div><?php endif; ?>
            <?php if ($zipUrl): ?><div>URL : <code><?= h($zipUrl) ?></code></div><?php endif; ?>
          </td>
          <td><?= rowResult($res) ?></td>
          <td><?= implode('<br>', $details) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
  <div class="card">
    <div class="h1" style="font-size:18px">Zips orphelins (data/market/*.zip)</div>
    <div class="muted" style="margin-bottom:8px">Contrôle des fichiers présents localement qui ne sont pas listés dans le JSON.</div>
    <table>
      <thead><tr><th>Fichier</th><th>Guess ID</th><th>Résultat</th><th>Détails</th></tr></thead>
      <tbody>
      <?php
        $orphans = glob($marketDir.'*.zip') ?: [];
        if (!$orphans){
          echo '<tr><td colspan="4" class="muted">Aucun ZIP local trouvé.</td></tr>';
        } else {
          foreach ($orphans as $zp){
            $fname = basename($zp);
            $guessId = preg_replace('~\.zip$~i','',$fname);
            $res = validateZipStructure($zp, $guessId);
            $det = [];
            if (!empty($res['meta'])){
              $det[] = "Fichiers : <strong>".$res['meta']['files']."</strong>, Taille : <strong>".number_format(($res['meta']['size']??0)/1024,1,'.',' ')." Ko</strong>";
              if (!empty($res['meta']['roots'])){
                $det[] = "Racines : ".implode(' ', array_map(fn($x)=>'<span class=\"pill\">'.h($x).'</span>', $res['meta']['roots']));
              }
            }
            if (!empty($res['issues'])) foreach ($res['issues'] as $iss) $det[] = $iss;
            if (!$det) $det[] = "<span style='color:#6fdc6f'>RAS</span>";
            echo '<tr>';
            echo '<td><code>'.h('data/market/'.$fname).'</code></td>';
            echo '<td><code>'.h($guessId).'</code></td>';
            echo '<td>'.rowResult($res).'</td>';
            echo '<td>'.implode('<br>', $det).'</td>';
            echo '</tr>';
          }
        }
      ?>
      </tbody>
    </table>
  </div>
  <div class="card">
  <div class="h1" style="font-size:18px">Rappel — Structure attendue d’un ZIP</div>
<pre style="white-space:pre-wrap;word-break:break-word;margin:0">
modules/
  &lt;id&gt;/
    &lt;id&gt;.php          ← obligatoire (point d’entrée du module)
    &lt;id&gt;cfg.php       ← optionnel recommandé (config)
    assets/...         ← images, js, css, etc. (si besoin)
</pre>
    <div class="muted" style="margin-top:6px">Interdits dans le ZIP : dossiers <code>users/</code>, <code>data/</code>, chemins absolus, <code>../</code>.</div>
  </div>
</div>
</body>
</html>
