<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { echo "<div class='error'>⛔ Non connecté</div>"; return; }
$dir       = __DIR__ . "/../../users/profiles/$email/contact/";
$avatarDir = $dir . "avatars/";
$dataFile  = $dir . "contacts.json";
@mkdir($avatarDir, 0775, true);
if (!file_exists($dataFile)) file_put_contents($dataFile, "[]");
$contacts = json_decode(@file_get_contents($dataFile), true);
if (!is_array($contacts)) $contacts = [];
?>
<style>
  #contact-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill, minmax(220px, 1fr));
  gap:12px;
  width:100%;
}
.ctile{
  position:relative;display:flex;flex-direction:column;align-items:center;gap:6px;
  padding:10px;border-radius:12px;
  background:var(--card-bg,rgba(255,255,255,0.04));
  cursor:pointer;
  min-height:auto; 
}
  .ctile .pic{width:48px;height:48px;border-radius:50%;object-fit:cover;background:#ddd}
  .ctile .name{font-weight:600;font-size:.9rem;max-width:100%;
    white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:center}
  .ctile .mail{font-size:.8rem;opacity:.85;max-width:100%;
    white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:center}
  .ctile .tools{position:absolute;top:6px;right:6px;display:flex;gap:6px}
.toolbtn {
    width: 22px;
    height: 22px;
    border: none !important; 
    border-radius: 6px;
    background: none !important; 
    box-shadow: none !important; 
    display: grid;
    place-items: center;
    cursor: pointer;
    font-size: 12px;
    line-height: 1;
    padding: 0;
}
  .toolbtn:focus{outline:2px solid var(--focus,#cc5555)}
  .cmodal{position:fixed;inset:0;display:none;place-items:center;z-index:9999}
  .cmodal.on{display:grid}
  .cmodal .backdrop{position:absolute;inset:0;background:rgba(0,0,0,.6)}
  .cmodal .dialog{
    position:relative;width:min(420px,92vw);border-radius:14px;border:1px solid var(--card-border,#3a3a3a);
    background:var(--panel,#1a1a1a);padding:16px 16px 12px;box-shadow:0 12px 30px rgba(0,0,0,.35)
  }
.cm-x{position:absolute;top:8px;right:10px;border:none;background:transparent;font-size:20px;cursor:pointer}
  .cm-head{display:flex;align-items:center;gap:10px;margin-bottom:8px}
  .cm-head .pic{width:56px;height:56px;border-radius:50%;object-fit:cover;background:#ddd}
  .cm-title{font-weight:800;font-size:1rem}
  .cm-sub{opacity:.8}
  .cm-row{display:flex;align-items:center;gap:10px;margin:8px 0;padding:8px 10px;border:1px dashed rgba(255,255,255,.15);border-radius:10px}
  .cm-label{width:108px;text-decoration:underline;text-underline-offset:3px;opacity:.9}
  .cm-val a{color:inherit;text-decoration:none;border-bottom:1px dotted currentColor}
  .cm-val a:hover{text-decoration:underline}
  .ctile:focus{outline:2px solid var(--focus,#cc5555)}
  .app-icon, .window-header .app-icon, .popup-header .app-icon { display:none !important; }
@media (max-width:900px){
  #contact-grid{ grid-template-columns:repeat(2, minmax(0,1fr)); }
}
@media (max-width:540px){
  #contact-grid{ grid-template-columns:1fr; }
  .ctile .pic{ width:42px; height:42px; }
  .ctile .name{ font-size:.95rem; }
  .ctile .mail{ font-size:.85rem; }
}
.cwin{
  position:fixed; top:80px; left:80px; z-index:1000;
  width:min(340px, 92vw);            /* plus petit au départ */
  min-width:260px; max-width:92vw;
  min-height:140px;                  /* garde une base */
  border-radius:12px;
  border:1px solid var(--card-border,#3a3a3a);
  background:var(--panel,#1a1a1a);
  box-shadow:0 12px 30px rgba(0,0,0,.35);
  user-select:none;
  resize: both;
  overflow: auto;
}
.cwin:focus-within{ outline:2px solid rgba(255,120,120,.35); }
.cwin-h{ display:flex; align-items:center; gap:10px; padding:8px 10px;
         cursor:move; border-bottom:1px solid rgba(255,255,255,.08); }
.cwin-h .pic{width:36px;height:36px;border-radius:50%;object-fit:cover;background:#ddd;flex:0 0 auto}
.cwin-h .t{font-weight:800}
.cwin-h .x{margin-left:auto;background:none;border:none;font-size:18px;cursor:pointer}
.cwin-b{ padding:10px 12px 12px; user-select:text; cursor:default; }
.crow{display:flex;align-items:center;gap:10px;margin:6px 0;padding:8px 10px;border:1px dashed rgba(255,255,255,.15);border-radius:10px}
.clab{width:108px;text-decoration:underline;text-underline-offset:3px;opacity:.9}
.cval a{color:inherit;text-decoration:none;border-bottom:1px dotted currentColor}
.cval a:hover{text-decoration:underline}
@media (max-width:540px){
  .cwin{width:92vw; left:4vw!important;}
}
</style>
<div id="contact-module" class="section">
  <button type="button" class="section-toggle" aria-expanded="false">
    <span>CONTACT</span><span class="caret">▾</span>
  </button>
  <div class="section-panel" style="display:none">
    <div class="form-grid">
      <input type="hidden" id="c_id">
      <input id="c_prenom"     placeholder="Prénom">
      <input id="c_nom"        placeholder="Nom">
      <input id="c_mail"       type="email" placeholder="Email">
      <input id="c_entreprise" placeholder="Entreprise">
      <input id="c_tel"        placeholder="Téléphone">
      <input id="c_avatar"     type="file" accept="image/*">
      <div class="form-actions">
        <button id="c_save"  type="button">Ajouter</button>
        <button id="c_reset" type="button">Nouveau</button>
      </div>
      <div id="c_msg" class="form-msg"></div>
    </div>
  </div>
</div>
<div class="section">
  <h3>Contacts: (<?= count($contacts) ?>)</h3>
  <div id="contact-grid">
    <?php foreach ($contacts as $c):
      $id   = htmlspecialchars($c['id'] ?? '');
      $nom  = htmlspecialchars(trim(($c['prenom'] ?? '').' '.($c['nom'] ?? '')));
      $mail = htmlspecialchars($c['mail'] ?? '');
      $ent  = htmlspecialchars($c['entreprise'] ?? '');
      $tel  = htmlspecialchars($c['tel'] ?? '');
      $hasA = !empty($c['avatar']) && file_exists($avatarDir.$c['avatar']);
      $src  = $hasA ? "users/profiles/".htmlspecialchars($email)."/contact/avatars/".htmlspecialchars($c['avatar']) : "";
    ?>
      <div class="ctile contact-pop"
           tabindex="0"
           data-id="<?= $id ?>"
           data-prenom="<?= htmlspecialchars($c['prenom'] ?? '') ?>"
           data-nom="<?= htmlspecialchars($c['nom'] ?? '') ?>"
           data-mail="<?= $mail ?>"
           data-entreprise="<?= $ent ?>"
           data-tel="<?= $tel ?>"
           data-avatar="<?= $src ?>">
        <div class="tools">
          <button class="toolbtn edit" type="button" title="Modifier" onclick="event.stopPropagation()" data-id="<?= $id ?>">✏️</button>
          <button class="toolbtn del"  type="button" title="Supprimer" onclick="event.stopPropagation()" data-id="<?= $id ?>">🗑️</button>
        </div>
        <?php if ($hasA): ?>
          <img class="pic" src="<?= $src ?>" alt="">
        <?php else: ?>
          <span class="pic"></span>
        <?php endif; ?>
        <div class="name"><?= $nom ?: '(Sans nom)' ?></div>
        <div class="mail"><?= $mail ?></div>
      </div>
    <?php endforeach; ?>
    <?php if (empty($contacts)): ?><p>Aucun contact.</p><?php endif; ?>
  </div>
</div>
<script>
(()=> {
  let zTop = 2000;
  function bringToFront(win){ win.style.zIndex = ++zTop; }
  function makeDraggable(win, handle){
    let dx=0, dy=0, startX=0, startY=0, dragging=false;
    const onDown = (e)=>{
      dragging=true; bringToFront(win);
      const ev = (e.touches && e.touches[0]) ? e.touches[0] : e;
      startX = ev.clientX; startY = ev.clientY;
      const rect = win.getBoundingClientRect();
      dx = startX - rect.left; dy = startY - rect.top;
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
      document.addEventListener('touchmove', onMove, {passive:false});
      document.addEventListener('touchend', onUp);
    };
    const onMove = (e)=>{
      if(!dragging) return;
      const ev = (e.touches && e.touches[0]) ? e.touches[0] : e;
      if (e.cancelable) e.preventDefault();
      let x = ev.clientX - dx;
      let y = ev.clientY - dy;
      // garde la fenêtre à l’écran
      const W = window.innerWidth, H = window.innerHeight;
      const rect = win.getBoundingClientRect();
      const w = rect.width, h = rect.height;
      x = Math.max(6, Math.min(W - w - 6, x));
      y = Math.max(6, Math.min(H - h - 6, y));
      win.style.left = x + 'px';
      win.style.top  = y + 'px';
    };
    const onUp = ()=>{
      dragging=false;
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      document.removeEventListener('touchmove', onMove);
      document.removeEventListener('touchend', onUp);
    };
    handle.addEventListener('mousedown', onDown);
    handle.addEventListener('touchstart', onDown, {passive:false});
    win.addEventListener('mousedown', ()=> bringToFront(win));
  }
  function createContactWindow(d, anchorRect){
    const el = document.createElement('div');
    el.className = 'cwin';
    el.style.left = (anchorRect ? Math.max(8, Math.min(window.innerWidth-360, anchorRect.left)) : 80) + 'px';
    el.style.top  = (anchorRect ? Math.max(8, anchorRect.bottom + 8) : 80) + 'px';
    el.style.zIndex = ++zTop;
    el.innerHTML = `
      <div class="cwin-h">
        ${d.avatar ? `<img class="pic" src="${d.avatar}">` : `<span class="pic"></span>`}
        <div class="t">${[d.prenom,d.nom].filter(Boolean).join(' ')||'(Sans nom)'}</div>
        <button class="x" type="button" aria-label="Fermer">×</button>
      </div>
      <div class="cwin-b">
        <div class="crow"><div class="clab">Entreprise</div><div class="cval">${d.entreprise||'—'}</div></div>
        <div class="crow"><div class="clab">Email</div><div class="cval"><a href="${d.mail?('mailto:'+d.mail):'#'}">${d.mail||'—'}</a></div></div>
        <div class="crow"><div class="clab">Téléphone</div><div class="cval"><a href="${d.tel?('tel:'+d.tel.replace(/\s+/g,'')):'#'}">${d.tel||'—'}</a></div></div>
      </div>
    `;
    document.body.appendChild(el);
    const header = el.querySelector('.cwin-h');
    const close  = el.querySelector('.x');
    close.addEventListener('click', ()=> el.remove());
    makeDraggable(el, header);
    return el;
  }
  document.querySelectorAll('.ctile.contact-pop').forEach(tile=>{
    tile.addEventListener('click', ()=>{
      const r = tile.getBoundingClientRect();
      createContactWindow({
        prenom: tile.dataset.prenom||'',
        nom: tile.dataset.nom||'',
        mail: tile.dataset.mail||'',
        entreprise: tile.dataset.entreprise||'',
        tel: tile.dataset.tel||'',
        avatar: tile.dataset.avatar||''
      }, r);
    });
  });
})();
</script>
<script>
(()=> {
  const mod=document.getElementById('contact-module');
  const tog=mod.querySelector('.section-toggle');
  const pnl=mod.querySelector('.section-panel');
  const caret=mod.querySelector('.caret');
  const msg=document.getElementById('c_msg');
  function setOpen(b){tog.setAttribute('aria-expanded',b?'true':'false');pnl.style.display=b?'':'none';caret.style.transform=b?'rotate(180deg)':'rotate(0deg)';}
  setOpen(false); tog.addEventListener('click',()=>setOpen(tog.getAttribute('aria-expanded')!=='true'));
  const f={ id:document.getElementById('c_id'), p:document.getElementById('c_prenom'), n:document.getElementById('c_nom'),
            m:document.getElementById('c_mail'), e:document.getElementById('c_entreprise'), t:document.getElementById('c_tel'),
            av:document.getElementById('c_avatar'), save:document.getElementById('c_save'), reset:document.getElementById('c_reset') };
  function fillForm(d){ f.id.value=d.id||''; f.p.value=d.prenom||''; f.n.value=d.nom||''; f.m.value=d.mail||''; f.e.value=d.entreprise||''; f.t.value=d.tel||''; f.av.value=''; f.save.textContent=d.id?'Mettre à jour':'Ajouter'; setOpen(true); }
  f.reset.addEventListener('click',()=>fillForm({}));
  f.save.addEventListener('click',async()=>{
    msg.textContent='Enregistrement...';
    const fd=new FormData();
    fd.append('form_contactcfg','1');
    fd.append('id',f.id.value.trim());
    fd.append('prenom',f.p.value.trim());
    fd.append('nom',f.n.value.trim());
    fd.append('mail',f.m.value.trim());
    fd.append('entreprise',f.e.value.trim());
    fd.append('tel',f.t.value.trim());
    if(f.av.files[0]) fd.append('avatar',f.av.files[0]);
    try{
      const r=await fetch('modules/contact/contact_process.php',{method:'POST',body:fd,credentials:'same-origin'});
      if(!r.ok) throw new Error('HTTP '+r.status);
      const j=await r.json().catch(()=>({ok:true}));
      if(!j.ok) throw new Error(j.error||'Échec');
      location.reload();
    }catch(e){msg.textContent='Erreur : '+e.message;}
  });
  document.querySelectorAll('.toolbtn.edit').forEach(b=>{
    b.addEventListener('click',()=>{
      const t=b.closest('.ctile');
      fillForm({id:t.dataset.id, prenom:t.dataset.prenom, nom:t.dataset.nom, mail:t.dataset.mail, entreprise:t.dataset.entreprise, tel:t.dataset.tel});
    });
  });
  document.querySelectorAll('.toolbtn.del').forEach(b=>{
    b.addEventListener('click',async()=>{
      if(!confirm('Supprimer ce contact ?')) return;
      const fd=new FormData(); fd.append('delete_contact_id', b.dataset.id);
      try{
        const r=await fetch('modules/contact/contact_process.php',{method:'POST',body:fd,credentials:'same-origin'});
        if(!r.ok) throw new Error('HTTP '+r.status);
        location.reload();
      }catch(e){ alert('Erreur : '+e.message); }
    });
  });
  const modal=document.getElementById('cModal');
  const back=modal.querySelector('.backdrop');
  const closeBtn=modal.querySelector('.cm-x');
  const mPic=document.getElementById('m_pic');
  const mTitle=document.getElementById('m_title');
  const mSub=document.getElementById('m_sub');
  const mEnt=document.getElementById('m_ent');
  const mMail=document.getElementById('m_mail');
  const mTel=document.getElementById('m_tel');
  function openModal(d){
    mTitle.textContent=[d.prenom,d.nom].filter(Boolean).join(' ')||'(Sans nom)';
    mSub.textContent=d.mail||'';
    mEnt.textContent=d.entreprise||'—';
    mMail.textContent=d.mail||'—'; mMail.href=d.mail?('mailto:'+d.mail):'#';
    mTel.textContent=d.tel||'—';   mTel.href=d.tel?('tel:'+d.tel.replace(/\s+/g,'')):'#';
    if(d.avatar){mPic.src=d.avatar; mPic.style.visibility='visible';} else {mPic.removeAttribute('src'); mPic.style.visibility='hidden';}
    modal.classList.add('on'); modal.setAttribute('aria-hidden','false');
  }
  function closeModal(){ modal.classList.remove('on'); modal.setAttribute('aria-hidden','true'); }
  back.addEventListener('click',closeModal); closeBtn.addEventListener('click',closeModal);
  window.addEventListener('keydown',e=>{ if(e.key==='Escape') closeModal(); });
  document.querySelectorAll('.ctile.contact-pop').forEach(t=>{
    t.addEventListener('click',()=>{
      openModal({prenom:t.dataset.prenom||'', nom:t.dataset.nom||'', mail:t.dataset.mail||'', entreprise:t.dataset.entreprise||'', tel:t.dataset.tel||'', avatar:t.dataset.avatar||''});
    });
  });
})();
</script>
