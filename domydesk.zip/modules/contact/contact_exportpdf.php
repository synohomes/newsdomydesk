<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) {
    http_response_code(403);
    exit("⛔ Accès refusé");
}
$dir = __DIR__ . "/../../users/profiles/$email/contact/";
$file = $dir . "contacts.json";
if (!file_exists($file)) exit("Aucun contact à exporter.");
$contacts = json_decode(file_get_contents($file), true);
if (!is_array($contacts)) $contacts = [];
require_once(__DIR__ . '/../../vendor/autoload.php');
use Mpdf\Mpdf;
$mpdf = new Mpdf();
$mpdf->SetTitle('Liste des contacts');
$html = "<h1>Liste des contacts</h1><table border='1' cellspacing='0' cellpadding='6'><thead><tr>
<th>Prénom</th><th>Nom</th><th>Email</th><th>Entreprise</th><th>Téléphone</th></tr></thead><tbody>";
foreach ($contacts as $c) {
    $html .= "<tr>
        <td>" . htmlspecialchars($c['prenom'] ?? '') . "</td>
        <td>" . htmlspecialchars($c['nom'] ?? '') . "</td>
        <td>" . htmlspecialchars($c['mail'] ?? '') . "</td>
        <td>" . htmlspecialchars($c['entreprise'] ?? '') . "</td>
        <td>" . htmlspecialchars($c['tel'] ?? '') . "</td>
    </tr>";
    if (!empty($c['custom']) && is_array($c['custom'])) {
        $html .= "<tr><td colspan='5'><ul>";
        foreach ($c['custom'] as $k => $v) {
            $html .= "<li><strong>" . htmlspecialchars($k) . "</strong> : " . htmlspecialchars($v) . "</li>";
        }
        $html .= "</ul></td></tr>";
    }
}
$html .= "</tbody></table>";
$mpdf->WriteHTML($html);
$mpdf->Output('contacts.pdf', 'D');
exit;
