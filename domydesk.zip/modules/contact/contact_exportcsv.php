<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) {
    http_response_code(403);
    exit("⛔ Accès refusé");
}
$dir = __DIR__ . "/../../users/profiles/$email/contact/";
$file = $dir . "contacts.json";
if (!file_exists($file)) exit("Aucun contact à exporter.");
$contacts = json_decode(file_get_contents($file), true);
if (!is_array($contacts)) $contacts = [];
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=contacts.csv');
$output = fopen('php://output', 'w');
$baseCols = ['ID', 'Prénom', 'Nom', 'Email', 'Entreprise', 'Téléphone'];
$customKeys = [];
foreach ($contacts as $c) {
    if (!empty($c['custom']) && is_array($c['custom'])) {
        foreach ($c['custom'] as $k => $v) $customKeys[$k] = true;
    }
}
$customCols = array_keys($customKeys);
fputcsv($output, array_merge($baseCols, $customCols));
foreach ($contacts as $c) {
    $row = [
        $c['id'] ?? '',
        $c['prenom'] ?? '',
        $c['nom'] ?? '',
        $c['mail'] ?? '',
        $c['entreprise'] ?? '',
        $c['tel'] ?? ''
    ];
    foreach ($customCols as $ck) $row[] = $c['custom'][$ck] ?? '';
    fputcsv($output, $row);
}
fclose($output);
exit;
