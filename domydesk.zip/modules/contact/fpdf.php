<?php
define('FPDF_VERSION', '1.82');
class FPDF
{
    protected $page;              
    protected $n;                  
    protected $offsets;          
    protected $buffer;          
    protected $pages;           
    protected $state;            
    protected $compress;
    protected $DefOrientation;
    protected $CurOrientation;
    protected $OrientationChanges = [];
    protected $k;
    protected $fwPt;
    protected $fhPt;
    protected $fw;
    protected $fh;
    protected $wPt;
    protected $hPt;
    protected $w;
    protected $h;
    protected $lMargin;
    protected $tMargin;
    protected $rMargin;
    protected $bMargin;
    protected $cMargin;
    protected $x;
    protected $y;
    protected $lasth;
    protected $LineWidth;
    protected $fontpath;
    protected $CoreFonts;
    protected $fonts;
    protected $FontFiles;
    protected $diffs;
    protected $FontFamily;
    protected $FontStyle;
    protected $underline;
    protected $CurrentFont;
    protected $FontSizePt;
    protected $FontSize;
    protected $DrawColor;
    protected $FillColor;
    protected $TextColor;
    protected $ColorFlag;
    protected $ws;
    protected $images;
    protected $PageLinks;
    protected $links;
    protected $AutoPageBreak;
    protected $PageBreakTrigger;
    protected $InHeader;
    protected $InFooter;
    protected $ZoomMode;
    protected $LayoutMode;
    protected $title;
    protected $subject;
    protected $author;
    protected $keywords;
    protected $creator;
    protected $AliasNbPages;
    protected $PDFVersion;

    function __construct($orientation='P', $unit='mm', $size='A4')
    {
        $this->CoreFonts = ['courier','helvetica','times','symbol','zapfdingbats'];
        $this->fonts = [];
        $this->FontFiles = [];
        $this->diffs = [];
        $this->images = [];
        $this->links = [];
        $this->pages = [];
        $this->OrientationChanges = [];
        $this->state = 0;
        $this->page = 0;
        $this->n = 2;
        $this->buffer = '';
        $this->pages = [];
        $this->OrientationChanges = [];
        $this->offsets = [];
        $this->compress = true;
        $this->k = ($unit == 'pt' ? 1 : ($unit == 'mm' ? 72/25.4 : ($unit == 'cm' ? 72/2.54 : 72)));
        $this->DefOrientation = $orientation;
        $this->CurOrientation = $orientation;
        $format = $this->_getpagesize($size);
        $this->fwPt = $format[0];
        $this->fhPt = $format[1];
        $this->fw = $this->fwPt/$this->k;
        $this->fh = $this->fhPt/$this->k;
        if ($orientation == 'P') {
            $this->wPt = $this->fwPt;
            $this->hPt = $this->fhPt;
            $this->w = $this->fw;
            $this->h = $this->fh;
        } else {
            $this->wPt = $this->fhPt;
            $this->hPt = $this->fwPt;
            $this->w = $this->fh;
            $this->h = $this->fw;
        }
        $this->lMargin = 10;
        $this->tMargin = 10;
        $this->rMargin = 10;
        $this->bMargin = 10;
        $this->cMargin = 1;
        $this->x = $this->lMargin;
        $this->y = $this->tMargin;
        $this->FontFamily = '';
        $this->FontStyle = '';
        $this->FontSizePt = 12;
        $this->underline = false;
        $this->DrawColor = '0 G';
        $this->FillColor = '0 g';
        $this->TextColor = '0 g';
        $this->ColorFlag = false;
        $this->ws = 0;
        $this->PDFVersion = '1.3';
    }

    function AddPage($orientation='', $size='')
    {
        $this->page++;
        $this->pages[$this->page] = '';
        $this->x = $this->lMargin;
        $this->y = $this->tMargin;
    }

    function SetFont($family, $style='', $size=0)
    {
        $this->FontFamily = strtolower($family);
        $this->FontStyle = $style;
        $this->FontSizePt = $size;
        $this->FontSize = $size / $this->k;
        $this->CurrentFont = ['cw'=>[], 'family'=>$this->FontFamily, 'style'=>$this->FontStyle];
    }

    function Cell($w, $h=0, $txt='', $border=0, $ln=0, $align='', $fill=false, $link='')
    {
        $this->pages[$this->page] .= $txt."\n";
    }

    function Output($dest='', $name='')
    {
        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="'.$name.'"');
        echo "%PDF-1.3\n";
        echo "1 0 obj\n<< /Type /Catalog >>\nendobj\n";
        echo "trailer\n<< /Root 1 0 R >>\n%%EOF";
    }

    function _getpagesize($size)
    {
        if (is_string($size)) {
            $size = strtolower($size);
            switch($size) {
                case 'a3': return [841.89,1190.55];
                case 'a4': return [595.28,841.89];
                case 'a5': return [420.94,595.28];
                case 'letter': return [612,792];
                case 'legal': return [612,1008];
                default: return [595.28,841.89];
            }
        } elseif (is_array($size)) {
            return $size;
        } else {
            return [595.28,841.89];
        }
    }
}
?>
