<?php
if (session_status() === PHP_SESSION_NONE) session_start();
error_reporting(E_ALL); ini_set('display_errors', 1);
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { echo "<div style='color:#f66'>⛔ Non connecté</div>"; return; }
$BASE = realpath(dirname(__DIR__, 2));
$DIR  = $BASE . "/users/profiles/$email/contact";
$AV   = $DIR . "/avatars";
$JSON = $DIR . "/contacts.json";
if (!is_dir($DIR) && !mkdir($DIR, 0775, true)) { echo "mkdir $DIR"; return; }
if (!is_dir($AV)  && !mkdir($AV,  0775, true)) { echo "mkdir $AV"; return; }
if (!file_exists($JSON) && file_put_contents($JSON, "[]") === false) { echo "create $JSON"; return; }
function read_contacts($file){ $raw=@file_get_contents($file); $a=$raw?json_decode($raw,true):[]; return is_array($a)?$a:[]; }
function write_contacts($file,$arr){
  $json = json_encode(array_values($arr), JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);
  if ($json===false) return false;
  $fp = fopen($file,'wb'); if(!$fp) return false;
  if(!flock($fp,LOCK_EX)){ fclose($fp); return false; }
  $ok = fwrite($fp,$json); fflush($fp); flock($fp,LOCK_UN); fclose($fp);
  clearstatcache(true,$file);
  return $ok!==false;
}
if (($_GET['api'] ?? '') === '1') {
  header('Content-Type: application/json; charset=utf-8');
  $contacts = read_contacts($JSON);
  $id         = ($_POST['id'] ?? '') ?: uniqid('c_', true);
  $prenom     = trim($_POST['prenom'] ?? '');
  $nom        = trim($_POST['nom'] ?? '');
  $mail       = trim($_POST['mail'] ?? '');
  $entreprise = trim($_POST['entreprise'] ?? '');
  $tel        = trim($_POST['tel'] ?? '');
  $avatar     = '';
  if (!empty($_FILES['avatar']['tmp_name']) && is_uploaded_file($_FILES['avatar']['tmp_name'])) {
    $ext = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
    if (!preg_match('/^(png|jpe?g|gif|webp)$/', $ext)) $ext = 'png';
    $name = uniqid('av_', true).'.'.$ext;
    if (move_uploaded_file($_FILES['avatar']['tmp_name'], $AV.'/'.$name)) $avatar = $name;
  }
  $found = false;
  foreach ($contacts as &$c) {
    if (($c['id'] ?? null) === $id) {
      $c['prenom']=$prenom; $c['nom']=$nom; $c['mail']=$mail; $c['entreprise']=$entreprise; $c['tel']=$tel;
      if ($avatar) $c['avatar']=$avatar;
      $found = true; break;
    }
  }
  unset($c);
  if (!$found) $contacts[] = ['id'=>$id,'prenom'=>$prenom,'nom'=>$nom,'mail'=>$mail,'entreprise'=>$entreprise,'tel'=>$tel,'avatar'=>$avatar];
  if (!write_contacts($JSON, $contacts)) { echo json_encode(['ok'=>false,'error'=>'WRITE']); exit; }
  echo json_encode(['ok'=>true,'count'=>count($contacts)]);
  exit;
}
$contacts = read_contacts($JSON);
$action   = htmlspecialchars($_SERVER['PHP_SELF'] . (strpos($_SERVER['QUERY_STRING'] ?? '', 'module=') !== false ? '?'.$_SERVER['QUERY_STRING'].'&api=1' : '?api=1'));
?>

<iframe name="contact_iframe" style="display:none"></iframe>
<form id="contactApiForm" action="<?= $action ?>" method="post" enctype="multipart/form-data" target="contact_iframe"></form>
<div class="section" id="contactcfg">
  <div id="contactcfg-toggle" class="collapser" aria-expanded="false" style="display:flex;align-items:center;gap:10px;cursor:pointer;user-select:none;">
    <h2 style="margin:0;flex:1;">CONTACTS</h2>
    <span id="contactcfg-caret" style="display:inline-block;transition:transform .2s ease;">▾</span>
  </div>
  <div id="contactcfg-panel" style="overflow:hidden;transition:max-height .28s ease;max-height:0;">
    <div style="margin-top:12px;display:grid;grid-template-columns:1fr 1fr;gap:10px;">
      <input type="hidden" name="id" form="contactApiForm" value="">
      <input type="text" name="prenom" placeholder="Prénom" required form="contactApiForm" style="padding:8px;">
      <input type="text" name="nom" placeholder="Nom" required form="contactApiForm" style="padding:8px;">
      <input type="email" name="mail" placeholder="Email" required form="contactApiForm" style="padding:8px;">
      <input type="text" name="entreprise" placeholder="Entreprise" form="contactApiForm" style="padding:8px;">
      <input type="text" name="tel" placeholder="Téléphone" form="contactApiForm" style="padding:8px;">
      <input type="file" name="avatar" accept="image/*" form="contactApiForm" style="padding:6px;">
      <div style="grid-column:1/-1;display:flex;gap:8px;justify-content:flex-end;">
        <button type="button" onclick="document.getElementById('contactApiForm').submit()">Enregistrer</button>
      </div>
      <div id="contactMsg" style="grid-column:1/-1;font:12px monospace;"></div>
    </div>
  </div>
</div>
<script>
(()=> {
  const t=document.getElementById('contactcfg-toggle');
  const p=document.getElementById('contactcfg-panel');
  const c=document.getElementById('contactcfg-caret');
  const msg=document.getElementById('contactMsg');
  function setOpen(x){ t.setAttribute('aria-expanded',x?'true':'false'); c.style.transform=x?'rotate(180deg)':'rotate(0deg)'; p.style.maxHeight=x? (p.scrollHeight+'px') : '0px'; }
  setOpen(false);
  t.addEventListener('click', ()=> setOpen(t.getAttribute('aria-expanded')!=='true'));
  const ifr=document.getElementsByName('contact_iframe')[0];
  ifr.addEventListener('load', ()=>{
    try{
      const txt=ifr.contentDocument.body.innerText||'';
      if(!txt) return;
      const j=JSON.parse(txt);
      if(j.ok) location.reload();
      else msg.textContent='Erreur API: '+(j.error||'inconnue');
    }catch(e){
      msg.textContent=ifr.contentDocument.body.innerText||'Réponse non JSON';
    }
  });
})();
</script>
<div class="section">
  <h3>📋 CONTACTS (<?= count($contacts) ?>)</h3>
  <div style="display:flex;flex-wrap:wrap;gap:10px;">
    <?php foreach ($contacts as $c): ?>
      <div style="flex:1 1 220px;min-width:200px;max-width:250px;background:#fff;padding:6px 8px;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.08);border:1px solid #ccc;display:flex;align-items:center;gap:6px;position:relative;height:70px;">
        <?php if (!empty($c['avatar']) && file_exists($AV.'/'.$c['avatar'])): ?>
          <img src="users/profiles/<?= htmlspecialchars($email) ?>/contact/avatars/<?= htmlspecialchars($c['avatar']) ?>" style="width:36px;height:36px;border-radius:50%;object-fit:cover">
        <?php else: ?>
          <div style="width:36px;height:36px;border-radius:50%;background:#ddd;display:flex;align-items:center;justify-content:center;font-size:12px;">-</div>
        <?php endif; ?>
        <div style="flex:1;font-size:12.5px;line-height:1.3;overflow:hidden;">
          <strong style="display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
            <?= htmlspecialchars(($c['prenom'] ?? '') . ' ' . ($c['nom'] ?? '')) ?>
          </strong>
          <div style="color:#666;font-size:11.5px"><?= htmlspecialchars($c['entreprise'] ?? '') ?></div>
          <div style="color:#0077cc;font-size:11.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
            <a href="mailto:<?= htmlspecialchars($c['mail'] ?? '') ?>" style="color:#0077cc;text-decoration:none">
              <?= htmlspecialchars($c['mail'] ?? '') ?>
            </a>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
    <?php if (empty($contacts)): ?><p>Aucun contact enregistré.</p><?php endif; ?>
  </div>
</div>
