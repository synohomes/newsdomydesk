<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: text/plain; charset=utf-8');

/* ---- Admin only ---- */
if (($_SESSION['user']['role_system'] ?? '') !== 'admin') {
    http_response_code(403);
    exit("⛔ Accès refusé (admin requis).");
}

/* ---- ID du module ---- */
$raw = $_GET['id'] ?? $_POST['id'] ?? $_POST['module_id'] ?? '';
$raw = trim((string)$raw);
if ($raw === '') {
    http_response_code(400);
    exit("⛔ ID module manquant (paramètre id/module_id).");
}
$id = strtolower(basename($raw));
$DEBUG = isset($_GET['debug']) || isset($_POST['debug']);

/* ---- Chemins ---- */
$modulesDir  = realpath(__DIR__);          // .../domydesk/modules
$baseDir     = dirname($modulesDir);       // .../domydesk
$listPath    = $modulesDir . '/list.json';
$profilesDir = $baseDir   . '/users/profiles';
$moduleDir   = $modulesDir . '/' . $id;

/* ---- Utils ---- */
function load_json_safe($p){
    $t = @file_get_contents($p);
    if ($t === false) return [];
    $j = json_decode($t, true);
    return is_array($j) ? $j : [];
}
function save_json_safe($p,$arr){
    @file_put_contents($p, json_encode($arr, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE), LOCK_EX);
    @chmod($p, 0666);
}
function rrmdir_simple($dir){
    if (!is_dir($dir)) return;
    foreach (array_diff(scandir($dir), ['.', '..']) as $it){
        $path = $dir . '/' . $it;
        if (is_dir($path)) rrmdir_simple($path); else @unlink($path);
    }
    @rmdir($dir);
}

/* ---- Debug ---- */
if ($DEBUG) {
    echo ">> DEBUG ON\nID: $id\n";
    echo "list.json     : " . (realpath($listPath) ?: $listPath) . "\n";
    echo "profiles dir  : " . (realpath($profilesDir) ?: $profilesDir) . "\n";
    echo "modules dir   : " . (realpath($modulesDir) ?: $modulesDir) . "\n\n";
}

/* ---- 1) list.json ---- */
$removedGlobal = 0;
if (is_file($listPath)){
    $list = load_json_safe($listPath);
    $new = [];
    foreach ($list as $row){
        $rid  = strtolower(trim($row['id'] ?? ''));
        $icon = strtolower(trim($row['icon'] ?? ''));
        $match = ($rid === $id) || ($icon && strpos($icon, '/'.$id.'/') !== false);
        if (!$match) $new[] = $row;
    }
    $removedGlobal = count($list) - count($new);
    save_json_safe($listPath, $new);
}

/* ---- 2) users/*/modules.json ---- */
$removedUsers = 0;
if (is_dir($profilesDir)){
    foreach (glob($profilesDir . '/*', GLOB_ONLYDIR) as $ud){
        $mf = $ud . '/modules.json';
        if (!is_file($mf)) continue;
        $mods = load_json_safe($mf);
        $new  = [];
        foreach ($mods as $row){
            $rid = strtolower(trim($row['id'] ?? ''));
            if ($rid !== $id) $new[] = $row;
        }
        if (count($new) !== count($mods)){
            save_json_safe($mf, $new);
            $removedUsers++;
        }
    }
}

/* ---- 3) dossier du module ---- */
if (is_dir($moduleDir)) rrmdir_simple($moduleDir);

/* ---- Résumé ---- */
echo "✅ Suppression terminée pour l’ID \"$id\".\n";
echo "- list.json: " . ($removedGlobal ? "entrée supprimée" : "aucune entrée trouvée") . "\n";
echo "- modules.json utilisateurs modifiés: $removedUsers\n";
