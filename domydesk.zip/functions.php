<?php
function getUserProfile($email) {
    $profilePath = "users/profiles/" . $email . "/profile.json";
    if (file_exists($profilePath)) {
        $profileJson = file_get_contents($profilePath);
        return json_decode($profileJson, true);
    } else {
        return null;
    }
}
function isLoggedIn() {
    return isset($_SESSION['user']) && isset($_SESSION['user']['email']);
}
function redirectIfNotLoggedIn() {
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit;
    }
}
function logout() {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit;
}
?>
