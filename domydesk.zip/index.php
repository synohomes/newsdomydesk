<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>DoMyDesk - DEV</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="theme/default/style.css">
</head>
<body>
<?php include 'header.php'; ?>
<div style="height: 5px;"></div>
<main>
    <!-- SECTION ACTUALITÉS -->
    <div class="section">
        <h2>Actualités</h2>
        <div id="news-container">Chargement des actualités...</div>
        <div class="pagination">
            <button id="prev-btn" disabled>Précédent</button>
            <button id="next-btn" disabled>Suivant</button>
        </div>
    </div>
</main>
<style>
    main {
        margin-top: 5px;
    }
</style>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const url = "data/news/news.php";
    const container = document.getElementById('news-container');
    const prevBtn = document.getElementById('prev-btn');
    const nextBtn = document.getElementById('next-btn');
    const itemsPerPage = 4;
    let newsData = [];
    let currentPage = 1;

    function renderPage(page) {
        container.innerHTML = '';
        const start = (page - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        const currentNews = newsData.slice(start, end);

        currentNews.forEach(news => {
            const auteur = (news.auteur || (news.titre && news.titre.toLowerCase().includes("domydesk"))) ?
                ` — ✍️ <i>écrit par</i> <b>${news.auteur || "DoMyDesk"}</b>` : "";

            const newsHTML = `
                <div class="news-item">
                    <div class="news-title">${news.titre}</div>
                    <div class="news-subtitle">${news.soustitre}</div>
                    <div class="news-date">📅 ${news.date}${auteur}</div>
                    <div class="news-description">${news.description}</div>
                </div>
            `;
            container.innerHTML += newsHTML;
        });

        prevBtn.disabled = page === 1;
        nextBtn.disabled = end >= newsData.length;
    }

    prevBtn.addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage--;
            renderPage(currentPage);
        }
    });

    nextBtn.addEventListener('click', () => {
        if ((currentPage * itemsPerPage) < newsData.length) {
            currentPage++;
            renderPage(currentPage);
        }
    });

    fetch(url)
        .then(response => {
            if (!response.ok) throw new Error("Erreur de chargement du fichier JSON.");
            return response.json();
        })
        .then(data => {
            if (Array.isArray(data)) {
                newsData = data;
                renderPage(currentPage);
            } else if (data.error) {
                container.innerHTML = `<div style="color:red">⚠ ${data.error}</div>`;
            }
        })
        .catch(error => {
            container.innerHTML = "<div style='color:red'>Impossible de charger les actualités.</div>";
            console.error(error);
        });
});
</script>
</body>
</html>
