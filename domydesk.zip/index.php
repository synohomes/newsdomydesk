<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>DoMyDesk - Index</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="theme/default/style.css">
  <style>
    main{margin-top:8px}
    .section{background:var(--dms-card, #161616); border:1px solid var(--primary-color,#6cf); border-radius:10px; padding:12px}
    .news-item{border-top:1px solid rgba(255,255,255,.08); padding:10px 0}
    .news-item:first-child{border-top:0}
    .news-title{font-weight:600}
    .news-subtitle{opacity:.85; margin-top:2px}
    .news-meta{opacity:.7; font-size:.95em; margin-top:4px}
    .news-description{margin-top:6px}
    .pagination{display:flex; gap:8px; margin-top:12px}
    .pagination button{background:#1f1f1f; border:1px solid #333; border-radius:6px; padding:6px 10px; color:#eee}
    .muted{opacity:.75}
  </style>
</head>
<body>
<?php include 'header.php'; ?>
<main>
  <div class="section" aria-labelledby="actu-title">
    <h2 id="actu-title">Actualités</h2>
    <div id="news-container" class="muted">Chargement…</div>
    <div class="pagination">
      <button id="prev-btn" disabled>Précédent</button>
      <button id="next-btn" disabled>Suivant</button>
    </div>
  </div>
</main>
<script>
document.addEventListener('DOMContentLoaded', () => {
  const url = 'data/news/news.php';
  const container = document.getElementById('news-container');
  const prevBtn = document.getElementById('prev-btn');
  const nextBtn = document.getElementById('next-btn');

  const PAR_PAGE = 4;
  let data = [];
  let page = 1;

  function render(pageIndex){
    container.innerHTML = '';
    if (!data.length){
      container.innerHTML = '<div class="muted">Aucune actualité.</div>';
      prevBtn.disabled = true;
      nextBtn.disabled = true;
      return;
    }
    const start = (pageIndex - 1) * PAR_PAGE;
    const slice = data.slice(start, start + PAR_PAGE);

    slice.forEach(n => {
      const auteur = n.auteur ? ` — ${n.auteur}` : '';
      const html = `
        <div class="news-item">
          <div class="news-title">${escapeHTML(n.titre || '')}</div>
          <div class="news-subtitle">${escapeHTML(n.soustitre || '')}</div>
          <div class="news-meta">${escapeHTML(n.date || '')}${escapeHTML(auteur)}</div>
          <div class="news-description">${escapeHTML(n.description || '')}</div>
        </div>`;
      container.insertAdjacentHTML('beforeend', html);
    });

    prevBtn.disabled = pageIndex === 1;
    nextBtn.disabled = (pageIndex * PAR_PAGE) >= data.length;
  }

  function escapeHTML(s){
    return String(s)
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;')
      .replace(/'/g,'&#039;');
  }

  prevBtn.addEventListener('click', () => { if (page > 1){ page--; render(page); } });
  nextBtn.addEventListener('click', () => { if (page * PAR_PAGE < data.length){ page++; render(page); } });

  fetch(url)
    .then(r => { if(!r.ok) throw new Error('load'); return r.json(); })
    .then(json => { data = Array.isArray(json) ? json : []; render(page); })
    .catch(() => { container.innerHTML = '<div style="color:#e66">Impossible de charger les actualités.</div>'; });
});
</script>
</body>
</html>
