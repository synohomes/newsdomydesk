<?php
session_start();

function json_read(string $file, $fallback) {
    if (!is_file($file)) {
        return $fallback;
    }

    $raw = file_get_contents($file);
    $data = json_decode($raw, true);

    return (json_last_error() === JSON_ERROR_NONE && is_array($data)) ? $data : $fallback;
}

function h($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/* ==========================================================
   Thème utilisateur
   Source : users/profiles/[email]/theme.json
   CSS chargé : theme/[theme]/style.css
   Fallback : theme/default/style.css
   ========================================================== */

$theme = 'default';

if (!empty($_SESSION['user']['email'])) {
    $email = $_SESSION['user']['email'];
    $userDir = __DIR__ . '/users/profiles/' . $email;

    $themeJson = $userDir . '/theme.json';

    if (is_file($themeJson)) {
        $themeData = json_read($themeJson, []);

        if (
            !empty($themeData['theme']) &&
            is_file(__DIR__ . '/theme/' . basename($themeData['theme']) . '/style.css')
        ) {
            $theme = basename($themeData['theme']);
        }
    } else {
        $profileFile = $userDir . '/profile.json';

        if (is_file($profileFile)) {
            $profileData = json_read($profileFile, []);

            if (
                !empty($profileData['theme']) &&
                is_file(__DIR__ . '/theme/' . basename($profileData['theme']) . '/style.css')
            ) {
                $theme = basename($profileData['theme']);
            }
        }
    }
}

/* ==========================================================
   Configuration de l'accueil
   Source : data/indexcfg.json
   ========================================================== */

$defaultConfig = [
    'hero' => [
        'eyebrow' => 'Bureau web modulaire',
        'title' => 'Pilote ton univers numérique',
        'title_span' => 'depuis un seul endroit.',
        'lead' => 'DoMyDesk rassemble tes modules, tes outils, tes services et tes informations dans une interface claire, rapide et personnalisable selon ton thème.',
        'buttons' => [
            [
                'label' => 'Se connecter',
                'url' => 'login.php',
                'class' => 'primary'
            ],
            [
                'label' => 'Créer un compte',
                'url' => 'register.php',
                'class' => ''
            ],
            [
                'label' => 'Voir les vidéos',
                'url' => 'https://www.youtube.com/watch?v=E3nn6WN2faM&list=PLqtzZSNg-E8BiDME_SGllHBiOmtL7KIDM',
                'class' => ''
            ]
        ]
    ],
    'visual' => [
        'enabled' => true,
        'windows' => [
            [
                'lines' => ['big', 'mid', 'small']
            ],
            [
                'lines' => ['big', '', 'mid']
            ],
            [
                'lines' => ['big', 'small']
            ]
        ]
    ],
    'stats' => [
        [
            'value' => '100%',
            'text' => 'Interface web depuis navigateur.'
        ],
        [
            'value' => '0 DB',
            'text' => 'Logique simple par fichiers.'
        ],
        [
            'value' => 'Modules',
            'text' => 'Activation selon les besoins.'
        ],
        [
            'value' => 'Thèmes',
            'text' => 'Style utilisateur respecté.'
        ]
    ],
    'features_panel' => [
        'kicker' => 'Centre de contrôle',
        'title' => 'Tout est pensé pour aller vite.',
        'description' => 'Une page d’accueil propre, utile et cohérente avec DoMyDesk.',
        'features' => [
            [
                'icon' => '▦',
                'title' => 'Modules à la carte',
                'text' => 'Active uniquement ce dont tu as besoin et garde un bureau propre.'
            ],
            [
                'icon' => '◈',
                'title' => 'Thème respecté',
                'text' => 'La page utilise les variables du thème, sans imposer une couleur fixe.'
            ],
            [
                'icon' => '⚙',
                'title' => 'Accès rapide',
                'text' => 'Bureau, modules et paramètres restent accessibles dès l’accueil.'
            ]
        ]
    ],
    'news_panel' => [
        'kicker' => 'Actualités',
        'title' => 'Dernières nouvelles',
        'description' => 'Les informations publiées dans data/news/news.php.'
    ],
    'mini_footer' => 'DoMyDesk reste simple : un bureau web, des modules, des thèmes, et une interface pensée pour évoluer.'
];

$configFile = __DIR__ . '/data/indexcfg.json';
$config = json_read($configFile, $defaultConfig);

$hero = array_replace_recursive($defaultConfig['hero'], $config['hero'] ?? []);
$visual = array_replace_recursive($defaultConfig['visual'], $config['visual'] ?? []);
$stats = $config['stats'] ?? $defaultConfig['stats'];
$featuresPanel = array_replace_recursive($defaultConfig['features_panel'], $config['features_panel'] ?? []);
$newsPanel = array_replace_recursive($defaultConfig['news_panel'], $config['news_panel'] ?? []);
$miniFooter = $config['mini_footer'] ?? $defaultConfig['mini_footer'];

if (!is_array($stats) || empty($stats)) {
    $stats = $defaultConfig['stats'];
}

if (empty($hero['buttons']) || !is_array($hero['buttons'])) {
    $hero['buttons'] = $defaultConfig['hero']['buttons'];
}

if (empty($visual['windows']) || !is_array($visual['windows'])) {
    $visual['windows'] = $defaultConfig['visual']['windows'];
}

if (empty($featuresPanel['features']) || !is_array($featuresPanel['features'])) {
    $featuresPanel['features'] = $defaultConfig['features_panel']['features'];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>DoMyDesk</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- CSS du thème choisi par l'utilisateur -->
    <link rel="stylesheet" href="theme/<?= h($theme) ?>/style.css">
</head>

<body>
<?php include 'header.php'; ?>

<main class="dmd-home">
    <section class="hero" aria-labelledby="home-title">
        <div>
            <?php if (!empty($hero['eyebrow'])): ?>
                <p class="eyebrow"><?= h($hero['eyebrow']) ?></p>
            <?php endif; ?>

            <h1 id="home-title">
                <?= h($hero['title'] ?? '') ?>

                <?php if (!empty($hero['title_span'])): ?>
                    <span><?= h($hero['title_span']) ?></span>
                <?php endif; ?>
            </h1>

            <?php if (!empty($hero['lead'])): ?>
                <p class="hero-lead">
                    <?= nl2br(h($hero['lead'])) ?>
                </p>
            <?php endif; ?>

            <?php if (!empty($hero['buttons']) && is_array($hero['buttons'])): ?>
                <div class="hero-actions">
                    <?php foreach ($hero['buttons'] as $button): ?>
                        <?php
                        if (!is_array($button)) {
                            continue;
                        }

                        $label = trim((string)($button['label'] ?? ''));
                        $url = trim((string)($button['url'] ?? ''));
                        $class = trim((string)($button['class'] ?? ''));

                        if ($label === '' || $url === '') {
                            continue;
                        }

                        $allowedClass = $class === 'primary' ? ' primary' : '';
                        ?>
                        <a class="home-btn<?= h($allowedClass) ?>" href="<?= h($url) ?>">
                            <?= h($label) ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <?php if (!empty($visual['enabled'])): ?>
            <div class="hero-visual" aria-hidden="true">
                <?php foreach ($visual['windows'] as $window): ?>
                    <?php
                    if (!is_array($window)) {
                        continue;
                    }

                    $lines = $window['lines'] ?? [];

                    if (!is_array($lines) || empty($lines)) {
                        continue;
                    }
                    ?>

                    <div class="mock-window">
                        <div class="mock-top">
                            <span class="dot"></span>
                            <span class="dot"></span>
                            <span class="dot"></span>
                        </div>

                        <div class="mock-body">
                            <?php foreach ($lines as $line): ?>
                                <?php
                                $line = trim((string)$line);
                                $allowed = ['', 'big', 'mid', 'small'];

                                if (!in_array($line, $allowed, true)) {
                                    $line = '';
                                }

                                $lineClass = $line !== '' ? ' ' . $line : '';
                                ?>
                                <div class="mock-line<?= h($lineClass) ?>"></div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <?php if (!empty($stats) && is_array($stats)): ?>
        <section class="stats" aria-label="Points forts DoMyDesk">
            <?php foreach ($stats as $stat): ?>
                <?php
                if (!is_array($stat)) {
                    continue;
                }

                $value = trim((string)($stat['value'] ?? ''));
                $text = trim((string)($stat['text'] ?? ''));

                if ($value === '' && $text === '') {
                    continue;
                }
                ?>

                <article class="stat">
                    <?php if ($value !== ''): ?>
                        <strong><?= h($value) ?></strong>
                    <?php endif; ?>

                    <?php if ($text !== ''): ?>
                        <span><?= h($text) ?></span>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <div class="home-grid">
        <section class="panel" aria-labelledby="features-title">
            <div class="panel-head">
                <?php if (!empty($featuresPanel['kicker'])): ?>
                    <p class="panel-kicker"><?= h($featuresPanel['kicker']) ?></p>
                <?php endif; ?>

                <?php if (!empty($featuresPanel['title'])): ?>
                    <h2 class="panel-title" id="features-title"><?= h($featuresPanel['title']) ?></h2>
                <?php endif; ?>

                <?php if (!empty($featuresPanel['description'])): ?>
                    <p class="panel-desc"><?= h($featuresPanel['description']) ?></p>
                <?php endif; ?>
            </div>

            <?php if (!empty($featuresPanel['features']) && is_array($featuresPanel['features'])): ?>
                <div class="feature-list">
                    <?php foreach ($featuresPanel['features'] as $feature): ?>
                        <?php
                        if (!is_array($feature)) {
                            continue;
                        }

                        $icon = trim((string)($feature['icon'] ?? ''));
                        $title = trim((string)($feature['title'] ?? ''));
                        $text = trim((string)($feature['text'] ?? ''));

                        if ($icon === '' && $title === '' && $text === '') {
                            continue;
                        }
                        ?>

                        <article class="feature">
                            <?php if ($icon !== ''): ?>
                                <div class="ico"><?= h($icon) ?></div>
                            <?php endif; ?>

                            <div>
                                <?php if ($title !== ''): ?>
                                    <h3><?= h($title) ?></h3>
                                <?php endif; ?>

                                <?php if ($text !== ''): ?>
                                    <p><?= h($text) ?></p>
                                <?php endif; ?>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <section class="panel" aria-labelledby="actu-title">
            <div class="panel-head">
                <?php if (!empty($newsPanel['kicker'])): ?>
                    <p class="panel-kicker"><?= h($newsPanel['kicker']) ?></p>
                <?php endif; ?>

                <?php if (!empty($newsPanel['title'])): ?>
                    <h2 class="panel-title" id="actu-title"><?= h($newsPanel['title']) ?></h2>
                <?php endif; ?>

                <?php if (!empty($newsPanel['description'])): ?>
                    <p class="panel-desc">
                        <?= h($newsPanel['description']) ?>
                    </p>
                <?php endif; ?>
            </div>

            <div class="news-toolbar">
                <span class="news-count" id="news-count">Chargement…</span>
            </div>

            <div id="news-container">
                <div class="loading-state">Chargement des actualités…</div>
            </div>

            <div class="pagination">
                <span class="page-indicator" id="page-indicator">Page 1</span>

                <div class="pagination-actions">
                    <button id="prev-btn" type="button" disabled>Précédent</button>
                    <button id="next-btn" type="button" disabled>Suivant</button>
                </div>
            </div>
        </section>
    </div>

    <?php if (!empty($miniFooter)): ?>
        <div class="mini-footer">
            <?= h($miniFooter) ?>
        </div>
    <?php endif; ?>
</main>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const url = 'data/news/news.php';

    const container = document.getElementById('news-container');
    const count = document.getElementById('news-count');
    const indicator = document.getElementById('page-indicator');
    const prevBtn = document.getElementById('prev-btn');
    const nextBtn = document.getElementById('next-btn');

    const PAR_PAGE = 4;

    let data = [];
    let page = 1;

    function escapeHTML(s) {
        return String(s ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function render() {
        container.innerHTML = '';

        if (!data.length) {
            container.innerHTML = '<div class="empty-state">Aucune actualité pour le moment.</div>';
            count.textContent = '0 actualité';
            indicator.textContent = 'Page 1';
            prevBtn.disabled = true;
            nextBtn.disabled = true;
            return;
        }

        const totalPages = Math.max(1, Math.ceil(data.length / PAR_PAGE));
        const slice = data.slice((page - 1) * PAR_PAGE, page * PAR_PAGE);

        slice.forEach(n => {
            const auteur = n.auteur
                ? `<span class="news-pill">${escapeHTML(n.auteur)}</span>`
                : '';

            container.insertAdjacentHTML(
                'beforeend',
                `
                <article class="news-card">
                    <h3 class="news-title">${escapeHTML(n.titre || 'Actualité')}</h3>
                    <div class="news-subtitle">${escapeHTML(n.soustitre || '')}</div>
                    <div class="news-meta">
                        <span class="news-pill">${escapeHTML(n.date || '')}</span>
                        ${auteur}
                    </div>
                    <p class="news-description">${escapeHTML(n.description || '')}</p>
                </article>
                `
            );
        });

        count.textContent = data.length + (data.length > 1 ? ' actualités' : ' actualité');
        indicator.textContent = `Page ${page} / ${totalPages}`;

        prevBtn.disabled = page <= 1;
        nextBtn.disabled = page >= totalPages;
    }

    prevBtn.addEventListener('click', () => {
        if (page > 1) {
            page--;
            render();
        }
    });

    nextBtn.addEventListener('click', () => {
        if (page * PAR_PAGE < data.length) {
            page++;
            render();
        }
    });

    fetch(url, {
        cache: 'no-store'
    })
        .then(r => {
            if (!r.ok) {
                throw new Error('load');
            }

            return r.json();
        })
        .then(json => {
            data = Array.isArray(json) ? json : [];
            render();
        })
        .catch(() => {
            container.innerHTML = '<div class="error-state">Impossible de charger les actualités.</div>';
            count.textContent = 'Erreur de chargement';
            prevBtn.disabled = true;
            nextBtn.disabled = true;
        });
});
</script>

</body>
</html>