<?php
set_time_limit(0);
echo "<pre>🔧 DOCKER / NAS / WINDOWS / LINUX — FIX PERMISSIONS...\n";
$base = realpath(__DIR__);
$totalFiles = 0;
$totalDirs = 0;
function fixAll($path) {
    global $totalFiles, $totalDirs;
    $rii = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($rii as $item) {
        $pathName = $item->getPathname();
        if ($item->isDir()) {
            if (@chmod($pathName, 0775)) {
                $totalDirs++;
            } else {
                echo "❌ DIR FAIL : $pathName\n";
            }
        } else {
            if (@chmod($pathName, 0664)) {
                $totalFiles++;
            } else {
                echo "❌ FILE FAIL : $pathName\n";
            }
        }
    }
}
fixAll($base);
echo "CORRECTION TERMINÉE : $totalDirs dossiers, $totalFiles fichiers.\n</pre>";
?>
