<?php
session_start();
if (!isset($_SESSION['user']['email'])) {
    die("❌ Vous devez être connecté pour accéder à cette page.");
}
$email = $_SESSION['user']['email'];
$userPath = __DIR__ . "/../users/profiles/$email";
$profileFile = "$userPath/profile.json";
if (!is_dir($userPath)) {
    mkdir($userPath, 0777, true);
}
$data = file_exists($profileFile) ? json_decode(file_get_contents($profileFile), true) : [];
$data['role'] = 'admin';
file_put_contents($profileFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
chmod($profileFile, 0666);
$_SESSION['user']['role'] = 'admin';
echo "✅ Le rôle 'admin' a été attribué à <strong>$email</strong>.<br>";
echo "<a href='../domydesk/adm/market/marketmodules.php'>➡️ Accéder au Market des modules</a>";
