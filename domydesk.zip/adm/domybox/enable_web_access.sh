#!/bin/bash
FILE=/etc/sudoers.d/domybox_web_access
cat > $FILE <<EOF
www-data ALL=(ALL) NOPASSWD: /var/www/html/domydesk/adm/domybox/rename_box.sh
www-data ALL=(ALL) NOPASSWD: /var/www/html/domydesk/adm/domybox/change_pass.sh
www-data ALL=(ALL) NOPASSWD: /var/www/html/domydesk/adm/domybox/set_wifi.sh
www-data ALL=(ALL) NOPASSWD: /var/www/html/domydesk/adm/domybox/disable_web_access.sh
EOF
chmod 440 $FILE
