#!/bin/bash
SSID="$1"
WIFIPASS="$2"
cat > /etc/wpa_supplicant/wpa_supplicant.conf <<EOF
ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev
update_config=1
country=FR
network={
    ssid="$SSID"
    psk="$WIFIPASS"
}
EOF
wpa_cli -i wlan0 reconfigure
