#!/bin/bash
echo "domydesk:$1" | chpasswd
