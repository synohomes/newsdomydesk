#!/bin/bash
rm -f /etc/sudoers.d/domybox_web_access
