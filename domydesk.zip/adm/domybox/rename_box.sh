#!/bin/bash
NEW="$1"
echo "$NEW" >/etc/hostname
sed -i "s/127.0.1.1.*/127.0.1.1\t$NEW/" /etc/hosts
hostnamectl set-hostname "$NEW"
