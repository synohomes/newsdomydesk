<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';

dmd_api_require_method('POST');
$payload=dmd_json_body(array());
dmd_api_require_csrf('agent_admin',$payload);

dmd_json_response(array(
    'ok'=>true,
    'audits'=>dmd_agent_list_backup_activity_audits(300),
));
