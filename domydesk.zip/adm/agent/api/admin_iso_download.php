<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
require_once dirname(__DIR__) . '/includes/iso_repository.php';
dmd_api_require_method('GET');
$id=(string)($_GET['id'] ?? '');
if(!preg_match('/^[a-f0-9]{24}$/D',$id)) { http_response_code(404); exit; }
$state=dmd_iso_state();
if(!isset($state[$id])) { http_response_code(404); exit; }
$path=dmd_iso_file($id);
if(!is_file($path)||is_link($path)) { http_response_code(404); exit; }
$f=fopen($path,'rb');
if(!$f) { http_response_code(404); exit; }
$size=(int)filesize($path); $start=0; $end=$size-1;
session_write_close(); @set_time_limit(0);
while(ob_get_level()>0) @ob_end_clean();
header('Content-Type: application/x-iso9660-image'); header('Accept-Ranges: bytes');
header('X-Content-Type-Options: nosniff'); header('Cache-Control: private, no-store');
$name=basename(str_replace('\\','/',(string)$state[$id]['name']));
header("Content-Disposition: attachment; filename=\"DMD-Recovery.iso\"; filename*=UTF-8''".rawurlencode($name));
if(isset($_SERVER['HTTP_RANGE'])) {
    $range=$_SERVER['HTTP_RANGE'];
    if(!preg_match('/^bytes=(\d*)-(\d*)$/D',$range,$m)||($m[1]===''&&$m[2]==='')) { http_response_code(416); header('Content-Range: bytes */'.$size); fclose($f); exit; }
    if($m[1]==='') {$start=max(0,$size-(int)$m[2]);} else {$start=(int)$m[1];if($m[2]!=='')$end=min($end,(int)$m[2]);}
    if($start>$end||$start>=$size) { http_response_code(416);header('Content-Range: bytes */'.$size);fclose($f);exit; }
    http_response_code(206); header("Content-Range: bytes $start-$end/$size");
}
header('Content-Length: '.($end-$start+1));
fseek($f,$start); $left=$end-$start+1;
while($left>0&&!connection_aborted()) {$chunk=fread($f,min(1048576,$left));if($chunk===false||$chunk==='')break;echo $chunk;$left-=strlen($chunk);flush();}
fclose($f);
