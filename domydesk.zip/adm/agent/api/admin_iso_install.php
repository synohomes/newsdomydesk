<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
require_once dirname(__DIR__) . '/includes/iso_repository.php';
dmd_api_require_method('POST');
$body=dmd_json_body(array());
dmd_api_require_csrf('agent_admin',$body);
$key=(string)($body['key'] ?? '');
$replace=(string)($body['replace_id'] ?? '');
if(!preg_match('/^[a-f0-9]{64}$/D',$key) || ($replace!=='' && !preg_match('/^[a-f0-9]{24}$/D',$replace))) dmd_json_response(array('ok'=>false,'error'=>'Sélection ISO invalide.'),400);
session_write_close();
@set_time_limit(0); ignore_user_abort(true);
@ini_set('zlib.output_compression','0');
while(ob_get_level()>0) @ob_end_flush();
header('Content-Type: application/x-ndjson; charset=utf-8');
header('Cache-Control: no-store'); header('X-Accel-Buffering: no');
function dmd_iso_event($stage,$message,$extra=array()) { echo json_encode(array_merge(array('stage'=>$stage,'message'=>$message),$extra),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n"; @flush(); }
$lock=null; $tmp=''; $published=''; $committed=false;
try {
    if(PHP_INT_SIZE<8) throw new RuntimeException('PHP 64 bits requis pour les ISO.');
    if(!dmd_agent_repo_ensure_dir(dmd_iso_dir()) || !dmd_agent_repo_ensure_dir(dmd_agent_repo_state_dir())) throw new RuntimeException('Dossier iso non accessible en écriture.');
    $lock=fopen(dmd_agent_repo_state_dir().'/iso-download.lock','c+');
    if(!$lock || !flock($lock,LOCK_EX|LOCK_NB)) throw new RuntimeException('Un téléchargement ISO est déjà en cours.');
    $state=dmd_iso_state();
    if($replace!=='' && (!isset($state[$replace]) || !is_file(dmd_iso_file($replace)))) throw new RuntimeException('ISO à remplacer introuvable. Actualise la liste.');
    dmd_iso_event('catalog','Lecture du catalogue OneDrive…');
    $items=dmd_iso_catalog();
    if(!isset($items[$key])) throw new RuntimeException('ISO absente du catalogue. Actualise la liste.');
    $item=$items[$key];
    $free=disk_free_space(dmd_iso_dir());
    if($free!==false && $free<$item['size']+67108864) throw new RuntimeException('Espace insuffisant : la nouvelle ISO doit être vérifiée avant de remplacer l’ancienne.');
    $id=bin2hex(random_bytes(12)); $tmp=dmd_iso_dir().'/'.$id.'.part';
    dmd_iso_event('download','Téléchargement vers DoMyDesk…',array('percent'=>0));
    $result=dmd_agent_repo_download_file($item['download_url'],$tmp,function($pct,$bytes,$total){dmd_iso_event('download','Téléchargement vers DoMyDesk…',array('percent'=>$pct,'bytes'=>$bytes,'total'=>$total));},DMD_ISO_MAX_BYTES);
    if(empty($result['ok'])) throw new RuntimeException('Téléchargement interrompu : '.($result['error'] ?? 'erreur réseau'));
    if((int)filesize($tmp)!==(int)$item['size']) throw new RuntimeException('Taille reçue différente du catalogue ; ancienne ISO conservée.');
    dmd_iso_event('verify','Vérification du format ISO bootable et de la somme SHA-256…');
    if(!dmd_iso_check($tmp)) throw new RuntimeException('Le fichier reçu n’est pas une ISO El Torito reconnue.');
    $published=dmd_iso_file($id);
    if(!rename($tmp,$published)) throw new RuntimeException('Impossible de publier l’ISO locale.');
    $tmp=''; @chmod($published,0640);
    $state[$id]=array('name'=>$item['name'],'size'=>$item['size'],'sha256'=>$result['sha256'],'downloaded_at'=>gmdate('c'),'source_key'=>$key);
    if($replace!=='') unset($state[$replace]);
    if(!dmd_agent_repo_write_json_file(dmd_iso_state_path(),$state)) throw new RuntimeException('Enregistrement de l’ISO impossible.');
    $committed=true;
    $warning='';
    if($replace!=='' && !@unlink(dmd_iso_file($replace))) $warning='La nouvelle ISO est disponible ; l’ancien fichier n’a pas pu être supprimé du disque.';
    dmd_system_log('agent_iso_downloaded',$item['name'],'success','ISO de secours enregistrée localement.',array('sha256'=>$result['sha256'],'replaced'=>$replace!==''));
    dmd_iso_event('done','ISO disponible sur ce DoMyDesk.',array('ok'=>true,'local'=>dmd_iso_local(),'warning'=>$warning));
} catch(Throwable $e) { dmd_iso_event('error',$e->getMessage(),array('ok'=>false)); }
finally {
    if($tmp!=='') @unlink($tmp);
    if(!$committed && $published!=='') @unlink($published);
    if(is_resource($lock)) { @flock($lock,LOCK_UN); fclose($lock); }
}
