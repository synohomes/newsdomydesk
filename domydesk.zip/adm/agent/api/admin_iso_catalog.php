<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
require_once dirname(__DIR__) . '/includes/iso_repository.php';
dmd_api_require_method('GET');
session_write_close();
try {
    // Local mode never contacts OneDrive. It works without Internet.
    $out=array('ok'=>true,'local'=>dmd_iso_local());
    if (($_GET['remote'] ?? '') === '1') {
        $items=dmd_iso_catalog();
        foreach($items as &$item) unset($item['download_url']);
        unset($item);
        $out['remote']=array_values($items);
    }
    dmd_json_response($out);
} catch(Throwable $e) { dmd_json_response(array('ok'=>false,'error'=>$e->getMessage(),'local'=>dmd_iso_local()),502); }
