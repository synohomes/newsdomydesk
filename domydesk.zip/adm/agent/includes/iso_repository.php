<?php
require_once __DIR__ . '/agent_repository.php';
const DMD_ISO_SOURCE = 'https://1drv.ms/f/c/515115639c39fd9d/IgCNAsHLuMvXSYV9GmT6y7UhAU0t6AK4U4mc0LZGguLIdBQ?e=yWkLaX';
const DMD_ISO_MAX_BYTES = 17179869184; // 16 GiB, PHP 64 bits required.
function dmd_iso_dir() { return dirname(__DIR__) . '/iso'; }
function dmd_iso_state_path() { return dmd_agent_repo_state_dir() . '/iso-installed.json'; }
function dmd_iso_state() { return dmd_agent_repo_read_json_file(dmd_iso_state_path(), array()); }
function dmd_iso_file($id) {
    if (!preg_match('/^[a-f0-9]{24}$/D', (string)$id)) throw new RuntimeException('ISO locale invalide.');
    return dmd_iso_dir() . '/' . $id . '.iso';
}
function dmd_iso_local() {
    $out = array();
    foreach (dmd_iso_state() as $id => $row) {
        if (!preg_match('/^[a-f0-9]{24}$/D', (string)$id) || !is_array($row)) continue;
        $file = dmd_iso_file($id);
        if (!is_file($file) || is_link($file)) continue;
        $row['id'] = $id;
        $row['size'] = (int)filesize($file);
        $row['url'] = 'api/admin_iso_download.php?id=' . $id;
        $out[] = $row;
    }
    usort($out, function($a,$b) { return strcmp($b['downloaded_at'] ?? '', $a['downloaded_at'] ?? ''); });
    return $out;
}
function dmd_iso_catalog() {
    $scan = dmd_agent_repo_onedrive_personal_rows(DMD_ISO_SOURCE);
    if (empty($scan['ok'])) throw new RuntimeException('Dossier OneDrive inaccessible : ' . ($scan['error'] ?? 'erreur inconnue'));
    $items = array();
    foreach (($scan['rows'] ?? array()) as $row) {
        $name = (string)($row['name'] ?? '');
        if (!isset($row['file']) || !preg_match('/\.iso$/iD', $name)) continue;
        $size = (int)($row['size'] ?? 0);
        $url = (string)($row['@content.downloadUrl'] ?? $row['@microsoft.graph.downloadUrl'] ?? '');
        if ($size < 32768 || $size > DMD_ISO_MAX_BYTES || stripos($url,'https://') !== 0) continue;
        $key = hash('sha256',(string)($row['id'] ?? '') . "\n" . $name);
        $items[$key] = array('key'=>$key,'name'=>$name,'size'=>$size,'modified'=>$row['lastModifiedDateTime'] ?? '', 'download_url'=>$url);
    }
    uasort($items,function($a,$b){return strnatcasecmp($b['name'],$a['name']);});
    return $items;
}
function dmd_iso_check($path) {
    $f = fopen($path,'rb');
    if (!$f) return false;
    $volume=false; $boot=false;
    // ISO9660 descriptors (including the El Torito boot descriptor).
    for($sector=16;$sector<64;$sector++) {
        fseek($f,$sector*2048); $block=fread($f,2048);
        if(strlen($block)!==2048) break;
        if(substr($block,1,5)!=='CD001') continue;
        if(ord($block[0])===1) $volume=true;
        if(ord($block[0])===0 && rtrim(substr($block,7,32),"\x00 ")==='EL TORITO SPECIFICATION') $boot=true;
        if(ord($block[0])===255) break;
    }
    fclose($f);
    return $volume && $boot;
}
