        <section class="dmd-agent-admin-pane dmd-network-plan-pane" data-admin-pane="network-plan" hidden>
            <iframe id="dmdNetworkPlanFrame" class="dmd-network-plan-frame" src="network-plan/index.php?embedded=1" title="Plan réseau DMD-Agent" loading="eager" scrolling="auto"></iframe>
        </section>
        <script>
        (function(){
            const frame=document.getElementById('dmdNetworkPlanFrame');
            if(!frame)return;
            let lastHeight=0,raf=0;
            function applyHeight(value){
                const raw=Math.ceil(Number(value)||0);
                if(!raw)return;
                /* Protection anti-boucle : le contenu normal reste très loin de cette limite. */
                const h=Math.max(720,Math.min(12000,raw));
                if(Math.abs(h-lastHeight)<2)return;
                lastHeight=h;
                frame.style.setProperty('height',h+'px','important');
                frame.parentElement?.style.setProperty('--dmd-network-plan-frame-height',h+'px');
            }
            function requestHeight(){
                cancelAnimationFrame(raf);
                raf=requestAnimationFrame(function(){
                    try{frame.contentWindow?.postMessage({type:'dmd-network-plan-request-height'},window.location.origin);}catch(_){}
                });
            }
            frame.addEventListener('load',function(){
                requestHeight();
                setTimeout(requestHeight,80);
                setTimeout(requestHeight,300);
            });
            window.addEventListener('message',function(event){
                if(event.origin!==window.location.origin)return;
                if(event.source!==frame.contentWindow)return;
                if(!event.data)return;
                if(event.data.type==='dmd-network-plan-height'){
                    applyHeight(event.data.height);
                    return;
                }
                if(event.data.type==='dmd-network-plan-wheel'){
                    const dy=Number(event.data.deltaY)||0, dx=Number(event.data.deltaX)||0;
                    let el=frame.parentElement;
                    while(el&&el!==document.body&&el!==document.documentElement){
                        const cs=getComputedStyle(el),max=Math.max(0,el.scrollHeight-el.clientHeight);
                        if(/auto|scroll/.test(cs.overflowY||'')&&max>1){ el.scrollBy({top:dy,left:dx,behavior:'auto'}); return; }
                        el=el.parentElement;
                    }
                    window.scrollBy({top:dy,left:dx,behavior:'auto'});
                }
            });
            window.addEventListener('resize',requestHeight);
            if(window.MutationObserver&&frame.parentElement){
                const mo=new MutationObserver(requestHeight);
                mo.observe(frame.parentElement,{attributes:true,attributeFilter:['hidden','class','style']});
            }
        })();
        </script>
