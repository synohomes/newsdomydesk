<div id="dmdIsoManager">
    <div class="dmd-iso-heading"><div><strong>Support de secours DoMyDesk</strong><p>Télécharge une ISO sur ce serveur, puis récupère-la ici pour créer ta clé USB.</p></div><span class="dmd-iso-tag">Stockage local</span></div>
    <div class="dmd-iso-columns">
        <section class="dmd-iso-card"><h4>ISO disponibles sur OneDrive</h4><p>Internet est utilisé uniquement pour consulter le catalogue et importer une ISO.</p><button type="button" id="dmdIsoScan" class="dmd-agent-mini-btn">Consulter les ISO disponibles</button><div id="dmdIsoRemote" class="dmd-iso-list">Catalogue non chargé.</div></section>
        <section class="dmd-iso-card"><h4>ISO stockées sur ce DoMyDesk</h4><p>Ces téléchargements passent directement par ton serveur.</p><button type="button" id="dmdIsoRefresh" class="dmd-agent-mini-btn">Actualiser le stockage local</button><div id="dmdIsoLocal" class="dmd-iso-list">Chargement…</div></section>
    </div>
    <div id="dmdIsoImport" class="dmd-iso-card" hidden>
        <strong id="dmdIsoSelected"></strong>
        <label>Conservation <select id="dmdIsoReplace"><option value="">Conserver les anciennes ISO</option></select></label>
        <button type="button" id="dmdIsoInstall" class="dmd-agent-mini-btn primary">Télécharger cette ISO sur DoMyDesk</button>
        <small>L’ancienne ISO est conservée jusqu’à la réception et la vérification complète de la nouvelle.</small>
    </div>
    <div id="dmdIsoStatus" role="status" aria-live="polite"></div><progress id="dmdIsoProgress" max="100" value="0" hidden></progress>
    <p class="dmd-iso-note">Le fichier récupéré est une véritable image .iso. Pour démarrer un PC, utilise-la dans un outil de création de clé USB bootable ou monte-la dans une VM.</p>
</div>
