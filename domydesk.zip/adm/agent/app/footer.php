<script>
const CSRF=<?= json_encode($csrfAgent) ?>;
const DEVICE_DATA=<?= $deviceJson ?: '[]' ?>;
let PC_GROUPS=<?= $pcGroupsJson ?: '[]' ?>;
let USER_GROUPS=<?= $userGroupsJson ?: '[]' ?>;
let ACCESS_POLICIES=<?= $policiesJson ?: '[]' ?>;
const DMD_USERS=<?= $usersJson ?: '[]' ?>;
const AGENT_AUDITS=<?= $auditsJson ?: '[]' ?>;
let BACKUP_AUDITS=<?= $backupAuditsJson ?: '[]' ?>;
const DMD_MYDESK_LIMIT_LABEL=<?= json_encode($licenseQuotaText($myDeskLimit)) ?>;
</script>
<script src="app/agent-panel.js?v=<?= (int)filemtime(__DIR__.'/agent-panel.js') ?>"></script>
<script src="assets/iso-manager.js?v=<?= (int)filemtime(__DIR__.'/../assets/iso-manager.js') ?>"></script>
</body>
</html>
