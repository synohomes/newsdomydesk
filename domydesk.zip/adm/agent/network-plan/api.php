<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';



header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

define('DATA_DIRECTORY', DMD_AGENT_VAR . '/network-plan/users/' . substr(hash('sha256', (string)$email), 0, 40));
define('DATA_FILE', DATA_DIRECTORY . '/schemas.php');
define('LOCK_FILE', DATA_DIRECTORY . '/.schemas.lock');
define('UPLOAD_DIRECTORY', DATA_DIRECTORY . '/uploads');

function respond(array $payload, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function fail(string $message, int $status = 400): never
{
    respond(['ok' => false, 'message' => $message], $status);
}

function ensureStorage(): void
{
    if (!is_dir(DATA_DIRECTORY) && !mkdir(DATA_DIRECTORY, 0770, true) && !is_dir(DATA_DIRECTORY)) {
        fail('Le dossier de données ne peut pas être créé.', 500);
    }
    if (!is_writable(DATA_DIRECTORY)) {
        fail('Le dossier data doit être accessible en écriture pour PHP.', 500);
    }
    if (!is_dir(UPLOAD_DIRECTORY) && !mkdir(UPLOAD_DIRECTORY, 0770, true) && !is_dir(UPLOAD_DIRECTORY)) {
        fail('Le dossier des images ne peut pas être créé.', 500);
    }
    if (!is_writable(UPLOAD_DIRECTORY)) {
        fail('Le dossier uploads doit être accessible en écriture pour PHP.', 500);
    }
}

function readStore(): array
{
    if (!is_file(DATA_FILE)) {
        return ['version' => 1, 'projects' => []];
    }
    $store = dmd_agent_json_read(DATA_FILE, ['version' => 1, 'projects' => []]);
    if (!is_array($store) || !isset($store['projects']) || !is_array($store['projects'])) {
        fail('Le fichier de données des schémas a une structure invalide.', 500);
    }
    return $store;
}

function writeStore(array $store): void
{
    if (!dmd_agent_json_write(DATA_FILE, $store, 0640)) {
        fail('Impossible d’enregistrer le schéma sur le serveur.', 500);
    }
}

function shortText(mixed $value, int $max = 160): string
{
    $text = trim(preg_replace('/\s+/u', ' ', (string) $value) ?? '');
    return function_exists('mb_substr') ? mb_substr($text, 0, $max) : substr($text, 0, $max);
}

function cleanId(mixed $value): string
{
    $id = (string) $value;
    return preg_match('/^[a-zA-Z0-9_-]{8,80}$/', $id) ? $id : '';
}

function cleanColor(mixed $value, string $fallback = '#59d9fb'): string
{
    $color = (string) $value;
    return preg_match('/^#[0-9a-fA-F]{6}$/', $color) ? strtolower($color) : $fallback;
}

function cleanPosition(mixed $value): int
{
    $number = is_numeric($value) ? (int) $value : 24;
    $number = max(24, min(24000, $number));
    return max(24, (int) (round($number / 24) * 24));
}

function cleanImagePath(mixed $value): string
{
    $path = (string) $value;
    return preg_match('/^file\.php\?f=i_[a-zA-Z0-9_-]{12,100}\.(?:jpg|jpeg|png|webp|gif)$/', $path) ? $path : '';
}

function cleanAttachments(mixed $attachments): array
{
    if (!is_array($attachments)) return [];
    $clean = [];
    foreach (array_slice($attachments, 0, 20) as $item) {
        if (!is_array($item)) continue;
        $path = (string) ($item['path'] ?? '');
        if (!preg_match('/^file\.php\?f=a_[a-zA-Z0-9_-]{12,100}\.(?:pdf|txt|csv|log|json|xml|ini|conf|cfg|jpg|jpeg|png|webp|gif|zip)$/', $path)) continue;
        $clean[] = ['name' => shortText($item['name'] ?? 'Pièce jointe', 120), 'path' => $path, 'type' => shortText($item['type'] ?? '', 80)];
    }
    return $clean;
}

function cleanCustomFields(mixed $fields): array
{
    if (!is_array($fields)) {
        return [];
    }
    $clean = [];
    foreach (array_slice($fields, 0, 30) as $field) {
        if (!is_array($field)) {
            continue;
        }
        $label = shortText($field['label'] ?? '', 60);
        $value = shortText($field['value'] ?? '', 500);
        if ($label !== '' || $value !== '') {
            $clean[] = ['label' => $label, 'value' => $value];
        }
    }
    return $clean;
}

function cleanDevice(array $device, int $index): array
{
    $types = ['desktop', 'laptop', 'server', 'network', 'printer', 'camera', 'other'];
    $statuses = ['online', 'warning', 'offline', 'unknown'];
    $id = cleanId($device['id'] ?? '') ?: 'd_' . bin2hex(random_bytes(8));
    return [
        'id' => $id,
        'name' => shortText($device['name'] ?? ('Équipement ' . ($index + 1)), 80) ?: ('Équipement ' . ($index + 1)),
        'ip' => shortText($device['ip'] ?? '', 64),
        'mac' => shortText($device['mac'] ?? '', 64),
        'subnet' => shortText($device['subnet'] ?? '', 80),
        'type' => in_array($device['type'] ?? '', $types, true) ? $device['type'] : 'desktop',
        'status' => in_array($device['status'] ?? '', $statuses, true) ? $device['status'] : 'online',
        'owner' => shortText($device['owner'] ?? '', 80),
        'location' => shortText($device['location'] ?? '', 80),
        'notes' => shortText($device['notes'] ?? '', 900),
        'source' => shortText($device['source'] ?? 'Ajout manuel', 160) ?: 'Ajout manuel',
        'image' => cleanImagePath($device['image'] ?? ''),
        'attachments' => cleanAttachments($device['attachments'] ?? []),
        'dhcpState' => in_array($device['dhcpState'] ?? '', ['present', 'new', 'missing'], true) ? $device['dhcpState'] : '',
        'previousIp' => shortText($device['previousIp'] ?? '', 64),
        'lastSeen' => shortText($device['lastSeen'] ?? '', 40),
        'borderColor' => cleanColor($device['borderColor'] ?? '', '#2f759e'),
        'locked' => (bool) ($device['locked'] ?? false),
        'customFields' => cleanCustomFields($device['customFields'] ?? []),
        'x' => cleanPosition($device['x'] ?? 24),
        'y' => cleanPosition($device['y'] ?? 24),
    ];
}

function cleanProject(array $project): array
{
    $rawDevices = $project['devices'] ?? [];
    if (!is_array($rawDevices) || count($rawDevices) > 1000) {
        fail('Un schéma peut contenir au maximum 1 000 équipements.');
    }
    $devices = [];
    $deviceIds = [];
    foreach ($rawDevices as $index => $device) {
        if (!is_array($device)) {
            continue;
        }
        $clean = cleanDevice($device, (int) $index);
        while (isset($deviceIds[$clean['id']])) {
            $clean['id'] = 'd_' . bin2hex(random_bytes(8));
        }
        $deviceIds[$clean['id']] = true;
        $devices[] = $clean;
    }
    $rawLinks = $project['links'] ?? [];
    $links = [];
    if (is_array($rawLinks)) {
        foreach (array_slice($rawLinks, 0, 3000) as $link) {
            if (!is_array($link)) {
                continue;
            }
            $from = cleanId($link['from'] ?? '');
            $to = cleanId($link['to'] ?? '');
            if ($from === '' || $to === '' || $from === $to || !isset($deviceIds[$from], $deviceIds[$to])) {
                continue;
            }
            $links[] = [
                'id' => cleanId($link['id'] ?? '') ?: 'l_' . bin2hex(random_bytes(8)),
                'from' => $from,
                'to' => $to,
                'label' => shortText($link['label'] ?? 'Liaison', 50) ?: 'Liaison',
                'details' => shortText($link['details'] ?? '', 220),
                'kind' => in_array($link['kind'] ?? '', ['network', 'backup', 'storage', 'dependency', 'camera', 'power', 'remote'], true) ? $link['kind'] : 'network',
                'style' => in_array($link['style'] ?? '', ['solid', 'dashed', 'dotted'], true) ? $link['style'] : 'solid',
                'direction' => in_array($link['direction'] ?? '', ['both', 'forward', 'none'], true) ? $link['direction'] : 'both',
                'width' => max(1, min(6, (int) ($link['width'] ?? 3))),
                'fromPort' => shortText($link['fromPort'] ?? '', 50),
                'toPort' => shortText($link['toPort'] ?? '', 50),
                'vlan' => shortText($link['vlan'] ?? '', 40),
                'speed' => shortText($link['speed'] ?? '', 40),
                'protocol' => shortText($link['protocol'] ?? '', 50),
                'color' => cleanColor($link['color'] ?? ''),
                'markerColor' => cleanColor($link['markerColor'] ?? ($link['color'] ?? '')),
            ];
        }
    }
    $sources = [];
    if (is_array($project['sources'] ?? null)) {
        foreach (array_slice($project['sources'], 0, 100) as $source) {
            if (!is_array($source)) {
                continue;
            }
            $sources[] = [
                'name' => shortText($source['name'] ?? 'Source DHCP', 160) ?: 'Source DHCP',
                'count' => max(0, min(100000, (int) ($source['count'] ?? 0))),
                'addedAt' => shortText($source['addedAt'] ?? gmdate(DATE_ATOM), 40),
            ];
        }
    }
    $zones = [];
    if (is_array($project['zones'] ?? null)) {
        foreach (array_slice($project['zones'], 0, 100) as $index => $zone) {
            if (!is_array($zone)) {
                continue;
            }
            $zones[] = [
                'id' => cleanId($zone['id'] ?? '') ?: 'z_' . bin2hex(random_bytes(8)),
                'name' => shortText($zone['name'] ?? ('Zone ' . ($index + 1)), 80),
                'color' => cleanColor($zone['color'] ?? '', '#2c87aa'),
                'x' => cleanPosition($zone['x'] ?? 24),
                'y' => cleanPosition($zone['y'] ?? 24),
                'width' => max(240, min(12000, cleanPosition($zone['width'] ?? 480))),
                'height' => max(168, min(12000, cleanPosition($zone['height'] ?? 336))),
            ];
        }
    }
    return [
        'id' => cleanId($project['id'] ?? ''),
        'name' => shortText($project['name'] ?? 'Schéma sans titre', 80) ?: 'Schéma sans titre',
        'devices' => $devices,
        'links' => $links,
        'zones' => $zones,
        'sources' => $sources,
        'board' => [
            'width' => max(1056, min(50000, cleanPosition($project['board']['width'] ?? 1056))),
            'height' => max(720, min(50000, cleanPosition($project['board']['height'] ?? 720))),
        ],
    ];
}

function projectSummary(array $project): array
{
    return [
        'id' => $project['id'],
        'name' => $project['name'],
        'device_count' => count($project['devices'] ?? []),
        'updated_at' => $project['updated_at'] ?? gmdate(DATE_ATOM),
    ];
}

function lockStorage(): mixed
{
    $handle = fopen(LOCK_FILE, 'c+');
    if ($handle === false || !flock($handle, LOCK_EX)) {
        fail('Les schémas sont temporairement verrouillés. Réessayez. ', 503);
    }
    return $handle;
}

function unlockStorage(mixed $handle): void
{
    flock($handle, LOCK_UN);
    fclose($handle);
}

ensureStorage();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = (string) ($_GET['action'] ?? '');
$input = [];

if ($method === 'POST') {
    if (isset($_POST['action'])) {
        $input = $_POST;
    } else {
        try {
            $input = json_decode((string) file_get_contents('php://input'), true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            fail('La requête reçue par le serveur est invalide.');
        }
        if (!is_array($input)) {
            fail('La requête reçue par le serveur est invalide.');
        }
    }
    $action = (string) ($input['action'] ?? '');
}

if ($method === 'POST') {
    dmd_api_require_csrf('agent_admin', $input);
}

if ($method === 'GET' && $action === 'list') {
    $store = readStore();
    $projects = array_map('projectSummary', $store['projects']);
    usort($projects, static fn(array $a, array $b): int => strcmp($b['updated_at'], $a['updated_at']));
    respond(['ok' => true, 'projects' => $projects]);
}

if ($method === 'GET' && $action === 'load') {
    $id = cleanId($_GET['id'] ?? '');
    foreach (readStore()['projects'] as $project) {
        if (($project['id'] ?? '') === $id) {
            respond(['ok' => true, 'project' => $project]);
        }
    }
    fail('Ce schéma n’existe plus sur le serveur.', 404);
}

if ($method === 'POST' && $action === 'upload_image') {
    $upload = $_FILES['image'] ?? null;
    if (!is_array($upload) || ($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        fail('L’image n’a pas été reçue correctement.');
    }
    if (($upload['size'] ?? 0) > 8 * 1024 * 1024) {
        fail('L’image ne doit pas dépasser 8 Mo.');
    }
    $mime = '';
    if (class_exists('finfo')) {
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = (string) $finfo->file((string) $upload['tmp_name']);
    }
    if ($mime === '' && function_exists('mime_content_type')) {
        $mime = (string) mime_content_type((string) $upload['tmp_name']);
    }
    $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    if (!isset($extensions[$mime])) {
        fail('Le fichier doit être une image JPG, PNG, WEBP ou GIF.');
    }
    $filename = 'i_' . bin2hex(random_bytes(12)) . '.' . $extensions[$mime];
    if (!move_uploaded_file((string) $upload['tmp_name'], UPLOAD_DIRECTORY . DIRECTORY_SEPARATOR . $filename)) {
        fail('Impossible de conserver l’image sur le serveur.', 500);
    }
    respond(['ok' => true, 'path' => 'file.php?f=' . rawurlencode($filename)]);
}

if ($method === 'POST' && $action === 'upload_attachment') {
    $upload = $_FILES['attachment'] ?? null;
    if (!is_array($upload) || ($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) fail('La pièce jointe n’a pas été reçue correctement.');
    if (($upload['size'] ?? 0) > 20 * 1024 * 1024) fail('La pièce jointe ne doit pas dépasser 20 Mo.');
    $original = basename((string) ($upload['name'] ?? 'fichier'));
    $extension = strtolower((string) pathinfo($original, PATHINFO_EXTENSION));
    $allowed = ['pdf','txt','csv','log','json','xml','ini','conf','cfg','jpg','jpeg','png','webp','gif','zip'];
    if (!in_array($extension, $allowed, true)) fail('Format de pièce jointe non autorisé.');
    $filename = 'a_' . bin2hex(random_bytes(12)) . '.' . $extension;
    if (!move_uploaded_file((string) $upload['tmp_name'], UPLOAD_DIRECTORY . DIRECTORY_SEPARATOR . $filename)) fail('Impossible de conserver la pièce jointe.', 500);
    respond(['ok' => true, 'path' => 'file.php?f=' . rawurlencode($filename), 'name' => shortText($original, 120), 'type' => shortText($upload['type'] ?? '', 80)]);
}

if ($method === 'POST' && $action === 'save') {
    if (!is_array($input['project'] ?? null)) {
        fail('Le schéma à enregistrer est absent.');
    }
    $project = cleanProject($input['project']);
    $handle = lockStorage();
    $store = readStore();
    $now = gmdate(DATE_ATOM);
    $found = false;
    foreach ($store['projects'] as $index => $existing) {
        if ($project['id'] !== '' && ($existing['id'] ?? '') === $project['id']) {
            $project['id'] = $existing['id'];
            $project['created_at'] = $existing['created_at'] ?? $now;
            $project['updated_at'] = $now;
            $store['projects'][$index] = $project;
            $found = true;
            break;
        }
    }
    if (!$found) {
        $project['id'] = 'p_' . bin2hex(random_bytes(10));
        $project['created_at'] = $now;
        $project['updated_at'] = $now;
        $store['projects'][] = $project;
    }
    writeStore($store);
    unlockStorage($handle);
    dmd_system_log('agent_network_plan_save', $project['id'], 'success', 'Plan réseau enregistré.', ['actor'=>$email,'name'=>$project['name'],'devices'=>count($project['devices'])]);
    respond(['ok' => true, 'project' => $project]);
}

if ($method === 'POST' && $action === 'delete') {
    $id = cleanId($input['id'] ?? '');
    if ($id === '') {
        fail('Identifiant de schéma invalide.');
    }
    $handle = lockStorage();
    $store = readStore();
    $before = count($store['projects']);
    $store['projects'] = array_values(array_filter($store['projects'], static fn(array $project): bool => ($project['id'] ?? '') !== $id));
    if (count($store['projects']) === $before) {
        unlockStorage($handle);
        fail('Ce schéma n’existe plus sur le serveur.', 404);
    }
    writeStore($store);
    unlockStorage($handle);
    dmd_system_log('agent_network_plan_delete', $id, 'success', 'Plan réseau supprimé.', ['actor'=>$email]);
    respond(['ok' => true]);
}

fail('Action non reconnue.', 404);
