<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
$name = basename((string)($_GET['f'] ?? ''));
if (!preg_match('/^(?:i|a)_[A-Za-z0-9_-]{12,100}\.(?:jpg|jpeg|png|webp|gif|pdf|txt|csv|log|json|xml|ini|conf|cfg|zip)$/i', $name)) { http_response_code(404); exit; }
$root = DMD_AGENT_VAR . '/network-plan/users/' . substr(hash('sha256', (string)$email), 0, 40) . '/uploads';
$file = $root . '/' . $name;
if (!is_file($file)) { http_response_code(404); exit; }
$ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
$types = ['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','gif'=>'image/gif','pdf'=>'application/pdf','txt'=>'text/plain; charset=utf-8','csv'=>'text/csv; charset=utf-8','log'=>'text/plain; charset=utf-8','json'=>'application/json','xml'=>'application/xml','ini'=>'text/plain; charset=utf-8','conf'=>'text/plain; charset=utf-8','cfg'=>'text/plain; charset=utf-8','zip'=>'application/zip'];
header('Content-Type: ' . ($types[$ext] ?? 'application/octet-stream'));
header('Content-Length: ' . (string)filesize($file));
header('Cache-Control: private, max-age=300');
header('X-Content-Type-Options: nosniff');
readfile($file);
