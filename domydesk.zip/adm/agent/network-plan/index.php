<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
$theme = 'default';
$themeFile = $baseDir . '/users/profiles/' . $email . '/theme.json';
$themeData = dmd_sys_json_read($themeFile, array());
if (!empty($themeData['theme']) && is_file($baseDir . '/theme/' . basename((string)$themeData['theme']) . '/style.css')) {
    $theme = basename((string)$themeData['theme']);
}
$uiScale = 100;
if (isset($themeData['ui_scale']) && is_numeric($themeData['ui_scale'])) {
    $uiScale = max(60, min(150, (int)$themeData['ui_scale']));
}
$uiScaleFactor = $uiScale / 100;
$uiScaleWidth = 100 / $uiScaleFactor;
?>

<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script>try{document.documentElement.classList.add(window.self!==window.top?'dmd-plan-embedded':'dmd-plan-standalone');}catch(_){document.documentElement.classList.add('dmd-plan-standalone');}</script>
  <title>Plan réseau - DMD-Agent</title>
  <meta name="description" content="Plan réseau DMD-Agent : import DHCP, agents, scans et cartographie modifiable.">
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='16' fill='%23081727'/%3E%3Cpath d='M14 22h36M14 32h36M14 42h36' stroke='%2359d9fb' stroke-width='5' stroke-linecap='round'/%3E%3Ccircle cx='18' cy='22' r='2.5' fill='%23d9f8ff'/%3E%3Ccircle cx='18' cy='32' r='2.5' fill='%23d9f8ff'/%3E%3Ccircle cx='18' cy='42' r='2.5' fill='%23d9f8ff'/%3E%3C/svg%3E">
  <link rel="stylesheet" href="assets/app.css?v=<?= (int)filemtime(__DIR__.'/assets/app.css') ?>">
  <link rel="stylesheet" href="../../../theme/<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>/style.css">
  <link rel="stylesheet" href="assets/dmd-integration.css?v=<?= (int)filemtime(__DIR__.'/assets/dmd-integration.css') ?>">
  <link rel="stylesheet" href="assets/print-fix.css?v=<?= (int)filemtime(__DIR__.'/assets/print-fix.css') ?>">
  <style>:root{--dmd-plan-scale:<?= htmlspecialchars(number_format($uiScaleFactor,3,'.',''),ENT_QUOTES,'UTF-8') ?>;--dmd-plan-scale-width:<?= htmlspecialchars(number_format($uiScaleWidth,4,'.',''),ENT_QUOTES,'UTF-8') ?>%;--dmd-agent-ui-scale:<?= htmlspecialchars(number_format($uiScaleFactor,3,'.',''),ENT_QUOTES,'UTF-8') ?>;}</style>
</head>
<body>
  <main class="app">
    <header class="header">
      <div class="identity">
        <div class="logo" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="5" rx="1.4"/><rect x="3" y="15" width="18" height="5" rx="1.4"/><path d="M7 6.5h.01M7 17.5h.01M11 6.5h6M11 17.5h6"/></svg></div>
        <div><h1>Plan réseau</h1><p>DMD-Agent · <?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?></p></div>
      </div>
      <div class="header-actions">
        <input class="project-title" id="projectTitle" aria-label="Nom du schéma" value="Schéma sans titre" maxlength="80">
        <button class="button" id="newProject" type="button">Nouveau</button>
        <button class="button primary" id="saveProject" type="button">Enregistrer</button>
        <button class="button" id="exportProject" type="button">Sauvegarde fichier</button>
        <select class="pdf-export-mode" id="pdfExportMode" aria-label="Contenu de l’export PDF"><option value="map">Plan uniquement</option><option value="links">Liaisons uniquement</option><option value="both">Plan + liaisons</option></select>
        <button class="button" id="printProject" type="button" disabled>Exporter PDF</button>
      </div>
    </header>

    <section class="editor-layout">
      <aside class="side-column">
        <section class="panel compact-panel dmd-agent-import-panel">
          <div class="panel-heading"><div><h2>Agents DoMyDesk</h2><p>Ajoute les postes enrôlés ou scanne un LAN depuis un Agent.</p></div><span class="badge" id="dmdAgentCount">0</span></div>
          <div class="panel-content stack">
            <button class="button primary" id="dmdImportAgents" type="button">Importer / mettre à jour les Agents</button>
            <label class="field compact-field"><span>PC sonde</span><select id="dmdProbeAgent"><option value="">Choisir un Agent…</option></select></label>
            <div class="double dmd-scan-grid"><label class="field compact-field"><span>Réseau</span><select id="dmdProbeNetwork"><option value="">Détection automatique…</option></select></label><label class="field compact-field"><span>Profil</span><select id="dmdProbeProfile"><option value="light">Rapide</option><option value="standard" selected>Standard</option><option value="extended">Étendu</option></select></label></div>
            <div class="row-actions"><button class="button slim" id="dmdDetectNetworks" type="button" disabled>Détecter les réseaux</button><button class="button slim accent" id="dmdScanNetwork" type="button" disabled>Scanner et intégrer</button></div>
            <div class="dmd-agent-plan-status" id="dmdPlanAgentStatus">Connexion au parc DMD-Agent…</div>
          </div>
        </section>

        <section class="panel compact-panel">
          <div class="panel-heading"><div><h2>Import DHCP</h2><p>TXT, CSV ou journal ; plusieurs sources peuvent former le même plan.</p></div><span class="badge" id="deviceBadge">0</span></div>
          <div class="panel-content stack">
            <label class="drop-zone" id="dropZone" for="dhcpInput"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16V4M7.5 8.5 12 4l4.5 4.5"/><path d="M5 14.5v4A1.5 1.5 0 0 0 6.5 20h11a1.5 1.5 0 0 0 1.5-1.5v-4"/></svg><strong>Importer les exports DHCP</strong><span>Glissez plusieurs fichiers ou cliquez ici.</span></label>
            <input class="file-input" id="dhcpInput" type="file" accept=".txt,.csv,.log,text/plain,text/csv" multiple>
            <div class="compact-list-control"><div class="section-label"><span>Sources intégrées</span><span class="badge" id="sourceBadge">0</span></div><div class="select-action-row"><select id="sourceSelect" aria-label="Sources DHCP intégrées"><option value="">Aucune source intégrée</option></select><button class="button slim danger-soft" id="removeSelectedSource" type="button" disabled>Retirer</button></div><div class="source-list legacy-list" id="sourceList"><p class="empty">Aucun fichier importé.</p></div></div>
            <button class="button" id="addDevice" type="button">+ Ajouter un périphérique manuel</button>
            <div class="note">Cliquez une fois sur une vignette pour ouvrir sa fiche. Le déplacement se fait en glissant la vignette sur la grille.</div>
          </div>
        </section>

        <section class="panel compact-panel">
          <div class="panel-heading"><div><h2>Schémas serveur</h2><p>Les positions, fiches, images, champs et liaisons sont conservés.</p></div><span class="status"><i></i><span id="saveStatus">Non enregistré</span></span></div>
          <div class="panel-content stack">
            <div class="row-actions"><button class="button slim" id="importProjectButton" type="button">Importer un fichier sauvegardé</button><button class="button slim" id="demoButton" type="button">Démo</button></div>
            <input class="file-input" id="projectInput" type="file" accept=".dhcpmap,.json,application/json">
            <div class="select-action-row saved-project-row"><select id="savedProjectSelect" aria-label="Schémas enregistrés"><option value="">Chargement des schémas…</option></select><button class="button slim" id="openSavedProject" type="button" disabled>Ouvrir</button><button class="button slim danger-soft" id="deleteSavedProject" type="button" disabled>Suppr.</button></div>
            <div class="saved-list legacy-list" id="savedList"><p class="empty">Chargement des schémas…</p></div>
          </div>
        </section>
        <section class="panel compact-panel">
          <div class="panel-heading"><div><h2>Contrôle du plan</h2><p>Statistiques, anomalies et versions locales.</p></div></div>
          <div class="panel-content stack"><div class="stats-summary" id="statsSummary"></div><div class="row-actions"><button class="button slim" id="saveCheckpoint" type="button">Créer une version</button><button class="button slim" id="restoreCheckpoint" type="button">Restaurer</button></div><select class="checkpoint-list" id="checkpointList"><option value="">Aucune version locale</option></select><div class="anomaly-list" id="anomalyList"></div></div>
        </section>
      </aside>

      <section class="workspace">
        <section class="panel editor-panel">
          <div class="editor-toolbar">
            <div class="toolbar-group"><button class="button slim" id="arrangeButton" type="button" disabled>Réorganiser par réseau</button><button class="button slim" id="centerButton" type="button" disabled>Centrer la sélection</button><button class="button slim accent" id="openLinkModal" type="button" disabled>+ Nouvelle liaison</button><button class="button slim" id="addZone" type="button">+ Zone</button></div>
            <span class="toolbar-text" id="canvasInfo">Importez un export DHCP pour commencer.</span>
          </div>
          <div class="advanced-toolbar">
            <input id="deviceSearch" type="search" placeholder="Rechercher nom, IP, MAC, utilisateur…" aria-label="Rechercher un périphérique">
            <select id="filterType" aria-label="Filtrer par type"><option value="">Tous les types</option><option value="desktop">Postes</option><option value="laptop">Portables</option><option value="server">Serveurs / NAS</option><option value="network">Réseau</option><option value="printer">Imprimantes</option><option value="camera">Caméras</option><option value="other">Autres</option></select>
            <select id="filterStatus" aria-label="Filtrer par état"><option value="">Tous les états</option><option value="online">Actifs</option><option value="warning">À vérifier</option><option value="offline">Hors ligne</option><option value="unknown">Inconnus</option></select>
            <select id="filterSubnet" aria-label="Filtrer par réseau"><option value="">Tous les réseaux</option></select>
            <select id="linkLayerFilter" aria-label="Filtrer les liaisons"><option value="">Tous les calques</option><option value="network">Physique / réseau</option><option value="dependency">Logique / dépendances</option><option value="backup">Sauvegardes</option><option value="storage">Stockage</option><option value="camera">Vidéosurveillance</option><option value="remote">Virtualisation / distant</option><option value="power">Alimentation</option></select>
            <button class="tool-icon" id="toggleLinkLabels" type="button">Titres : oui</button>
            <button class="tool-icon" id="openNetworkTools" type="button">Outils réseau</button>
            <button class="tool-icon" id="resetFilters" type="button" title="Effacer les filtres">Filtres ×</button>
            <span class="tool-separator"></span><button class="tool-icon" id="undoAction" type="button" title="Annuler">↶</button><button class="tool-icon" id="redoAction" type="button" title="Rétablir">↷</button>
            <span class="tool-separator"></span><button class="tool-icon" id="zoomOut" type="button">−</button><strong id="zoomLevel">100 %</strong><button class="tool-icon" id="zoomIn" type="button">+</button><button class="tool-icon" id="fitBoard" type="button">Ajuster</button><button class="tool-icon" id="fullScreen" type="button">Plein écran</button>
            <span class="tool-separator"></span><button class="tool-icon" id="shrinkBoard" type="button" title="Réduire la grille">Grille −</button><strong id="boardSizeLabel">1056 × 720</strong><button class="tool-icon" id="expandBoard" type="button" title="Agrandir la grille">Grille +</button>
          </div>
          <div class="selection-toolbar hidden" id="selectionToolbar"><strong id="selectionCount">0 sélection</strong><button class="button slim" id="selectAllVisible" type="button">Tout sélectionner</button><button class="button slim" id="alignHorizontal" type="button">Aligner ↔</button><button class="button slim" id="alignVertical" type="button">Aligner ↕</button><button class="button slim" id="distributeHorizontal" type="button">Espacer ↔</button><button class="button slim" id="distributeVertical" type="button">Espacer ↕</button><button class="button slim" id="lockSelection" type="button">Verrouiller</button><button class="button slim" id="duplicateSelection" type="button">Dupliquer</button><select id="bulkType"><option value="">Changer le type…</option><option value="desktop">Poste</option><option value="laptop">Portable</option><option value="server">Serveur / NAS</option><option value="network">Réseau</option><option value="printer">Imprimante</option><option value="camera">Caméra</option><option value="other">Autre</option></select><input id="bulkColour" type="color" value="#2f759e" title="Changer les contours"><button class="button slim danger" id="deleteSelection" type="button">Supprimer</button><button class="button slim" id="clearSelection" type="button">Fermer</button></div>
          <div class="link-legend" id="linkLegend"></div>
          <div class="board-viewport" id="boardViewport">
            <div class="link-focus-banner hidden" id="linkFocusBanner"></div>
            <aside class="mini-map" id="miniMapWrap"><header><strong>Mini-carte</strong><button id="toggleMiniMap" type="button">−</button></header><canvas id="miniMap" width="240" height="150" aria-label="Mini-carte du schéma"></canvas></aside>
            <div class="board" id="board" aria-label="Plan réseau modifiable">
              <div class="zone-layer" id="zoneLayer"></div>
              <svg class="links-layer" id="linksLayer" aria-hidden="true"></svg>
              <div class="board-empty" id="boardEmpty"><div class="empty-box"><div class="empty-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="5" rx="1.4"/><rect x="3" y="15" width="18" height="5" rx="1.4"/><path d="M7 6.5h.01M7 17.5h.01M11 6.5h6M11 17.5h6"/></svg></div><h2>Créez le plan réel de l’infrastructure</h2><p>Importez les exports DHCP, déplacez les vignettes sur la grille, puis ouvrez chaque fiche pour compléter l’inventaire.</p></div></div>
              <div id="deviceLayer"></div>
              <button class="board-resize-handle" id="boardResizeHandle" type="button" aria-label="Redimensionner la grille" title="Glissez pour agrandir ou réduire la grille"><i></i></button>
            </div>
          </div>
          <div class="board-footer"><span><strong>Fiche :</strong> clic simple. <strong>Déplacement :</strong> glissez sur la grille. <strong>Taille de la grille :</strong> boutons Grille − / + ou poignée en bas à droite.</span><span><span id="visibleFooter">0 visible</span> · <span id="linkFooter">0 liaison</span></span></div>
        </section>
      </section>
    </section>

    <section class="panel links-report" id="linksReport">
      <div class="panel-heading"><div><h2>Liaisons du schéma</h2><p>Les actions documentées : leurs couleurs correspondent aux pastilles visibles sur les équipements.</p></div><div class="report-actions"><button class="button slim" id="toggleLinksReport" type="button" aria-expanded="true">Réduire</button><button class="button slim" id="exportSvg" type="button">Exporter SVG</button><button class="button slim" id="exportPng" type="button">Exporter PNG</button><button class="button slim" id="exportLinksCsv" type="button" disabled>Exporter les liaisons CSV</button><button class="button slim" id="printLinks" type="button" disabled>Exporter les liaisons PDF</button><span class="badge" id="linkBadge">0</span></div></div>
      <div class="table-wrap" id="linksTableWrap"><p class="table-empty">Aucune liaison documentée.</p></div>
    </section>
    <section class="print-map-output" id="printMapOutput" aria-hidden="true"></section>
  </main>

  <div class="modal" id="deviceModal" aria-hidden="true">
    <div class="modal-backdrop" data-close-modal="deviceModal"></div>
    <section class="modal-dialog device-dialog" role="dialog" aria-modal="true" aria-labelledby="deviceModalTitle">
      <header class="modal-header"><div><span class="eyebrow">Fiche équipement</span><h2 id="deviceModalTitle">Équipement</h2><p id="deviceModalMeta"></p></div><button class="modal-close" type="button" data-close-modal="deviceModal" aria-label="Fermer">×</button></header>
      <section class="device-summary" id="deviceSummary">
        <div class="device-summary-top">
          <div class="device-summary-image" id="deviceSummaryImage"><span id="deviceSummaryImageFallback"></span><img id="deviceSummaryImageTag" alt="Aperçu de l’équipement" hidden></div>
          <div class="device-summary-details">
            <div class="device-summary-badges"><span id="deviceSummaryType"></span><span id="deviceSummaryStatus"></span></div>
            <div class="device-summary-grid">
              <div><small>Adresse IP</small><b id="deviceSummaryIp">—</b></div><div><small>Adresse MAC</small><b id="deviceSummaryMac">—</b></div><div><small>Réseau / VLAN</small><b id="deviceSummarySubnet">—</b></div>
              <div><small>Client / utilisateur</small><b id="deviceSummaryOwner">—</b></div><div><small>Emplacement</small><b id="deviceSummaryLocation">—</b></div><div><small>Source</small><b id="deviceSummarySource">—</b></div>
            </div>
          </div>
        </div>
        <div class="device-summary-section"><strong>Notes techniques</strong><p id="deviceSummaryNotes">Aucune note.</p></div>
        <div class="device-summary-section"><div class="section-label"><span>Champs complémentaires</span></div><div class="device-summary-extra" id="deviceSummaryCustom"></div></div>
        <div class="device-summary-section"><div class="section-label"><span>Périphériques liés</span><span class="badge" id="deviceSummaryRelationsCount">0</span></div><div class="device-summary-relations" id="deviceSummaryRelations"></div></div>
        <div class="device-summary-actions"><button class="button primary" id="deviceEditButton" type="button">Modifier la fiche</button><button class="button accent" id="deviceSummaryLink" type="button">Créer une liaison</button><button class="button" id="deviceSummaryPrint" type="button">Exporter cette fiche PDF</button></div>
      </section>
      <form class="device-form" id="deviceForm" hidden>
        <aside class="device-identity-card">
          <div class="device-image" id="deviceImagePreview"><span id="deviceImageFallback"></span><img id="deviceImage" alt="Aperçu de l’équipement" hidden></div>
          <label class="image-upload" for="deviceImageInput">Ajouter / remplacer l’image</label>
          <input class="file-input" id="deviceImageInput" type="file" accept="image/jpeg,image/png,image/webp,image/gif">
          <button class="text-button" id="removeDeviceImage" type="button">Retirer l’image</button>
          <div class="identity-info"><strong id="identityDeviceName"></strong><span id="identityDeviceType"></span><span id="identityDeviceSource"></span></div>
          <button class="button accent link-from-device" id="linkFromDevice" type="button">Créer une liaison depuis cet équipement</button>
          <button class="button link-from-device" id="printDevice" type="button">Exporter cette fiche PDF</button>
        </aside>
        <div class="device-fields">
          <div class="field"><label for="deviceName">Nom de l’équipement</label><input id="deviceName" maxlength="80" required></div>
          <div class="triple"><div class="field"><label for="deviceType">Type</label><select id="deviceType"><option value="desktop">Poste de travail</option><option value="laptop">Portable</option><option value="server">Serveur / NAS</option><option value="network">Réseau</option><option value="printer">Imprimante</option><option value="camera">Caméra</option><option value="other">Autre</option></select></div><div class="field"><label for="deviceStatus">État</label><select id="deviceStatus"><option value="online">Actif</option><option value="warning">À vérifier</option><option value="offline">Hors ligne</option><option value="unknown">Inconnu</option></select></div><div class="field"><label for="deviceSubnet">Réseau / VLAN</label><input id="deviceSubnet" placeholder="192.168.1.0/24"></div></div>
          <div class="double"><div class="field device-colour"><label for="deviceBorderColor">Couleur du contour de la vignette</label><input id="deviceBorderColor" type="color" value="#2f759e" aria-label="Couleur du contour"></div><label class="check-field"><input id="deviceLocked" type="checkbox"><span>Verrouiller la position</span></label></div>
          <div class="double"><div class="field"><label for="deviceIp">Adresse IP</label><input id="deviceIp" placeholder="192.168.1.10"></div><div class="field"><label for="deviceMac">Adresse MAC</label><input id="deviceMac" placeholder="AA:BB:CC:DD:EE:FF"></div></div>
          <div class="double"><div class="field"><label for="deviceOwner">Client / utilisateur</label><input id="deviceOwner" maxlength="80" placeholder="Ex. Atelier Martin"></div><div class="field"><label for="deviceLocation">Emplacement</label><input id="deviceLocation" maxlength="80" placeholder="Ex. Bureau 2"></div></div>
          <div class="field"><label for="deviceNotes">Notes techniques</label><textarea id="deviceNotes" maxlength="900" placeholder="Rôle, accès, configuration, remarques…"></textarea></div>
          <div class="custom-fields-area"><div class="section-label"><span>Champs complémentaires</span><button class="mini-action" id="addCustomField" type="button">+ Ajouter un champ</button></div><div id="customFields"></div></div>
          <div class="device-relations"><div class="section-label"><span>Périphériques liés</span><span class="badge" id="deviceRelationsCount">0</span></div><div id="deviceRelations"></div></div>
          <div class="attachments-area"><div class="section-label"><span>Pièces jointes</span><label class="mini-action" for="deviceAttachmentsInput">+ Ajouter</label></div><input class="file-input" id="deviceAttachmentsInput" type="file" multiple><div id="deviceAttachments"></div></div>
          <div class="form-actions"><button class="button primary" type="submit">Enregistrer la fiche</button><button class="button danger" id="deleteDevice" type="button">Supprimer</button></div>
        </div>
      </form>
    </section>
  </div>

  <div class="modal" id="linkModal" aria-hidden="true">
    <div class="modal-backdrop" data-close-modal="linkModal"></div>
    <section class="modal-dialog link-dialog" role="dialog" aria-modal="true" aria-labelledby="linkModalTitle">
      <header class="modal-header"><div><span class="eyebrow">Liaison documentée</span><h2 id="linkModalTitle">Nouvelle liaison</h2><p>Chaque liaison conserve sa propre couleur. Un périphérique peut afficher plusieurs pastilles lorsqu’il participe à plusieurs liaisons.</p></div><button class="modal-close" type="button" data-close-modal="linkModal" aria-label="Fermer">×</button></header>
      <form class="link-form" id="linkForm">
        <div class="field"><label for="linkFrom">Périphérique principal</label><select id="linkFrom" required></select></div>
        <div class="field"><label for="linkTargetSearch">Périphérique(s) à relier</label><div class="link-target-tools"><input id="linkTargetSearch" type="search" placeholder="Rechercher par nom, IP, MAC, type ou emplacement…" autocomplete="off"><button class="button slim" id="selectVisibleTargets" type="button">Tout cocher</button><button class="button slim" id="clearLinkTargets" type="button">Effacer</button></div><div class="link-targets" id="linkTargets"></div><small class="field-help" id="linkTargetsHelp">Cochez tous les périphériques à relier en une seule fois.</small></div>
        <div class="field"><label for="linkLabel">Action / titre de la liaison</label><input id="linkLabel" maxlength="50" placeholder="Ex. Sauvegarde de nuit" required></div>
        <div class="field"><label for="linkDetails">Infobulle / détail</label><textarea id="linkDetails" maxlength="220" placeholder="Ex. NAS-01 sauvegarde ce poste chaque nuit à 02:00." required></textarea></div>
        <div class="link-tech-grid"><div class="field"><label for="linkFromPort">Interface / port source</label><input id="linkFromPort" maxlength="50" placeholder="eth0 / Gi1/0/4"></div><div class="field"><label for="linkToPort">Interface / port cible</label><input id="linkToPort" maxlength="50" placeholder="LAN1 / vmbr0"></div><div class="field"><label for="linkVlan">VLAN</label><input id="linkVlan" maxlength="40" placeholder="10 - CAMERAS"></div><div class="field"><label for="linkSpeed">Débit</label><input id="linkSpeed" maxlength="40" placeholder="1 Gbit/s"></div><div class="field"><label for="linkProtocol">Protocole</label><input id="linkProtocol" maxlength="50" placeholder="Ethernet, iSCSI, RTSP…"></div></div>
        <div class="triple"><div class="field"><label for="linkKind">Type de liaison</label><select id="linkKind"><option value="network">Réseau</option><option value="backup">Sauvegarde</option><option value="storage">Stockage</option><option value="dependency">Dépendance</option><option value="camera">Caméra</option><option value="power">Alimentation</option><option value="remote">Accès distant</option></select></div><div class="field"><label for="linkStyle">Style du trait</label><select id="linkStyle"><option value="solid">Continu</option><option value="dashed">Pointillé</option><option value="dotted">Points</option></select></div><div class="field"><label for="linkDirection">Sens</label><select id="linkDirection"><option value="both">Bidirectionnel</option><option value="forward">Principal → cible</option><option value="none">Sans flèche</option></select></div></div>
        <div class="field"><label for="linkWidth">Épaisseur du trait</label><input id="linkWidth" type="range" min="1" max="6" value="3"></div>
        <div class="field"><label for="linkColor">Couleur de la pastille et du trait pour tout le groupe</label><div class="color-row"><input id="linkColor" type="color" value="#50d99b"><select id="linkPreset"><option value="#50d99b">Vert — sauvegarde / OK</option><option value="#59d9fb">Cyan — réseau / synchronisation</option><option value="#6480ff">Bleu — service / accès</option><option value="#f4b74e">Orange — intervention</option><option value="#fa6d7a">Rouge — incident</option><option value="custom">Personnalisée</option></select></div></div>
        <div class="form-actions"><button class="button primary" id="addLink" type="submit">Ajouter la liaison</button></div>
      </form>
    </section>
  </div>

  <div class="modal" id="networkToolsModal" aria-hidden="true">
    <div class="modal-backdrop" data-close-modal="networkToolsModal"></div>
    <section class="modal-dialog tools-dialog" role="dialog" aria-modal="true" aria-labelledby="networkToolsTitle">
      <header class="modal-header"><div><span class="eyebrow">Analyse et navigation</span><h2 id="networkToolsTitle">Outils réseau</h2><p>Adressage, chemin réseau, modèles et historique.</p></div><button class="modal-close" type="button" data-close-modal="networkToolsModal" aria-label="Fermer">×</button></header>
      <div class="tools-content">
        <section class="tools-card"><h3>Chemin réseau</h3><div class="tools-row"><select id="pathFrom"></select><span>→</span><select id="pathTo"></select><button class="button primary" id="showPath" type="button">Afficher le chemin</button><button class="button" id="clearPath" type="button">Effacer</button></div><div id="pathResult" class="tool-result"></div></section>
        <section class="tools-card"><div class="tools-card-title"><h3>Tableau d’adressage IP / VLAN</h3><button class="button slim" id="exportIpPlan" type="button">Exporter CSV</button></div><input id="ipPlanSearch" type="search" placeholder="Rechercher une IP, un VLAN, un nom…"><div class="ip-plan-wrap" id="ipPlanTable"></div></section>
        <section class="tools-grid"><div class="tools-card"><h3>Modèles réutilisables</h3><div class="tools-row"><select id="deviceTemplate"><option value="nas">NAS</option><option value="switch">Switch</option><option value="camera">Caméra</option><option value="wifi">Borne Wi-Fi</option><option value="server">Serveur</option><option value="vm">Machine virtuelle</option><option value="printer">Imprimante</option></select><input id="templateCount" type="number" min="1" max="50" value="1"><button class="button primary" id="addTemplateDevice" type="button">Ajouter</button></div></div><div class="tools-card"><h3>Comparer deux versions</h3><div class="tools-row"><select id="compareCheckpoint"><option value="">Version de départ…</option></select><select id="compareCheckpointTo"><option value="current">Schéma actuel</option></select><button class="button" id="compareVersion" type="button">Comparer</button></div><div id="versionComparison" class="tool-result"></div></div></section>
      </div>
    </section>
  </div>

  <div class="tooltip" id="tooltip" role="tooltip"></div>
  <div class="toast" id="toast" role="status" aria-live="polite"></div>
  <script>
  window.NETWORK_PLAN_CONFIG = {
    csrf: <?= json_encode($csrfAgent, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) ?>,
    userKey: <?= json_encode(substr(hash('sha256', $email), 0, 20)) ?>
  };
  </script>
  <script src="assets/app.js?v=<?= (int)filemtime(__DIR__.'/assets/app.js') ?>"></script>
  <script src="assets/advanced.js?v=<?= (int)filemtime(__DIR__.'/assets/advanced.js') ?>"></script>
  <script src="assets/agent-integration.js?v=<?= (int)filemtime(__DIR__.'/assets/agent-integration.js') ?>"></script>
  <script>
  (function(){
    if(window.self===window.top)return;
    let raf=0,lastHeight=0;

    function contentHeight(){
      const app=document.querySelector('.app');
      const links=document.getElementById('linksReport');
      if(!app)return 720;
      const appRect=app.getBoundingClientRect();
      const lastRect=(links||app.lastElementChild||app).getBoundingClientRect();
      const style=getComputedStyle(app);
      const paddingBottom=parseFloat(style.paddingBottom)||0;
      /* Mesure exclusivement le contenu réel : jamais scrollHeight du document/viewport. */
      return Math.max(720,Math.ceil(lastRect.bottom-appRect.top+paddingBottom+2));
    }

    function reportHeight(){
      cancelAnimationFrame(raf);
      raf=requestAnimationFrame(function(){
        const h=contentHeight();
        if(!Number.isFinite(h)||Math.abs(h-lastHeight)<2)return;
        lastHeight=h;
        try{window.parent.postMessage({type:'dmd-network-plan-height',height:h},location.origin);}catch(_){}
      });
    }
    window.dmdNetworkPlanReportHeight=reportHeight;

    function canConsumeWheel(target,dy){
      let el=target instanceof Element?target:null;
      while(el&&el!==document.body&&el!==document.documentElement){
        const cs=getComputedStyle(el),max=Math.max(0,el.scrollHeight-el.clientHeight);
        if(/auto|scroll/.test(cs.overflowY||'')&&max>1){
          if((dy>0&&el.scrollTop<max-1)||(dy<0&&el.scrollTop>1))return true;
        }
        el=el.parentElement;
      }
      return false;
    }
    window.addEventListener('wheel',function(event){
      if(canConsumeWheel(event.target,event.deltaY))return;
      try{window.parent.postMessage({type:'dmd-network-plan-wheel',deltaX:event.deltaX||0,deltaY:event.deltaY||0},location.origin);}catch(_){}
    },{passive:true});

    window.addEventListener('load',reportHeight);
    window.addEventListener('resize',reportHeight,{passive:true});
    window.addEventListener('dmd-network-plan-layout',reportHeight);
    window.addEventListener('message',function(event){
      if(event.origin!==location.origin)return;
      if(event.data&&event.data.type==='dmd-network-plan-request-height')reportHeight();
    });
    if(window.ResizeObserver){
      const ro=new ResizeObserver(reportHeight);
      ['.side-column','.board-viewport','#linksReport'].forEach(function(selector){
        const el=document.querySelector(selector); if(el)ro.observe(el);
      });
    }
    reportHeight();
    setTimeout(reportHeight,120);
    setTimeout(reportHeight,500);
  })();
  </script>
</body>
</html>
