<?php
session_start();
if (!isset($_SESSION['user']['role_system']) || $_SESSION['user']['role_system'] !== 'admin') {
    http_response_code(403);
    echo "Accès refusé.";
    exit;
}
$baseDir = dirname(__DIR__);
$rii = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($baseDir, FilesystemIterator::SKIP_DOTS),
    RecursiveIteratorIterator::SELF_FIRST
);
$resultats = [];
foreach ($rii as $file) {
    $path = $file->getPathname();
    $relative = substr($path, strlen($baseDir)+1);
    if ($file->isDir()) {
        if (@chmod($path, 0777)) {
            $resultats[] = "📁 ✅ $relative";
        } else {
            $resultats[] = "📁 ❌ $relative";
        }
    } else {
        if (@chmod($path, 0666)) {
            $resultats[] = "📄 ✅ $relative";
        } else {
            $resultats[] = "📄 ❌ $relative";
        }
    }
}
echo "<h2>🔐 Droits corrigés</h2><ul>";
foreach ($resultats as $r) echo "<li>$r</li>";
echo "</ul><a href='site_settings.php'>⬅️ Retour</a>";
?>
