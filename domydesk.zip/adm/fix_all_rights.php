<?php
session_start();

header('Content-Type: text/html; charset=UTF-8');

if (function_exists('mb_internal_encoding')) {
    mb_internal_encoding('UTF-8');
}

$baseDir = dirname(__DIR__);
$profilesDir = $baseDir . '/users/profiles/';
$email = $_SESSION['user']['email'] ?? null;

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function dmd_read_json(string $file, array $default = []): array {
    if (!is_file($file)) return $default;
    $data = json_decode((string)file_get_contents($file), true);
    return is_array($data) ? $data : $default;
}

/* Thème utilisateur */
$theme = 'default';
if ($email) {
    $themeJson = $profilesDir . $email . '/theme.json';
    if (is_file($themeJson)) {
        $themeData = dmd_read_json($themeJson);
        if (!empty($themeData['theme'])) {
            $candidateTheme = basename((string)$themeData['theme']);
            if (is_file($baseDir . '/theme/' . $candidateTheme . '/style.css')) {
                $theme = $candidateTheme;
            }
        }
    }
}
$themeCssFile = $baseDir . '/theme/' . $theme . '/style.css';
$themeCssHref = '../theme/' . rawurlencode($theme) . '/style.css';
if (is_file($themeCssFile)) {
    $themeCssHref .= '?v=' . filemtime($themeCssFile);
}

/* Sécurité admin */
$roleSystem = $_SESSION['user']['role_system'] ?? $_SESSION['role_system'] ?? 'user';

if (!$email || !in_array($roleSystem, ['admin', 'superadmin'], true)) {
    http_response_code(403);
    ?>
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <title>Accès refusé — DoMyDesk</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?= e($themeCssHref) ?>">
    </head>
    <body>
        <?php if (is_file($baseDir . '/header.php')) include $baseDir . '/header.php'; ?>
        <main class="rights-page">
            <section class="rights-hero rights-denied">
                <div>
                    <h1 class="rights-title"><span class="rights-title-icon">⛔</span>Accès refusé</h1>
                    <p class="rights-subtitle">Cette action est réservée aux administrateurs système.</p>
                </div>
                <div class="rights-actions">
                    <a class="rights-btn rights-btn-secondary" href="../profile_view.php">Retour au profil</a>
                </div>
            </section>
        </main>
    </body>
    </html>
    <?php
    exit;
}

/* Correction des droits */
$resultats = [];
$countDirsOk = 0;
$countDirsKo = 0;
$countFilesOk = 0;
$countFilesKo = 0;
$total = 0;
$startTime = microtime(true);

try {
    $rii = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($baseDir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );

    foreach ($rii as $file) {
        $path = $file->getPathname();
        $relative = substr($path, strlen($baseDir) + 1);
        $relative = str_replace('\\', '/', $relative);

        if ($relative === '') continue;

        $total++;

        if ($file->isDir()) {
            $ok = @chmod($path, 0777);
            $ok ? $countDirsOk++ : $countDirsKo++;
            $resultats[] = [
                'type' => 'dir',
                'icon' => '📁',
                'label' => 'Dossier',
                'ok' => $ok,
                'mode' => '0777',
                'path' => $relative
            ];
        } else {
            $ok = @chmod($path, 0666);
            $ok ? $countFilesOk++ : $countFilesKo++;
            $resultats[] = [
                'type' => 'file',
                'icon' => '📄',
                'label' => 'Fichier',
                'ok' => $ok,
                'mode' => '0666',
                'path' => $relative
            ];
        }
    }
} catch (Throwable $ex) {
    $resultats[] = [
        'type' => 'error',
        'icon' => '⚠️',
        'label' => 'Erreur',
        'ok' => false,
        'mode' => '-',
        'path' => 'Erreur : ' . $ex->getMessage()
    ];
}

$duration = round(microtime(true) - $startTime, 3);
$totalOk = $countDirsOk + $countFilesOk;
$totalKo = $countDirsKo + $countFilesKo;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Droits corrigés — DoMyDesk</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?= e($themeCssHref) ?>">
</head>

<body>
<?php if (is_file($baseDir . '/header.php')) include $baseDir . '/header.php'; ?>

<main class="rights-page">

    <header class="rights-hero">
        <div>
            <h1 class="rights-title"><span class="rights-title-icon">🔐</span>Droits corrigés</h1>
            <p>
            </p>
        </div>
        <div class="rights-actions">
            <a class="rights-btn rights-btn-secondary" href="site_settings.php">⬅️ Retour admin</a>
            <a class="rights-btn" href="fix_all_rights.php">🔁 Relancer</a>
        </div>
    </header>

    <section class="rights-stats-grid" aria-label="Résumé">
        <div class="rights-stat-card"><p class="rights-stat-label">Éléments scannés</p><p class="rights-stat-value"><?= (int)$total ?></p></div>
        <div class="rights-stat-card rights-stat-ok"><p class="rights-stat-label">Dossiers OK</p><p class="rights-stat-value"><?= (int)$countDirsOk ?></p></div>
        <div class="rights-stat-card rights-stat-ok"><p class="rights-stat-label">Fichiers OK</p><p class="rights-stat-value"><?= (int)$countFilesOk ?></p></div>
        <div class="rights-stat-card rights-stat-ko"><p class="rights-stat-label">Échecs</p><p class="rights-stat-value"><?= (int)$totalKo ?></p></div>
        <div class="rights-stat-card"><p class="rights-stat-label">Durée</p><p class="rights-stat-value"><?= e($duration) ?>s</p></div>
    </section>

    <section class="rights-tools">
        <input class="rights-search" type="search" id="searchInput" placeholder="Rechercher un fichier ou un dossier..." autocomplete="off">
        <div class="rights-filters" aria-label="Filtres">
            <button type="button" class="rights-filter-btn is-active" data-filter="all">Tout</button>
            <button type="button" class="rights-filter-btn" data-filter="ok">OK</button>
            <button type="button" class="rights-filter-btn" data-filter="ko">Échecs</button>
            <button type="button" class="rights-filter-btn" data-filter="dir">Dossiers</button>
            <button type="button" class="rights-filter-btn" data-filter="file">Fichiers</button>
        </div>
    </section>

    <section class="rights-results-panel">
        <div class="rights-results-head"><div>Type</div><div>Statut</div><div>Droits</div><div>Chemin</div></div>
        <div class="rights-results-list" id="resultsList">
            <?php if (empty($resultats)): ?>
                <div class="rights-empty">Aucun élément traité.</div>
            <?php else: ?>
                <?php foreach ($resultats as $r): ?>
                    <div class="rights-result-row" data-type="<?= e($r['type']) ?>" data-status="<?= $r['ok'] ? 'ok' : 'ko' ?>">
                        <div><span class="rights-badge"><?= e($r['icon']) ?> <?= e($r['label']) ?></span></div>
                        <div>
                            <?php if ($r['ok']): ?>
                                <span class="rights-badge rights-badge-ok">✅ OK</span>
                            <?php else: ?>
                                <span class="rights-badge rights-badge-ko">❌ Échec</span>
                            <?php endif; ?>
                        </div>
                        <div class="rights-mode"><?= e($r['mode']) ?></div>
                        <div class="rights-path" title="<?= e($r['path']) ?>"><?= e($r['path']) ?></div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </section>

</main>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const search = document.getElementById('searchInput');
    const rows = Array.from(document.querySelectorAll('.rights-result-row'));
    const buttons = Array.from(document.querySelectorAll('.rights-filter-btn[data-filter]'));

    let currentFilter = 'all';

    function normalizeText(value) {
        return String(value || '')
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '');
    }

    function getRowType(row) {
        return String(row.dataset.type || row.getAttribute('data-type') || '').toLowerCase();
    }

    function getRowStatus(row) {
        return String(row.dataset.status || row.getAttribute('data-status') || '').toLowerCase();
    }

    function rowMatchesFilter(row) {
        const type = getRowType(row);
        const status = getRowStatus(row);

        switch (currentFilter) {
            case 'ok':
                return status === 'ok';
            case 'ko':
                return status === 'ko';
            case 'dir':
                return type === 'dir';
            case 'file':
                return type === 'file';
            case 'all':
            default:
                return true;
        }
    }

    function applyFilters() {
        const query = normalizeText(search ? search.value : '');

        rows.forEach(function (row) {
            const text = normalizeText(row.textContent || '');
            const visible = text.includes(query) && rowMatchesFilter(row);

            row.style.display = visible ? '' : 'none';
        });
    }

    buttons.forEach(function (button) {
        button.addEventListener('click', function () {
            currentFilter = String(button.dataset.filter || button.getAttribute('data-filter') || 'all').toLowerCase();

            buttons.forEach(function (btn) {
                btn.classList.remove('is-active');
            });

            button.classList.add('is-active');
            applyFilters();
        });
    });

    if (search) {
        search.addEventListener('input', applyFilters);
        search.addEventListener('keyup', applyFilters);
        search.addEventListener('search', applyFilters);
        search.addEventListener('change', applyFilters);
    }

    applyFilters();
});
</script>

</body>
</html>
