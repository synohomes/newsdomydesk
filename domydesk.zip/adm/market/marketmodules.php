<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['user']['email'])) {
    header('Location: ../../login.php');
    exit;
}

$email   = $_SESSION['user']['email'];
$isAdmin = (($_SESSION['user']['role_system'] ?? '') === 'admin');

$baseDir = realpath(__DIR__ . '/../../') ?: __DIR__ . '/../../';
$userDir = $baseDir . '/users/profiles/' . $email . '/';

$theme = 'default';
$themeJson = $userDir . 'theme.json';

if (is_file($themeJson)) {
    $td = json_decode(@file_get_contents($themeJson), true) ?: [];
    if (!empty($td['theme']) && is_file($baseDir . "/theme/{$td['theme']}/style.css")) {
        $theme = basename($td['theme']);
    }
}

$uploadDir  = rtrim($baseDir, '/') . '/uploads/';
$modulesDir = rtrim($baseDir, '/') . '/modules/';
$listFile   = $modulesDir . 'list.json';
$cfgFile    = rtrim($baseDir, '/') . '/data/market/marketcfg.json';

@mkdir($uploadDir, 0775, true);
@mkdir(dirname($cfgFile), 0775, true);

$messages = [];

function slugify($s) {
    $s = preg_replace('~[^a-zA-Z0-9._-]+~', '-', (string)$s);
    return trim($s, '-');
}

function load_json($path) {
    $t = @file_get_contents($path);
    if ($t === false || trim($t) === '') {
        return [];
    }

    $j = json_decode($t, true);
    return is_array($j) ? $j : [];
}

function save_json($path, $data) {
    @mkdir(dirname($path), 0775, true);
    file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    @chmod($path, 0666);
}

function rrmdir_recursive($dir) {
    if (!is_dir($dir)) {
        return;
    }

    foreach (array_diff(scandir($dir), ['.', '..']) as $item) {
        $path = rtrim($dir, '/') . '/' . $item;

        if (is_dir($path)) {
            rrmdir_recursive($path);
        } else {
            @chmod($path, 0666);
            @unlink($path);
        }
    }

    @chmod($dir, 0777);
    @rmdir($dir);
}

function domyco_sync_after_market_action($baseDir, &$messages) {
    $syncFile = rtrim($baseDir, '/') . '/data/domyco_sync.php';

    if (!is_file($syncFile)) {
        $messages[] = [
            'type' => 'error',
            'text' => '⚠️ Sync DomyCo impossible : data/domyco_sync.php introuvable.'
        ];
        return false;
    }

    $beforeLevel = ob_get_level();

    try {
        ob_start();
        require_once $syncFile;

        while (ob_get_level() > $beforeLevel) {
            ob_end_clean();
        }

        if (!function_exists('domyco_sync_register')) {
            $messages[] = [
                'type' => 'error',
                'text' => '⚠️ Sync DomyCo impossible : fonction domyco_sync_register introuvable.'
            ];
            return false;
        }

        ob_start();
        $result = domyco_sync_register($baseDir);

        while (ob_get_level() > $beforeLevel) {
            ob_end_clean();
        }

        if (!empty($result['success'])) {
            $messages[] = [
                'type' => 'success',
                'text' => '✅ Synchronisation DomyCo Register effectuée.'
            ];
            return true;
        }

        $messages[] = [
            'type' => 'error',
            'text' => '⚠️ Sync DomyCo échouée. Voir data/domyco_sync_last.json.'
        ];

        return false;

    } catch (Throwable $e) {
        while (ob_get_level() > $beforeLevel) {
            ob_end_clean();
        }

        $messages[] = [
            'type' => 'error',
            'text' => '⚠️ Erreur sync DomyCo : ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8')
        ];

        return false;
    }
}

function remove_module_from_user_json_value($value, $idsToRemove, &$changed) {
    if (!is_array($value)) {
        return $value;
    }

    $isList = array_keys($value) === range(0, count($value) - 1);

    if ($isList) {
        $filtered = [];

        foreach ($value as $entry) {
            if (is_array($entry)) {
                $entryId = strtolower(slugify($entry['id'] ?? ''));

                if ($entryId !== '' && in_array($entryId, $idsToRemove, true)) {
                    $changed = true;
                    continue;
                }
            }

            $filtered[] = $entry;
        }

        return $filtered;
    }

    if (isset($value['modules']) && is_array($value['modules'])) {
        $filtered = [];

        foreach ($value['modules'] as $entry) {
            if (is_array($entry)) {
                $entryId = strtolower(slugify($entry['id'] ?? ''));

                if ($entryId !== '' && in_array($entryId, $idsToRemove, true)) {
                    $changed = true;
                    continue;
                }
            }

            $filtered[] = $entry;
        }

        $value['modules'] = $filtered;
    }

    if (isset($value['id'])) {
        $entryId = strtolower(slugify($value['id'] ?? ''));

        if ($entryId !== '' && in_array($entryId, $idsToRemove, true)) {
            $changed = true;
            return null;
        }
    }

    return $value;
}

function remove_module_from_users($baseDir, $moduleId, $moduleFolder) {
    $profilesDir = rtrim($baseDir, '/') . '/users/profiles/';

    if (!is_dir($profilesDir)) {
        return;
    }

    $idsToRemove = array_values(array_unique(array_filter([
        strtolower(slugify($moduleId)),
        strtolower(slugify($moduleFolder))
    ])));

    foreach (scandir($profilesDir) as $profileFolder) {
        if ($profileFolder === '.' || $profileFolder === '..') {
            continue;
        }

        $profileDir = $profilesDir . $profileFolder . '/';

        if (!is_dir($profileDir)) {
            continue;
        }

        foreach (glob($profileDir . '*.json') ?: [] as $jsonFile) {
            $fileName = basename($jsonFile);

            if (in_array($fileName, ['profile.json', 'theme.json', 'avatar.json'], true)) {
                continue;
            }

            $json = load_json($jsonFile);
            if (!is_array($json)) {
                continue;
            }

            $changed = false;
            $newJson = remove_module_from_user_json_value($json, $idsToRemove, $changed);

            if ($changed && $newJson !== null) {
                save_json($jsonFile, $newJson);
            }
        }
    }
}

function remove_module_everywhere($baseDir, $modulesDir, $listFile, $moduleId, $moduleFolder, &$messages) {
    $moduleId     = slugify($moduleId);
    $moduleFolder = slugify($moduleFolder ?: $moduleId);

    if ($moduleId === '' && $moduleFolder === '') {
        $messages[] = [
            'type' => 'error',
            'text' => '❌ Module invalide.'
        ];
        return false;
    }

    $idsToRemove = array_values(array_unique(array_filter([
        strtolower($moduleId),
        strtolower($moduleFolder)
    ])));

    $deletedFolder = false;
    $removedFromList = false;

    /*
     * 1. Suppression du dossier réel du module
     */
    $possibleFolders = array_unique(array_filter([
        $moduleFolder,
        $moduleId
    ]));

    foreach ($possibleFolders as $folder) {
        $modulePath = rtrim($modulesDir, '/') . '/' . $folder . '/';

        if (is_dir($modulePath)) {
            rrmdir_recursive($modulePath);
            $deletedFolder = !is_dir($modulePath);
        }
    }

    /*
     * 2. Suppression dans modules/list.json
     */
    $list = load_json($listFile);
    $newList = [];

    foreach ($list as $module) {
        if (!is_array($module)) {
            continue;
        }

        $listId   = strtolower(slugify($module['id'] ?? ''));
        $listName = strtolower(slugify($module['name'] ?? ''));
        $icon     = strtolower((string)($module['icon'] ?? ''));

        $match = false;

        foreach ($idsToRemove as $rid) {
            if ($rid === '') {
                continue;
            }

            if ($listId === $rid || $listName === $rid) {
                $match = true;
                break;
            }

            if (strpos($icon, 'modules/' . $rid . '/') !== false || strpos($icon, '/modules/' . $rid . '/') !== false) {
                $match = true;
                break;
            }
        }

        if ($match) {
            $removedFromList = true;
            continue;
        }

        $newList[] = $module;
    }

    save_json($listFile, $newList);

    /*
     * 3. Suppression dans les fichiers utilisateurs
     */
    remove_module_from_users($baseDir, $moduleId, $moduleFolder);

    if ($deletedFolder || $removedFromList) {
        $messages[] = [
            'type' => 'success',
            'text' => "✅ Module <strong>" . htmlspecialchars($moduleId ?: $moduleFolder, ENT_QUOTES, 'UTF-8') . "</strong> supprimé."
        ];
    } else {
        $messages[] = [
            'type' => 'error',
            'text' => "⚠️ Aucun dossier ni entrée list.json supprimé pour <strong>" . htmlspecialchars($moduleId ?: $moduleFolder, ENT_QUOTES, 'UTF-8') . "</strong>."
        ];
    }

    return true;
}

function github_to_raw($url) {
    $url = trim((string)$url);

    if ($url === '') {
        return $url;
    }

    $url = preg_replace('~\?.*$~', '', $url);
    $url = preg_replace('~/refs/heads/([^/]+)/~', '/$1/', $url);

    if (preg_match('~^https?://github\.com/([^/]+)/([^/]+)/blob/([^/]+)/(.*)$~i', $url, $m)) {
        return "https://raw.githubusercontent.com/{$m[1]}/{$m[2]}/{$m[3]}/{$m[4]}";
    }

    if (preg_match('~^https?://github\.com/([^/]+)/([^/]+)/raw/([^/]+)/(.*)$~i', $url, $m)) {
        return "https://raw.githubusercontent.com/{$m[1]}/{$m[2]}/{$m[3]}/{$m[4]}";
    }

    return $url;
}

function http_download($url, $dest, &$why = null) {
    $why = '';
    $url = github_to_raw($url);

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        $fp = fopen($dest, 'wb');

        curl_setopt_array($ch, [
            CURLOPT_FILE           => $fp,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_USERAGENT      => 'DoMyDesk-Market/1.0',
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT        => 60,
        ]);

        $ok   = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);

        curl_close($ch);
        fclose($fp);

        if (!$ok || $code < 200 || $code >= 300) {
            @unlink($dest);
            $why = "HTTP $code via cURL" . ($err ? " ($err)" : "");
            return false;
        }

        if (!filesize($dest)) {
            @unlink($dest);
            $why = 'Fichier vide après cURL';
            return false;
        }

        return true;
    }

    $ctx = stream_context_create([
        'http' => [
            'header'  => "User-Agent: DoMyDesk-Market/1.0\r\n",
            'timeout' => 60
        ]
    ]);

    $data = @file_get_contents($url, false, $ctx);

    if ($data === false) {
        $why = 'file_get_contents a échoué';
        return false;
    }

    if (!strlen($data)) {
        $why = 'Réponse vide';
        return false;
    }

    if (file_put_contents($dest, $data) === false) {
        $why = "Écriture impossible: $dest";
        return false;
    }

    return true;
}

function http_get_body($url, &$why = null) {
    $why = '';

    if (function_exists('curl_init')) {
        $ch = curl_init($url);

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_USERAGENT      => 'DoMyDesk-Market/1.0',
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT        => 30,
        ]);

        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);

        curl_close($ch);

        if ($body === false || $code < 200 || $code >= 300) {
            $why = $body === false ? ("cURL error: " . $err) : ("HTTP $code");
            return false;
        }

        return $body;
    }

    $ctx = stream_context_create([
        'http' => [
            'header'  => "User-Agent: DoMyDesk-Market/1.0\r\n",
            'timeout' => 30
        ]
    ]);

    $body = @file_get_contents($url, false, $ctx);

    if ($body === false) {
        $why = 'file_get_contents a échoué (allow_url_fopen ?)';
        return false;
    }

    return $body;
}

$cfg = load_json($cfgFile);

if (empty($cfg['catalog_url'])) {
    $cfg['catalog_url'] = 'https://github.com/synohomes/newsdomydesk/raw/refs/heads/main/modulesmarket.json';
    save_json($cfgFile, $cfg);
}

$catalogUrl = github_to_raw($cfg['catalog_url']);

/*
 * Enregistrement URL catalogue
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_catalog_url']) && $isAdmin) {
    $u = github_to_raw($_POST['catalog_url'] ?? '');

    if ($u === '') {
        $messages[] = [
            'type' => 'error',
            'text' => '❌ URL de catalogue vide.'
        ];
    } else {
        $cfg['catalog_url'] = $u;
        save_json($cfgFile, $cfg);
        $messages[] = [
            'type' => 'success',
            'text' => '✅ URL du catalogue enregistrée.'
        ];
        $catalogUrl = $u;
    }
}

/*
 * Installation module depuis URL
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_url'], $_POST['module_id'])) {
    $url = trim($_POST['download_url']);
    $id  = slugify($_POST['module_id']);

    if ($url && $id) {
        $zipTmp = $uploadDir . $id . '.zip';

        if (!http_download($url, $zipTmp, $why)) {
            $messages[] = [
                'type' => 'error',
                'text' => "❌ Téléchargement échoué : " . htmlspecialchars($why, ENT_QUOTES, 'UTF-8') . " — URL : " . htmlspecialchars($url, ENT_QUOTES, 'UTF-8')
            ];
        } else {
            $zip = new ZipArchive();

            if ($zip->open($zipTmp) === true) {
                $extractDir = $modulesDir . $id . '/';

                @mkdir($extractDir, 0777, true);

                $zip->extractTo($extractDir);
                $zip->close();

                @unlink($zipTmp);

                $rii = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($extractDir, FilesystemIterator::SKIP_DOTS),
                    RecursiveIteratorIterator::SELF_FIRST
                );

                foreach ($rii as $f) {
                    if ($f->isDir()) {
                        @chmod($f->getPathname(), 0777);
                    } else {
                        @chmod($f->getPathname(), 0666);
                    }
                }

                @chmod($extractDir, 0777);

                $list = load_json($listFile);
                $exists = false;

                foreach ($list as $e) {
                    if (strtolower(slugify($e['id'] ?? '')) === strtolower($id)) {
                        $exists = true;
                        break;
                    }
                }

                if (!$exists) {
                    $list[] = [
                        'id'          => $id,
                        'name'        => ucfirst($id),
                        'description' => "Module $id installé via URL",
                        'icon'        => "modules/$id/icon.png",
                        'enabled'     => false
                    ];

                    save_json($listFile, $list);
                }

                $messages[] = [
                    'type' => 'success',
                    'text' => "✅ Module <strong>" . htmlspecialchars($id, ENT_QUOTES, 'UTF-8') . "</strong> installé."
                ];

                domyco_sync_after_market_action($baseDir, $messages);

            } else {
                @unlink($zipTmp);

                $messages[] = [
                    'type' => 'error',
                    'text' => "❌ Impossible d’ouvrir le ZIP pour <strong>" . htmlspecialchars($id, ENT_QUOTES, 'UTF-8') . "</strong>."
                ];
            }
        }
    } else {
        $messages[] = [
            'type' => 'error',
            'text' => "❌ Paramètres invalides pour l’installation."
        ];
    }
}

/*
 * Installation module depuis ZIP uploadé
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['module_zip'])) {
    if ($_FILES['module_zip']['error'] === UPLOAD_ERR_OK) {
        $zipPath = $uploadDir . basename($_FILES['module_zip']['name']);
        $id = slugify(pathinfo($zipPath, PATHINFO_FILENAME));

        if (move_uploaded_file($_FILES['module_zip']['tmp_name'], $zipPath)) {
            $zip = new ZipArchive();

            if ($zip->open($zipPath) === true) {
                $extractDir = $modulesDir . $id . '/';

                @mkdir($extractDir, 0777, true);

                $zip->extractTo($extractDir);
                $zip->close();

                @unlink($zipPath);

                $rii = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($extractDir, FilesystemIterator::SKIP_DOTS),
                    RecursiveIteratorIterator::SELF_FIRST
                );

                foreach ($rii as $f) {
                    if ($f->isDir()) {
                        @chmod($f->getPathname(), 0777);
                    } else {
                        @chmod($f->getPathname(), 0666);
                    }
                }

                @chmod($extractDir, 0777);

                $list = load_json($listFile);
                $exists = false;

                foreach ($list as $e) {
                    if (strtolower(slugify($e['id'] ?? '')) === strtolower($id)) {
                        $exists = true;
                        break;
                    }
                }

                if (!$exists) {
                    $list[] = [
                        'id'          => $id,
                        'name'        => ucfirst($id),
                        'description' => "Module $id ajouté manuellement",
                        'icon'        => "modules/$id/icon.png",
                        'enabled'     => false
                    ];

                    save_json($listFile, $list);
                }

                $messages[] = [
                    'type' => 'success',
                    'text' => "✅ Module <strong>" . htmlspecialchars($id, ENT_QUOTES, 'UTF-8') . "</strong> installé depuis un ZIP."
                ];

                domyco_sync_after_market_action($baseDir, $messages);

            } else {
                $messages[] = [
                    'type' => 'error',
                    'text' => "❌ Erreur ouverture ZIP."
                ];
            }
        } else {
            $messages[] = [
                'type' => 'error',
                'text' => "❌ Échec de l’upload du ZIP."
            ];
        }
    } else {
        $messages[] = [
            'type' => 'error',
            'text' => "❌ Code d’erreur upload : " . (int)$_FILES['module_zip']['error']
        ];
    }
}

/*
 * Suppression module
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_module'])) {
    $moduleId = slugify($_POST['remove_module'] ?? '');
    $moduleFolder = slugify($_POST['remove_module_folder'] ?? $moduleId);

    if ($moduleId !== '' || $moduleFolder !== '') {
        remove_module_everywhere($baseDir, $modulesDir, $listFile, $moduleId, $moduleFolder, $messages);
        domyco_sync_after_market_action($baseDir, $messages);
    } else {
        $messages[] = [
            'type' => 'error',
            'text' => '❌ Module invalide.'
        ];
    }
}

if (!headers_sent()) {
    header('Content-Type: text/html; charset=UTF-8');
}

/*
 * Liste des modules installés
 * Elle lit à la fois :
 * - modules/list.json
 * - dossiers présents dans modules/
 */
$installedMap = [];

$list = load_json($listFile);

foreach ($list as $module) {
    if (!is_array($module)) {
        continue;
    }

    $id = slugify($module['id'] ?? '');

    if ($id === '') {
        continue;
    }

    $folder = $id;

    if (!empty($module['icon']) && preg_match('~modules/([^/]+)/~', (string)$module['icon'], $m)) {
        $folder = slugify($m[1]);
    }

    $installedMap[$id] = [
        'id'     => $id,
        'folder' => $folder,
        'name'   => $module['name'] ?? $id,
        'source' => 'list'
    ];
}

if (is_dir($modulesDir)) {
    foreach (scandir($modulesDir) as $folder) {
        if ($folder === '.' || $folder === '..' || $folder[0] === '.') {
            continue;
        }

        if (!is_dir($modulesDir . $folder)) {
            continue;
        }

        $folderId = slugify($folder);

        if ($folderId === '' || strtolower($folderId) === 'list.json') {
            continue;
        }

        $matched = false;

        foreach ($installedMap as $k => $mod) {
            if (strtolower($mod['folder']) === strtolower($folderId) || strtolower($mod['id']) === strtolower($folderId)) {
                $installedMap[$k]['source'] = 'list+folder';
                $installedMap[$k]['folder'] = $folderId;
                $matched = true;
                break;
            }
        }

        if (!$matched) {
            $installedMap[$folderId] = [
                'id'     => $folderId,
                'folder' => $folderId,
                'name'   => $folderId,
                'source' => 'folder'
            ];
        }
    }
}

ksort($installedMap);
$installed = array_values($installedMap);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Market des Modules</title>
<link rel="stylesheet" href="../../theme/<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>/style.css">
<style>
.market-wrapper{max-width:1300px;margin:30px auto;padding:10px;}
.grid-columns{display:grid;grid-template-columns:1fr 1fr;gap:20px;}
@media (max-width:1100px){.grid-columns{grid-template-columns:1fr;}}
.message{margin:10px 0;padding:10px;border-radius:8px;background:rgba(0,0,0,.2);}
.message.success::before{content:"✅ ";}
.message.error::before{content:"❌ ";}
.modules-table{width:100%;border-collapse:collapse;}
.modules-table th,.modules-table td{padding:10px;border-bottom:1px solid currentColor;text-align:left;}
.upload-section{margin-top:20px;padding:16px;border:1px dashed currentColor;border-radius:12px;}
.small{opacity:.75;font-size:12px;}
.danger-btn{background:#b00020;color:#fff;border:0;border-radius:8px;padding:8px 12px;cursor:pointer;}
</style>
</head>
<body>

<div class="market-wrapper container">
  <h1>Tous les modules</h1>

  <?php foreach ($messages as $m): ?>
    <div class="message <?= htmlspecialchars($m['type'], ENT_QUOTES, 'UTF-8') ?>"><?= $m['text'] ?></div>
  <?php endforeach; ?>

  <?php if ($isAdmin): ?>
  <?php endif; ?>

  <div class="grid-columns">

    <div class="section">
      <h2>Catalogue modules</h2>

      <?php
      $why = '';
      $raw = http_get_body($catalogUrl, $why);

      if ($raw === false) {
          echo "<div class='message error'>Impossible de charger le catalogue : "
              . htmlspecialchars($catalogUrl, ENT_QUOTES, 'UTF-8')
              . "<br><span class='small'>Détail : "
              . htmlspecialchars($why, ENT_QUOTES, 'UTF-8')
              . "</span></div>";
      } else {
          $marketModules = json_decode($raw, true);

          if (!is_array($marketModules)) {
              echo "<div class='message error'>Catalogue JSON invalide.</div>";
          } else {
              $categories = [];

              foreach ($marketModules as $mod) {
                  $cat = !empty($mod['category']) ? $mod['category'] : 'Autres';
                  $categories[$cat][] = $mod;
              }

              ksort($categories);

              foreach ($categories as $catName => $modules) {
                  echo "<h3 style='margin-top:20px; border-left: 4px solid #007bff; padding-left:10px;'>"
                      . htmlspecialchars($catName, ENT_QUOTES, 'UTF-8')
                      . "</h3>";

                  echo "<table class='modules-table'><tr><th>Nom</th><th>Description</th><th>Action</th></tr>";

                  foreach ($modules as $mod) {
                      $id   = slugify($mod['id'] ?? ($mod['name'] ?? 'module'));
                      $name = $mod['name'] ?? $id;
                      $desc = $mod['description'] ?? '';
                      $dl   = $mod['download_url'] ?? $mod['download'] ?? $mod['url'] ?? $mod['zip'] ?? null;

                      if ($dl) {
                          $dl = github_to_raw($dl);
                      }

                      echo "<tr>";
                      echo "<td>" . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . "</td>";
                      echo "<td>" . htmlspecialchars($desc, ENT_QUOTES, 'UTF-8') . "</td>";
                      echo "<td>";

                      if ($dl) {
                          echo "<form method='post' style='margin:0;'>
                                  <input type='hidden' name='download_url' value='" . htmlspecialchars($dl, ENT_QUOTES, 'UTF-8') . "'>
                                  <input type='hidden' name='module_id' value='" . htmlspecialchars($id, ENT_QUOTES, 'UTF-8') . "'>
                                  <button type='submit'>Installer</button>
                                </form>";
                      } else {
                          echo "<span class='small'>Lien manquant</span>";
                      }

                      echo "</td>";
                      echo "</tr>";
                  }

                  echo "</table>";
              }
          }
      }
      ?>
    </div>

    <div class="section">
      <h2> Modules installés</h2>

      <?php
      if (!empty($installed)) {
          echo "<table class='modules-table'><tr><th>Nom</th><th>Source</th><th>Action</th></tr>";

          foreach ($installed as $mod) {
              echo "<tr>";
              echo "<td>"
                  . htmlspecialchars($mod['name'], ENT_QUOTES, 'UTF-8')
                  . "<br><span class='small'>ID : "
                  . htmlspecialchars($mod['id'], ENT_QUOTES, 'UTF-8')
                  . " / dossier : "
                  . htmlspecialchars($mod['folder'], ENT_QUOTES, 'UTF-8')
                  . "</span></td>";

              echo "<td>" . htmlspecialchars($mod['source'], ENT_QUOTES, 'UTF-8') . "</td>";

              echo "<td>
                      <form method='post' style='margin:0;' onsubmit=\"return confirm('Supprimer ce module ?');\">
                        <input type='hidden' name='remove_module' value='" . htmlspecialchars($mod['id'], ENT_QUOTES, 'UTF-8') . "'>
                        <input type='hidden' name='remove_module_folder' value='" . htmlspecialchars($mod['folder'], ENT_QUOTES, 'UTF-8') . "'>
                        <button type='submit' class='danger-btn'>Supprimer</button>
                      </form>
                    </td>";

              echo "</tr>";
          }

          echo "</table>";
      } else {
          echo "<p>Aucun module installé.</p>";
      }
      ?>

      <div class="upload-section">
        <h3> Ajouter un module ZIP</h3>

        <form method="post" enctype="multipart/form-data" style="margin:0;">
          <input type="file" name="module_zip" accept=".zip" required>
          <br><br>
          <button type="submit">Uploader le module ZIP</button>
        </form>
      </div>
    </div>

  </div>
</div>

</body>
</html>