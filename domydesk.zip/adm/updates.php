<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');

if (function_exists('mb_internal_encoding')) {
    mb_internal_encoding('UTF-8');
}

$GITHUB_UPDATES_JSON_URL = 'https://raw.githubusercontent.com/synohomes/newsdomydesk/refs/heads/main/updates.json';

$email = $_SESSION['user']['email'] ?? null;

if (!$email) {
    header('Location: ../login.php');
    exit;
}

$baseDir = dirname(__DIR__);
$profilesDir = $baseDir . '/users/profiles/';
$profileFile = $profilesDir . $email . '/profile.json';

if (!is_file($profileFile)) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

$profileData = json_decode((string)file_get_contents($profileFile), true);

if (!is_array($profileData)) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

$roleSystem = $profileData['role_system'] ?? 'user';

if (!in_array($roleSystem, ['admin', 'superadmin'], true)) {
    header('Location: ../profile_view.php');
    exit;
}

$updatesDir = $baseDir . '/data/updates/';
$logsFile = $updatesDir . 'logs.json';

if (!is_dir($updatesDir)) {
    @mkdir($updatesDir, 0775, true);
}

$theme = 'default';
$themeJson = $profilesDir . $email . '/theme.json';

if (is_file($themeJson)) {
    $themeData = json_decode((string)file_get_contents($themeJson), true);

    if (is_array($themeData) && !empty($themeData['theme'])) {
        $candidateTheme = basename((string)$themeData['theme']);

        if (is_file($baseDir . '/theme/' . $candidateTheme . '/style.css')) {
            $theme = $candidateTheme;
        }
    }
}

$themeCssFile = $baseDir . '/theme/' . $theme . '/style.css';
$themeCssHref = '../theme/' . rawurlencode($theme) . '/style.css';

if (is_file($themeCssFile)) {
    $themeCssHref .= '?v=' . filemtime($themeCssFile);
}

function dmd_updates_h($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function dmd_updates_read_json(string $file, $default = []) {
    if (!is_file($file)) {
        return $default;
    }

    $data = json_decode((string)file_get_contents($file), true);

    return is_array($data) ? $data : $default;
}

function dmd_updates_write_json(string $file, array $data): bool {
    $dir = dirname($file);

    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }

    return file_put_contents(
        $file,
        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
    ) !== false;
}

function dmd_updates_clean_item(array $item): array {
    return [
        'titre' => trim((string)($item['titre'] ?? '')),
        'soustitre' => trim((string)($item['soustitre'] ?? '')),
        'date' => trim((string)($item['date'] ?? '')),
        'update' => trim((string)($item['update'] ?? '')),
        'description' => trim((string)($item['description'] ?? ''))
    ];
}

function dmd_updates_clean_log_item(array $item): array {
    $clean = dmd_updates_clean_item($item);

    $clean['installed_at'] = trim((string)($item['installed_at'] ?? ''));
    $clean['installed_by'] = trim((string)($item['installed_by'] ?? ''));

    return $clean;
}

function dmd_updates_has_main_fields(array $item): bool {
    $item = dmd_updates_clean_item($item);

    return $item['titre'] !== ''
        && $item['date'] !== ''
        && $item['update'] !== ''
        && $item['description'] !== '';
}

function dmd_updates_is_list(array $array): bool {
    if (function_exists('array_is_list')) {
        return array_is_list($array);
    }

    $i = 0;

    foreach ($array as $key => $_value) {
        if ($key !== $i++) {
            return false;
        }
    }

    return true;
}

function dmd_updates_url_dir(string $url): string {
    $pos = strrpos($url, '/');

    if ($pos === false) {
        return $url;
    }

    return substr($url, 0, $pos);
}

function dmd_updates_filename_from_title(string $title): string {
    $title = trim($title);
    $title = str_replace(['/', '\\', "\0"], '-', $title);

    return $title;
}

function dmd_updates_build_candidate_zip_urls(array $item, string $jsonUrl): array {
    $urls = [];

    foreach (['zip_url', 'url_zip', 'download_url', 'zip', 'url'] as $field) {
        if (!empty($item[$field])) {
            $urls[] = trim((string)$item[$field]);
        }
    }

    $base = dmd_updates_url_dir($jsonUrl);

    $titre = dmd_updates_filename_from_title((string)($item['titre'] ?? ''));
    $soustitre = dmd_updates_filename_from_title((string)($item['soustitre'] ?? ''));
    $update = dmd_updates_filename_from_title((string)($item['update'] ?? ''));

    foreach ([$titre, $soustitre, $update] as $name) {
        if ($name !== '') {
            $urls[] = $base . '/' . rawurlencode($name) . '.zip';
            $urls[] = $base . '/updates/' . rawurlencode($name) . '.zip';
            $urls[] = $base . '/zips/' . rawurlencode($name) . '.zip';
        }
    }

    return array_values(array_unique(array_filter($urls)));
}

function dmd_updates_fetch_catalog(string $url): array {
    $context = stream_context_create([
        'http' => [
            'timeout' => 25,
            'user_agent' => 'DoMyDesk-Updates'
        ],
        'https' => [
            'timeout' => 25,
            'user_agent' => 'DoMyDesk-Updates'
        ]
    ]);

    $raw = @file_get_contents($url, false, $context);

    if ($raw === false) {
        return [];
    }

    $json = json_decode($raw, true);

    if (!is_array($json)) {
        return [];
    }

    if (isset($json['updates']) && is_array($json['updates'])) {
        $json = $json['updates'];
    }

    if (!dmd_updates_is_list($json)) {
        return [];
    }

    $items = [];

    foreach ($json as $item) {
        if (!is_array($item)) {
            continue;
        }

        $clean = dmd_updates_clean_item($item);

        if (!dmd_updates_has_main_fields($clean)) {
            continue;
        }

        $clean['_zip_urls'] = dmd_updates_build_candidate_zip_urls($item, $url);

        $items[] = $clean;
    }

    return $items;
}

function dmd_updates_download_file(string $url, string $dest): bool {
    $context = stream_context_create([
        'http' => [
            'timeout' => 60,
            'user_agent' => 'DoMyDesk-Updates'
        ],
        'https' => [
            'timeout' => 60,
            'user_agent' => 'DoMyDesk-Updates'
        ]
    ]);

    $content = @file_get_contents($url, false, $context);

    if ($content === false || strlen($content) < 10) {
        return false;
    }

    return file_put_contents($dest, $content) !== false;
}

function dmd_updates_download_first_available(array $urls, string $dest): bool {
    foreach ($urls as $url) {
        $url = trim((string)$url);

        if ($url === '') {
            continue;
        }

        if (dmd_updates_download_file($url, $dest)) {
            return true;
        }
    }

    return false;
}

function dmd_updates_remove_dir(string $dir): void {
    if (!is_dir($dir)) {
        return;
    }

    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );

    foreach ($iterator as $item) {
        if ($item->isDir()) {
            @rmdir($item->getPathname());
        } else {
            @unlink($item->getPathname());
        }
    }

    @rmdir($dir);
}

function dmd_updates_temp_dir(string $updatesDir): string {
    $base = $updatesDir . 'tmp_' . date('Y-m-d_H-i-s');
    $dir = $base;
    $i = 2;

    while (file_exists($dir)) {
        $dir = $base . '_' . $i;
        $i++;
    }

    @mkdir($dir, 0775, true);

    return $dir;
}

function dmd_updates_starts_with(string $text, string $needle): bool {
    return substr($text, 0, strlen($needle)) === $needle;
}

function dmd_updates_bad_zip_path(string $path): bool {
    $path = str_replace('\\', '/', trim($path));

    if ($path === '') {
        return true;
    }

    if (dmd_updates_starts_with($path, '/')) {
        return true;
    }

    if (preg_match('#(^|/)\.\.(/|$)#', $path)) {
        return true;
    }

    if (strpos($path, "\0") !== false) {
        return true;
    }

    $blocked = [
        '.git/',
        '.env',
        'data/updates/',
        'users/profiles/'
    ];

    foreach ($blocked as $block) {
        if (dmd_updates_starts_with($path, $block)) {
            return true;
        }
    }

    return false;
}

function dmd_updates_copy_file(string $source, string $target): bool {
    $dir = dirname($target);

    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }

    return @copy($source, $target);
}

function dmd_updates_apply_zip(string $zipPath, string $baseDir, string $tempDir): array {
    $result = [
        'success' => false,
        'message' => ''
    ];

    if (!class_exists('ZipArchive')) {
        $result['message'] = 'ZipArchive n’est pas disponible.';
        return $result;
    }

    if (!is_file($zipPath)) {
        $result['message'] = 'ZIP introuvable.';
        return $result;
    }

    $zip = new ZipArchive();

    if ($zip->open($zipPath) !== true) {
        $result['message'] = 'Impossible d’ouvrir le ZIP.';
        return $result;
    }

    $extractDir = $tempDir . '/extract';

    if (!is_dir($extractDir)) {
        @mkdir($extractDir, 0775, true);
    }

    if (!$zip->extractTo($extractDir)) {
        $zip->close();
        $result['message'] = 'Extraction impossible.';
        return $result;
    }

    $zip->close();

    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($extractDir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );

    foreach ($iterator as $item) {
        if ($item->isDir()) {
            continue;
        }

        $sourcePath = $item->getPathname();
        $relativePath = substr($sourcePath, strlen($extractDir) + 1);
        $relativePath = str_replace('\\', '/', $relativePath);

        if ($relativePath === 'update.json' || $relativePath === 'manifest.json') {
            continue;
        }

        if (dmd_updates_bad_zip_path($relativePath)) {
            continue;
        }

        dmd_updates_copy_file($sourcePath, $baseDir . '/' . $relativePath);
    }

    $result['success'] = true;
    $result['message'] = 'Update appliquée.';

    return $result;
}

function dmd_updates_read_zip_meta(string $zipPath): array {
    if (!class_exists('ZipArchive') || !is_file($zipPath)) {
        return [];
    }

    $zip = new ZipArchive();

    if ($zip->open($zipPath) !== true) {
        return [];
    }

    $raw = false;

    foreach (['update.json', 'manifest.json'] as $file) {
        $index = $zip->locateName($file);

        if ($index !== false) {
            $raw = $zip->getFromIndex($index);
            break;
        }
    }

    $zip->close();

    if ($raw === false) {
        return [];
    }

    $json = json_decode((string)$raw, true);

    if (!is_array($json)) {
        return [];
    }

    $meta = dmd_updates_clean_item($json);

    if (!dmd_updates_has_main_fields($meta)) {
        return [];
    }

    return $meta;
}

function dmd_updates_manual_meta(string $uploadedName): array {
    $titre = trim(pathinfo($uploadedName, PATHINFO_FILENAME));

    if ($titre === '') {
        $titre = 'update-manuelle';
    }

    return [
        'titre' => $titre,
        'soustitre' => '',
        'date' => date('Y-m-d'),
        'update' => 'manual',
        'description' => ''
    ];
}

function dmd_updates_append_log(string $logsFile, array $item, string $email): bool {
    $logs = dmd_updates_read_json($logsFile, []);

    if (!is_array($logs)) {
        $logs = [];
    }

    $log = dmd_updates_clean_log_item($item);
    $log['installed_at'] = date('Y-m-d H:i:s');
    $log['installed_by'] = $email;

    $logs[] = $log;

    return dmd_updates_write_json($logsFile, $logs);
}

$messages = [];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'github_update') {
        $urlsRaw = (string)($_POST['zip_urls'] ?? '');
        $urlsJson = base64_decode($urlsRaw, true);
        $zipUrls = $urlsJson !== false ? json_decode((string)$urlsJson, true) : [];

        if (!is_array($zipUrls)) {
            $zipUrls = [];
        }

        $metaRaw = (string)($_POST['meta'] ?? '');
        $metaJson = base64_decode($metaRaw, true);
        $meta = $metaJson !== false ? json_decode((string)$metaJson, true) : [];

        if (!is_array($meta)) {
            $meta = [];
        }

        $meta = dmd_updates_clean_item($meta);

        if (!dmd_updates_has_main_fields($meta)) {
            $errors[] = 'Update invalide.';
        } else {
            $tempDir = dmd_updates_temp_dir($updatesDir);
            $zipPath = $tempDir . '/source.zip';

            if (!dmd_updates_download_first_available($zipUrls, $zipPath)) {
                $errors[] = 'ZIP introuvable.';
                dmd_updates_remove_dir($tempDir);
            } else {
                $apply = dmd_updates_apply_zip($zipPath, $baseDir, $tempDir);

                if ($apply['success']) {
                    dmd_updates_append_log($logsFile, $meta, $email);
                    $messages[] = 'Update appliquée.';
                } else {
                    $errors[] = $apply['message'];
                }

                dmd_updates_remove_dir($tempDir);
            }
        }
    }

    if ($action === 'manual_update') {
        if (empty($_FILES['update_zip']['tmp_name'])) {
            $errors[] = 'Aucun ZIP envoyé.';
        } else {
            $uploadedName = $_FILES['update_zip']['name'] ?? 'update.zip';
            $ext = strtolower(pathinfo($uploadedName, PATHINFO_EXTENSION));

            if ($ext !== 'zip') {
                $errors[] = 'Le fichier doit être un ZIP.';
            } else {
                $tempDir = dmd_updates_temp_dir($updatesDir);
                $zipPath = $tempDir . '/source.zip';

                if (!@move_uploaded_file($_FILES['update_zip']['tmp_name'], $zipPath)) {
                    $errors[] = 'Upload impossible.';
                    dmd_updates_remove_dir($tempDir);
                } else {
                    $meta = dmd_updates_read_zip_meta($zipPath);

                    if (empty($meta)) {
                        $meta = dmd_updates_manual_meta($uploadedName);
                    }

                    $apply = dmd_updates_apply_zip($zipPath, $baseDir, $tempDir);

                    if ($apply['success']) {
                        dmd_updates_append_log($logsFile, $meta, $email);
                        $messages[] = 'Update appliquée.';
                    } else {
                        $errors[] = $apply['message'];
                    }

                    dmd_updates_remove_dir($tempDir);
                }
            }
        }
    }
}

$catalog = dmd_updates_fetch_catalog($GITHUB_UPDATES_JSON_URL);
$logs = dmd_updates_read_json($logsFile, []);

if (!is_array($logs)) {
    $logs = [];
}

$installed = array_reverse(array_values(array_filter($logs, 'is_array')));
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Updates DoMyDesk</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="<?= dmd_updates_h($themeCssHref) ?>">
</head>
<body>

<div class="pe-page">

    <div class="pe-head">
        <div>
            <h1 class="pe-title">Toutes les updates</h1>
            <p class="pe-subtitle">Catalogue GitHub et updates installées.</p>
        </div>
    </div>

    <?php if (!empty($messages)): ?>
        <div class="pe-msg pe-msg-ok">
            <?php foreach ($messages as $message): ?>
                <?= dmd_updates_h($message) ?><br>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($errors)): ?>
        <div class="pe-msg pe-msg-error">
            <?php foreach ($errors as $error): ?>
                <?= dmd_updates_h($error) ?><br>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="pe-form-row">

        <section class="pe-section">
            <h2 class="pe-section-title">Catalogue updates</h2>

            <?php if (empty($catalog)): ?>
                <p class="pe-note">Aucune update disponible.</p>
            <?php else: ?>
                <div class="table-wrap">
                    <table class="roles-table">
                        <thead>
                            <tr>
                                <th>Titre</th>
                                <th>Date</th>
                                <th>Installation</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($catalog as $index => $update): ?>
                                <?php
                                $popupId = 'popup-update-catalog-' . $index;
                                $zipUrls = $update['_zip_urls'] ?? [];
                                $visibleMeta = dmd_updates_clean_item($update);
                                $metaEncoded = base64_encode(json_encode($visibleMeta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
                                $urlsEncoded = base64_encode(json_encode($zipUrls, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
                                ?>
                                <tr>
                                    <td>
                                        <button type="button" class="btn" data-popup-open="<?= dmd_updates_h($popupId) ?>">
                                            <?= dmd_updates_h($update['titre']) ?>
                                        </button>
                                    </td>
                                    <td><?= dmd_updates_h($update['date']) ?></td>
                                    <td>
                                        <form method="post" accept-charset="UTF-8" onsubmit="return confirm('Installer cette update ?');">
                                            <input type="hidden" name="action" value="github_update">
                                            <input type="hidden" name="zip_urls" value="<?= dmd_updates_h($urlsEncoded) ?>">
                                            <input type="hidden" name="meta" value="<?= dmd_updates_h($metaEncoded) ?>">
                                            <button type="submit">Installer</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <?php foreach ($catalog as $index => $update): ?>
                    <?php $popupId = 'popup-update-catalog-' . $index; ?>
                    <div id="<?= dmd_updates_h($popupId) ?>" class="pe-popup" aria-hidden="true">
                        <div class="pe-popup-window">
                            <div class="pe-popup-head">
                                <h2><?= dmd_updates_h($update['titre']) ?></h2>
                                <button type="button" data-popup-close>Fermer</button>
                            </div>
                            <div class="pe-popup-body">
                                <?php if (!empty($update['soustitre'])): ?>
                                    <p><strong><?= dmd_updates_h($update['soustitre']) ?></strong></p>
                                <?php endif; ?>
                                <p class="pe-note"><?= dmd_updates_h($update['date']) ?> — <?= dmd_updates_h($update['update']) ?></p>
                                <p><?= nl2br(dmd_updates_h($update['description'])) ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <h2 class="pe-section-title">Update manuelle</h2>

            <form method="post" accept-charset="UTF-8" enctype="multipart/form-data" class="pe-form" onsubmit="return confirm('Installer ce ZIP de mise à jour ?');">
                <input type="hidden" name="action" value="manual_update">

                <div>
                    <label>ZIP de mise à jour</label>
                    <input type="file" name="update_zip" accept=".zip" required>
                </div>

                <p class="pe-note">Le ZIP doit contenir l’arborescence depuis la racine DoMyDesk.</p>

                <div class="pe-actions">
                    <button type="submit">Installer le ZIP</button>
                </div>
            </form>
        </section>

        <section class="pe-section">
            <h2 class="pe-section-title">Updates installées</h2>

            <?php if (empty($installed)): ?>
                <p class="pe-note">Aucune update installée.</p>
            <?php else: ?>
                <div class="table-wrap">
                    <table class="roles-table">
                        <thead>
                            <tr>
                                <th>Titre</th>
                                <th>Date update</th>
                                <th>Installée le</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($installed as $index => $update): ?>
                                <?php
                                $update = dmd_updates_clean_log_item($update);
                                $popupId = 'popup-update-installed-' . $index;
                                ?>
                                <tr>
                                    <td>
                                        <button type="button" class="btn" data-popup-open="<?= dmd_updates_h($popupId) ?>">
                                            <?= dmd_updates_h($update['titre']) ?>
                                        </button>
                                    </td>
                                    <td><?= dmd_updates_h($update['date']) ?></td>
                                    <td><?= dmd_updates_h($update['installed_at']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <?php foreach ($installed as $index => $update): ?>
                    <?php
                    $update = dmd_updates_clean_log_item($update);
                    $popupId = 'popup-update-installed-' . $index;
                    ?>
                    <div id="<?= dmd_updates_h($popupId) ?>" class="pe-popup" aria-hidden="true">
                        <div class="pe-popup-window">
                            <div class="pe-popup-head">
                                <h2><?= dmd_updates_h($update['titre']) ?></h2>
                                <button type="button" data-popup-close>Fermer</button>
                            </div>
                            <div class="pe-popup-body">
                                <?php if (!empty($update['soustitre'])): ?>
                                    <p><strong><?= dmd_updates_h($update['soustitre']) ?></strong></p>
                                <?php endif; ?>
                                <p class="pe-note">Date update : <?= dmd_updates_h($update['date']) ?></p>
                                <p class="pe-note">Type update : <?= dmd_updates_h($update['update']) ?></p>
                                <p class="pe-note">Installée le : <?= dmd_updates_h($update['installed_at']) ?></p>
                                <p class="pe-note">Installée par : <?= dmd_updates_h($update['installed_by']) ?></p>
                                <p><?= nl2br(dmd_updates_h($update['description'])) ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </section>

    </div>
</div>

<script>
(function () {
    function openPopup(id) {
        const popup = document.getElementById(id);
        if (!popup) return;
        popup.classList.add('is-open');
        popup.setAttribute('aria-hidden', 'false');
        document.body.classList.add('noscroll');
    }

    function closePopup(popup) {
        if (!popup) return;
        popup.classList.remove('is-open');
        popup.setAttribute('aria-hidden', 'true');

        if (!document.querySelector('.pe-popup.is-open')) {
            document.body.classList.remove('noscroll');
        }
    }

    document.querySelectorAll('[data-popup-open]').forEach(function (button) {
        button.addEventListener('click', function () {
            openPopup(button.getAttribute('data-popup-open'));
        });
    });

    document.querySelectorAll('[data-popup-close]').forEach(function (button) {
        button.addEventListener('click', function () {
            closePopup(button.closest('.pe-popup'));
        });
    });

    document.querySelectorAll('.pe-popup').forEach(function (popup) {
        popup.addEventListener('click', function (event) {
            if (event.target === popup) {
                closePopup(popup);
            }
        });
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            document.querySelectorAll('.pe-popup.is-open').forEach(closePopup);
        }
    });
})();
</script>

</body>
</html>