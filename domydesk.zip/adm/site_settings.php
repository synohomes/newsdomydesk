<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');

if (function_exists('mb_internal_encoding')) {
    mb_internal_encoding('UTF-8');
}

$email = $_SESSION['user']['email'] ?? null;

if (!$email) {
    header('Location: ../login.php');
    exit;
}

$baseDir = dirname(__DIR__); // fichier placé dans /domydesk/adm/
$profilesDir = $baseDir . '/users/profiles/';
$profileFile = $profilesDir . $email . '/profile.json';

if (!is_file($profileFile)) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

$profileData = json_decode((string)file_get_contents($profileFile), true);
if (!is_array($profileData)) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

$roleSystemReal = $profileData['role_system'] ?? 'user';

if (!in_array($roleSystemReal, ['admin', 'superadmin'], true)) {
    header('Location: ../profile_view.php');
    exit;
}

$isAdmin = true;

if (empty($_SESSION['csrf_site_settings'])) {
    $_SESSION['csrf_site_settings'] = bin2hex(random_bytes(32));
}

$settingsFile = $baseDir . '/adm/settings.json';
$rolesFile = $baseDir . '/data/roles_metier.json';
$idFile = $baseDir . '/data/id_domydesk.txt';
$themeMarketUrl = 'https://github.com/synohomes/newsdomydesk/raw/refs/heads/main/theme.json';
$themesDir = $baseDir . '/theme/';
$themeUploadDir = $baseDir . '/uploads/themes/';

@mkdir($themesDir, 0775, true);
@mkdir($themeUploadDir, 0775, true);

$success = false;
$errors = [];
$message = '';
$idDoMyDesk = is_file($idFile) ? trim((string)file_get_contents($idFile)) : '';

$theme = 'default';
if ($email) {
    $themeJson = $profilesDir . $email . '/theme.json';
    if (is_file($themeJson)) {
        $themeData = json_decode((string)file_get_contents($themeJson), true);
        if (is_array($themeData) && !empty($themeData['theme'])) {
            $candidateTheme = basename((string)$themeData['theme']);
            if (is_file($baseDir . '/theme/' . $candidateTheme . '/style.css')) {
                $theme = $candidateTheme;
            }
        }
    }
}
$themeCssFile = $baseDir . '/theme/' . $theme . '/style.css';
$themeCssHref = '../theme/' . rawurlencode($theme) . '/style.css';
if (is_file($themeCssFile)) {
    $themeCssHref .= '?v=' . filemtime($themeCssFile);
}

function dmd_json_read(string $file, $default = []) {
    if (!is_file($file)) return $default;
    $data = json_decode((string)file_get_contents($file), true);
    return is_array($data) ? $data : $default;
}

function dmd_json_write(string $file, array $data): bool {
    $dir = dirname($file);
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $ok = file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) !== false;
    if ($ok) @chmod($file, 0664);
    return $ok;
}

function dmd_remove_dir(string $dir): bool {
    if (!is_dir($dir)) return false;
    $it = new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS);
    $ri = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($ri as $file) {
        if ($file->isDir()) {
            @chmod($file->getPathname(), 0775);
            @rmdir($file->getPathname());
        } else {
            @chmod($file->getPathname(), 0664);
            @unlink($file->getPathname());
        }
    }
    @chmod($dir, 0775);
    return @rmdir($dir);
}

function dmd_set_permissions(string $path): void {
    if (!file_exists($path)) return;
    if (is_dir($path)) {
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path, RecursiveDirectoryIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
        foreach ($iterator as $item) {
            @chmod($item->getPathname(), $item->isDir() ? 0775 : 0664);
        }
        @chmod($path, 0775);
    } else {
        @chmod($path, 0664);
    }
}


function dmd_horizontal_menu_emojis(): array {
    return [
        '🖥️','🌎','🔅','⭐','🏃','✅','❌','📜','🛠️','🎫',
        '🏠','👤','👥','⚙️','🔐','📁','📂','📝','📌','📊',
        '📈','📉','💬','📧','🔔','🔍','🧰','🗂️','🧾','💾',
        '🖨️','🌐','🔗','🚀','⚡','💡','❤️','🔒','🔓','🧪',
        '🧭','📡','🖱️','⌨️','📱','💻','🖧','🧱','🧩','📦',
        '🛒','🎨','🧑‍💻','🗃️','🕘','📣'
    ];
}

function dmd_default_horizontal_menu(): array {
    return [
        ['title' => 'Dashboard', 'icon' => '🖥️', 'url' => '/domydesk/dashboard.php', 'type' => 'page'],
        ['title' => 'DoMyDesk public', 'icon' => '🌎', 'url' => 'https://domydesk.com/', 'type' => 'external'],
        ['title' => 'Votre DoMySocial', 'icon' => '🔅', 'url' => '/domysocial/index.php', 'type' => 'page'],
        ['title' => 'Accueil', 'icon' => '⭐', 'url' => '/domydesk/index.php', 'type' => 'page'],
        ['title' => 'Profil', 'icon' => '🏃', 'url' => '/domydesk/profile_view.php', 'type' => 'page'],
        ['title' => 'Se connecter', 'icon' => '✅', 'url' => '/domydesk/login.php', 'type' => 'page'],
        ['title' => 'Déconnexion', 'icon' => '❌', 'url' => '/domydesk/logout.php', 'type' => 'page'],
        ['title' => 'Aide', 'icon' => '📜', 'url' => '/domydesk/data/procedures/procedures_list.php', 'type' => 'page'],
        ['title' => 'Administration', 'icon' => '🛠️', 'url' => '/domydesk/adm/site_settings.php', 'type' => 'page'],
    ];
}

function dmd_normalize_horizontal_url(string $url, string $type): string {
    $url = trim($url);
    if ($url === '') return '';
    if (strlen($url) > 255) return '';

    if ($type === 'external') {
        if (!filter_var($url, FILTER_VALIDATE_URL)) return '';
        $scheme = strtolower((string)parse_url($url, PHP_URL_SCHEME));
        return in_array($scheme, ['http', 'https'], true) ? $url : '';
    }

    if (preg_match('~^https?://~i', $url)) return '';
    $url = str_replace('\\', '/', $url);
    if (str_contains($url, '..')) return '';
    if (str_starts_with($url, '//')) return '';
    if (!str_starts_with($url, '/')) {
        $url = '/domydesk/' . ltrim($url, '/');
    }
    return $url;
}

function dmd_normalize_horizontal_menu_from_post(array $post, array $allowedEmojis): array {
    $titles = $post['menu_title'] ?? [];
    $icons  = $post['menu_icon'] ?? [];
    $types  = $post['menu_type'] ?? [];
    $urls   = $post['menu_url'] ?? [];
    $delete = $post['menu_delete'] ?? [];

    if (!is_array($titles) || !is_array($icons) || !is_array($types) || !is_array($urls)) {
        return [];
    }

    $items = [];
    $count = min(count($titles), 30);

    for ($i = 0; $i < $count; $i++) {
        if (isset($delete[$i])) continue;

        $title = trim((string)($titles[$i] ?? ''));
        $icon  = trim((string)($icons[$i] ?? ''));
        $type  = ((string)($types[$i] ?? 'page')) === 'external' ? 'external' : 'page';
        $url   = dmd_normalize_horizontal_url((string)($urls[$i] ?? ''), $type);

        if ($title === '' && $url === '') continue;
        if ($title === '' || $url === '') continue;

        if (function_exists('mb_substr')) {
            $title = mb_substr($title, 0, 80, 'UTF-8');
        } else {
            $title = substr($title, 0, 80);
        }

        if (!in_array($icon, $allowedEmojis, true)) {
            $icon = '⭐';
        }

        $items[] = [
            'title' => $title,
            'icon'  => $icon,
            'url'   => $url,
            'type'  => $type,
        ];
    }

    return $items;
}

function dmd_horizontal_menu_to_html(array $items): string {
    $html = '';
    foreach ($items as $item) {
        if (!is_array($item)) continue;
        $title = trim((string)($item['title'] ?? ''));
        $icon  = trim((string)($item['icon'] ?? ''));
        $url   = trim((string)($item['url'] ?? ''));
        $type  = ((string)($item['type'] ?? 'page')) === 'external' ? 'external' : 'page';

        if ($title === '' || $icon === '' || $url === '') continue;

        $target = $type === 'external' ? ' target="_blank" rel="noopener noreferrer"' : '';
        $html .= '<a href="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '" class="icon-link" title="' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '"' . $target . '>' . htmlspecialchars($icon, ENT_QUOTES, 'UTF-8') . '</a>' . "
";
    }
    return $html;
}

function dmd_theme_github_to_raw(string $url): string {
    $url = trim($url);
    if ($url === '') return '';

    $url = preg_replace('~\?.*$~', '', $url);
    $url = preg_replace('~/refs/heads/([^/]+)/~', '/$1/', $url);

    if (preg_match('~^https?://github\.com/([^/]+)/([^/]+)/blob/([^/]+)/(.*)$~i', $url, $m)) {
        return "https://raw.githubusercontent.com/{$m[1]}/{$m[2]}/{$m[3]}/{$m[4]}";
    }

    if (preg_match('~^https?://github\.com/([^/]+)/([^/]+)/raw/([^/]+)/(.*)$~i', $url, $m)) {
        return "https://raw.githubusercontent.com/{$m[1]}/{$m[2]}/{$m[3]}/{$m[4]}";
    }

    return $url;
}

function dmd_theme_slug(string $value): string {
    $value = basename($value);
    $value = preg_replace('~\.zip$~i', '', $value);
    $value = preg_replace('~[^a-zA-Z0-9._-]+~', '-', $value);
    return trim($value, '-');
}

function dmd_theme_folder_from_url(string $url, string $fallbackName): string {
    $path = parse_url($url, PHP_URL_PATH);
    $folder = $path ? dmd_theme_slug(pathinfo($path, PATHINFO_FILENAME)) : '';
    if ($folder === '') $folder = dmd_theme_slug($fallbackName);
    return $folder;
}

function dmd_theme_http_get(string $url, ?string &$why = null) {
    $why = '';
    $url = dmd_theme_github_to_raw($url);

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_USERAGENT      => 'DoMyDesk-ThemeMarket/1.0',
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT        => 40,
        ]);
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($body === false || $code < 200 || $code >= 300) {
            $why = $body === false ? ('cURL : ' . $err) : ('HTTP ' . $code);
            return false;
        }

        return $body;
    }

    $ctx = stream_context_create([
        'http' => [
            'header'  => "User-Agent: DoMyDesk-ThemeMarket/1.0\r\n",
            'timeout' => 40,
        ]
    ]);

    $body = @file_get_contents($url, false, $ctx);
    if ($body === false) {
        $why = 'file_get_contents impossible.';
        return false;
    }

    return $body;
}

function dmd_theme_http_download(string $url, string $dest, ?string &$why = null): bool {
    $why = '';
    $url = dmd_theme_github_to_raw($url);

    if (function_exists('curl_init')) {
        $fp = @fopen($dest, 'wb');
        if (!$fp) {
            $why = 'Écriture du ZIP impossible.';
            return false;
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_FILE           => $fp,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_USERAGENT      => 'DoMyDesk-ThemeMarket/1.0',
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT        => 60,
        ]);
        $ok   = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        fclose($fp);

        if (!$ok || $code < 200 || $code >= 300 || !filesize($dest)) {
            @unlink($dest);
            $why = 'HTTP ' . $code . ($err ? ' - ' . $err : '');
            return false;
        }

        @chmod($dest, 0664);
        return true;
    }

    $data = @file_get_contents($url);
    if ($data === false || $data === '') {
        $why = 'Téléchargement impossible ou fichier vide.';
        return false;
    }

    if (@file_put_contents($dest, $data) === false) {
        $why = 'Écriture du ZIP impossible.';
        return false;
    }

    @chmod($dest, 0664);
    return true;
}

function dmd_theme_safe_extract_zip(ZipArchive $zip, string $extractDir, array &$errors): bool {
    @mkdir($extractDir, 0775, true);
    $extractReal = realpath($extractDir);

    if ($extractReal === false) {
        $errors[] = 'Dossier temporaire du thème invalide.';
        return false;
    }

    for ($i = 0; $i < $zip->numFiles; $i++) {
        $name = $zip->getNameIndex($i);
        if ($name === false || $name === '') continue;

        $name = str_replace('\\', '/', $name);

        if (
            str_starts_with($name, '/') ||
            preg_match('~(^|/)\.\.(/|$)~', $name) ||
            preg_match('~^[a-zA-Z]:/~', $name)
        ) {
            $errors[] = 'ZIP thème refusé : chemin dangereux détecté.';
            return false;
        }
    }

    if (!$zip->extractTo($extractDir)) {
        $errors[] = 'Extraction du thème impossible.';
        return false;
    }

    dmd_set_permissions($extractDir);
    return true;
}

function dmd_theme_normalize_extract(string $extractDir): bool {
    $extractDir = rtrim($extractDir, '/') . '/';
    if (is_file($extractDir . 'style.css')) return true;

    $children = array_values(array_filter(scandir($extractDir) ?: [], fn($x) => $x !== '.' && $x !== '..' && $x !== '__MACOSX'));
    $candidates = [];

    foreach ($children as $child) {
        $childPath = $extractDir . $child;
        if (is_dir($childPath) && is_file($childPath . '/style.css')) {
            $candidates[] = $childPath;
        }
    }

    if (count($candidates) !== 1) return false;

    $source = rtrim($candidates[0], '/') . '/';
    foreach (array_diff(scandir($source), ['.', '..']) as $item) {
        @rename($source . $item, $extractDir . $item);
    }
    @rmdir($source);

    return is_file($extractDir . 'style.css');
}

function dmd_theme_installed_list(string $themesDir): array {
    $items = [];
    foreach (glob(rtrim($themesDir, '/') . '/*', GLOB_ONLYDIR) ?: [] as $folder) {
        if (is_file($folder . '/style.css')) {
            $items[] = basename($folder);
        }
    }
    sort($items, SORT_NATURAL | SORT_FLAG_CASE);
    return $items;
}

$settings = dmd_json_read($settingsFile, []);
$metiers = dmd_json_read($rolesFile, []);
if (!is_array($metiers)) $metiers = [];

$dmdHorizontalMenuEmojis = dmd_horizontal_menu_emojis();
if (empty($settings['menu_horizontal']) || !is_array($settings['menu_horizontal'])) {
    $settings['menu_horizontal'] = dmd_default_horizontal_menu();
}
$settings['menu_vertical'] = dmd_horizontal_menu_to_html($settings['menu_horizontal']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['save_site'])) {
        $settings['site_name'] = trim((string)($_POST['site_name'] ?? ($settings['site_name'] ?? 'DoMyDesk')));
        if ($settings['site_name'] === '') {
            $settings['site_name'] = 'DoMyDesk';
        }

        $menuHorizontal = dmd_normalize_horizontal_menu_from_post($_POST, $dmdHorizontalMenuEmojis);
        if ($menuHorizontal) {
            $settings['menu_horizontal'] = $menuHorizontal;
            $settings['menu_vertical'] = dmd_horizontal_menu_to_html($menuHorizontal);
        } elseif (!empty($settings['menu_horizontal']) && is_array($settings['menu_horizontal'])) {
            $settings['menu_vertical'] = dmd_horizontal_menu_to_html($settings['menu_horizontal']);
        } else {
            $settings['menu_horizontal'] = dmd_default_horizontal_menu();
            $settings['menu_vertical'] = dmd_horizontal_menu_to_html($settings['menu_horizontal']);
        }

        if (!empty($_FILES['logo']) && ($_FILES['logo']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
            $allowed = ['png','jpg','jpeg','gif','svg','webp'];
            $ext = strtolower(pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, $allowed, true)) {
                $uploadDir = $baseDir . '/adm/uploads/';
                if (!is_dir($uploadDir)) @mkdir($uploadDir, 0775, true);
                $targetFile = $uploadDir . 'logo.' . $ext;
                if (@move_uploaded_file($_FILES['logo']['tmp_name'], $targetFile)) {
                    $settings['logo_path'] = 'uploads/logo.' . $ext;
                    dmd_set_permissions($targetFile);
                } else {
                    $errors[] = "Impossible d'envoyer le logo.";
                }
            } else {
                $errors[] = 'Format de logo non autorisé.';
            }
        }
        if (!$errors && dmd_json_write($settingsFile, $settings)) {
            $success = true;
            $message = 'Paramètres du site enregistrés.';
        }
    }

    if ($isAdmin && isset($_POST['install_theme_market'])) {
        $token = $_POST['csrf_token'] ?? '';
        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Formulaire thème expiré ou invalide.';
        } else {
            $themeName = trim((string)($_POST['theme_name'] ?? ''));
            $themeDl = dmd_theme_github_to_raw(trim((string)($_POST['theme_dl'] ?? '')));
            $themeFolder = dmd_theme_folder_from_url($themeDl, $themeName);

            if ($themeDl === '' || $themeFolder === '') {
                $errors[] = 'Thème invalide.';
            } elseif (!class_exists('ZipArchive')) {
                $errors[] = 'ZipArchive n’est pas disponible sur le serveur.';
            } else {
                $zipTmp = rtrim($themeUploadDir, '/') . '/' . $themeFolder . '.zip';
                $tmpExtract = rtrim($themeUploadDir, '/') . '/extract_' . $themeFolder . '_' . time() . '/';
                $targetThemeDir = rtrim($themesDir, '/') . '/' . $themeFolder . '/';
                $why = '';

                if (!dmd_theme_http_download($themeDl, $zipTmp, $why)) {
                    $errors[] = 'Téléchargement du thème impossible : ' . $why;
                } else {
                    $zip = new ZipArchive();
                    if ($zip->open($zipTmp) === true) {
                        if (dmd_theme_safe_extract_zip($zip, $tmpExtract, $errors) && dmd_theme_normalize_extract($tmpExtract)) {
                            $zip->close();
                            @unlink($zipTmp);

                            if (is_dir($targetThemeDir)) dmd_remove_dir($targetThemeDir);

                            if (@rename($tmpExtract, $targetThemeDir)) {
                                dmd_set_permissions($targetThemeDir);
                                $success = true;
                                $message = 'Thème installé : ' . $themeFolder;
                            } else {
                                $errors[] = 'Impossible de placer le thème dans le dossier /theme/.';
                                dmd_remove_dir($tmpExtract);
                            }
                        } else {
                            $zip->close();
                            @unlink($zipTmp);
                            dmd_remove_dir($tmpExtract);
                            if (!$errors) $errors[] = 'Le ZIP du thème ne contient pas de style.css utilisable.';
                        }
                    } else {
                        @unlink($zipTmp);
                        $errors[] = 'Impossible d’ouvrir le ZIP du thème.';
                    }
                }
            }
        }
    }

    if ($isAdmin && isset($_POST['delete_module'])) {
        $mod = basename((string)$_POST['delete_module']);
        if ($mod !== '' && dmd_remove_dir($baseDir . '/modules/' . $mod)) {
            $success = true;
            $message = 'Module supprimé.';
        } else {
            $errors[] = 'Impossible de supprimer ce module.';
        }
    }

    if ($isAdmin && isset($_POST['add_metier'])) {
        $new = trim($_POST['new_metier'] ?? '');
        if ($new !== '' && !in_array($new, $metiers, true)) {
            $metiers[] = $new;
            sort($metiers, SORT_NATURAL | SORT_FLAG_CASE);
            dmd_json_write($rolesFile, array_values($metiers));
            $success = true;
            $message = 'Rôle ajouté.';
        }
    }

    if ($isAdmin && isset($_POST['delete_metier'])) {
        $del = trim($_POST['del_metier'] ?? '');
        if ($del !== '') {
            $metiers = array_values(array_filter($metiers, fn($m) => $m !== $del));
            dmd_json_write($rolesFile, $metiers);
            $success = true;
            $message = 'Rôle supprimé.';
        }
    }

    if ($isAdmin && isset($_POST['add_user'])) {
        $prenom = trim($_POST['prenom'] ?? '');
        $nom = trim($_POST['nom'] ?? '');
        $emailNew = trim($_POST['email'] ?? '');
        $roleMetier = trim($_POST['role_metier'] ?? '');
        $roleSystem = trim($_POST['role_system'] ?? 'user');
        $password = $_POST['password'] ?? '';
        if (!$prenom || !$nom || !$emailNew || !$roleMetier || !$password || !$roleSystem) {
            $errors[] = 'Tous les champs utilisateur sont obligatoires.';
        } elseif (!filter_var($emailNew, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Email invalide.';
        } elseif (!in_array($roleMetier, $metiers, true)) {
            $errors[] = 'Rôle métier invalide.';
        } elseif (!in_array($roleSystem, ['user','admin'], true)) {
            $errors[] = 'Rôle système invalide.';
        } elseif (is_dir($profilesDir . $emailNew)) {
            $errors[] = "L'utilisateur existe déjà.";
        } else {
            $folder = $profilesDir . $emailNew . '/';
            @mkdir($folder, 0775, true);
            dmd_json_write($folder . 'profile.json', [
                'prenom' => $prenom,
                'nom' => $nom,
                'email' => $emailNew,
                'role_system' => $roleSystem,
                'role_metier' => $roleMetier,
                'motdepasse' => password_hash($password, PASSWORD_DEFAULT),
            ]);
            dmd_json_write($folder . 'dashboard.json', []);
            dmd_json_write($folder . 'menu.json', []);
            @copy($baseDir . '/data/Logo_2025_Mini.png', $folder . 'avatar.png');
            dmd_set_permissions($folder);
            $success = true;
            $message = 'Utilisateur ajouté.';
        }
    }

    if ($isAdmin && isset($_POST['update_user_roles'])) {
        $userMail = trim($_POST['user_email'] ?? '');
        $roleSys = trim($_POST['new_role_system'] ?? 'user');
        $roleMetier = trim($_POST['new_role_metier'] ?? '');
        $profileFile = $profilesDir . $userMail . '/profile.json';
        if (is_file($profileFile)) {
            $data = dmd_json_read($profileFile, []);
            if (in_array($roleSys, ['admin','user'], true)) $data['role_system'] = $roleSys;
            if (in_array($roleMetier, $metiers, true)) $data['role_metier'] = $roleMetier;
            dmd_json_write($profileFile, $data);
            $success = true;
            $message = 'Rôles mis à jour.';
        }
    }

    if ($isAdmin && isset($_POST['save_user_roles'])) {
        $roleSystems = $_POST['role_systems'] ?? [];
        $roleMetiers = $_POST['role_metiers'] ?? [];
        if (is_array($roleSystems) && is_array($roleMetiers)) {
            foreach ($roleSystems as $userMail => $roleSys) {
                $userMail = trim((string)$userMail);
                $roleSys = trim((string)$roleSys);
                $roleMetier = trim((string)($roleMetiers[$userMail] ?? ''));
                $profileFile = $profilesDir . $userMail . '/profile.json';
                if (!is_file($profileFile)) continue;
                $data = dmd_json_read($profileFile, []);
                if (in_array($roleSys, ['admin','user'], true)) $data['role_system'] = $roleSys;
                if (in_array($roleMetier, $metiers, true)) $data['role_metier'] = $roleMetier;
                dmd_json_write($profileFile, $data);
            }
            $success = true;
            $message = 'Rôles utilisateurs enregistrés.';
        }
    }

    if ($isAdmin && isset($_POST['delete_user'])) {
        $userMail = trim($_POST['delete_user'] ?? ($_POST['user_email'] ?? ''));
        if ($userMail !== '' && $userMail !== $email && is_dir($profilesDir . $userMail)) {
            dmd_remove_dir($profilesDir . $userMail);
            $success = true;
            $message = 'Utilisateur supprimé.';
        } else {
            $errors[] = "Impossible de supprimer l'utilisateur courant ou un dossier introuvable.";
        }
    }

    if ($isAdmin && isset($_POST['save_user_pages'])) {
        $emailSel = trim($_POST['user_email'] ?? '');
        $picked = isset($_POST['pages']) && is_array($_POST['pages']) ? $_POST['pages'] : [];
        if ($emailSel && is_dir($profilesDir . $emailSel)) {
            dmd_json_write($profilesDir . $emailSel . '/pages.json', array_values($picked));
            $success = true;
            $message = 'Autorisations enregistrées.';
        } else {
            $errors[] = 'Utilisateur invalide pour la sauvegarde des accès.';
        }
    }
}

$users = [];
$userRoles = [];
$userProfiles = [];
foreach (glob($profilesDir . '*', GLOB_ONLYDIR) ?: [] as $folder) {
    $mail = basename($folder);
    $profile = dmd_json_read($folder . '/profile.json', []);
    $users[] = $mail;
    $userProfiles[$mail] = $profile;
    $userRoles[$mail] = $profile['role_system'] ?? 'user';
}
sort($users, SORT_NATURAL | SORT_FLAG_CASE);

$pagesScan = [];
foreach (['', 'adm','data',] as $sub) {
    foreach (glob($baseDir . ($sub ? '/' . $sub : '') . '/*.php') ?: [] as $f) {
        $rel = str_replace($baseDir . '/', '', $f);
        if (preg_match('/(?:cfg|inc|ajax|api)\.php$/i', $rel)) continue;
        $pagesScan[] = $rel;
    }
}
sort($pagesScan, SORT_NATURAL | SORT_FLAG_CASE);

$userPagesMap = [];
foreach ($users as $u) {
    $arr = dmd_json_read($profilesDir . $u . '/pages.json', []);
    $userPagesMap[$u] = is_array($arr) ? $arr : [];
}

$modDir = $baseDir . '/modules';
$allModules = array_values(array_filter(glob($modDir . '/*') ?: [], 'is_dir'));
$totalModules = count($allModules);
$perPage = 40;
$page = max(1, (int)($_GET['mpage'] ?? 1));
$pagesCount = max(1, (int)ceil($totalModules / $perPage));
$page = min($page, $pagesCount);
$modulesPage = array_slice($allModules, ($page - 1) * $perPage, $perPage);

$themeMarketWhy = '';
$themeMarketRaw = dmd_theme_http_get($themeMarketUrl, $themeMarketWhy);
$themeMarketItems = [];
if ($themeMarketRaw !== false) {
    $decodedThemeMarket = json_decode($themeMarketRaw, true);
    if (is_array($decodedThemeMarket)) $themeMarketItems = $decodedThemeMarket;
}
$installedThemes = dmd_theme_installed_list($themesDir);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Administration systeme</title>
<link rel="stylesheet" href="<?= htmlspecialchars($themeCssHref) ?>">
</head>
<body>
<?php include $baseDir . '/header.php'; ?>
<div class="pe-page">
    <div class="pe-head">
        <div>
            <h1 class="pe-title">Administration systeme</h1>
            <p class="pe-subtitle">Gestion du site, des modules, des utilisateurs et des acces.</p>
        </div>
        <div class="pe-user-pill"><?= htmlspecialchars($email ?? 'Utilisateur') ?></div>
    </div>

    <?php if ($success || $message): ?><div class="pe-msg pe-msg-ok"><?= htmlspecialchars($message ?: 'Action effectuée.') ?></div><?php endif; ?>
    <?php if ($errors): ?><div class="pe-msg pe-msg-error"><?php foreach ($errors as $e) echo htmlspecialchars($e) . '<br>'; ?></div><?php endif; ?>

    <h2 class="pe-section-title">Site</h2>
    <div class="pe-grid">
        <button type="button" class="pe-card" data-popup-open="popup-site-settings">
            <span class="pe-card-main"><span class="pe-card-title">Parametres du site</span><span class="pe-card-desc">Nom, logo et menu horizontal</span></span>
        </button>
        <button type="button" class="pe-card" data-popup-open="popup-site-maintenance">
            <span class="pe-card-main"><span class="pe-card-title">Maintenance</span><span class="pe-card-desc">ID DoMyDesk et permissions</span></span>
        </button>
        <button type="button" class="pe-card" data-popup-open="popup-index-settings">
            <span class="pe-card-main"><span class="pe-card-title">Reglages page d'accueil</span><span class="pe-card-desc">Reglage de l'index du site</span></span>
        </button>
        <button type="button" class="pe-card" data-popup-open="popup-updates">
            <span class="pe-card-main"><span class="pe-card-title">Updates DoMyDesk</span><span class="pe-card-desc">Mises a jour systeme depuis GitHub ou ZIP manuel</span></span>
        </button>
        <button type="button" class="pe-card" data-popup-open="popup-theme-market">
            <span class="pe-card-main"><span class="pe-card-title">Market des themes</span><span class="pe-card-desc">Aperçus et installation depuis GitHub</span></span>
        </button>
		<button type="button" class="pe-card" data-popup-open="popup-news">
    <span class="pe-card-main">
        <span class="pe-card-title">Actualités</span>
        <span class="pe-card-desc">Configuration des actualités DoMyDesk</span>
    </span>
</button>
    </div>

    <h2 class="pe-section-title">Modules</h2>
    <div class="pe-grid">
        <button type="button" class="pe-card" data-popup-open="popup-market-inline">
            <span class="pe-card-main"><span class="pe-card-title">Installer un module</span><span class="pe-card-desc">Market DoMyDesk</span></span>
        </button>
        <button type="button" class="pe-card" data-popup-open="popup-modules-list">
            <span class="pe-card-main"><span class="pe-card-title">Modules installes</span><span class="pe-card-desc">Liste et suppression</span></span>
        </button>
    </div>

    <h2 class="pe-section-title">Utilisateurs</h2>
    <div class="pe-grid">
        <button type="button" class="pe-card" data-popup-open="popup-user-add">
            <span class="pe-card-main"><span class="pe-card-title">Ajouter utilisateur</span><span class="pe-card-desc">Creer un compte</span></span>
        </button>
        <button type="button" class="pe-card" data-popup-open="popup-user-roles">
            <span class="pe-card-main"><span class="pe-card-title">Roles utilisateurs</span><span class="pe-card-desc">Admin/user et metier</span></span>
        </button>
        <button type="button" class="pe-card" data-popup-open="popup-user-pages">
            <span class="pe-card-main"><span class="pe-card-title">Autorisations</span><span class="pe-card-desc">Pages par utilisateur</span></span>
        </button>
        <button type="button" class="pe-card" data-popup-open="popup-metiers">
            <span class="pe-card-main"><span class="pe-card-title">Roles metier</span><span class="pe-card-desc">Ajouter ou supprimer</span></span>
        </button>
    </div>
</div>

<div id="popup-site-settings" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2>Paramètres du site</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body">
            <form method="post" accept-charset="UTF-8" enctype="multipart/form-data" class="pe-form">
                <div><label>Nom du site</label><input type="text" name="site_name" value="<?= htmlspecialchars($settings['site_name'] ?? '', ENT_QUOTES, 'UTF-8') ?>"></div>
                <div>
                    <label>Logo actuel</label>
                    <?php if (isset($settings['logo_path']) && is_file(__DIR__ . '/' . $settings['logo_path'])): ?>
                        <br><img class="logo-preview" src="<?= htmlspecialchars($settings['logo_path'], ENT_QUOTES, 'UTF-8') ?>?v=<?= time() ?>" alt="Logo">
                    <?php else: ?>
                        <p class="pe-note">Aucun logo</p>
                    <?php endif; ?>
                </div>
                <div><label>Changer de logo</label><input type="file" name="logo" accept=".png,.jpg,.jpeg,.gif,.svg,.webp"></div>

                <h3>Menu horizontal du header</h3>
                <p class="pe-note">Ajoute une page interne ou un lien externe. L’icône doit venir de la liste.</p>
                <datalist id="dmd-pages-list">
                    <?php foreach ($pagesScan as $pageOption): ?>
                        <option value="/domydesk/<?= htmlspecialchars($pageOption, ENT_QUOTES, 'UTF-8') ?>"></option>
                    <?php endforeach; ?>
                    <option value="/domydesk/dashboard.php"></option>
                    <option value="/domydesk/index.php"></option>
                    <option value="/domydesk/profile_view.php"></option>
                    <option value="/domydesk/login.php"></option>
                    <option value="/domydesk/logout.php"></option>
                    <option value="/domydesk/adm/site_settings.php"></option>
                </datalist>

                <div class="table-wrap">
                    <table class="roles-table">
                        <thead>
                            <tr>
                                <th>Titre</th>
                                <th>Emoji</th>
                                <th>Type</th>
                                <th>Page ou lien</th>
                                <th>Supprimer</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $menuRows = $settings['menu_horizontal'] ?? dmd_default_horizontal_menu();
                            if (!is_array($menuRows)) $menuRows = dmd_default_horizontal_menu();
                            for ($emptyRow = 0; $emptyRow < 5; $emptyRow++) {
                                $menuRows[] = ['title' => '', 'icon' => '⭐', 'url' => '', 'type' => 'page'];
                            }
                            foreach ($menuRows as $idx => $menuItem):
                                if (!is_array($menuItem)) $menuItem = [];
                                $miTitle = (string)($menuItem['title'] ?? '');
                                $miIcon = (string)($menuItem['icon'] ?? '⭐');
                                $miType = ((string)($menuItem['type'] ?? 'page')) === 'external' ? 'external' : 'page';
                                $miUrl = (string)($menuItem['url'] ?? '');
                            ?>
                                <tr>
                                    <td><input type="text" name="menu_title[]" value="<?= htmlspecialchars($miTitle, ENT_QUOTES, 'UTF-8') ?>" placeholder="Ex : Dashboard"></td>
                                    <td>
                                        <select name="menu_icon[]">
                                            <?php foreach ($dmdHorizontalMenuEmojis as $emoji): ?>
                                                <option value="<?= htmlspecialchars($emoji, ENT_QUOTES, 'UTF-8') ?>" <?= $emoji === $miIcon ? 'selected' : '' ?>><?= htmlspecialchars($emoji, ENT_QUOTES, 'UTF-8') ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </td>
                                    <td>
                                        <select name="menu_type[]">
                                            <option value="page" <?= $miType === 'page' ? 'selected' : '' ?>>Page</option>
                                            <option value="external" <?= $miType === 'external' ? 'selected' : '' ?>>Lien externe</option>
                                        </select>
                                    </td>
                                    <td><input type="text" name="menu_url[]" list="dmd-pages-list" value="<?= htmlspecialchars($miUrl, ENT_QUOTES, 'UTF-8') ?>" placeholder="/domydesk/page.php ou https://..."></td>
                                    <td><input type="checkbox" name="menu_delete[<?= (int)$idx ?>]" value="1"></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="pe-actions"><button name="save_site">Enregistrer</button></div>
            </form>
        </div>
    </div>
</div>

<div id="popup-site-maintenance" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window">
        <div class="pe-popup-head"><h2>Maintenance</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body">
            <?php if ($idDoMyDesk): ?>
                <p class="pe-note">ID DoMyDesk : <strong><?= htmlspecialchars($idDoMyDesk) ?></strong></p>
                <p><a class="btn" href="/domydesk/data/id_domydesk.txt" download>Sauvegarder l’ID</a></p>
            <?php else: ?>
                <p class="pe-note">Aucun ID DoMyDesk trouvé.</p>
            <?php endif; ?>
            <p><a href="../adm/fix_all_rights.php" target="_blank" class="btn">Accorder les permissions</a></p>
        </div>
    </div>
</div>

<div id="popup-index-settings" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2>Reglages page d'accueil</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body market-body">
            <iframe src="../adm/indexcfg.php" title="Reglages page d'accueil DoMyDesk" style="width:100%;height:78vh;border:0;display:block;background:transparent;"></iframe>
        </div>
    </div>
</div>

<div id="popup-updates" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2>Updates DoMyDesk</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body market-body">
            <iframe src="updates.php" title="Updates DoMyDesk" style="width:100%;height:78vh;border:0;display:block;background:transparent;"></iframe>
        </div>
    </div>
</div>

<div id="popup-news" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2>Actualités</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>
        <div class="pe-popup-body">
            <?php include $baseDir . "/data/news/newscfg.php"; ?>
        </div>
    </div>
</div>

<div id="popup-theme-market" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2>Market des themes</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>

        <div class="pe-popup-body">
            <?php if ($themeMarketRaw === false): ?>
                <div class="pe-msg pe-msg-error">Impossible de charger le catalogue des themes : <?= htmlspecialchars($themeMarketWhy) ?></div>

            <?php elseif (!$themeMarketItems): ?>
                <div class="pe-msg pe-msg-error">Catalogue des themes vide ou JSON invalide.</div>

            <?php else: ?>

                <div class="mods-grid theme-market-grid">
                    <?php foreach ($themeMarketItems as $themeItem):
                        if (!is_array($themeItem)) continue;

                        $tmName = trim((string)($themeItem['name'] ?? 'Theme'));
                        $tmDate = trim((string)($themeItem['date'] ?? ''));
                        $tmDesc = trim((string)($themeItem['description'] ?? ''));
                        $tmImage = dmd_theme_github_to_raw((string)($themeItem['image'] ?? ''));
                        $tmDl = dmd_theme_github_to_raw((string)($themeItem['dl'] ?? ''));
                        $tmSize = trim((string)($themeItem['size'] ?? ''));
                        $tmFolder = dmd_theme_folder_from_url($tmDl, $tmName);
                        $tmInstalled = $tmFolder !== '' && in_array($tmFolder, $installedThemes, true);
                    ?>

                        <div class="mod-card theme-market-card">

                            <?php if ($tmImage): ?>
                                <img
                                    src="<?= htmlspecialchars($tmImage, ENT_QUOTES, 'UTF-8') ?>"
                                    alt="<?= htmlspecialchars($tmName, ENT_QUOTES, 'UTF-8') ?>"
                                    class="mod-thumb theme-market-thumb"
                                    title="Cliquer pour agrandir"
                                    onclick='openThemePreview(
                                        <?= json_encode($tmImage, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>,
                                        <?= json_encode($tmName, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>
                                    )'
                                >
                            <?php endif; ?>

                            <div class="mod-meta">
                                <div class="mod-name" title="<?= htmlspecialchars($tmName, ENT_QUOTES, 'UTF-8') ?>">
                                    <?= htmlspecialchars($tmName, ENT_QUOTES, 'UTF-8') ?>
                                </div>

                                <div class="mod-id">
                                    Dossier : <?= htmlspecialchars($tmFolder ?: '-', ENT_QUOTES, 'UTF-8') ?>
                                    <?php if ($tmDate): ?> · <?= htmlspecialchars($tmDate, ENT_QUOTES, 'UTF-8') ?><?php endif; ?>
                                    <?php if ($tmSize): ?> · <?= htmlspecialchars($tmSize, ENT_QUOTES, 'UTF-8') ?><?php endif; ?>
                                </div>

                                <?php if ($tmDesc): ?>
                                    <p class="pe-note"><?= htmlspecialchars($tmDesc, ENT_QUOTES, 'UTF-8') ?></p>
                                <?php endif; ?>

                                <?php if ($tmInstalled): ?>
                                    <p class="pe-note"><strong>Déjà installé</strong></p>
                                <?php endif; ?>
                            </div>

                            <?php if ($tmDl): ?>
                                <form method="post" accept-charset="UTF-8" class="pe-form">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                    <input type="hidden" name="theme_name" value="<?= htmlspecialchars($tmName, ENT_QUOTES, 'UTF-8') ?>">
                                    <input type="hidden" name="theme_dl" value="<?= htmlspecialchars($tmDl, ENT_QUOTES, 'UTF-8') ?>">
                                    <button type="submit" name="install_theme_market" value="1">
                                        <?= $tmInstalled ? 'Réinstaller' : 'Installer' ?>
                                    </button>
                                </form>
                            <?php else: ?>
                                <p class="pe-note">Lien ZIP manquant.</p>
                            <?php endif; ?>

                        </div>

                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div id="popup-theme-preview" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2 id="theme-preview-title">Aperçu du thème</h2>
            <button type="button" onclick="closeThemePreview()">Fermer</button>
        </div>

        <div class="pe-popup-body theme-preview-body">
            <img id="theme-preview-img" src="" alt="" class="theme-preview-img">
        </div>
    </div>
</div>

<div id="popup-market-inline" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide market-modal">
        <div class="pe-popup-head market-head"><h2>Installer un module</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body market-body">
            <iframe src="../adm/market/marketmodules.php" title="Market DoMyDesk"></iframe>
        </div>
    </div>
</div>

<div id="popup-modules-list" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2>Modules installes</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body">
            <form method="post" accept-charset="UTF-8" class="pe-form">
                <div class="mods-grid">
                    <?php foreach ($modulesPage as $path):
                        $mod = basename($path);
                        $displayName = ucwords(trim(preg_replace('/[_\.\-]+/', ' ', $mod)));
                        $icon = '';
                        foreach (['icon.png','logo.png','icon.jpg','icon.webp','logo.webp'] as $f) {
                            if (is_file($path . '/' . $f)) { $icon = '../modules/' . $mod . '/' . $f; break; }
                        }
                    ?>
                        <div class="mod-card">
                            <?php if ($icon): ?><img src="<?= htmlspecialchars($icon) ?>" alt="" class="mod-thumb"><?php endif; ?>
                            <div class="mod-meta"><div class="mod-name" title="<?= htmlspecialchars($mod) ?>"><?= htmlspecialchars($displayName) ?></div><div class="mod-id"><?= htmlspecialchars($mod) ?></div></div>
                            <?php if ($isAdmin): ?><button type="submit" name="delete_module" value="<?= htmlspecialchars($mod) ?>" class="btn-del" onclick="return confirm('Supprimer définitivement le module <?= htmlspecialchars($mod) ?> ?')">Supprimer</button><?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php if ($pagesCount > 1): ?><div class="mods-pager"><?php for ($i=1; $i <= $pagesCount; $i++): ?><?php if ($i === $page): ?><strong class="btn"><?= $i ?></strong><?php else: ?><a class="btn" href="?mpage=<?= $i ?>"><?= $i ?></a><?php endif; ?><?php endfor; ?></div><?php endif; ?>
            </form>
        </div>
    </div>
</div>

<div id="popup-user-add" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window">
        <div class="pe-popup-head"><h2>Ajouter utilisateur</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body">
            <form method="post" accept-charset="UTF-8" class="pe-form">
                <div class="pe-form-row"><div><label>Prenom</label><input type="text" name="prenom" required></div><div><label>Nom</label><input type="text" name="nom" required></div></div>
                <div><label>Email</label><input type="email" name="email" required></div>
                <div class="pe-form-row"><div><label>Role interne</label><select name="role_metier" required><option value="" disabled selected>Selectionner</option><?php foreach ($metiers as $m): ?><option value="<?= htmlspecialchars($m) ?>"><?= htmlspecialchars($m) ?></option><?php endforeach; ?></select></div><div><label>Role systeme</label><select name="role_system" required><option value="user">Utilisateur</option><option value="admin">Administrateur</option></select></div></div>
                <div><label>Mot de passe</label><input type="password" name="password" required></div>
                <div class="pe-actions"><button type="submit" name="add_user">Ajouter</button></div>
            </form>
        </div>
    </div>
</div>

<div id="popup-user-roles" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2>Roles utilisateurs</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body">
            <form method="post" accept-charset="UTF-8" class="pe-form">
                <div class="table-wrap"><table class="roles-table"><thead><tr><th>Utilisateur</th><th>Email</th><th>Role systeme</th><th>Role metier</th><th>Action</th></tr></thead><tbody>
                    <?php foreach ($users as $mail):
                        $profile = $userProfiles[$mail] ?? [];
                        $prenom = $profile['prenom'] ?? $mail;
                        $nom = $profile['nom'] ?? '';
                        $roleSys = $profile['role_system'] ?? 'user';
                        $roleMetier = $profile['role_metier'] ?? '';
                    ?>
                    <tr>
                        <td><strong><?= htmlspecialchars(trim($prenom . ' ' . $nom)) ?></strong><br><a href="/domydesk/profile_view.php?email=<?= urlencode($mail) ?>">Voir profil</a></td>
                        <td><?= htmlspecialchars($mail) ?><?= $mail === $email ? '<br><strong>Vous</strong>' : '' ?></td>
                        <td><select name="role_systems[<?= htmlspecialchars($mail) ?>]"><option value="user" <?= $roleSys === 'user' ? 'selected' : '' ?>>Utilisateur</option><option value="admin" <?= $roleSys === 'admin' ? 'selected' : '' ?>>Administrateur</option></select></td>
                        <td><select name="role_metiers[<?= htmlspecialchars($mail) ?>]"><?php foreach ($metiers as $m): ?><option value="<?= htmlspecialchars($m) ?>" <?= $m === $roleMetier ? 'selected' : '' ?>><?= htmlspecialchars($m) ?></option><?php endforeach; ?></select></td>
                        <td><?php if ($mail !== $email): ?><button type="submit" name="delete_user" value="<?= htmlspecialchars($mail) ?>" class="btn-del" onclick="return confirm('Supprimer définitivement <?= htmlspecialchars($mail) ?> ?')">Supprimer</button><?php else: ?>—<?php endif; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody></table></div>
                <div class="pe-actions"><button type="submit" name="save_user_roles">Enregistrer les rôles</button></div>
            </form>
        </div>
    </div>
</div>

<div id="popup-user-pages" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2>Autorisations</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body">
            <form method="post" accept-charset="UTF-8" id="acc-form" class="pe-form">
                <input type="hidden" name="save_user_pages" value="1">
                <div class="access-wrap">
                    <div><label>Utilisateur</label><select id="acc-user" name="user_email"><option value="">Sélectionner</option><?php foreach ($users as $u): ?><option value="<?= htmlspecialchars($u) ?>"><?= htmlspecialchars($u) ?></option><?php endforeach; ?></select></div>
                    <div class="table-wrap"><table id="pages-matrix"><tbody></tbody></table></div>
                </div>
                <div class="pe-actions"><button type="submit">Enregistrer les accès</button></div>
            </form>
        </div>
    </div>
</div>

<div id="popup-metiers" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window">
        <div class="pe-popup-head"><h2>Roles metier</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body">
            <form method="post" accept-charset="UTF-8" class="pe-form">
                <div><label>Nouveau role metier</label><input type="text" name="new_metier" placeholder="ex: Technicien, RH, Commercial"></div>
                <div><label>Supprimer un role metier</label><select name="del_metier"><option value="">Ne rien supprimer</option><?php foreach ($metiers as $m): ?><option value="<?= htmlspecialchars($m) ?>"><?= htmlspecialchars($m) ?></option><?php endforeach; ?></select></div>
                <div class="pe-actions"><button type="submit" name="add_metier">Ajouter</button><button type="submit" name="delete_metier" class="btn-del">Supprimer</button></div>
            </form>
        </div>
    </div>
</div>

<script>
const PAGES_ALL = <?= json_encode($pagesScan, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const USER_PAGES = <?= json_encode($userPagesMap, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
function openPopup(id){ const pop=document.getElementById(id); if(!pop) return; pop.classList.add('is-open'); pop.setAttribute('aria-hidden','false'); document.body.classList.add('noscroll'); }
function closePopup(pop){ if(!pop) return; pop.classList.remove('is-open'); pop.setAttribute('aria-hidden','true'); if(!document.querySelector('.pe-popup.is-open')) document.body.classList.remove('noscroll'); }
function esc(s){ return String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;', "'":'&#39;'}[m])); }
function cellHTML(page, checked){ if(!page) return '<td></td>'; return `<td><div class="page-cell"><div class="page-info"><span class="dot ${checked ? 'green':''}"></span><span class="page-name" title="${esc(page)}">${esc(page)}</span></div><input type="checkbox" name="pages[]" value="${esc(page)}" ${checked ? 'checked' : ''}></div></td>`; }
function renderFor(user){ const tbody=document.querySelector('#pages-matrix tbody'); if(!tbody) return; tbody.innerHTML=''; if(!user) return; const allowed=new Set(USER_PAGES[user] || []); const cols=3; const rows=Math.ceil(PAGES_ALL.length/cols); let html=''; for(let r=0;r<rows;r++){ html+='<tr>'; for(let c=0;c<cols;c++){ const idx=r+c*rows; const page=PAGES_ALL[idx] || null; html+=cellHTML(page, page ? allowed.has(page) : false); } html+='</tr>'; } tbody.innerHTML=html; }
document.querySelectorAll('[data-popup-open]').forEach(btn => btn.addEventListener('click', () => openPopup(btn.dataset.popupOpen)));
document.querySelectorAll('.pe-popup').forEach(pop => pop.addEventListener('click', e => { if(e.target === pop) closePopup(pop); }));
document.querySelectorAll('[data-popup-close]').forEach(btn => btn.addEventListener('click', () => closePopup(btn.closest('.pe-popup'))));
document.addEventListener('keydown', e => { if(e.key === 'Escape') document.querySelectorAll('.pe-popup.is-open').forEach(closePopup); });
const selUser=document.getElementById('acc-user'); selUser?.addEventListener('change', () => renderFor(selUser.value)); if(selUser && selUser.options.length > 1){ selUser.selectedIndex=1; renderFor(selUser.value); }
function openThemePreview(src, title) {
    const popup = document.getElementById('popup-theme-preview');
    const img = document.getElementById('theme-preview-img');
    const headTitle = document.getElementById('theme-preview-title');

    if (!popup || !img || !headTitle) return;

    img.src = src;
    img.alt = title || 'Aperçu du thème';
    headTitle.textContent = title || 'Aperçu du thème';

    popup.classList.add('is-open');
    popup.setAttribute('aria-hidden', 'false');
    document.body.classList.add('noscroll');
}

function closeThemePreview() {
    const popup = document.getElementById('popup-theme-preview');
    const img = document.getElementById('theme-preview-img');

    if (!popup) return;

    popup.classList.remove('is-open');
    popup.setAttribute('aria-hidden', 'true');

    if (img) {
        img.src = '';
        img.alt = '';
    }

    if (!document.querySelector('.pe-popup.is-open')) {
        document.body.classList.remove('noscroll');
    }
}

document.getElementById('popup-theme-preview')?.addEventListener('click', function(e) {
    if (e.target === this) {
        closeThemePreview();
    }
});
</script>
</body>
</html>
