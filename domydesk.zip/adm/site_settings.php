
<?php
session_start();
$email = $_SESSION['user']['email'] ?? null;
$theme = 'default';
$idDoMyDesk = '';
$idFile = __DIR__ . '/../data/id_domydesk.txt';
if (file_exists($idFile)) {
    $idDoMyDesk = trim(file_get_contents($idFile));
}
if ($email) {
    $themePath = __DIR__ . "/../users/profiles/$email/theme.json";
    if (file_exists($themePath)) {
        $data = json_decode(file_get_contents($themePath), true);
        if (!empty($data['theme']) && file_exists(__DIR__ . "/../theme/" . $data['theme'] . "/style.css")) {
            $theme = basename($data['theme']);
        }
    }
}
$baseDir = dirname(__DIR__, 2); 
$metiers = [];
$rolesFile = "$baseDir/data/roles_metier.json";
if (file_exists($rolesFile)) {
    $json = file_get_contents($rolesFile);
    $decoded = json_decode($json, true);
    if (is_array($decoded)) {
        $metiers = $decoded;
    } else {
        $metiers = [];
    }
}
$theme        = $_SESSION['user']['theme'] ?? 'default';
$baseDir      = dirname(__DIR__);
$settingsFile = "$baseDir/adm/settings.json";
$accessFile   = "$baseDir/adm/menus/access_per_user.json";
$profilesDir  = "$baseDir/users/profiles/";
$settings = file_exists($settingsFile) ? json_decode(file_get_contents($settingsFile), true) : [];
$success  = false; 
$errors   = []; 
if (!function_exists('setPermissions')) {
    function setPermissions(string $path): void {
        if (!file_exists($path)) return;
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($path, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($iterator as $item) {
            @chmod($item, $item->isDir() ? 0775 : 0664);
        }
        @chmod($path, 0775);
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
if (isset($_POST['delete_module'])) {
    $mod = basename($_POST['delete_module']);
    $modPath = "$baseDir/modules/$mod";
    if (is_dir($modPath)) {
        $it = new RecursiveDirectoryIterator($modPath, RecursiveDirectoryIterator::SKIP_DOTS);
        $ri = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($ri as $file) {
            $file->isDir() ? rmdir($file) : unlink($file);
        }
        rmdir($modPath);
        $success = true;
    }
}
if (isset($_POST['update_user_roles'])) {
    $email       = trim($_POST['user_email'] ?? '');
    $roleSystem  = trim($_POST['new_role_system'] ?? '');
    $roleMetier  = trim($_POST['new_role_metier'] ?? '');
    $profileFile = $profilesDir . $email . '/profile.json';
    if (is_file($profileFile)) {
        $data = json_decode(file_get_contents($profileFile), true) ?: [];
        if (in_array($roleSystem, ['admin', 'user'], true)) {
            $data['role_system'] = $roleSystem;
        }
        if (in_array($roleMetier, $metiers ?? [], true)) {
            $data['role_metier'] = $roleMetier;
        }
        file_put_contents($profileFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $success = true;
    }
}
if (isset($_POST['update_user_roles'])) {
    $email = trim($_POST['user_email'] ?? '');
    $roleSystem = trim($_POST['new_role_system'] ?? '');
    $roleMetier = trim($_POST['new_role_metier'] ?? '');
    $profileFile = $profilesDir . $email . '/profile.json';
    if (is_file($profileFile)) {
        $data = json_decode(file_get_contents($profileFile), true);
        if (!is_array($data)) $data = [];
        if (in_array($roleSystem, ['admin', 'user'], true)) {
            $data['role_system'] = $roleSystem;
        }
        if (in_array($roleMetier, $metiers, true)) {
            $data['role_metier'] = $roleMetier;
        }
        file_put_contents($profileFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $success = true;
    }
}
$rolesFile = "$baseDir/data/roles_metier.json";
if (!file_exists($rolesFile)) {
    file_put_contents($rolesFile, json_encode([], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}
function loadMetiers($file) {
    $arr = json_decode(file_get_contents($file), true);
    return is_array($arr) ? $arr : [];
}
function saveMetiers($file, array $arr) {
    file_put_contents($file, json_encode(array_values(array_unique($arr)),
                     JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}
$metiers = loadMetiers($rolesFile);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_metier'])) {
        $new = trim($_POST['new_metier'] ?? '');
        if ($new !== '' && !in_array($new, $metiers, true)) {
            $metiers[] = $new;
            saveMetiers($rolesFile, $metiers);
        }
    }
    if (isset($_POST['delete_metier'])) {
        $del = $_POST['del_metier'] ?? '';
        $metiers = array_filter($metiers, fn($m) => $m !== $del);
        saveMetiers($rolesFile, $metiers);
    }
}
if (isset($_POST['add_user'])) {
    $prenom      = trim($_POST['prenom'] ?? '');
    $nom         = trim($_POST['nom'] ?? '');
    $emailNew    = trim($_POST['email'] ?? '');
    $role_metier = trim($_POST['role_metier'] ?? '');
    $role_system = trim($_POST['role_system'] ?? 'user');
    $password    = $_POST['password'] ?? '';
    if (!$prenom || !$nom || !$emailNew || !$role_metier || !$password || !$role_system) {
        $message = "? Tous les champs sont obligatoires.";
    } elseif (!filter_var($emailNew, FILTER_VALIDATE_EMAIL)) {
        $message = "? Email invalide.";
    } elseif (!in_array($role_metier, $metiers ?? [], true)) {
        $message = "? R�le m�tier invalide.";
    } elseif (!in_array($role_system, ['user', 'admin'], true)) {
        $message = "? R�le syst�me invalide.";
    } else {
        $folder = $profilesDir . $emailNew . '/';
        if (file_exists($folder)) {
            $message = "? L'utilisateur existe d�j�.";
        } else {
            mkdir($folder, 0755, true);
            $data = [
                'prenom'      => $prenom,
                'nom'         => $nom,
                'email'       => $emailNew,
                'role_system' => $role_system,
                'role_metier' => $role_metier,
                'motdepasse'  => password_hash($password, PASSWORD_DEFAULT),
            ];
            file_put_contents($folder . 'profile.json', json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
            file_put_contents($folder . 'dashboard.json', json_encode([], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
            file_put_contents($folder . 'menu.json', json_encode([], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
            @copy("$baseDir/data/Logo_2025_Mini.png", $folder . 'avatar.png');
            setPermissions($folder);
            $message = "? Utilisateur ajout� avec succ�s.";
        }
    }
}
    if (isset($_POST['save_site'])) {
        $settings['site_name']      = $_POST['site_name']      ?? 'DoMyDesk';
        $settings['menu_vertical']  = $_POST['menu_vertical']  ?? '';
        if (!empty($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
            $ext    = pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION);
            $target = "uploads/logo.$ext";
            move_uploaded_file($_FILES['logo']['tmp_name'], $target);
            $settings['logo_path'] = $target;
        }
        file_put_contents($settingsFile, json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $success = true;
    }
    if (isset($_POST['set_role_admin']) || isset($_POST['set_role_user'])) {
        $email       = $_POST['user_email'] ?? '';
        $profileFile = "$profilesDir/$email/profile.json";
        if (is_file($profileFile)) {
            $profile                = json_decode(file_get_contents($profileFile), true);
            $profile['role_system'] = isset($_POST['set_role_admin']) ? 'admin' : 'user';
            file_put_contents($profileFile, json_encode($profile, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }
    }
    if (isset($_POST['manage_access'])) {
        $email  = $_POST['user']  ?? '';
        $pages  = $_POST['pages'] ?? [];
        $rights = file_exists($accessFile) ? json_decode(file_get_contents($accessFile), true) : [];
        $rights[$email] = $pages;
        file_put_contents($accessFile, json_encode($rights, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
    if (isset($_POST['delete_user'])) {
        $email  = $_POST['user_email'] ?? '';
        $folder = "$profilesDir/$email";
        if ($email !== $_SESSION['user']['email'] && is_dir($folder)) {
            $it = new RecursiveDirectoryIterator($folder, RecursiveDirectoryIterator::SKIP_DOTS);
            $fi = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);
            foreach ($fi as $f) $f->isDir() ? rmdir($f) : unlink($f);
            rmdir($folder);
            if (is_file($accessFile)) {
                $rights = json_decode(file_get_contents($accessFile), true);
                unset($rights[$email]);
                file_put_contents($accessFile, json_encode($rights, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            }
            $success = true;
        } else {
            $errors[] = "Impossible de supprimer l'utilisateur courant ou le dossier est introuvable.";
        }
    }
}
$userRoles = $users = [];
foreach (glob("$profilesDir*", GLOB_ONLYDIR) as $folder) {
    $mail = basename($folder);
    $users[]          = $mail;
    $profileFile      = "$folder/profile.json";
    $data             = is_file($profileFile) ? json_decode(file_get_contents($profileFile), true) : [];
    $userRoles[$mail] = $data['role_system'] ?? 'user';
}
$accessRights = file_exists($accessFile) ? json_decode(file_get_contents($accessFile), true) : [];
$accessRights = array_intersect_key($accessRights, array_flip($users)); // garde seulement users existants
file_put_contents($accessFile, json_encode($accessRights, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
$pagesScan = [];
$dirs = ['', 'adm']; 
foreach ($dirs as $sub) {
    foreach (glob($baseDir . ($sub ? "/$sub" : '') . '/*.php') as $f) {
        $rel = str_replace("$baseDir/", '', $f);
        if (preg_match('/(?:cfg|inc|ajax|api)\.php$/i', $rel)) continue;
        $pagesScan[] = $rel;
    }
}
$modulesDir = __DIR__ . '/../modules/';
foreach (glob($modulesDir . '*/*cfg.php') as $cfgFile) {
    $moduleName = basename(dirname($cfgFile));
    if ($isAdmin && in_array($moduleName, array_column($modulesActifs, 'id'))) {
        include $cfgFile;
    }
}
?>
<?php
$modulesEnabledPath = "users/profiles/$email/modules.json";
if (file_exists($modulesEnabledPath)) {
    $enabledModules = json_decode(file_get_contents($modulesEnabledPath), true);
    foreach ($enabledModules as $mod) {
        $modName = is_array($mod) ? ($mod['id'] ?? '') : $mod;
        $cfgPath = "modules/$modName/{$modName}cfg.php";
        if (is_file($cfgPath)) {
            include $cfgPath;
        }
    }
}
$scriptDir = "/var/www/html/domydesk/adm/domybox/";
$enable   = $scriptDir . "enable_web_access.sh";
$disable  = $scriptDir . "disable_web_access.sh";
$rename   = $scriptDir . "rename_box.sh";
$chgpass  = $scriptDir . "change_pass.sh";
$setwifi  = $scriptDir . "set_wifi.sh";
$installSamba = $scriptDir . "install_samba.sh";
$shareFolderScript = $scriptDir . "create_share.sh";
$shareError = "";
$shareSuccess = "";
if (isset($_POST['add_metier'])) {
    $newMetier = trim($_POST['new_metier'] ?? '');

    if ($newMetier !== '' && !in_array($newMetier, $metiers, true)) {
        $metiers[] = $newMetier;
        file_put_contents($rolesFile, json_encode($metiers, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
}
if (isset($_POST['update_user_roles'])) {
    $email       = trim($_POST['user_email'] ?? '');
    $roleSys     = trim($_POST['new_role_system']  ?? 'user');
    $roleMetier  = trim($_POST['new_role_metier'] ?? '');

    $profileFile = $profilesDir . $email . '/profile.json';
    if (is_file($profileFile)) {
        $data = json_decode(file_get_contents($profileFile), true) ?: [];

        if (in_array($roleSys, ['admin','user'], true))     $data['role_system'] = $roleSys;
        if (in_array($roleMetier, $metiers, true))          $data['role_metier'] = $roleMetier;

        file_put_contents($profileFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
}
if (isset($_POST['add_user'])) {
    // �?garde ton code actuel, mais remplace la vérif métier par :
    if (!in_array($role_metier, $metiers, true)) {
        $message = "�?Rôle métier invalide.";
    }
  
}
$modulesPath = __DIR__ . '/../modules/';
$enabledModulesFile = "users/profiles/$email/modules.json";
$enabledModules = file_exists($enabledModulesFile) ? json_decode(file_get_contents($enabledModulesFile), true) : [];
foreach ($enabledModules as $mod) {
    if (!empty($mod['enabled']) && !empty($mod['id'])) {
        $cfgFile = $modulesPath . $mod['id'] . '/' . $mod['id'] . 'cfg.php';
        if (file_exists($cfgFile)) {
            echo '<div class="section" style="flex:1 1 48%;">';
            include $cfgFile;
            echo '</div>';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Administration system</title>
<?php
$themeFile = __DIR__ . "/../theme/$theme/style.css";
$baseUrl   = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\'); // /domydesk/adm -> base /domydesk
$themeHref = $baseUrl . "/theme/" . rawurlencode($theme) . "/style.css";
if (is_file($themeFile)) {
    $themeHref .= '?v=' . filemtime($themeFile);
}
?>
<link rel="stylesheet" href="<?= htmlspecialchars($themeHref) ?>">
<style>
body {
  background-color: var(--background-color, #121212);
  color: var(--text-color, #ccc);
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
}
.section {
  background: var(--section-bg, #1e1e1e);
  border: 1px solid var(--border-color, #333);
  border-radius: 10px;
  box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
  padding: 20px;
  margin: 20px auto;
  max-width: 900px;
}
.section h2 {
  margin-top: 0;
  color: var(--primary-color, #ffaa00);
  border-bottom: 1px solid var(--border-color, #333);
  padding-bottom: 5px;
}
input[type="text"],
input[type="email"],
input[type="password"],
select,
textarea {
  width: 50%;
  padding: 8px 10px;
  margin-top: 5px;
  margin-bottom: 10px;
  border: 1px solid var(--border-color, #444);
  border-radius: 5px;
  background-color: var(--input-bg, #222);
  color: var(--text-color, #ccc);
  box-sizing: border-box;
}
button {
  background-color: var(--button-bg, #222);
  color: var(--text-color, #ccc);
  border: 1px solid var(--border-color, #444);
  border-radius: 5px;
  padding: 6px 14px;
  cursor: pointer;
  font-size: 13px;
  margin-right: 5px;
}
button:hover {
  background-color: var(--button-hover, #333);
}
label {
  font-weight: bold;
  display: block;
  margin-bottom: 4px;
  color: var(--text-color, #ccc);
}
input[type="checkbox"] {
  margin-right: 8px;
  transform: scale(1.1);
}
.row {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
}
.col {
  flex: 1;
  min-width: 280px;
}
hr {
  border: none;
  border-top: 1px solid var(--border-color, #444);
  margin: 30px 0;
}
.warning {
  color: var(--danger-color, red);
  font-weight: bold;
}
</style>
</head>
<body>
<?php include "$baseDir/header.php"; ?>
<div class="container">
  <div class="settings-wrapper">
  <div class="left-settings">
<h2>SITE
<?php if ($idDoMyDesk): ?>
  <span style="font-size:0.7em; font-weight:normal; margin-left:10px; color:#ccc;"
        title="⚠️ Sauvegardez cet identifiant précieusement. Il est nécessaire pour récupérer vos modules premium en cas de crash ou lors d’une assistance.">
     Votre ID DoMyDesk : <code style="color:#ffaa00"><?= htmlspecialchars($idDoMyDesk) ?></code>
    <a href="/domydesk/data/id_domydesk.txt" download
       title="Telechargez votre ID (A�conserver dans un endroit sur)"
       style="margin-left:8px; text-decoration:none; font-size:1.1em;">Sauvegarder</a>
  </span>
<?php endif; ?>
</h2>
      <details>
<a href="../adm/fix_all_rights.php" target="_blank" class="btn btn-nolink">Accorder les permissions</a>
      <?php if($errors):?><div class="msg-err"><?php foreach($errors as $e) echo htmlspecialchars($e)."<br>";?></div><?php endif;?>
<br>
<br>
<style>
.btn-nolink {
  color: cyan;
  text-decoration: none;
}
</style>
      <form method="post" enctype="multipart/form-data">
        <label>Nom du site:<br>
          <input type="text" name="site_name" value="<?=htmlspecialchars($settings['site_name'] ?? '')?>">
        </label>
       <br> <label>Logo actuel<br>
          <?php if(isset($settings['logo_path']) && is_file(__DIR__.'/'.$settings['logo_path'])):?>
            <img class="logo-preview" src="<?=htmlspecialchars($settings['logo_path'])?>" alt="Logo">
          <br><?php else:?>Aucun logo<?php endif;?>
        </label>
       <br><label>Changer de logo:<br>    
          <input type="file" name="logo" accept=".png,.jpg,.jpeg,.gif,.svg">
        </label>
       <br><label>HTML du menu horizontal<br>
          <textarea name="menu_vertical" rows="5"><?=htmlspecialchars($settings['menu_vertical'] ?? '')?></textarea>
        </label>
      <br>  <button name="save_site">Enregistrer</button>
      </form>
    </details>
<h2>MODULES</h2>
<details>
<?php
$isAdmin = isset($_SESSION['user']['role_system']) && $_SESSION['user']['role_system'] === 'admin';
$baseDir = $baseDir ?? dirname(__DIR__);
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_module'])) {
    $mod = basename($_POST['delete_module']);
    $modPath = "$baseDir/modules/$mod";
    if (is_dir($modPath)) {
        $it = new RecursiveDirectoryIterator($modPath, RecursiveDirectoryIterator::SKIP_DOTS);
        $ri = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($ri as $file) {
            $file->isDir() ? @rmdir($file) : @unlink($file);
        }
        @rmdir($modPath);
    }
}
?>
<style>
  .mods-toolbar{
    display:flex; gap:8px; align-items:center; justify-content:flex-end; margin:6px 0 14px;
  }
  .btn-pill{
    display:inline-flex; align-items:center; gap:8px; padding:8px 12px; border-radius:999px;
    text-decoration:none; border:1px solid var(--border-color,#444); background:var(--button-bg,#222);
    color:var(--text-color,#ddd); font-weight:600; cursor:pointer;
  }
  .btn-pill:hover{ filter:brightness(1.1); }
  .mods-grid{
    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(340px,1fr)); /* largeur confortable pour lire les noms */
    gap:14px;
  }
  .mod-card{
    background:var(--section-bg,#1e1e1e); border:1px solid var(--border-color,#333);
    border-radius:12px; padding:12px; display:flex; gap:12px; align-items:flex-start;
    box-shadow:0 4px 14px rgba(0,0,0,.25);
  }
  .mod-thumb{
    width:52px; height:52px; border-radius:10px; flex:0 0 52px; object-fit:cover;
    border:1px solid rgba(255,255,255,.1); background:rgba(255,255,255,.05);
    display:flex; align-items:center; justify-content:center; font-size:26px;
  }
  .mod-meta{ flex:1 1 auto; min-width:0; }

  /* Nom bien lisible, 2 lignes max + tooltip avec l’id complet */
  .mod-name{
    font-size:1.05rem; font-weight:700; line-height:1.25;
    white-space:normal; word-break:break-word;
    display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;
  }
  .mod-actions{ display:flex; gap:6px; align-items:center; }
  .mod-actions form{ margin:0; }
  .btn-del{
    padding:6px 8px; border-radius:8px; border:1px solid var(--border-color,#444);
    background:#3a1f1f; color:#ffb3b3; cursor:pointer;
  }
  .btn-del:hover{ filter:brightness(1.1); }
  .mods-pager{ margin-top:12px; text-align:center; display:flex; gap:8px; justify-content:center; }
  .mods-pager a, .mods-pager strong{ padding:6px 10px; border-radius:8px; border:1px solid var(--border-color,#444); }
  .mods-pager strong{ background:var(--button-bg,#222); }
  .market-overlay{ position:fixed; inset:0; display:none; align-items:center; justify-content:center;
    background:rgba(0,0,0,.65); z-index:9999; }
  .market-modal{ width:min(1100px,96vw); height:min(80vh, 800px); background:#111; border:1px solid rgba(255,255,255,.12);
    border-radius:12px; overflow:hidden; display:flex; flex-direction:column; }
  .market-head{ display:flex; align-items:center; justify-content:space-between; padding:8px 10px;
    border-bottom:1px solid rgba(255,255,255,.08); }
  .market-body{ flex:1 1 auto; }
  .market-body iframe{ width:100%; height:100%; border:0; }
</style>
<div class="mods-toolbar">
  <button type="button" class="btn-pill" id="open-market" title="Voir les modules installables">Installer un module</button>
</div>
<?php
$modDir        = "$baseDir/modules";
$allModules    = array_values(array_filter(glob("$modDir/*"), 'is_dir'));
$totalModules  = count($allModules);
$perPage       = 40;
$page          = max(1, (int)($_GET['mpage'] ?? 1));
$start         = ($page - 1) * $perPage;
$modulesPage   = array_slice($allModules, $start, $perPage);
?>
<div class="mods-grid">
  <?php foreach ($modulesPage as $path): 
    $mod = basename($path);
    $displayName = ucwords(trim(preg_replace('/[_\.\-]+/', ' ', $mod)));
    $icon = '';
    foreach (['icon.png','logo.png','icon.jpg','icon.webp','logo.webp'] as $f) {
      if (is_file("$path/$f")) { $icon = "../modules/$mod/$f"; break; }
    }
  ?>
    <div class="mod-card">
      <?php if ($icon): ?>
        <img src="<?= htmlspecialchars($icon) ?>" alt="" class="mod-thumb">
      <?php else: ?>
      <?php endif; ?>
      <div class="mod-meta">
        <div class="mod-name" title="<?= htmlspecialchars($mod) ?>">
          <?= htmlspecialchars($displayName) ?>
        </div>
      </div>
      <div class="mod-actions">
        <?php if ($isAdmin): ?>
          <form method="post" onsubmit="return confirm('Supprimer définitivement le module <?= htmlspecialchars($mod) ?> ?');">
            <input type="hidden" name="delete_module" value="<?= htmlspecialchars($mod) ?>">
            <button type="submit" class="btn-del" title="Supprimer">Supprimer
          </form>
        <?php endif; ?>
      </div>
    </div>
  <?php endforeach; ?>
</div>
<?php
$pages = max(1, ceil($totalModules / $perPage));
if ($pages > 1): ?>
  <div class="mods-pager">
    <?php for ($i = 1; $i <= $pages; $i++): ?>
      <?php if ($i == $page): ?>
        <strong><?= $i ?></strong>
      <?php else: ?>
        <a href="?mpage=<?= $i ?>#modules"><?= $i ?></a>
      <?php endif; ?>
    <?php endfor; ?>
  </div>
<?php endif; ?>
<div class="market-overlay" id="marketOverlay">
  <div class="market-modal">
    <div class="market-head">
      <strong style="display:flex;align-items:center;gap:6px;">Installer un module via notre panel ou manuellement</strong>
      <button type="button" class="btn-pill" id="close-market">Fermer</button>
    </div>
    <div class="market-body">
      <iframe src="../adm/market/marketmodules.php"></iframe>
    </div>
  </div>
</div>
<script>
  const openBtn  = document.getElementById('open-market');
  const closeBtn = document.getElementById('close-market');
  const overlay  = document.getElementById('marketOverlay');
  openBtn?.addEventListener('click', ()=> overlay.style.display='flex');
  closeBtn?.addEventListener('click', ()=> overlay.style.display='none');
  overlay?.addEventListener('click', (e)=>{ if(e.target===overlay) overlay.style.display='none'; });
  document.addEventListener('keydown', (e)=>{ if(e.key==='Escape') overlay.style.display='none'; });
</script>
</details>
<?php
$pagesScan = [];
foreach (['', 'adm'] as $sub) { // pas "modules"
    foreach (glob($baseDir . ($sub ? "/$sub" : '') . '/*.php') as $f) {
        $pagesScan[] = str_replace("$baseDir/", '', $f);
    }
}
sort($pagesScan);
$userPagesMap = [];
foreach (glob($profilesDir . '*', GLOB_ONLYDIR) as $folder) {
    $mail = basename($folder);
    $file = $folder . '/pages.json';
    if (is_file($file)) {
        $arr = json_decode(file_get_contents($file), true);
        if (is_array($arr)) $userPagesMap[$mail] = $arr;
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_user_pages'])) {
    $emailSel = trim($_POST['user_email'] ?? '');
    $picked   = isset($_POST['pages']) && is_array($_POST['pages']) ? $_POST['pages'] : [];
    $picked   = array_values(array_intersect($pagesScan, $picked));

    if ($emailSel && is_dir($profilesDir . $emailSel)) {
        $dest = $profilesDir . $emailSel . '/pages.json';
        file_put_contents($dest, json_encode($picked, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $userPagesMap[$emailSel] = $picked; // pour réaffichage
        $success = true;
    } else {
        $errors[] = "Utilisateur invalide pour la sauvegarde des accès.";
    }
}
?>
<h2>UTILISATEURS</h2>
<details>
<style>
    .access-wrap{
  display:flex;
  flex-direction: column;
  gap:16px;
  align-items: stretch;
}
.access-left{
  width:100%; 
  max-width:420px;
}
.access-right{ width:100%; } 
    .access-left label { display:block; font-weight:600; margin-bottom:6px; }
    .access-left select { width:100%; }
    table.pages-matrix { width:100%; border-collapse:collapse; }
    table.pages-matrix th, table.pages-matrix td {
      border-bottom:1px solid var(--border-color, #333);
      padding:8px 10px;
      vertical-align:top;
      width:25%;
    }
    table.pages-matrix th { text-align:left; font-weight:700; }
    .page-cell {
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:10px;
      min-height:32px;
    }
    .page-info { display:flex; align-items:center; gap:8px; overflow:hidden; }
    .page-name {
      white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
      max-width: 260px;
    }
    .dot { width:10px; height:10px; border-radius:50%; display:inline-block; }
    .dot.green { background:#2ecc71; box-shadow:0 0 0 2px rgba(46,204,113,.15); }
    .dot.red   { background:#e74c3c; box-shadow:0 0 0 2px rgba(231,76,60,.15); }
    .access-actions { margin-top:14px; text-align:right; }
  </style>
  <div class="access-wrap">
    <div class="access-left">
  <h3>AUTORISATIONS</h3>
      <select id="acc-user">
        <option value="">S�lectionner</option>
        <?php foreach ($users as $u): ?>
          <option value="<?= htmlspecialchars($u) ?>"><?= htmlspecialchars($u) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div style="flex:1 1 auto;">
      <form method="post" id="acc-form">
        <input type="hidden" name="save_user_pages" value="1">
        <input type="hidden" name="user_email" id="acc-user-email">
        <table class="pages-matrix" id="pages-matrix">
          <thead>
          </thead>
          <tbody></tbody>
        </table>
        <div class="access-actions">
          <button type="submit">ENREGISTRER</button>
        </div>
      </form>
    </div>
  </div>
  <h3>AJOUTER UTILISATEUR</h3>
  <?php if (!empty($message)): ?>
    <div style="color:<?= strpos($message, 'existe') !== false ? 'red' : 'green' ?>;margin-bottom:10px">
      <?= htmlspecialchars($message) ?>
    </div>
  <?php endif; ?>
  <style>
    .user-form {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(420px, 1fr));
      gap: 5px;
      align-items: end;
      max-width: 500px;
      margin: 0 auto;
    }
    .user-form label {
      display: flex;
      flex-direction: column;
      font-weight: 250;
      font-size: 0.95em;
    }
    .user-form input,
    .user-form select {
      padding: 6px 8px;
      border-radius: 4px;
      border: 1px solid var(--border-color, #444);
      background: var(--input-bg, #111);
      color: inherit;
    }
    .user-form button {
      padding: 8px 14px;
      border: none;
      border-radius: 4px;
      background: var(--primary-color, #28a745);
      color: #fff;
      cursor: pointer;
      font-size: 0.95em;
    }
    .user-form button:hover {
      background: var(--primary-dark, #1e7e34);
    }
    .user-form .full {
      grid-column: 1 / -1;
    }
    .user-form-wrap {
      display: flex;
      justify-content: center;
    }
  </style>
  <div class="user-form-wrap">
    <form method="post" class="user-form">
      <label>Prenom
        <input type="text" name="prenom" required>
      </label>
      <label>Nom
        <input type="text" name="nom" required>
      </label>
      <label class="full">Email
        <input type="email" name="email" required>
      </label>
      <label class="full">Role interne
        <select name="role_metier" required>
          <option value="" disabled selected>Selectionner</option>
          <?php foreach ($metiers as $m): ?>
            <option value="<?= htmlspecialchars($m) ?>"><?= htmlspecialchars($m) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label>Mot de passe
        <input type="password" name="password" required>
      </label>
      <label>Role systeme
        <select name="role_system" required>
          <option value="user">Utilisateur</option>
          <option value="admin">Administrateur</option>
        </select>
      </label>
      <div class="full" style="text-align:right">
        <button type="submit" name="add_user">ENREGISTRER</button>
      </div>
    </form>
  </div>
  <h3>ROLES</h3>
  <style>
    .roles-table select,
    .roles-table button {
      font-size: 0.8em;
      padding: 4px 6px;
    }
    .roles-table td, .roles-table th {
      padding: 4px 8px;
      vertical-align: middle;
    }
    .roles-table form {
      display: inline-flex;
      gap: 6px;
      flex-wrap: wrap;
      align-items: center;
    }
    .roles-table input[type="text"], .roles-table select {
      max-width: 160px;
    }
    .roles-table input[type="text"] {
      height: 28px;
    }
    .roles-table button {
      height: 28px;
    }
	details {
  margin-bottom: 5px;
  border: 1px solid var(--primary-dark);
  border-radius: 10px;
  background-color: #1c1c1c;
  padding: 10px;
}
details summary h2 {
  margin: 0;
  color: var(--primary-color);
  cursor: pointer;
}
fieldset {
  background-color: #ffff;
}
  </style>
  <table class="roles-table">
    <tbody>
      <?php foreach($userRoles as $mail => $roleSys): 
        $profileFile = $profilesDir . $mail . '/profile.json';
        $prenom = $mail;
        $roleMetier = 'N/A';
        if (is_file($profileFile)) {
          $data = json_decode(file_get_contents($profileFile), true);
          $prenom = $data['prenom'] ?? $mail;
          $roleMetier = $data['role_metier'] ?? 'N/A';
        }
      ?>
      <tr>
        <td>
          <?= htmlspecialchars($prenom) ?>
          <a href="/domydesk/profile_view.php?email=<?= urlencode($mail) ?>" title="Voir profil">  VOIR
        </td>
        <td><?= ($mail === $_SESSION['user']['email']) ? '👑 Vous' : ($roleSys === 'admin' ? '🛡�?Admin' : '👤 User') ?></td>
        <td><?= htmlspecialchars($roleMetier) ?></td>
        <td>
          <form method="post">
            <input type="hidden" name="user_email" value="<?= htmlspecialchars($mail) ?>">

            <select name="new_role_system">
              <option value="user"  <?= $roleSys === 'user' ? 'selected' : '' ?>>Utilisateur</option>
              <option value="admin" <?= $roleSys === 'admin' ? 'selected' : '' ?>>Administrateur</option>
            </select>
            <select name="new_role_metier">
              <?php foreach ($metiers as $m): ?>
                <option value="<?= htmlspecialchars($m) ?>" <?= $m === $roleMetier ? 'selected' : '' ?>>
                  <?= htmlspecialchars($m) ?>
                </option>
              <?php endforeach; ?>
            </select><button name="update_user_roles">ENREGISTRER</button>

            <?php if ($mail !== $_SESSION['user']['email']): ?>
              <button name="delete_user" onclick="return confirm('Supprimer définitivement <?= htmlspecialchars($mail) ?> ?')">AJOUTER
            <?php endif; ?>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <form method="post" style="margin-top:10px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
    <label style="font-size:0.9em">Nouveau role :
      <input type="text" name="new_metier" required placeholder="ex: Technicien, RH, etc." style="height:42px">
    </label>    <button name="add_metier" style="height:42px">AJOUTER</button>
  </form>
  <?php if (!empty($metiers)): ?>
  <form method="post" style="margin-top:6px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
    <label style="font-size:1em">Supprimer un role :
      <select name="del_metier" required style="height:42px">
        <option value="">Roles</option>
        <?php foreach ($metiers as $m): ?>
          <option value="<?= htmlspecialchars($m) ?>"><?= htmlspecialchars($m) ?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <button name="delete_metier" style="height:42px">Supprimer</button>
  </form>
  <?php endif; ?>
  <script>
    const PAGES_ALL  = <?= json_encode($pagesScan, JSON_UNESCAPED_UNICODE) ?>;
    const USER_PAGES = <?= json_encode($userPagesMap, JSON_UNESCAPED_UNICODE) ?>;
    const selUser = document.getElementById('acc-user');
    const hiddenU = document.getElementById('acc-user-email');
    const tbody   = document.querySelector('#pages-matrix tbody');
    function cellHTML(page, checked){
      if (!page) return '<td></td>';
      const esc = s => s.replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;', "'":'&#39;'}[m]));
      return `
        <td>
          <div class="page-cell">
            <div class="page-info">
              <span class="dot ${checked ? 'green':'red'}"></span>
              <span class="page-name" title="${esc(page)}">${esc(page)}</span>
            </div>
            <input type="checkbox" name="pages[]" value="${esc(page)}" ${checked ? 'checked' : ''}>
          </div>
        </td>`;
    }
    function renderFor(user){
      tbody.innerHTML = '';
      hiddenU.value = user || '';
      if (!user) return;
      const allowed = new Set(USER_PAGES[user] || []);
      const cols = 4;
      const rows = Math.ceil(PAGES_ALL.length / cols);
      let html = '';
      for (let r = 0; r < rows; r++){
        html += '<tr>';
        for (let c = 0; c < cols; c++){
          const idx = r + c*rows;     
          const page = PAGES_ALL[idx] || null;
          html += cellHTML(page, page ? allowed.has(page) : false);
        }
        html += '</tr>';
      }
      tbody.innerHTML = html;
    }
    selUser.addEventListener('change', () => renderFor(selUser.value));
    if (selUser.options.length > 1) { selUser.selectedIndex = 1; renderFor(selUser.value); }
  </script>
</details>

</div>
</html>