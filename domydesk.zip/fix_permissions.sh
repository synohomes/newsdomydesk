#!/bin/bash
DOMYDESK_PATH="/var/www/html/domydesk"
echo "Application des droits"
find "$DOMYDESK_PATH/modules" -type d -exec chmod 777 {} \;
find "$DOMYDESK_PATH/modules" -type f -exec chmod 666 {} \;
echo "Droits attribués aux pages."
