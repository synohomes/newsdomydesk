<?php
header('Content-Type: application/json');
error_reporting(0);
$idFile = __DIR__ . '/id_domydesk.txt';
$id = file_exists($idFile) ? trim(file_get_contents($idFile)) : null;
if (!$id) {
    echo json_encode(['error' => 'ID introuvable']); exit;
}
$modulesList = __DIR__ . '/../modules/list.json';
$list = file_exists($modulesList) ? json_decode(file_get_contents($modulesList), true) : [];
$profilesDir = __DIR__ . '/../users/profiles/';
$modules = [];
if (is_dir($profilesDir)) {
    foreach (scandir($profilesDir) as $user) {
        if ($user === '.' || $user === '..') continue;
        $userModulesFile = "$profilesDir/$user/modules.json";
        if (!file_exists($userModulesFile)) continue;

        $userModules = json_decode(file_get_contents($userModulesFile), true);
        if (!is_array($userModules)) continue;

        foreach ($userModules as $mod) {
            if (!empty($mod['enabled']) && !isset($modules[$mod['id']])) {
                $modules[$mod['id']] = [
                    'id' => $mod['id'],
                    'name' => $mod['name'] ?? $mod['id']
                ];
            }
        }
    }
}
echo json_encode([
    'id' => $id,
    'modules' => array_values($modules)
], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
