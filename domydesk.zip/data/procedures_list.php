<?php
session_start();

$userEmail = $_SESSION['user']['email'] ?? '';
$roleSystem = $_SESSION['user']['role_system'] ?? '';
$isAdmin = ($roleSystem === 'admin' || $roleSystem === 'superadmin');

if (!$userEmail) {
    http_response_code(403);
    die('Accès refusé');
}

$baseDir = realpath(__DIR__ . '/../../');
if ($baseDir === false) {
    http_response_code(500);
    die('Erreur de chemin DoMyDesk.');
}

$userDir = $baseDir . '/users/profiles/' . $userEmail;
$theme = 'default';
$themePath = $userDir . '/theme.json';

if (is_file($themePath)) {
    $themeData = json_decode((string)file_get_contents($themePath), true);
    if (is_array($themeData) && !empty($themeData['theme'])) {
        $theme = basename((string)$themeData['theme']);
    }
}

$procedureDir = __DIR__ . '/procedures/documents';
if (!is_dir($procedureDir)) {
    mkdir($procedureDir, 0755, true);
}

$message = '';
$messageType = 'info';

function dmd_h($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function dmd_format_size(int $bytes): string
{
    if ($bytes >= 1073741824) return round($bytes / 1073741824, 2) . ' Go';
    if ($bytes >= 1048576) return round($bytes / 1048576, 2) . ' Mo';
    if ($bytes >= 1024) return round($bytes / 1024, 1) . ' Ko';
    return $bytes . ' o';
}

function dmd_safe_pdf_name(string $name): string
{
    $name = basename($name);
    $name = preg_replace('/[^a-zA-Z0-9À-ÿ._\- ]/u', '-', $name);
    $name = preg_replace('/\s+/', ' ', trim((string)$name));
    return $name !== '' ? $name : 'procedure.pdf';
}

if ($isAdmin && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_pdf'])) {
    $toDelete = basename((string)$_POST['delete_pdf']);
    $targetDel = $procedureDir . '/' . $toDelete;

    if (is_file($targetDel) && strtolower(pathinfo($targetDel, PATHINFO_EXTENSION)) === 'pdf') {
        if (@unlink($targetDel)) {
            $message = 'Procédure supprimée : ' . $toDelete;
            $messageType = 'success';
        } else {
            $message = 'Impossible de supprimer cette procédure.';
            $messageType = 'error';
        }
    } else {
        $message = 'Procédure introuvable.';
        $messageType = 'error';
    }
}

if ($isAdmin && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['procedure_pdf'])) {
    $file = $_FILES['procedure_pdf'];
    $ext = strtolower(pathinfo((string)$file['name'], PATHINFO_EXTENSION));

    if ($file['error'] === UPLOAD_ERR_OK && $ext === 'pdf') {
        $safeName = dmd_safe_pdf_name((string)$file['name']);
        if (strtolower(pathinfo($safeName, PATHINFO_EXTENSION)) !== 'pdf') {
            $safeName .= '.pdf';
        }

        $target = $procedureDir . '/' . $safeName;
        if (is_file($target)) {
            $target = $procedureDir . '/' . pathinfo($safeName, PATHINFO_FILENAME) . '-' . date('Ymd-His') . '.pdf';
            $safeName = basename($target);
        }

        if (move_uploaded_file($file['tmp_name'], $target)) {
            $message = 'Procédure ajoutée avec succès.';
            $messageType = 'success';
        } else {
            $message = 'Erreur lors de l’enregistrement du fichier.';
            $messageType = 'error';
        }
    } else {
        $message = 'Erreur lors de l’envoi du fichier. PDF uniquement.';
        $messageType = 'error';
    }
}

$pdfs = [];
foreach (scandir($procedureDir) ?: [] as $file) {
    $fullPath = $procedureDir . '/' . $file;
    if (is_file($fullPath) && strtolower(pathinfo($file, PATHINFO_EXTENSION)) === 'pdf') {
        $pdfs[] = [
            'name' => $file,
            'encoded' => rawurlencode($file),
            'size' => dmd_format_size((int)filesize($fullPath)),
            'mtime' => filemtime($fullPath) ?: 0,
        ];
    }
}

usort($pdfs, static fn($a, $b) => $b['mtime'] <=> $a['mtime']);

$modulesFile = $userDir . '/modules.json';
$hasYoutubeModule = false;
if (is_file($modulesFile)) {
    $mods = json_decode((string)file_get_contents($modulesFile), true);
    if (is_array($mods)) {
        foreach ($mods as $m) {
            if (!empty($m['id']) && $m['id'] === 'youtube' && !empty($m['enabled'])) {
                $hasYoutubeModule = true;
                break;
            }
        }
    }
}

$remoteJson = 'https://raw.githubusercontent.com/synohomes/newsdomydesk/refs/heads/main/procedures_list.json';
$youtubePlaylistUrl = 'https://www.youtube.com/playlist?list=PLqtzZSNg-E8BiDME_SGllHBiOmtL7KIDM';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Procédures disponibles</title>
    <link rel="stylesheet" href="/domydesk/theme/<?= dmd_h($theme) ?>/style.css">
    <style>
        .procedures-page {
            width: min(1180px, calc(100% - 32px));
            margin: 24px auto;
        }

        .procedures-shell,
        .procedures-card,
        .procedures-modal {
            background: var(--card-bg, var(--panel-bg, var(--section-bg)));
            color: var(--text-color);
            border: 1px solid var(--border-color, rgba(255,255,255,.10));
            box-shadow: var(--shadow, 0 18px 50px rgba(0,0,0,.22));
        }

        .procedures-shell {
            border-radius: var(--radius-xl, 24px);
            padding: clamp(18px, 3vw, 32px);
        }

        .procedures-hero {
            display: grid;
            grid-template-columns: 1fr auto;
            gap: 18px;
            align-items: center;
            margin-bottom: 22px;
        }

        .procedures-kicker {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            width: fit-content;
            padding: 7px 11px;
            border-radius: var(--radius-pill, 999px);
            background: color-mix(in srgb, var(--primary-color) 14%, transparent);
            color: var(--primary-color);
            border: 1px solid color-mix(in srgb, var(--primary-color) 30%, transparent);
            font-weight: 700;
            font-size: .86rem;
            margin-bottom: 12px;
        }

        .procedures-title {
            margin: 0;
            color: var(--title-color, var(--primary-color));
            font-size: clamp(1.55rem, 3vw, 2.25rem);
            line-height: 1.1;
        }

        .procedures-subtitle {
            margin: 10px 0 0;
            color: var(--muted-color, var(--text-muted, var(--text-color)));
            max-width: 760px;
            line-height: 1.6;
        }

        .procedures-stats {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            justify-content: flex-end;
        }

        .procedures-stat {
            min-width: 122px;
            padding: 12px 14px;
            border-radius: var(--radius-lg, 18px);
            background: var(--section-bg, var(--panel-bg));
            border: 1px solid var(--border-color, rgba(255,255,255,.10));
            text-align: center;
        }

        .procedures-stat strong {
            display: block;
            color: var(--title-color, var(--primary-color));
            font-size: 1.25rem;
        }

        .procedures-stat span {
            color: var(--muted-color, var(--text-color));
            font-size: .84rem;
        }

        .procedures-toolbar {
            display: grid;
            grid-template-columns: minmax(220px, 1fr) auto;
            gap: 12px;
            align-items: center;
            margin: 20px 0;
        }

        .procedures-search {
            display: flex;
            align-items: center;
            gap: 10px;
            min-height: 44px;
            padding: 0 14px;
            border-radius: var(--radius-lg, 16px);
            background: var(--input-bg, var(--section-bg));
            border: 1px solid var(--border-color, rgba(255,255,255,.12));
        }

        .procedures-search input {
            width: 100%;
            border: 0;
            outline: 0;
            background: transparent;
            color: var(--text-color);
            font: inherit;
        }

        .procedures-search input::placeholder {
            color: var(--muted-color, var(--text-color));
            opacity: .75;
        }

        .procedures-actions,
        .procedures-card-actions,
        .procedures-modal-actions,
        .procedures-zoom {
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }

        .procedures-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            min-height: 40px;
            padding: 9px 13px;
            border-radius: var(--radius-md, 12px);
            border: 1px solid color-mix(in srgb, var(--primary-color) 52%, transparent);
            background: var(--primary-color);
            color: var(--button-text, #fff);
            font-weight: 750;
            text-decoration: none;
            cursor: pointer;
            line-height: 1;
            transition: transform .15s ease, background .15s ease, border-color .15s ease, opacity .15s ease;
        }

        .procedures-btn:hover {
            background: var(--primary-dark, var(--primary-color));
            transform: translateY(-1px);
            text-decoration: none;
        }

        .procedures-btn.secondary {
            background: color-mix(in srgb, var(--primary-color) 10%, transparent);
            color: var(--primary-color);
        }

        .procedures-btn.ghost {
            background: transparent;
            color: var(--text-color);
            border-color: var(--border-color, rgba(255,255,255,.14));
        }

        .procedures-btn.danger {
            background: color-mix(in srgb, var(--danger-color, #ff5c5c) 12%, transparent);
            color: var(--danger-color, #ff7b7b);
            border-color: color-mix(in srgb, var(--danger-color, #ff5c5c) 38%, transparent);
        }

        .procedures-alert {
            margin: 16px 0;
            padding: 12px 14px;
            border-radius: var(--radius-md, 14px);
            border: 1px solid var(--border-color, rgba(255,255,255,.14));
            background: var(--section-bg, var(--panel-bg));
            color: var(--text-color);
        }

        .procedures-alert.success {
            border-color: color-mix(in srgb, var(--success-color, #44d17a) 36%, transparent);
            background: color-mix(in srgb, var(--success-color, #44d17a) 12%, transparent);
        }

        .procedures-alert.error {
            border-color: color-mix(in srgb, var(--danger-color, #ff5c5c) 36%, transparent);
            background: color-mix(in srgb, var(--danger-color, #ff5c5c) 12%, transparent);
        }

        .procedures-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(245px, 1fr));
            gap: 12px;
        }

        .procedures-card {
            position: relative;
            border-radius: var(--radius-lg, 18px);
            padding: 15px;
            overflow: hidden;
        }

        .procedures-card::before {
            content: '';
            position: absolute;
            inset: 0 auto 0 0;
            width: 4px;
            background: var(--primary-color);
            opacity: .85;
        }

        .procedures-card-head {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            min-width: 0;
        }

        .procedures-icon {
            flex: 0 0 42px;
            width: 42px;
            height: 42px;
            border-radius: var(--radius-md, 14px);
            display: grid;
            place-items: center;
            background: color-mix(in srgb, var(--primary-color) 15%, transparent);
            color: var(--primary-color);
            border: 1px solid color-mix(in srgb, var(--primary-color) 32%, transparent);
            font-size: 1.25rem;
        }

        .procedures-card-title {
            margin: 1px 0 7px;
            color: var(--title-color, var(--text-color));
            font-weight: 800;
            line-height: 1.25;
            word-break: break-word;
        }

        .procedures-card-meta {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            color: var(--muted-color, var(--text-color));
            font-size: .84rem;
        }

        .procedures-pill {
            padding: 4px 8px;
            border-radius: var(--radius-pill, 999px);
            background: var(--section-bg, var(--panel-bg));
            border: 1px solid var(--border-color, rgba(255,255,255,.10));
        }

        .procedures-card-actions {
            justify-content: flex-end;
            margin-top: 14px;
        }

        .procedures-empty {
            padding: 28px 18px;
            text-align: center;
            border-radius: var(--radius-lg, 18px);
            background: var(--section-bg, var(--panel-bg));
            border: 1px dashed var(--border-color, rgba(255,255,255,.18));
            color: var(--muted-color, var(--text-color));
        }

        .procedures-upload {
            margin-top: 18px;
            padding: 16px;
            border-radius: var(--radius-lg, 18px);
            background: var(--section-bg, var(--panel-bg));
            border: 1px solid var(--border-color, rgba(255,255,255,.10));
        }

        .procedures-upload-title {
            margin: 0 0 10px;
            color: var(--title-color, var(--text-color));
            font-weight: 800;
        }

        .procedures-upload-row {
            display: grid;
            grid-template-columns: minmax(180px, 1fr) auto;
            gap: 10px;
            align-items: center;
        }

        .procedures-upload input[type="file"] {
            width: 100%;
            min-height: 42px;
            padding: 9px;
            border-radius: var(--radius-md, 12px);
            background: var(--input-bg, var(--card-bg));
            color: var(--text-color);
            border: 1px solid var(--border-color, rgba(255,255,255,.12));
        }

        .procedures-overlay {
            position: fixed;
            inset: 0;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 18px;
            background: rgba(0,0,0,.68);
            z-index: 9999;
        }

        .procedures-modal {
            width: min(1120px, 96vw);
            max-height: 92vh;
            border-radius: var(--radius-xl, 24px);
            padding: 16px;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        .procedures-modal-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 12px;
        }

        .procedures-modal-title {
            color: var(--title-color, var(--primary-color));
            font-weight: 900;
            font-size: 1.05rem;
        }

        .procedures-remote-list {
            overflow: auto;
            padding-right: 6px;
            display: grid;
            gap: 10px;
        }

        .procedures-remote-card {
            padding: 14px;
            border-radius: var(--radius-lg, 18px);
            background: var(--section-bg, var(--panel-bg));
            border: 1px solid var(--border-color, rgba(255,255,255,.10));
        }

        .procedures-remote-card h3 {
            margin: 0 0 6px;
            color: var(--title-color, var(--text-color));
            font-size: 1rem;
        }

        .procedures-remote-desc,
        .procedures-remote-meta {
            color: var(--muted-color, var(--text-color));
            line-height: 1.45;
            font-size: .92rem;
        }

        .procedures-remote-actions {
            display: flex;
            justify-content: flex-end;
            gap: 8px;
            margin-top: 10px;
        }

        .procedures-viewer-toolbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 10px;
            color: var(--muted-color, var(--text-color));
        }

        .procedures-zoom-indicator {
            min-width: 56px;
            text-align: center;
            font-weight: 800;
            color: var(--text-color);
        }

        .procedures-frame-wrap {
            flex: 1 1 auto;
            min-height: 560px;
            border-radius: var(--radius-lg, 18px);
            overflow: auto;
            background: var(--input-bg, var(--section-bg));
            border: 1px solid var(--border-color, rgba(255,255,255,.10));
        }

        .procedures-frame {
            width: 100%;
            height: 100%;
            min-height: 560px;
            border: 0;
            transform-origin: top left;
        }

        .procedures-hidden {
            display: none !important;
        }

        @media (max-width: 760px) {
            .procedures-page {
                width: min(100% - 18px, 1180px);
                margin: 12px auto;
            }

            .procedures-shell {
                padding: 14px;
                border-radius: var(--radius-lg, 18px);
            }

            .procedures-hero,
            .procedures-toolbar,
            .procedures-upload-row {
                grid-template-columns: 1fr;
            }

            .procedures-stats,
            .procedures-actions,
            .procedures-card-actions,
            .procedures-modal-actions {
                justify-content: stretch;
            }

            .procedures-btn {
                width: 100%;
            }

            .procedures-frame-wrap,
            .procedures-frame {
                min-height: 62vh;
            }
        }
    </style>
</head>
<body>
<?php include $baseDir . '/domydesk/header.php'; ?>

<main class="procedures-page">
    <section class="procedures-shell">
        <div class="procedures-hero">
            <div>
                <div class="procedures-kicker">📚 Centre de procédures</div>
                <h1 class="procedures-title">Procédures disponibles</h1>
                <p class="procedures-subtitle">
                    Consulte, recherche et ouvre rapidement les documents PDF disponibles. Les administrateurs peuvent aussi ajouter ou supprimer des procédures.
                </p>
            </div>
            <div class="procedures-stats" aria-label="Statistiques des procédures">
                <div class="procedures-stat">
                    <strong><?= count($pdfs) ?></strong>
                    <span>PDF local<?= count($pdfs) > 1 ? 's' : '' ?></span>
                </div>
                <div class="procedures-stat">
                    <strong><?= $isAdmin ? 'Admin' : 'Lecture' ?></strong>
                    <span>Mode actuel</span>
                </div>
            </div>
        </div>

        <div class="procedures-toolbar">
            <label class="procedures-search" for="procedureSearch">
                <span>🔎</span>
                <input id="procedureSearch" type="search" placeholder="Rechercher une procédure locale..." autocomplete="off">
            </label>
            <div class="procedures-actions">
                <button type="button" class="procedures-btn secondary" id="openListBtn">📄 Procédures GitHub</button>
                <button type="button" class="procedures-btn secondary" id="openYoutubeBtn">▶️ YouTube DoMyDesk</button>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="procedures-alert <?= dmd_h($messageType) ?>"><?= dmd_h($message) ?></div>
        <?php endif; ?>

        <?php if (!empty($pdfs)): ?>
            <div class="procedures-grid" id="localProceduresGrid">
                <?php foreach ($pdfs as $pdf): ?>
                    <article class="procedures-card" data-procedure-card data-name="<?= dmd_h(mb_strtolower($pdf['name'], 'UTF-8')) ?>">
                        <div class="procedures-card-head">
                            <div class="procedures-icon">PDF</div>
                            <div>
                                <div class="procedures-card-title"><?= dmd_h($pdf['name']) ?></div>
                                <div class="procedures-card-meta">
                                    <span class="procedures-pill"><?= dmd_h($pdf['size']) ?></span>
                                    <span class="procedures-pill">Mis à jour le <?= date('d/m/Y', (int)$pdf['mtime']) ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="procedures-card-actions">
                            <button type="button" class="procedures-btn" onclick="openLocalPdf('<?= dmd_h($pdf['encoded']) ?>','<?= dmd_h($pdf['name']) ?>')">Lire</button>
                            <a class="procedures-btn ghost" href="procedures/documents/<?= dmd_h($pdf['encoded']) ?>" download>Télécharger</a>
                            <?php if ($isAdmin): ?>
                                <form method="post" onsubmit="return confirmDelete(this);">
                                    <input type="hidden" name="delete_pdf" value="<?= dmd_h($pdf['name']) ?>">
                                    <button type="submit" class="procedures-btn danger">Supprimer</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
            <div class="procedures-empty procedures-hidden" id="noSearchResult">Aucune procédure ne correspond à cette recherche.</div>
        <?php else: ?>
            <div class="procedures-empty">Aucun fichier PDF local pour le moment.</div>
        <?php endif; ?>

        <?php if ($isAdmin): ?>
            <form class="procedures-upload" method="post" enctype="multipart/form-data">
                <p class="procedures-upload-title">Ajouter une procédure locale</p>
                <div class="procedures-upload-row">
                    <input type="file" name="procedure_pdf" accept="application/pdf" required>
                    <button type="submit" class="procedures-btn">Téléverser le PDF</button>
                </div>
            </form>
        <?php endif; ?>
    </section>
</main>

<div class="procedures-overlay" id="listOverlay" aria-hidden="true">
    <div class="procedures-modal" role="dialog" aria-modal="true" aria-labelledby="listTitle">
        <div class="procedures-modal-header">
            <div class="procedures-modal-title" id="listTitle">📄 Procédures DoMyDesk depuis GitHub</div>
            <div class="procedures-modal-actions">
                <button type="button" class="procedures-btn ghost" id="closeListBtn">Fermer</button>
            </div>
        </div>
        <div class="procedures-remote-list" id="listContainer">
            <div class="procedures-empty">Chargement…</div>
        </div>
    </div>
</div>

<div class="procedures-overlay" id="viewerOverlay" aria-hidden="true">
    <div class="procedures-modal" role="dialog" aria-modal="true" aria-labelledby="viewerTitle">
        <div class="procedures-modal-header">
            <div class="procedures-modal-title" id="viewerTitle">📄 Aperçu de la procédure</div>
            <div class="procedures-modal-actions">
                <a class="procedures-btn" id="downloadBtn" href="#" download>Télécharger</a>
                <button type="button" class="procedures-btn ghost" id="closeViewerBtn">Fermer</button>
            </div>
        </div>
        <div class="procedures-viewer-toolbar">
            <div class="procedures-zoom">
                <button type="button" class="procedures-btn secondary" id="zoomOutBtn">−</button>
                <span class="procedures-zoom-indicator" id="zoomIndicator">100%</span>
                <button type="button" class="procedures-btn secondary" id="zoomInBtn">+</button>
                <button type="button" class="procedures-btn ghost" id="zoomResetBtn">Reset</button>
            </div>
            <div id="viewerMeta"></div>
        </div>
        <div class="procedures-frame-wrap">
            <iframe id="pdfFrame" class="procedures-frame" src="" title="Lecteur PDF"></iframe>
        </div>
    </div>
</div>

<div class="procedures-overlay" id="ytOverlay" aria-hidden="true">
    <div class="procedures-modal" role="dialog" aria-modal="true" aria-labelledby="ytTitle">
        <div class="procedures-modal-header">
            <div class="procedures-modal-title" id="ytTitle">🎬 Page YouTube DoMyDesk</div>
            <div class="procedures-modal-actions">
                <a class="procedures-btn" id="ytOpenExternal" href="<?= dmd_h($youtubePlaylistUrl) ?>" target="_blank" rel="noopener">Ouvrir à part</a>
                <button type="button" class="procedures-btn ghost" id="closeYtBtn">Fermer</button>
            </div>
        </div>
        <div class="procedures-frame-wrap">
            <iframe
                id="ytFrame"
                class="procedures-frame"
                src=""
                title="YouTube DoMyDesk"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowfullscreen
                referrerpolicy="strict-origin-when-cross-origin"></iframe>
        </div>
    </div>
</div>

<script>
const viewerOverlay = document.getElementById('viewerOverlay');
const pdfFrame = document.getElementById('pdfFrame');
const downloadBtn = document.getElementById('downloadBtn');
const viewerMeta = document.getElementById('viewerMeta');
const zoomIndicator = document.getElementById('zoomIndicator');
let zoom = 1;

function escapeHtml(value) {
    return (value ?? '').toString().replace(/[&<>"']/g, char => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    }[char]));
}

function openLocalPdf(encodedName, humanName) {
    const url = 'procedures/documents/' + encodedName + '#toolbar=0&navpanes=0&view=FitH';
    openPdf(url, humanName, '');
}

function openPdf(url, name, date) {
    if (!url) return;
    zoom = 1;
    updateZoom();
    pdfFrame.src = url;
    downloadBtn.href = url.split('#')[0];
    viewerMeta.textContent = name + (date ? ' — ' + date : '');
    openOverlay(viewerOverlay);
}

function updateZoom() {
    pdfFrame.style.transform = `scale(${zoom})`;
    pdfFrame.style.width = `${100 / zoom}%`;
    pdfFrame.style.height = `${100 / zoom}%`;
    zoomIndicator.textContent = `${Math.round(zoom * 100)}%`;
}

function openOverlay(overlay) {
    overlay.style.display = 'flex';
    overlay.setAttribute('aria-hidden', 'false');
}

function closeOverlay(overlay) {
    overlay.style.display = 'none';
    overlay.setAttribute('aria-hidden', 'true');
}

function confirmDelete(form) {
    const file = form.querySelector('input[name="delete_pdf"]').value || 'cette procédure';
    return confirm('Supprimer définitivement "' + file + '" ?');
}

document.getElementById('zoomInBtn').addEventListener('click', () => {
    zoom = Math.min(2.2, zoom + 0.1);
    updateZoom();
});

document.getElementById('zoomOutBtn').addEventListener('click', () => {
    zoom = Math.max(0.6, zoom - 0.1);
    updateZoom();
});

document.getElementById('zoomResetBtn').addEventListener('click', () => {
    zoom = 1;
    updateZoom();
});

document.getElementById('closeViewerBtn').addEventListener('click', () => {
    closeOverlay(viewerOverlay);
    pdfFrame.src = '';
});

viewerOverlay.addEventListener('click', event => {
    if (event.target === viewerOverlay) {
        closeOverlay(viewerOverlay);
        pdfFrame.src = '';
    }
});

const ytOverlay = document.getElementById('ytOverlay');
const ytFrame = document.getElementById('ytFrame');
const ytEmbed = 'https://www.youtube.com/embed/videoseries?list=PLqtzZSNg-E8BiDME_SGllHBiOmtL7KIDM&autoplay=1&modestbranding=1&rel=0';

document.getElementById('openYoutubeBtn').addEventListener('click', () => {
    ytFrame.src = ytEmbed;
    openOverlay(ytOverlay);
});

document.getElementById('closeYtBtn').addEventListener('click', () => {
    closeOverlay(ytOverlay);
    ytFrame.src = '';
});

ytOverlay.addEventListener('click', event => {
    if (event.target === ytOverlay) {
        closeOverlay(ytOverlay);
        ytFrame.src = '';
    }
});

const remoteJson = <?= json_encode($remoteJson, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
const listOverlay = document.getElementById('listOverlay');
const listContainer = document.getElementById('listContainer');
let remoteLoaded = false;

document.getElementById('openListBtn').addEventListener('click', () => {
    openOverlay(listOverlay);
    if (!remoteLoaded) loadProcedures();
});

document.getElementById('closeListBtn').addEventListener('click', () => {
    closeOverlay(listOverlay);
});

listOverlay.addEventListener('click', event => {
    if (event.target === listOverlay) closeOverlay(listOverlay);
});

async function loadProcedures() {
    listContainer.innerHTML = '<div class="procedures-empty">Chargement…</div>';
    try {
        const response = await fetch(remoteJson, { cache: 'no-store' });
        if (!response.ok) throw new Error('Chargement impossible');
        const items = await response.json();
        renderRemoteList(Array.isArray(items) ? items : []);
        remoteLoaded = true;
    } catch (error) {
        listContainer.innerHTML = '<div class="procedures-empty">Impossible de charger la liste distante.</div>';
    }
}

function renderRemoteList(items) {
    if (!items.length) {
        listContainer.innerHTML = '<div class="procedures-empty">Aucune procédure distante.</div>';
        return;
    }

    items.sort((a, b) => String(b?.date || '').localeCompare(String(a?.date || '')));
    listContainer.innerHTML = items.map(item => {
        const name = escapeHtml(item.name || 'Procédure');
        const date = escapeHtml(item.date || '');
        const desc = escapeHtml(item.description || '');
        const url = (item.pdf || item.file || '').toString();
        const size = escapeHtml(item.size || '');
        const safeUrl = encodeURI(url);

        return `
            <article class="procedures-remote-card">
                <h3>${name}</h3>
                <div class="procedures-remote-meta">
                    ${date ? `📅 ${date}` : ''}${date && size ? ' · ' : ''}${size ? `🗂️ ${size}` : ''}
                </div>
                ${desc ? `<div class="procedures-remote-desc">${desc}</div>` : ''}
                <div class="procedures-remote-actions">
                    <button type="button" class="procedures-btn" onclick="openPdf('${safeUrl}','${name}','${date}')">Lire</button>
                    <a class="procedures-btn ghost" href="${safeUrl}" target="_blank" rel="noopener">Ouvrir</a>
                </div>
            </article>
        `;
    }).join('');
}

const procedureSearch = document.getElementById('procedureSearch');
const noSearchResult = document.getElementById('noSearchResult');
const localCards = Array.from(document.querySelectorAll('[data-procedure-card]'));

if (procedureSearch && localCards.length) {
    procedureSearch.addEventListener('input', () => {
        const query = procedureSearch.value.trim().toLowerCase();
        let visibleCount = 0;

        localCards.forEach(card => {
            const name = (card.dataset.name || '').toLowerCase();
            const visible = !query || name.includes(query);
            card.classList.toggle('procedures-hidden', !visible);
            if (visible) visibleCount++;
        });

        if (noSearchResult) {
            noSearchResult.classList.toggle('procedures-hidden', visibleCount !== 0);
        }
    });
}

document.addEventListener('keydown', event => {
    if (event.key !== 'Escape') return;
    closeOverlay(listOverlay);
    closeOverlay(viewerOverlay);
    closeOverlay(ytOverlay);
    pdfFrame.src = '';
    ytFrame.src = '';
});
</script>
</body>
</html>
