<?php
declare(strict_types=1);

$baseDir = realpath(__DIR__ . '/..') ?: dirname(__DIR__);
$baseDir = rtrim($baseDir, '/\\');

$dataDir  = $baseDir . '/data';
$syncFile = $dataDir . '/domyco_sync.php';
$lockFile = $dataDir . '/domyco_heartbeat.lock';
$logFile  = $dataDir . '/domyco_heartbeat.log';
$lastFile = $dataDir . '/domyco_heartbeat_last.json';

@mkdir($dataDir, 0775, true);

$isDirect = isset($_SERVER['SCRIPT_FILENAME'])
    && realpath((string)$_SERVER['SCRIPT_FILENAME']) === realpath(__FILE__);

$force = false;
if (PHP_SAPI === 'cli') {
    $force = in_array('--force', $argv ?? [], true);
} else {
    $force = isset($_GET['force']) && $_GET['force'] === '1';
}

function dmd_hb_finish(array $result, bool $direct, int $code = 200): void
{
    if ($direct) {
        if (!headers_sent()) {
            header('Content-Type: application/json; charset=utf-8');
            http_response_code($code);
        }

        echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    return;
}

/*
 * On bloque uniquement si une sync RÉUSSIE date de moins de 120 secondes.
 * Pas de verrou posé avant réussite.
 */
$lastSuccess = 0;

if (is_file($lockFile)) {
    $lastSuccess = (int)@file_get_contents($lockFile);
}

if (!$force && $lastSuccess > 0 && (time() - $lastSuccess) < 120) {
    dmd_hb_finish([
        'success' => true,
        'skipped' => true,
        'reason' => 'THROTTLED',
        'seconds_since_last_success' => time() - $lastSuccess,
        'next_allowed_in' => 120 - (time() - $lastSuccess),
    ], $isDirect);
}

if (!is_file($syncFile)) {
    $result = [
        'success' => false,
        'error' => 'SYNC_FILE_MISSING',
        'sync_file' => $syncFile,
    ];

    @file_put_contents($lastFile, json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    @file_put_contents($logFile, date('c') . " - ERROR sync file missing\n", FILE_APPEND);

    dmd_hb_finish($result, $isDirect, 500);
}

$beforeLevel = ob_get_level();

try {
    ob_start();
    require_once $syncFile;

    while (ob_get_level() > $beforeLevel) {
        ob_end_clean();
    }

    if (!function_exists('domyco_sync_register')) {
        $result = [
            'success' => false,
            'error' => 'SYNC_FUNCTION_MISSING',
        ];

        @file_put_contents($lastFile, json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        @file_put_contents($logFile, date('c') . " - ERROR function missing\n", FILE_APPEND);

        dmd_hb_finish($result, $isDirect, 500);
    }

    ob_start();
    $syncResult = domyco_sync_register($baseDir);

    while (ob_get_level() > $beforeLevel) {
        ob_end_clean();
    }

    $success = !empty($syncResult['success']);

    $result = [
        'success' => $success,
        'sent_at' => date('c'),
        'base_dir' => $baseDir,
        'http_code' => $syncResult['http_code'] ?? null,
        'curl_error' => $syncResult['curl_error'] ?? null,
        'sync_result' => $syncResult,
    ];

    /*
     * Verrou mis à jour uniquement si DomyCo Register a répondu OK.
     */
    if ($success) {
        @file_put_contents($lockFile, (string)time());
    }

    @file_put_contents($lastFile, json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    @file_put_contents(
        $logFile,
        date('c') . ' - success=' . ($success ? '1' : '0') . ' - http=' . ($result['http_code'] ?? '-') . PHP_EOL,
        FILE_APPEND
    );

    dmd_hb_finish($result, $isDirect, $success ? 200 : 500);

} catch (Throwable $e) {
    while (ob_get_level() > $beforeLevel) {
        ob_end_clean();
    }

    $result = [
        'success' => false,
        'error' => 'HEARTBEAT_EXCEPTION',
        'message' => $e->getMessage(),
    ];

    @file_put_contents($lastFile, json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    @file_put_contents($logFile, date('c') . ' - EXCEPTION ' . $e->getMessage() . PHP_EOL, FILE_APPEND);

    dmd_hb_finish($result, $isDirect, 500);
}