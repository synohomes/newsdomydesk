<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| DoMyDesk -> DomyCo Register heartbeat
|--------------------------------------------------------------------------
| Fichier : data/domyco_heartbeat.php
|
| Aucun chemin serveur en dur.
| Fonctionne en inclusion PHP, en appel navigateur, ou en CLI.
| Appelle data/domyco_sync.php avec verrou de 120 secondes.
|--------------------------------------------------------------------------
*/

$isDirect = (
    isset($_SERVER['SCRIPT_FILENAME'])
    && realpath((string)$_SERVER['SCRIPT_FILENAME']) === realpath(__FILE__)
);

if ($isDirect && !headers_sent()) {
    header('Content-Type: application/json; charset=utf-8');
}

function domyco_heartbeat_output(array $data, int $code = 200): void
{
    if (!headers_sent()) {
        http_response_code($code);
    }

    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$baseDir = realpath(__DIR__ . '/..') ?: dirname(__DIR__);
$baseDir = rtrim($baseDir, '/\\');

$dataDir  = $baseDir . '/data';
$lockFile = $dataDir . '/domyco_heartbeat.lock';
$logFile  = $dataDir . '/domyco_heartbeat.log';
$lastFile = $dataDir . '/domyco_heartbeat_last.json';
$syncFile = $dataDir . '/domyco_sync.php';

@mkdir($dataDir, 0775, true);

$force = false;

if (PHP_SAPI === 'cli') {
    $force = in_array('--force', $argv ?? [], true);
} else {
    $force = isset($_GET['force']) && (string)$_GET['force'] === '1';
}

$lastRun = is_file($lockFile) ? (int)@file_get_contents($lockFile) : 0;
$secondsSinceLastRun = $lastRun > 0 ? (time() - $lastRun) : null;

if (!$force && $lastRun > 0 && $secondsSinceLastRun !== null && $secondsSinceLastRun < 120) {
    $result = [
        'success' => true,
        'skipped' => true,
        'reason' => 'THROTTLED',
        'message' => 'Heartbeat ignoré : dernière sync trop récente.',
        'seconds_since_last_run' => $secondsSinceLastRun,
        'next_allowed_in' => 120 - $secondsSinceLastRun,
        'base_dir' => $baseDir,
        'sync_file' => $syncFile,
    ];

    @file_put_contents($lastFile, json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

    if ($isDirect) {
        domyco_heartbeat_output($result);
    }

    return;
}

if (!is_file($syncFile)) {
    $result = [
        'success' => false,
        'error' => 'SYNC_FILE_MISSING',
        'message' => 'Fichier data/domyco_sync.php introuvable.',
        'base_dir' => $baseDir,
        'sync_file' => $syncFile,
    ];

    @file_put_contents($lastFile, json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    @file_put_contents($logFile, date('c') . ' - ERROR sync_file_missing - ' . $syncFile . PHP_EOL, FILE_APPEND);

    if ($isDirect) {
        domyco_heartbeat_output($result, 500);
    }

    return;
}

$beforeLevel = ob_get_level();

try {
    ob_start();
    require_once $syncFile;

    while (ob_get_level() > $beforeLevel) {
        ob_end_clean();
    }

    if (!function_exists('domyco_sync_register')) {
        $result = [
            'success' => false,
            'error' => 'SYNC_FUNCTION_MISSING',
            'message' => 'La fonction domyco_sync_register() est introuvable.',
            'base_dir' => $baseDir,
            'sync_file' => $syncFile,
        ];

        @file_put_contents($lastFile, json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        @file_put_contents($logFile, date('c') . ' - ERROR function_missing' . PHP_EOL, FILE_APPEND);

        if ($isDirect) {
            domyco_heartbeat_output($result, 500);
        }

        return;
    }

    ob_start();
    $syncResult = domyco_sync_register($baseDir);

    while (ob_get_level() > $beforeLevel) {
        ob_end_clean();
    }

    $success = !empty($syncResult['success']);

    $result = [
        'success' => $success,
        'skipped' => false,
        'message' => $success ? 'Heartbeat DomyCo envoyé.' : 'Heartbeat lancé, mais sync DomyCo échouée.',
        'base_dir' => $baseDir,
        'sync_file' => $syncFile,
        'http_code' => $syncResult['http_code'] ?? null,
        'curl_error' => $syncResult['curl_error'] ?? null,
        'sent_at' => date('c'),
        'sync_result' => $syncResult,
    ];

    /*
     * On met à jour le verrou seulement après tentative réelle.
     */
    @file_put_contents($lockFile, (string)time());

    @file_put_contents($lastFile, json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

    @file_put_contents(
        $logFile,
        date('c') .
        ' - success=' . ($success ? '1' : '0') .
        ' - http=' . ($syncResult['http_code'] ?? '-') .
        ' - curl=' . ($syncResult['curl_error'] ?? '-') .
        PHP_EOL,
        FILE_APPEND
    );

    if ($isDirect) {
        domyco_heartbeat_output($result, $success ? 200 : 500);
    }

    return;

} catch (Throwable $e) {
    while (ob_get_level() > $beforeLevel) {
        ob_end_clean();
    }

    $result = [
        'success' => false,
        'error' => 'HEARTBEAT_EXCEPTION',
        'message' => $e->getMessage(),
        'base_dir' => $baseDir,
        'sync_file' => $syncFile,
        'sent_at' => date('c'),
    ];

    @file_put_contents($lastFile, json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    @file_put_contents($logFile, date('c') . ' - EXCEPTION - ' . $e->getMessage() . PHP_EOL, FILE_APPEND);

    if ($isDirect) {
        domyco_heartbeat_output($result, 500);
    }

    return;
}