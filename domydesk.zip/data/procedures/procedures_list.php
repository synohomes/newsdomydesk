<?php
session_start();
$userEmail = $_SESSION['user']['email'] ?? '';
$isAdmin = isset($_SESSION['user']['role_system']) && $_SESSION['user']['role_system'] === 'admin';
if (!$userEmail) die("Accès refusé");
$userDir = __DIR__ . "/../../users/profiles/" . $userEmail . "/";
$theme = "default";
$themePath = $userDir . "theme.json";
if (file_exists($themePath)) {
    $themeData = json_decode(file_get_contents($themePath), true);
    if (!empty($themeData['theme'])) {
        $theme = basename($themeData['theme']);
    }
}
$procedureDir = __DIR__ . "/documents";
$pdfs = [];
if (!is_dir($procedureDir)) mkdir($procedureDir, 0755, true);
$message = '';
if ($isAdmin && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_pdf'])) {
    $toDelete = basename($_POST['delete_pdf']); // anti-traversée
    $targetDel = $procedureDir . '/' . $toDelete;
    if (is_file($targetDel) && strtolower(pathinfo($targetDel, PATHINFO_EXTENSION)) === 'pdf') {
        if (@unlink($targetDel)) {
            $message = "Fichier supprimé : " . htmlspecialchars($toDelete);
        } else {
            $message = "Impossible de supprimer le fichier.";
        }
    } else {
        $message = "Fichier introuvable.";
    }
}
if ($isAdmin && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['procedure_pdf'])) {
    $file = $_FILES['procedure_pdf'];
    if ($file['error'] === UPLOAD_ERR_OK && strtolower(pathinfo($file['name'], PATHINFO_EXTENSION)) === 'pdf') {
        $safeName = basename($file['name']);
        $target = $procedureDir . '/' . $safeName;
        if (move_uploaded_file($file['tmp_name'], $target)) {
            $message = "Fichier ajouté avec succès.";
        } else {
            $message = "Erreur lors de l'enregistrement du fichier.";
        }
    } else {
        $message = "Erreur lors de l'envoi du fichier (PDF uniquement).";
    }
}
foreach (scandir($procedureDir) as $file) {
    if (is_file($procedureDir . "/" . $file) && strtolower(pathinfo($file, PATHINFO_EXTENSION)) === 'pdf') {
        $pdfs[] = $file;
    }
    $modulesFile = $userDir . "modules.json";
    $hasYoutubeModule = false;
    if (file_exists($modulesFile)) {
        $mods = json_decode(file_get_contents($modulesFile), true);
        if (is_array($mods)) {
            foreach ($mods as $m) {
                if (!empty($m['id']) && $m['id']==='youtube' && !empty($m['enabled'])) {
                    $hasYoutubeModule = true;
                    break;
                }
            }
        }
    }
    $YOUTUBE_DEFAULT_URL = "https://www.youtube.com/@DoMyDesk";
}
$REMOTE_JSON = "https://raw.githubusercontent.com/synohomes/newsdomydesk/refs/heads/main/procedures_list.json";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Procédures disponibles</title>
    <link rel="stylesheet" href="/domydesk/theme/<?= htmlspecialchars($theme) ?>/style.css">
    <style>
        .section h1 {
            font-size: 1.6em;
            text-align: center;
            margin-bottom: 30px;
            color: var(--primary-color, #327fa6);
        }

        .pdf-list { list-style: none; padding: 0; margin: 0; }
        .pdf-list li {
            padding: 10px 15px;
            margin-bottom: 10px;
            background: #0f1b2a; 
            border: 1px solid rgba(255,255,255,.06);
            border-radius: 10px;
            display: flex; align-items: center; gap: 10px; justify-content: space-between;
        }
        .pdf-left { display:flex; align-items:center; gap:10px; min-width:0; color:#e9f1f8; }
        .pdf-name { font-weight:700; word-break: break-all; }

        .pdf-actions { display:flex; gap:8px; align-items:center; flex-wrap:wrap; }
        .btn {
            background: var(--primary-color, #327fa6);
            color: #fff; border:none; padding: 7px 12px; border-radius: 10px; cursor:pointer; font-weight:700;
        }
        .btn:hover { background: var(--primary-dark, #1a5c8d); }
        .btn.outline { background: transparent; color: var(--primary-color, #327fa6); border:1px solid var(--primary-color, #327fa6); }
        .btn.danger { background: transparent; color:#ff6b6b; border:1px solid rgba(255,107,107,.4); }
        .btn.danger:hover { background: rgba(255,107,107,.08); }

        .message { padding: 12px; background: #d1e7dd; color: #155724; border-radius: 6px; margin-bottom: 20px; text-align: center; }

        form.upload-form { margin-top: 30px; text-align: center; }
        form.upload-form label { font-weight: bold; color:#e9f1f8; }
        form.upload-form input[type="file"] { margin: 10px auto; padding: 8px; }
        form.upload-form button { composes: btn; }

        .no-pdf { background: rgba(255,228,225,.08); color: #ffc3c3; padding: 12px; border-radius: 6px; text-align: center; border:1px solid rgba(255,228,225,.2); }

        .proc-cta-wrap{ display:flex; justify-content:center; margin:-10px 0 16px; }
        .proc-cta{
            display:inline-flex; align-items:center; gap:8px;
            background:var(--primary-color, #327fa6); color:#fff; border:none;
            padding:10px 16px; border-radius:10px; font-weight:700; cursor:pointer;
            box-shadow:0 2px 10px rgba(0,0,0,.2);
        }
        .proc-cta:hover{ background:var(--primary-dark, #1a5c8d); }

        .overlay{ position:fixed; inset:0; background:rgba(0,0,0,.65); display:none; align-items:center; justify-content:center; z-index:9999; }
        .modal{
            width:min(1100px, 96vw); max-height:90vh; background:var(--card-bg, #0e2235);
            border-radius:16px; box-shadow:0 10px 30px rgba(0,0,0,.4); padding:16px; overflow:auto; color:#e9f1f8;
        }
        .modal-header{ display:flex; align-items:center; justify-content:space-between; gap:10px; margin-bottom:10px; }
        .modal-title{ font-size:1.1rem; font-weight:800; color:var(--primary-color, #327fa6); }
        .modal-actions{ display:flex; align-items:center; gap:8px; }
        .mbtn{ background:var(--primary-color, #327fa6); color:#fff; border:none; border-radius:10px; padding:7px 11px; cursor:pointer; font-weight:700; }
        .mbtn:hover{ background:var(--primary-dark, #1a5c8d); }
        .mbtn.secondary{ background:transparent; color:var(--primary-color, #327fa6); border:1px solid var(--primary-color, #327fa6); }

        .proc-list{ display:grid; grid-template-columns:1fr; gap:10px; }
        .proc-item{ background:rgba(255,255,255,.06); border:1px solid rgba(255,255,255,.12); border-radius:12px; padding:12px; }
        .proc-item h3{ margin:0 0 6px; font-size:1rem; color:#fff; }
        .proc-meta{ font-size:.86rem; opacity:.9; margin-bottom:6px; }
        .proc-desc{ font-size:.92rem; opacity:.95; margin-bottom:10px; }
        .proc-actions{ display:flex; gap:8px; flex-wrap:wrap; }

        .viewer-toolbar{ display:flex; align-items:center; justify-content:space-between; gap:8px; margin:6px 0 10px; }
        .zoom-group{ display:flex; gap:6px; align-items:center; }
        .zoom-indicator{ font-weight:700; min-width:54px; text-align:center; color:#fff; }

        .viewer-frame-wrap{
            background:#fff; border-radius:10px; overflow:hidden; height:min(76vh, 900px);
            border:1px solid rgba(0,0,0,.15);
        }
        .viewer-frame{ width:100%; height:100%; border:0; transform-origin: top left; }

        #listOverlay .modal{ display:flex; flex-direction:column; }
        #listContainer{ flex:1 1 auto; min-height:0; max-height:70vh; overflow-y:auto; padding-right:8px; }

        #ytFrame{ width:100%; height:100%; border:0; }
    </style>
</head>
<body>
<?php include __DIR__ . '/../../header.php'; ?>
<div class="container">
    <div class="section">
        <h1>📚 Procédures disponibles</h1>
        <div class="proc-cta-wrap">
            <button class="proc-cta" id="openListBtn">📄 Voir les procédures DoMyDesk (GitHub)</button>
        </div>
        <div class="proc-cta-wrap">
            <button class="proc-cta" id="openYoutubeBtn">▶️ Page YouTube DoMyDesk</button>
        </div>
        <?php if ($message): ?>
            <div class="message"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        <?php if (!empty($pdfs)): ?>
            <ul class="pdf-list">
                <?php foreach ($pdfs as $pdf): ?>
                    <li>
                        <div class="pdf-left">
                            📄 <span class="pdf-name"><?= htmlspecialchars($pdf) ?></span>
                        </div>
                        <div class="pdf-actions">
                            <button class="btn" onclick="openLocalPdf('<?= rawurlencode($pdf) ?>','<?= htmlspecialchars($pdf, ENT_QUOTES) ?>')">Lire</button>
                            <?php if ($isAdmin): ?>
                            <form method="post" class="del-form" onsubmit="return confirmDelete(this);">
                                <input type="hidden" name="delete_pdf" value="<?= htmlspecialchars($pdf) ?>">
                                <button type="submit" class="btn danger" title="Supprimer ce PDF">🗑️ Supprimer</button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <div class="no-pdf">Aucun fichier PDF trouvé.</div>
        <?php endif; ?>
        <?php if ($isAdmin): ?>
            <form class="upload-form" method="POST" enctype="multipart/form-data">
                <label for="procedure_pdf">Ajouter une nouvelle procédure (PDF) :</label><br>
                <input type="file" name="procedure_pdf" accept="application/pdf" required>
                <br><br>
                <button type="submit" class="btn">Téléverser</button>
            </form>
        <?php endif; ?>
    </div>
</div>
<div class="overlay" id="listOverlay" aria-hidden="true">
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="listTitle">
    <div class="modal-header">
      <div class="modal-title" id="listTitle">📄 Procédures DoMyDesk (depuis GitHub)</div>
      <div class="modal-actions">
        <button class="mbtn secondary" id="closeListBtn">Fermer</button>
      </div>
    </div>
    <div id="listContainer"><div class="no-proc-remote">Chargement…</div></div>
  </div>
</div>
<div class="overlay" id="viewerOverlay" aria-hidden="true">
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="viewerTitle">
    <div class="modal-header">
      <div class="modal-title" id="viewerTitle">📄 Aperçu de la procédure</div>
      <div class="modal-actions">
        <a class="mbtn" id="downloadBtn" href="#" download>Télécharger</a>
        <button class="mbtn secondary" id="closeViewerBtn">Fermer</button>
      </div>
    </div>
    <div class="viewer-toolbar">
      <div class="zoom-group">
        <button class="mbtn" id="zoomOutBtn">−</button>
        <div class="zoom-indicator" id="zoomIndicator">100%</div>
        <button class="mbtn" id="zoomInBtn">+</button>
        <button class="mbtn secondary" id="zoomResetBtn">100%</button>
      </div>
      <div style="opacity:.85;font-size:.9rem;color:#fff" id="viewerMeta"></div>
    </div>
    <div class="viewer-frame-wrap">
      <iframe id="pdfFrame" class="viewer-frame" src=""></iframe>
    </div>
  </div>
</div>
<div class="overlay" id="ytOverlay" aria-hidden="true" style="display:none;">
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="ytTitle">
    <div class="modal-header">
      <div class="modal-title" id="ytTitle">🎬 Page YouTube DoMyDesk</div>
      <div class="modal-actions">
        <a class="mbtn" id="ytOpenExternal" href="https://www.youtube.com/playlist?list=PLqtzZSNg-E8BiDME_SGllHBiOmtL7KIDM" target="_blank" rel="noopener">Nouvelle fenêtre hors de DoMyDesk</a>
        <button class="mbtn secondary" id="closeYtBtn">Fermer</button>
      </div>
    </div>
    <div class="viewer-frame-wrap" style="background:#000;">
      <iframe
        id="ytFrame"
        src=""
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowfullscreen
        referrerpolicy="strict-origin-when-cross-origin"
      ></iframe>
    </div>
  </div>
</div>
<script>
const viewerOverlay = document.getElementById('viewerOverlay');
const pdfFrame = document.getElementById('pdfFrame');
const downloadBtn = document.getElementById('downloadBtn');
const viewerMeta = document.getElementById('viewerMeta');
const zoomIndicator = document.getElementById('zoomIndicator');
let zoom = 1;
function openLocalPdf(encodedName, humanName){
  const url = 'documents/' + encodedName + '#toolbar=0&navpanes=0&view=FitH';
  openPdf(url, humanName, '');
}
function openPdf(url, name, date){
  zoom = 1; updateZoom();
  pdfFrame.src = url;
  downloadBtn.href = url.split('#')[0]; 
  viewerMeta.textContent = name + (date ? (' — ' + date) : '');
  viewerOverlay.style.display = 'flex';
}
function updateZoom(){
  pdfFrame.style.transform = `scale(${zoom})`;
  zoomIndicator.textContent = `${Math.round(zoom*100)}%`;
}
document.getElementById('zoomInBtn').addEventListener('click', ()=>{ zoom = Math.min(3, zoom + 0.1); updateZoom(); });
document.getElementById('zoomOutBtn').addEventListener('click', ()=>{ zoom = Math.max(0.5, zoom - 0.1); updateZoom(); });
document.getElementById('zoomResetBtn').addEventListener('click', ()=>{ zoom = 1; updateZoom(); });
document.getElementById('closeViewerBtn').addEventListener('click', ()=>{
  viewerOverlay.style.display = 'none';
  pdfFrame.src = '';
});
viewerOverlay.addEventListener('click', (e)=>{
  if (e.target === viewerOverlay) {
    viewerOverlay.style.display = 'none';
    pdfFrame.src = '';
  }
});
document.addEventListener('keydown', (e)=>{
  if (e.key === 'Escape') {
    viewerOverlay.style.display = 'none';
    pdfFrame.src = '';
  }
});
function confirmDelete(form){
  const file = form.querySelector('input[name="delete_pdf"]').value || 'ce fichier';
  return confirm('Supprimer définitivement "' + file + '" ?');
}
const ytOverlay = document.getElementById('ytOverlay');
const ytFrame   = document.getElementById('ytFrame');
const openYoutubeBtn = document.getElementById('openYoutubeBtn');
const closeYtBtn = document.getElementById('closeYtBtn');
const YT_EMBED = 'https://www.youtube.com/embed/videoseries?list=PLqtzZSNg-E8BiDME_SGllHBiOmtL7KIDM&autoplay=1&modestbranding=1&rel=0';
openYoutubeBtn.addEventListener('click', ()=>{
  ytFrame.src = YT_EMBED;
  ytOverlay.style.display = 'flex';
});
closeYtBtn.addEventListener('click', ()=>{
  ytOverlay.style.display = 'none';
  ytFrame.src = '';
});
ytOverlay.addEventListener('click', (e)=>{
  if (e.target === ytOverlay) {
    ytOverlay.style.display = 'none';
    ytFrame.src = '';
  }
});
document.addEventListener('keydown', (e)=>{
  if (e.key === 'Escape') {
    ytOverlay.style.display = 'none';
    ytFrame.src = '';
  }
});
const REMOTE_JSON = <?= json_encode($REMOTE_JSON) ?>;
const $ = s=>document.querySelector(s);
const listOverlay=$('#listOverlay');
const listContainer=$('#listContainer');
$('#openListBtn').addEventListener('click', ()=>{ listOverlay.style.display='flex'; loadProcedures(); });
$('#closeListBtn').addEventListener('click', ()=>{ listOverlay.style.display='none'; });
listOverlay.addEventListener('click', e=>{
  if(e.target===listOverlay){ listOverlay.style.display='none'; }
});
document.addEventListener('keydown', e=>{
  if(e.key==='Escape'){ listOverlay.style.display='none'; }
});
async function loadProcedures(){
  listContainer.innerHTML = '<div class="no-proc-remote">Chargement…</div>';
  try{
    const r = await fetch(REMOTE_JSON, {cache:'no-store'});
    if(!r.ok) throw new Error('fetch failed');
    const items = await r.json();
    renderList(Array.isArray(items)?items:[]);
  }catch(_){
    listContainer.innerHTML = '<div class="no-proc-remote">Impossible de charger la liste distante.</div>';
  }
}
function escapeHtml(s){ return (s??'').toString().replace(/[&<>"']/g, c=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c])); }
function renderList(items){
  if(!items.length){
    listContainer.innerHTML = '<div class="no-proc-remote">Aucune procédure distante.</div>';
    return;
  }
  items.sort((a,b)=> String(b?.date||'').localeCompare(String(a?.date||'')));
  listContainer.innerHTML = `
    <div class="proc-list">
      ${items.map(it=>{
        const name = escapeHtml(it.name||'Procédure');
        const date = escapeHtml(it.date||'');
        const desc = escapeHtml(it.description||'');
        const url  = (it.pdf||it.file||'').toString();
        const size = escapeHtml(it.size||'');
        // bouton LIRE ouvre la même popup interne
        return `
          <div class="proc-item">
            <h3>${name}</h3>
            <div class="proc-meta">
              ${date?`📅 ${date}`:''} ${size?` &nbsp;•&nbsp; 🗂️ ${size}`:''}
            </div>
            ${desc?`<div class="proc-desc">${desc}</div>`:''}
            <div class="proc-actions">
              <button class="mbtn" onclick="openPdf('${encodeURI(url)}','${name}','${date}')">Lire</button>
            </div>
          </div>
        `;
      }).join('')}
    </div>
  `;
}
</script>
</body>
</html>
