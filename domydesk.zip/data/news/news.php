<?php
header('Content-Type: application/json');

// Chemin config
$cfgPath = __DIR__ . '/newsconfig.json';
$mode = 'github';

if (file_exists($cfgPath)) {
    $cfg = json_decode(file_get_contents($cfgPath), true);
    if (!empty($cfg['mode'])) $mode = $cfg['mode'];
}

$newsList = [];

// ------------------------------
// 🔗 MODE GITHUB
// ------------------------------
if ($mode === 'github') {
    $githubUrl = 'https://raw.githubusercontent.com/synohomes/newsdomydesk/main/news.json';
    $context = stream_context_create([
        'http' => [
            'timeout' => 3,
            'header'  => "User-Agent: DoMyDeskNewsFetcher\r\n"
        ]
    ]);

    $json = @file_get_contents($githubUrl, false, $context);

    if ($json === false) {
        echo json_encode(["error" => "Chargement GitHub échoué"]);
        exit;
    }

    $data = json_decode($json, true);
    if (!is_array($data)) {
        echo json_encode(["error" => "Erreur de décodage JSON GitHub"]);
        exit;
    }

    foreach ($data as $item) {
        $item['auteur'] = (isset($item['titre']) && stripos($item['titre'], 'DoMyDesk') !== false) ? 'DoMyDesk' : '';
        $newsList[] = $item;
    }

    echo json_encode($newsList, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

// ------------------------------
// 📁 MODE LOCAL
// ------------------------------
$files = glob(__DIR__ . '/add/*/*/news*.json');
foreach ($files as $file) {
    $data = json_decode(file_get_contents($file), true);
    if (is_array($data) && isset($data['title'])) {
        $newsList[] = [
            'titre' => $data['title'],
            'soustitre' => $data['subtitle'] ?? '',
            'date' => $data['date'] ?? '',
            'auteur' => $data['author'] ?? '',
            'description' => strip_tags($data['content'] ?? '')
        ];
    }
}

usort($newsList, fn($a, $b) => strtotime($b['date']) - strtotime($a['date']));
echo json_encode($newsList, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
