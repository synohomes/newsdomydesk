<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| DoMyDesk -> DomyCo Register Sync
| Fichier : /volume1/web/data/domyco_sync.php
|--------------------------------------------------------------------------
| Rôle :
| - Relire l'état actuel de DoMyDesk
| - Relire modules/list.json
| - Renvoyer la déclaration complète vers :
|   https://register.synohomes.com/register.php
|--------------------------------------------------------------------------
| Utilisation :
| - Direct navigateur :
|   http://IP_DUDOMYDESK/data/domyco_sync.php
|
| - Depuis un autre fichier PHP :
|   require_once __DIR__ . '/data/domyco_sync.php';
|   domyco_sync_register();
|--------------------------------------------------------------------------
*/

if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    header('Content-Type: application/json; charset=utf-8');
}

function domyco_sync_response(array $data, int $httpCode = 200): void
{
    if (PHP_SAPI !== 'cli' && !headers_sent()) {
        http_response_code($httpCode);
    }

    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function domyco_sync_clean(?string $value): string
{
    return trim((string)$value);
}

function domyco_sync_read_json(string $file): array
{
    if (!file_exists($file)) {
        return [];
    }

    $content = file_get_contents($file);

    if ($content === false || trim($content) === '') {
        return [];
    }

    $json = json_decode($content, true);

    return is_array($json) ? $json : [];
}

function domyco_sync_find_admin_profile(string $rootDir): array
{
    $profilesDir = $rootDir . '/users/profiles';

    if (!is_dir($profilesDir)) {
        return [];
    }

    $dirs = scandir($profilesDir);

    if (!is_array($dirs)) {
        return [];
    }

    $firstProfile = [];

    foreach ($dirs as $dir) {
        if ($dir === '.' || $dir === '..') {
            continue;
        }

        $profileFile = $profilesDir . '/' . $dir . '/profile.json';

        if (!file_exists($profileFile)) {
            continue;
        }

        $profile = domyco_sync_read_json($profileFile);

        if (!$profile) {
            continue;
        }

        if (!$firstProfile) {
            $firstProfile = $profile;
        }

        $role = strtolower((string)($profile['role_system'] ?? ''));

        if ($role === 'admin') {
            return $profile;
        }
    }

    return $firstProfile;
}

function domyco_sync_get_modules(string $rootDir): array
{
    $modules = [];
    $modulesFile = $rootDir . '/modules/list.json';

    if (!file_exists($modulesFile)) {
        return [];
    }

    $modulesJson = domyco_sync_read_json($modulesFile);

    if (!$modulesJson) {
        return [];
    }

    foreach ($modulesJson as $module) {
        if (!is_array($module)) {
            continue;
        }

        $id = domyco_sync_clean($module['id'] ?? '');

        if ($id === '') {
            continue;
        }

        $modules[] = [
            'id'      => $id,
            'name'    => domyco_sync_clean($module['name'] ?? $id),
            'enabled' => isset($module['enabled']) ? (bool)$module['enabled'] : false
        ];
    }

    return $modules;
}

function domyco_sync_get_install_url(string $rootDir): array
{
    $host = $_SERVER['HTTP_HOST'] ?? '';
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    $scheme = $https ? 'https' : 'http';

    $scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
    $basePath = '';

    if ($scriptName !== '') {
        $basePath = str_replace('\\', '/', dirname(dirname($scriptName)));
        $basePath = rtrim($basePath, '/');

        if ($basePath === '') {
            $basePath = '';
        }
    }

    if ($host === '') {
        $host = gethostname() ?: '';
    }

    return [
        'domain' => $host,
        'install_url' => $host !== '' ? $scheme . '://' . $host . $basePath : ''
    ];
}

function domyco_sync_register(?string $rootDir = null): array
{
    $rootDir = $rootDir ?: dirname(__DIR__);
    $rootDir = rtrim($rootDir, '/');

    $endpoint = 'https://register.synohomes.com/register.php';

    $idFile = $rootDir . '/data/id_domydesk.txt';

    if (!file_exists($idFile)) {
        return [
            'success' => false,
            'error' => 'MISSING_INSTANCE_ID',
            'message' => 'Fichier data/id_domydesk.txt introuvable.',
            'root_dir' => $rootDir
        ];
    }

    $instanceUid = trim((string)file_get_contents($idFile));

    if ($instanceUid === '') {
        return [
            'success' => false,
            'error' => 'EMPTY_INSTANCE_ID',
            'message' => 'ID DoMyDesk vide dans data/id_domydesk.txt.',
            'root_dir' => $rootDir
        ];
    }

    $profile = domyco_sync_find_admin_profile($rootDir);
    $modules = domyco_sync_get_modules($rootDir);
    $urlInfo = domyco_sync_get_install_url($rootDir);

    $adminEmail = domyco_sync_clean($profile['email'] ?? '');
    $adminPrenom = domyco_sync_clean($profile['prenom'] ?? '');
    $adminNom = domyco_sync_clean($profile['nom'] ?? '');

    $payload = [
        'product_type'  => 'domydesk',
        'instance_uid'  => $instanceUid,
        'instance_name' => 'DoMyDesk',
        'admin_email'   => $adminEmail,
        'admin_prenom'  => $adminPrenom,
        'admin_nom'     => $adminNom,
        'domain'        => $urlInfo['domain'],
        'install_url'   => $urlInfo['install_url'],
        'version'       => '1.0.0',
        'modules'       => $modules,
        'services'      => [],
        'created_at'    => date('c')
    ];

    $ch = curl_init($endpoint);

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'User-Agent: DoMyDesk-DomyCo-Sync'
        ],
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT        => 10,
    ]);

    $response = curl_exec($ch);
    $curlError = curl_error($ch);
    $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);

    curl_close($ch);

    $logDir = $rootDir . '/data';

    if (!is_dir($logDir)) {
        @mkdir($logDir, 0775, true);
    }

$responseJson = json_decode((string)$response, true);

$responseSuccess = is_array($responseJson)
    && isset($responseJson['success'])
    && $responseJson['success'] === true;

$result = [
    'success' => ($curlError === '' && $httpCode >= 200 && $httpCode < 300 && $responseSuccess),
    'sent_at' => date('c'),
    'endpoint' => $endpoint,
    'http_code' => $httpCode,
    'curl_error' => $curlError,
    'response' => $response,
    'response_json' => $responseJson,
    'payload' => $payload
];

    @file_put_contents(
        $logDir . '/domyco_sync_last.json',
        json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
    );

    @file_put_contents(
        $logDir . '/domyco_sync.log',
        date('c') .
        ' - HTTP ' . $httpCode .
        ' - error: ' . $curlError .
        ' - instance: ' . $instanceUid .
        ' - modules: ' . count($modules) .
        PHP_EOL,
        FILE_APPEND
    );

    return $result;
}

if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    $result = domyco_sync_register(dirname(__DIR__));

    domyco_sync_response($result, $result['success'] ? 200 : 500);
}