<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['user'])) {
    header('Location: dashboard.php');
    exit;
}

$profilesDir = __DIR__ . '/users/profiles/';
$message = '';

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function setPermissions($path) {
    if (!file_exists($path)) {
        return;
    }

    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($path, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );

    foreach ($iterator as $item) {
        if ($item->isDir()) {
            @chmod($item, 0755);
        } else {
            @chmod($item, 0644);
        }
    }

    is_dir($path) ? @chmod($path, 0755) : @chmod($path, 0644);
}

function normalizeRolesMetier($rawRoles) {
    $roles = [];

    if (!is_array($rawRoles)) {
        return $roles;
    }

    foreach ($rawRoles as $key => $value) {
        if (is_string($value)) {
            $roles[] = $value;
        } elseif (is_array($value)) {
            if (!empty($value['name'])) {
                $roles[] = $value['name'];
            } elseif (!empty($value['label'])) {
                $roles[] = $value['label'];
            } elseif (!empty($value['value'])) {
                $roles[] = $value['value'];
            } elseif (is_string($key)) {
                $roles[] = $key;
            }
        } elseif (is_string($key)) {
            $roles[] = $key;
        }
    }

    $roles = array_values(array_unique(array_filter($roles)));
    sort($roles, SORT_NATURAL | SORT_FLAG_CASE);

    return $roles;
}

$metiers = [];
$rolesFile = __DIR__ . '/data/roles_metier.json';

if (is_file($rolesFile)) {
    $decoded = json_decode(file_get_contents($rolesFile), true);
    $metiers = normalizeRolesMetier($decoded);
}

$defaultRoleSystem = 'user';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prenom      = trim($_POST['prenom'] ?? '');
    $nom         = trim($_POST['nom'] ?? '');
    $email       = trim($_POST['email'] ?? '');
    $role_metier = trim($_POST['role_metier'] ?? '');
    $password    = $_POST['password'] ?? '';

    if ($prenom === '' || $nom === '' || $email === '' || $role_metier === '' || $password === '') {
        $message = 'Tous les champs sont obligatoires.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Email invalide.';
    } elseif (!empty($metiers) && !in_array($role_metier, $metiers, true)) {
        $message = 'Rôle métier invalide.';
    } elseif (strlen($password) < 8) {
        $message = 'Le mot de passe doit contenir au moins 8 caractères.';
    } else {
        $userFolder = $profilesDir . $email . '/';

        if (is_dir($userFolder)) {
            $message = 'Un utilisateur avec cet email existe déjà.';
        } else {
            if (!mkdir($userFolder, 0755, true)) {
                $message = 'Erreur lors de la création du dossier utilisateur.';
            } else {
                $passwordHash = password_hash($password, PASSWORD_DEFAULT);

                $profileData = [
                    'prenom'       => $prenom,
                    'nom'          => $nom,
                    'email'        => $email,
                    'role_system'  => $defaultRoleSystem,
                    'role_metier'  => $role_metier,
                    'created_at'   => date('Y-m-d H:i:s'),
                    'motdepasse'   => $passwordHash,
                    'password'     => $passwordHash
                ];

                file_put_contents(
                    $userFolder . 'profile.json',
                    json_encode($profileData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                );

                file_put_contents(
                    $userFolder . 'dashboard.json',
                    json_encode([], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                );

                file_put_contents(
                    $userFolder . 'dashboards.json',
                    json_encode(['dashboard'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                );

                file_put_contents(
                    $userFolder . 'menu.json',
                    json_encode([], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                );

                file_put_contents(
                    $userFolder . 'theme.json',
                    json_encode(['theme' => 'default'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                );

                if (is_file(__DIR__ . '/data/Logo_2025_Mini.png')) {
                    @copy(__DIR__ . '/data/Logo_2025_Mini.png', $userFolder . 'avatar.png');
                }

                setPermissions($userFolder);

                $_SESSION['user'] = [
                    'email'        => $email,
                    'prenom'       => $prenom,
                    'nom'          => $nom,
                    'role_system'  => $defaultRoleSystem,
                    'role_metier'  => $role_metier
                ];

                $_SESSION['role_system'] = $defaultRoleSystem;

                header('Location: dashboard.php');
                exit;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Créer un utilisateur — DoMyDesk</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
        :root {
            --dmd-bg: #070b12;
            --dmd-bg-2: #0c1320;
            --dmd-panel: rgba(17, 27, 43, .78);
            --dmd-panel-solid: #111b2b;
            --dmd-input: rgba(7, 12, 21, .72);
            --dmd-text: #eaf2ff;
            --dmd-muted: #9fb0c8;
            --dmd-title: #ffffff;
            --dmd-primary: #5b8cff;
            --dmd-primary-2: #7aa2ff;
            --dmd-primary-dark: #315fb8;
            --dmd-danger: #ff6b6b;
            --dmd-border: rgba(143, 181, 255, .28);
            --dmd-border-strong: rgba(143, 181, 255, .46);
            --dmd-shadow: rgba(0, 0, 0, .46);
            --dmd-radius-sm: 12px;
            --dmd-radius: 22px;
            --dmd-radius-lg: 34px;
        }

        * {
            box-sizing: border-box;
        }

        html,
        body {
            min-height: 100%;
            margin: 0;
        }

        body {
            min-height: 100vh;
            overflow-x: hidden;
            color: var(--dmd-text);
            font-family: "Segoe UI", Arial, Tahoma, sans-serif;
            background:
                radial-gradient(circle at 12% 10%, rgba(91, 140, 255, .22), transparent 34vw),
                radial-gradient(circle at 88% 18%, rgba(122, 162, 255, .16), transparent 32vw),
                radial-gradient(circle at 50% 100%, rgba(91, 140, 255, .10), transparent 38vw),
                linear-gradient(145deg, var(--dmd-bg), var(--dmd-bg-2));
        }

        .auth-bg {
            position: fixed;
            inset: 0;
            z-index: 0;
            overflow: hidden;
            pointer-events: none;
        }

        .auth-bg::before {
            content: "";
            position: absolute;
            inset: -30%;
            background:
                linear-gradient(115deg, transparent 0 42%, rgba(91, 140, 255, .08) 48%, transparent 55% 100%),
                linear-gradient(245deg, transparent 0 40%, rgba(122, 162, 255, .06) 50%, transparent 58% 100%);
            animation: auroraMove 18s ease-in-out infinite alternate;
        }

        .auth-cloud {
            position: absolute;
            inset: 0;
            transform: translate(var(--cloud-x, 0), var(--cloud-y, 0));
            transition: transform .18s ease-out;
            mask-image: radial-gradient(circle at center, #000 60%, transparent 100%);
        }

        .auth-word {
            position: absolute;
            left: 0;
            top: 0;
            transform: translate(var(--x-start), var(--y));
            color: color-mix(in srgb, var(--dmd-primary-2) 55%, white 45%);
            font-size: var(--size);
            font-weight: 900;
            white-space: nowrap;
            opacity: .105;
            text-shadow: 0 0 20px rgba(91, 140, 255, .34);
            user-select: none;
            animation: drift var(--dur) linear infinite;
            animation-delay: var(--delay);
        }

        .auth-word::before {
            content: "• ";
            opacity: .5;
        }

        @keyframes drift {
            from { transform: translate(var(--x-start), var(--y)); }
            to { transform: translate(var(--x-end), var(--y)); }
        }

        @keyframes auroraMove {
            from { transform: translate3d(-2%, -1%, 0) rotate(0deg); }
            to { transform: translate3d(3%, 2%, 0) rotate(4deg); }
        }

        .corner-badge {
            position: fixed;
            top: 18px;
            right: 18px;
            z-index: 5;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            max-width: min(270px, calc(100vw - 36px));
            padding: 9px 12px;
            color: var(--dmd-text);
            text-decoration: none;
            background: rgba(17, 27, 43, .72);
            border: 1px solid var(--dmd-border);
            border-radius: 999px;
            box-shadow: 0 14px 32px var(--dmd-shadow);
            backdrop-filter: blur(14px);
        }

        .corner-badge:hover {
            border-color: var(--dmd-primary);
            background: rgba(91, 140, 255, .15);
        }

        .corner-badge img {
            width: 34px;
            height: 34px;
            object-fit: contain;
            flex: 0 0 34px;
        }

        .corner-badge span {
            font-size: .9rem;
            font-weight: 900;
            white-space: nowrap;
        }

        .auth-wrap {
            position: relative;
            z-index: 2;
            min-height: 100vh;
            display: grid;
            place-items: center;
            padding: 34px 18px;
        }

        .auth-card {
            width: min(720px, 100%);
            color: var(--dmd-text);
            background:
                linear-gradient(145deg, rgba(255,255,255,.075), rgba(255,255,255,.026)),
                var(--dmd-panel);
            border: 1px solid var(--dmd-border);
            border-radius: var(--dmd-radius-lg);
            box-shadow:
                0 28px 90px rgba(0, 0, 0, .52),
                0 0 0 1px rgba(255,255,255,.035) inset,
                0 0 52px rgba(91, 140, 255, .11);
            backdrop-filter: blur(18px);
            overflow: hidden;
        }

        .auth-head {
            display: grid;
            justify-items: center;
            gap: 10px;
            padding: 28px 28px 18px;
            text-align: center;
            border-bottom: 1px solid rgba(143, 181, 255, .16);
            background:
                radial-gradient(circle at 50% 0%, rgba(91, 140, 255, .20), transparent 42%),
                rgba(255,255,255,.018);
        }

        .auth-logo {
            width: 88px;
            height: 88px;
            object-fit: contain;
            display: block;
            padding: 10px;
            background: rgba(7, 12, 21, .46);
            border: 1px solid var(--dmd-border);
            border-radius: 24px;
            box-shadow: 0 16px 42px rgba(0,0,0,.35);
        }

        .auth-title {
            margin: 0;
            color: var(--dmd-title);
            font-size: clamp(1.65rem, 3vw, 2.35rem);
            line-height: 1.08;
            letter-spacing: -.04em;
        }

        .auth-subtitle {
            width: min(470px, 100%);
            margin: 0;
            color: var(--dmd-muted);
            font-size: .98rem;
            line-height: 1.55;
        }

        .auth-body {
            padding: 24px 28px 28px;
        }

        .auth-message {
            margin: 0 0 16px;
            padding: 11px 13px;
            color: #ffd6d6;
            background: rgba(255, 107, 107, .12);
            border: 1px solid rgba(255, 107, 107, .34);
            border-radius: var(--dmd-radius-sm);
            font-weight: 900;
            text-align: center;
        }

        .auth-form {
            display: grid;
            gap: 14px;
        }

        .auth-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 14px;
        }

        .auth-field {
            display: grid;
            gap: 7px;
            min-width: 0;
        }

        .auth-full {
            grid-column: 1 / -1;
        }

        .auth-field label {
            color: var(--dmd-muted);
            font-size: .9rem;
            font-weight: 900;
        }

        .auth-control {
            position: relative;
            min-width: 0;
        }

        .auth-icon {
            position: absolute;
            left: 13px;
            top: 50%;
            width: 20px;
            height: 20px;
            transform: translateY(-50%);
            color: color-mix(in srgb, var(--dmd-primary-2) 68%, white 32%);
            opacity: .9;
            pointer-events: none;
        }

        .auth-input,
        .auth-select {
            width: 100%;
            min-height: 46px;
            padding: 11px 44px 11px 44px;
            color: var(--dmd-text);
            background: var(--dmd-input);
            border: 1px solid var(--dmd-border);
            border-radius: var(--dmd-radius-sm);
            outline: none;
            font-size: .98rem;
            transition: border-color .18s ease, box-shadow .18s ease, background .18s ease;
            appearance: none;
        }

        .auth-select {
            padding-right: 44px;
        }

        .auth-input::placeholder {
            color: rgba(234, 242, 255, .42);
        }

        .auth-control::after {
            content: "";
            position: absolute;
            inset: 1px;
            border-radius: calc(var(--dmd-radius-sm) - 1px);
            pointer-events: none;
            background: linear-gradient(180deg, rgba(255,255,255,.045), transparent);
        }

        .auth-control.select::before {
            content: "▾";
            position: absolute;
            right: 15px;
            top: 50%;
            z-index: 2;
            transform: translateY(-50%);
            color: var(--dmd-muted);
            font-weight: 900;
            pointer-events: none;
        }

        .auth-control:focus-within .auth-input,
        .auth-control:focus-within .auth-select {
            border-color: var(--dmd-primary);
            box-shadow:
                0 0 0 3px rgba(91, 140, 255, .18),
                0 12px 28px rgba(0,0,0,.22);
            background: rgba(7, 12, 21, .86);
        }

        .auth-toggle {
            position: absolute;
            right: 8px;
            top: 50%;
            z-index: 3;
            width: 34px;
            height: 34px;
            padding: 0;
            transform: translateY(-50%);
            border: 1px solid var(--dmd-border);
            border-radius: 999px;
            background: rgba(17, 27, 43, .86);
            color: var(--dmd-text);
            cursor: pointer;
        }

        .auth-toggle:hover {
            border-color: var(--dmd-primary);
            background: rgba(91, 140, 255, .18);
        }

        .auth-submit {
            width: 100%;
            min-height: 48px;
            border: 1px solid rgba(143, 181, 255, .42);
            border-radius: var(--dmd-radius-sm);
            color: #fff;
            font-weight: 950;
            font-size: 1rem;
            cursor: pointer;
            background:
                radial-gradient(140% 160% at 20% 0%, rgba(255,255,255,.28), transparent 38%),
                linear-gradient(135deg, var(--dmd-primary), var(--dmd-primary-dark));
            box-shadow:
                0 16px 34px rgba(0,0,0,.34),
                0 0 24px rgba(91, 140, 255, .18);
            transition: transform .12s ease, filter .18s ease, box-shadow .18s ease;
        }

        .auth-submit:hover {
            transform: translateY(-1px);
            filter: brightness(1.06);
            box-shadow:
                0 20px 42px rgba(0,0,0,.42),
                0 0 30px rgba(91, 140, 255, .24);
        }

        .auth-submit:active {
            transform: translateY(0);
        }

        .auth-link {
            display: block;
            text-align: center;
            color: var(--dmd-muted);
            font-weight: 900;
            text-decoration: none;
        }

        .auth-link:hover {
            color: var(--dmd-primary-2);
            text-decoration: none;
        }

        .auth-footnote {
            margin: 0;
            text-align: center;
            color: var(--dmd-muted);
            font-size: .83rem;
        }

        @media (max-width: 720px) {
            body {
                overflow-y: auto;
            }

            .corner-badge {
                display: none;
            }

            .auth-wrap {
                align-items: start;
                padding: 18px 12px;
            }

            .auth-card {
                width: 100%;
                border-radius: 24px;
            }

            .auth-head {
                padding: 22px 18px 15px;
            }

            .auth-body {
                padding: 18px;
            }

            .auth-grid {
                grid-template-columns: 1fr;
            }

            .auth-logo {
                width: 72px;
                height: 72px;
            }
        }
    </style>
</head>

<body>

<div class="auth-bg" aria-hidden="true">
    <div class="auth-cloud" id="floatCloud"></div>
</div>

<a class="corner-badge" href="https://domydesk.com" target="_blank" rel="noopener" title="domydesk.com">
    <img src="data/Logo.png" alt="Logo DoMyDesk" onerror="this.style.display='none'">
    <span>DoMyDesk</span>
</a>

<main class="auth-wrap">
    <section class="auth-card" aria-labelledby="register-title">

        <div class="auth-head">
            <img class="auth-logo" src="data/Logo.png" alt="Logo DoMyDesk" onerror="this.style.display='none'">
            <h1 class="auth-title" id="register-title">Créer un utilisateur</h1>
            <p class="auth-subtitle">Ajoute un compte DoMyDesk.</p>
        </div>

        <div class="auth-body">
            <?php if ($message !== ''): ?>
                <div class="auth-message"><?= e($message) ?></div>
            <?php endif; ?>

            <form class="auth-form" method="post" action="" autocomplete="on" novalidate>
                <div class="auth-grid">

                    <div class="auth-field">
                        <label for="prenom">Prénom</label>
                        <div class="auth-control">
                            <svg class="auth-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                                <path d="M12 12a5 5 0 1 0-5-5 5 5 0 0 0 5 5Zm0 2c-5 0-9 2.5-9 5.5V22h18v-2.5C21 16.5 17 14 12 14Z"/>
                            </svg>
                            <input class="auth-input" type="text" id="prenom" name="prenom" value="<?= e($_POST['prenom'] ?? '') ?>" required>
                        </div>
                    </div>

                    <div class="auth-field">
                        <label for="nom">Nom</label>
                        <div class="auth-control">
                            <svg class="auth-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                                <path d="M12 12a5 5 0 1 0-5-5 5 5 0 0 0 5 5Zm0 2c-5 0-9 2.5-9 5.5V22h18v-2.5C21 16.5 17 14 12 14Z"/>
                            </svg>
                            <input class="auth-input" type="text" id="nom" name="nom" value="<?= e($_POST['nom'] ?? '') ?>" required>
                        </div>
                    </div>

                    <div class="auth-field auth-full">
                        <label for="email">Email</label>
                        <div class="auth-control">
                            <svg class="auth-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                                <path d="M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2Zm0 4-8 5L4 8V6l8 5 8-5v2Z"/>
                            </svg>
                            <input class="auth-input" type="email" id="email" name="email" value="<?= e($_POST['email'] ?? '') ?>" required>
                        </div>
                    </div>

                    <div class="auth-field auth-full">
                        <label for="role_metier">Rôle métier</label>
                        <div class="auth-control select">
                            <svg class="auth-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                                <path d="M4 6a2 2 0 0 1 2-2h3V3a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v1h3a2 2 0 0 1 2 2v3H4V6Zm7-2v0h2v0h-2ZM4 11h16v7a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-7Z"/>
                            </svg>
                            <select class="auth-select" id="role_metier" name="role_metier" required>
                                <option value="" disabled <?= empty($_POST['role_metier']) ? 'selected' : '' ?>>
                                    -- Choisir un métier --
                                </option>
                                <?php foreach ($metiers as $metier): ?>
                                    <option value="<?= e($metier) ?>" <?= (($_POST['role_metier'] ?? '') === $metier) ? 'selected' : '' ?>>
                                        <?= e($metier) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="auth-field auth-full">
                        <label for="password">Mot de passe</label>
                        <div class="auth-control">
                            <svg class="auth-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                                <path d="M12 1a5 5 0 0 0-5 5v3H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8a2 2 0 0 0-2-2h-1V6a5 5 0 0 0-5-5Zm-3 8V6a3 3 0 0 1 6 0v3H9Zm3 5a2 2 0 1 1 0 4 2 2 0 0 1 0-4Z"/>
                            </svg>
                            <input class="auth-input" type="password" id="password" name="password" placeholder="Minimum 8 caractères" required minlength="8">
                            <button type="button" class="auth-toggle" id="togglePwd" aria-label="Afficher ou masquer le mot de passe">👁️</button>
                        </div>
                    </div>

                </div>

                <button class="auth-submit" type="submit">Créer le compte</button>

                <a class="auth-link" href="login.php">Déjà un compte ? Se connecter</a>

                <p class="auth-footnote">
                    <strong>DoMyDesk</strong> — Modular Private Workspace
                </p>
            </form>
        </div>

    </section>
</main>

<script>
(function () {
    const btn = document.getElementById('togglePwd');
    const inp = document.getElementById('password');

    if (btn && inp) {
        btn.addEventListener('click', () => {
            const type = inp.type === 'password' ? 'text' : 'password';
            inp.type = type;
            btn.textContent = type === 'password' ? '👁️' : '🙈';
        });
    }
})();

(function () {
    const procedures = [
        "Installation VPS", "Tunnels WireGuard", "IPSec NAT-T", "Reverse Proxy NGINX",
        "DoMyDesk ID", "Sauvegarde continue", "Thèmes CSS unifiés", "Profils utilisateurs JSON",
        "Gestion des modules", "Market Modules", "Tailscale", "Proxmox API",
        "DOC: profile_edit.php", "DOC: site_settings.php", "Grille magnétique", "Interact.js",
        "Multi-dashboard", "Droits & rôles", "Exports PDF/CSV", "Procédures RH"
    ];

    const modules = [
        "animals", "dmdcook", "ticketing", "folders", "pdfviewer", "map", "dmdyou",
        "gamesmanage", "chessai", "inventaire", "proxv2", "social", "translator",
        "remote", "vm", "weather", "todolist", "management", "infra", "hoas"
    ];

    const words = procedures.concat(modules);
    const cloud = document.getElementById('floatCloud');

    if (!cloud) {
        return;
    }

    function rand(min, max) {
        return Math.random() * (max - min) + min;
    }

    const maxWords = Math.min(words.length, 36);

    for (let i = 0; i < maxWords; i++) {
        const word = document.createElement('span');

        word.className = 'auth-word';
        word.textContent = words[i % words.length];

        word.style.setProperty('--y', rand(5, 95).toFixed(2) + 'vh');
        word.style.setProperty('--x-start', (-20 - rand(0, 30)).toFixed(2) + 'vw');
        word.style.setProperty('--x-end', (120 + rand(0, 30)).toFixed(2) + 'vw');
        word.style.setProperty('--dur', rand(28, 55).toFixed(2) + 's');
        word.style.setProperty('--delay', (-rand(0, 55)).toFixed(2) + 's');
        word.style.setProperty('--size', rand(12, 22).toFixed(0) + 'px');

        cloud.appendChild(word);
    }

    document.addEventListener('pointermove', e => {
        const dx = (e.clientX / window.innerWidth - .5) * 6;
        const dy = (e.clientY / window.innerHeight - .5) * 6;

        cloud.style.setProperty('--cloud-x', dx + 'px');
        cloud.style.setProperty('--cloud-y', dy + 'px');
    }, { passive: true });
})();
</script>

</body>
</html>
