<?php
// Démarrage de session sécurisé
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$profilesDir = __DIR__ . '/users/profiles/';
$message = '';

// Fonction de permissions automatiques
function setPermissions($path) {
    if (!file_exists($path)) return;

    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($path, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );

    foreach ($iterator as $item) {
        if ($item->isDir()) {
            @chmod($item, 0777); // tous droits sur dossiers
        } else {
            @chmod($item, 0666); // tous droits sur fichiers
        }
    }

    // Appliquer aussi à la racine du chemin
    is_dir($path) ? @chmod($path, 0777) : @chmod($path, 0666);
}

// Chargement des rôles métier depuis JSON
$metiers = [];
$rolesFile = __DIR__ . '/data/roles_metier.json';
if (file_exists($rolesFile)) {
    $json = file_get_contents($rolesFile);
    $metiers = json_decode($json, true);
    if (!is_array($metiers)) {
        $metiers = [];
    }
}

$defaultRoleSystem = 'user';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prenom = trim($_POST['prenom'] ?? '');
    $nom = trim($_POST['nom'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $role_metier = trim($_POST['role_metier'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$prenom || !$nom || !$email || !$role_metier || !$password) {
        $message = 'Tous les champs sont obligatoires.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Email invalide.';
    } elseif (!in_array($role_metier, $metiers, true)) {
        $message = 'Rôle métier invalide.';
    } else {
        $userFolder = $profilesDir . $email . '/';

        if (file_exists($userFolder)) {
            $message = 'Un utilisateur avec cet email existe déjà.';
        } else {
            if (!mkdir($userFolder, 0755, true)) {
                $message = 'Erreur lors de la création du dossier utilisateur.';
            } else {
                $profileData = [
                    'prenom' => $prenom,
                    'nom' => $nom,
                    'email' => $email,
                    'role_system' => $defaultRoleSystem,
                    'role_metier' => $role_metier,
                    'password' => password_hash($password, PASSWORD_DEFAULT)
                ];

                file_put_contents($userFolder . 'profile.json', json_encode($profileData, JSON_PRETTY_PRINT));
                file_put_contents($userFolder . 'dashboard.json', json_encode([], JSON_PRETTY_PRINT));
                file_put_contents($userFolder . 'menu.json', json_encode([], JSON_PRETTY_PRINT));
                copy(__DIR__ . '/data/Logo_2025_Mini.png', $userFolder . 'avatar.png');

                // 🔐 Appliquer les droits automatiquement
                setPermissions($userFolder);

                $_SESSION['user'] = $profileData;
                header('Location: dashboard.php');
                exit;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <title>Créer un utilisateur</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; margin: 0; padding: 0; }
        .container {
            max-width: 500px; margin: 80px auto; background: #fff;
            padding: 25px; border-radius: 10px;
            border: 2px solid red; box-shadow: 0 0 10px rgba(0, 120, 255, 0.7);
        }
        h1 { text-align: center; }
        .message { font-weight: bold; margin-bottom: 15px; color: red; }
        .success { color: green; }
        form { display: flex; flex-direction: column; gap: 12px; }
        label { font-weight: bold; }
        input, select { padding: 8px; font-size: 1em; }
        button {
            background-color: #222; color: white; border: none;
            padding: 10px; font-size: 1em; cursor: pointer;
        }
        button:hover { background-color: #0af; }
    </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="container">
    <h1>Créer un nouvel utilisateur</h1>

    <?php if ($message): ?>
        <p class="message <?= strpos($message, 'succès') !== false ? 'success' : '' ?>">
            <?= htmlspecialchars($message) ?>
        </p>
    <?php endif; ?>

    <form method="post" action="">
        <label for="prenom">Prénom :</label>
        <input type="text" id="prenom" name="prenom" required>

        <label for="nom">Nom :</label>
        <input type="text" id="nom" name="nom" required>

        <label for="email">Email :</label>
        <input type="email" id="email" name="email" required>

        <label for="role_metier">Rôle métier :</label>
        <select id="role_metier" name="role_metier" required>
            <option value="" disabled selected>-- Choisir un métier --</option>
            <?php foreach ($metiers as $metier): ?>
                <option value="<?= htmlspecialchars($metier) ?>"><?= htmlspecialchars($metier) ?></option>
            <?php endforeach; ?>
        </select>

        <label for="password">Mot de passe :</label>
        <input type="password" id="password" name="password" required>

        <button type="submit">Créer</button>
    </form>
</div>

</body>
</html>
