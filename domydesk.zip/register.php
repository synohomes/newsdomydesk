<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$profilesDir = __DIR__ . '/users/profiles/';
$message = '';
function setPermissions($path) {
    if (!file_exists($path)) return;
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($path, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($iterator as $item) {
        if ($item->isDir()) {
            @chmod($item, 0777);
        } else {
            @chmod($item, 0666);
        }
    }
    is_dir($path) ? @chmod($path, 0777) : @chmod($path, 0666);
}
$metiers = [];
$rolesFile = __DIR__ . '/data/roles_metier.json';
if (file_exists($rolesFile)) {
    $json = file_get_contents($rolesFile);
    $metiers = json_decode($json, true);
    if (!is_array($metiers)) $metiers = [];
}
$defaultRoleSystem = 'user';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prenom      = trim($_POST['prenom'] ?? '');
    $nom         = trim($_POST['nom'] ?? '');
    $email       = trim($_POST['email'] ?? '');
    $role_metier = trim($_POST['role_metier'] ?? '');
    $password    = $_POST['password'] ?? '';
    if (!$prenom || !$nom || !$email || !$role_metier || !$password) {
        $message = 'Tous les champs sont obligatoires.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Email invalide.';
    } elseif (!in_array($role_metier, $metiers, true)) {
        $message = 'Rôle métier invalide.';
    } else {
        $userFolder = $profilesDir . $email . '/';
        if (file_exists($userFolder)) {
            $message = 'Un utilisateur avec cet email existe déjà.';
        } else {
            if (!mkdir($userFolder, 0755, true)) {
                $message = 'Erreur lors de la création du dossier utilisateur.';
            } else {
                $profileData = [
                    'prenom'       => $prenom,
                    'nom'          => $nom,
                    'email'        => $email,
                    'role_system'  => $defaultRoleSystem,
                    'role_metier'  => $role_metier,
                    // IMPORTANT: compatible avec ta page de connexion
                    'motdepasse'   => password_hash($password, PASSWORD_DEFAULT)
                ];
                file_put_contents($userFolder . 'profile.json', json_encode($profileData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                file_put_contents($userFolder . 'dashboard.json', json_encode([], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                file_put_contents($userFolder . 'menu.json', json_encode([], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                @copy(__DIR__ . '/data/Logo_2025_Mini.png', $userFolder . 'avatar.png');
                setPermissions($userFolder);
                $_SESSION['user'] = $profileData;
                header('Location: dashboard.php');
                exit;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <title>Créer un utilisateur — DoMyDesk</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    *,*::before,*::after{ box-sizing:border-box; }
    :root{
      --primary-color: var(--primary-color, #3ea2ff);
      --primary-dark:  var(--primary-dark,  #1b2634);
      --bg-deep:       var(--bg-deep, #0b0f14);
      --text:          var(--text, #e8f0ff);
      --muted:         var(--muted, #a7b4c7);
    }
    html,body{height:100%;margin:0}
    body{
      font-family:'Segoe UI', Roboto, Arial, sans-serif;
      color:var(--text);
      background:
        radial-gradient(60rem 60rem at 10% 10%, rgba(255,255,255,.03), transparent 40%),
        radial-gradient(60rem 60rem at 90% 20%, rgba(255,255,255,.03), transparent 45%),
        linear-gradient(180deg, rgba(0,0,0,.4), rgba(0,0,0,.6)), var(--bg-deep);
      overflow:hidden;
    }
    .float-cloud{ position:fixed; inset:0; pointer-events:none; z-index:0;
      mask-image:radial-gradient(60% 60% at 50% 50%, #000 65%, transparent 100%); }
    .float-word{ position:absolute; font-weight:600; white-space:nowrap; opacity:.08;
      transform:translate(-50%,-50%); user-select:none; filter:drop-shadow(0 0 1px rgba(0,0,0,.15));
      animation:drift var(--dur) linear infinite; }
    .float-word::before{content:"• "; opacity:.4}
    @keyframes drift{ 0%{transform:translate(var(--xStart),var(--y))} 100%{transform:translate(var(--xEnd),var(--y))} }
    .corner-badge{
      position:fixed; top:18px; right:18px; z-index:3;
      background:linear-gradient(180deg, rgba(255,255,255,.08), rgba(255,255,255,.04));
      backdrop-filter:blur(6px);
      border:1px solid rgba(255,255,255,.12);
      border-radius:14px; box-shadow:0 8px 24px rgba(0,0,0,.35);
      padding:10px 12px; display:flex; align-items:center; gap:10px; text-decoration:none;
      color:#dfe7ff;
    }
    .corner-badge img{ width:34px; height:34px; object-fit:contain; border-radius:8px; background:rgba(0,0,0,.15); }
    .wrap{ position:relative; z-index:2; min-height:100%; display:grid; place-items:center; padding:clamp(16px,2vw,32px); }
    .card{
      width:min(720px, 94vw);
      background:linear-gradient(180deg, rgba(255,255,255,.06), rgba(255,255,255,.02));
      backdrop-filter:blur(8px);
      border-radius:18px; border:1px solid rgba(255,255,255,.08);
      box-shadow:0 10px 30px rgba(0,0,0,.35), 0 0 0 1px rgba(255,255,255,.03) inset;
      padding:28px; overflow:hidden;   /* coupe tout débordement */
    }
    .brand{ display:flex; align-items:center; justify-content:center; gap:12px; margin-bottom:14px; }
    .brand img{ width:38px; height:38px; object-fit:contain; border-radius:10px; background:rgba(0,0,0,.15); border:1px solid rgba(255,255,255,.12); box-shadow:0 2px 10px rgba(0,0,0,.35); }
    .brand h1{ margin:0; letter-spacing:.3px; font-size:1.35rem; color:#fff; }
    .brand a{ color:#fff; text-decoration:none; }
    .brand a:hover{ text-decoration:underline; text-underline-offset:3px; }
    .subtitle{ text-align:center; color:var(--muted); font-size:.95rem; margin-bottom:18px; }
    .divider{ height:1px; background:linear-gradient(90deg, transparent, rgba(255,255,255,.12), transparent); margin:14px 0 18px; }
    form{ display:grid; grid-template-columns: 1fr 1fr; gap:14px 16px; margin:0; }
    form .full{ grid-column:1 / -1; }
    label{ display:block; font-size:.9rem; color:#dfe8ff; margin-bottom:6px; }
    .field{ position:relative; overflow:hidden; isolation:isolate; min-width:0; }
    .inp, .sel{
      display:block; width:100%; max-width:100%;
      padding:12px 44px; font-size:.98rem; color:#eaf2ff;
      background:rgba(255,255,255,.06); border:1px solid rgba(255,255,255,.12);
      border-radius:12px; outline:none; transition:border-color .2s, box-shadow .2s, background .2s;
    }
    .inp::placeholder{ color:rgba(255,255,255,.45); }
    .field:focus-within .inp, .field:focus-within .sel{
      border-color: color-mix(in oklab, var(--primary-color) 70%, white 0%);
      box-shadow: 0 0 0 4px color-mix(in oklab, var(--primary-color) 15%, transparent 85%);
      background: rgba(255,255,255,.08);
    }
    .icon{
      position:absolute; left:12px; top:50%; transform:translateY(-50%);
      width:22px; height:22px; opacity:.85; pointer-events:none;
    }
    .toggle{
      position:absolute; right:12px; top:50%; transform:translateY(-50%);
      display:inline-flex; align-items:center; justify-content:center;
      width:26px; height:26px; border:none; background:transparent; color:#cfe2ff; cursor:pointer; padding:0; border-radius:6px; opacity:.9;
    }
    .toggle:hover{ opacity:1; }
    .field.select .sel{ padding-right:44px; appearance:none; -webkit-appearance:none; -moz-appearance:none; background-image:none; }
    .field.select::after{
      content:"▾"; position:absolute; right:14px; top:50%; transform:translateY(-50%); font-size:14px; color:#cfe2ff; opacity:.9; pointer-events:none;
    }
    .btn{
      width:100%; padding:12px 16px; font-weight:700; letter-spacing:.2px; border:none; cursor:pointer; border-radius:12px; color:#0a1018;
      background: radial-gradient(120% 150% at 20% 0%, rgba(255,255,255,.35), transparent 40%),
                  linear-gradient(90deg, color-mix(in oklab, var(--primary-dark) 20%, var(--primary-color) 80%), var(--primary-color));
      box-shadow:0 10px 24px rgba(0,0,0,.35); transition:transform .08s ease, filter .2s ease, box-shadow .2s ease;
    }
    .btn:hover{ filter:brightness(1.06) saturate(1.05); box-shadow:0 12px 26px rgba(0,0,0,.45); }
    .btn:active{ transform:translateY(1px); }

    .msg{
      background:rgba(255,65,65,.12);
      border:1px solid rgba(255,65,65,.25);
      color:#ffd4d4; padding:10px 12px; border-radius:10px; margin-bottom:12px; font-weight:600; text-align:center;
    }
    .msg.ok{
      background:rgba(60,255,120,.10); border-color:rgba(60,255,120,.25); color:#dbffe8;
    }

    @media (max-width:680px){
      form{ grid-template-columns:1fr; }
    }
  </style>
</head>
<body>
  <a class="corner-badge" href="https://domydesk.com" target="_blank" rel="noopener" title="domydesk.com">
    <img src="data/Logo.png" alt="Logo DoMyDesk" onerror="this.style.display='none'">
    <span>DoMyDesk</span>
  </a>
  <div class="float-cloud" aria-hidden="true" id="floatCloud"></div>
  <?php  ?>
  <?php include 'header.php'; ?>
  <div class="wrap">
    <div class="card" role="region" aria-labelledby="ttl">
      <div class="brand">
        <img src="data/Logo.png" alt="Logo" onerror="this.style.display='none'">
        <h1 id="ttl"><a href="https://domydesk.com" target="_blank" rel="noopener">Créer un utilisateur</a></h1>
      </div>
      <div class="subtitle">Ajoute un compte DoMyDesk en quelques secondes.</div>
      <div class="divider"></div>
      <?php if ($message): ?>
        <div class="msg <?= strpos($message,'succès')!==false ? 'ok':'' ?>"><?= htmlspecialchars($message) ?></div>
      <?php endif; ?>
      <form method="post" action="" autocomplete="on" novalidate>
        <div class="full">
          <label for="prenom">Prénom</label>
          <div class="field">
            <svg class="icon" viewBox="0 0 24 24" fill="currentColor"><path d="M12 12a5 5 0 1 0-5-5 5 5 0 0 0 5 5Zm0 2c-5 0-9 2.5-9 5.5V22h18v-2.5C21 16.5 17 14 12 14Z"/></svg>
            <input class="inp" type="text" id="prenom" name="prenom" value="<?= htmlspecialchars($_POST['prenom'] ?? '') ?>" required>
          </div>
        </div>
        <div>
          <label for="nom">Nom</label>
          <div class="field">
            <svg class="icon" viewBox="0 0 24 24" fill="currentColor"><path d="M12 12a5 5 0 1 0-5-5 5 5 0 0 0 5 5Zm0 2c-5 0-9 2.5-9 5.5V22h18v-2.5C21 16.5 17 14 12 14Z"/></svg>
            <input class="inp" type="text" id="nom" name="nom" value="<?= htmlspecialchars($_POST['nom'] ?? '') ?>" required>
          </div>
        </div>
        <div>
          <label for="email">Email</label>
          <div class="field">
            <svg class="icon" viewBox="0 0 24 24" fill="currentColor"><path d="M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2Zm0 4-8 5L4 8V6l8 5 8-5v2Z"/></svg>
            <input class="inp" type="email" id="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
          </div>
        </div>
        <div class="full">
          <label for="role_metier">Rôle métier</label>
          <div class="field select">
            <svg class="icon" viewBox="0 0 24 24" fill="currentColor"><path d="M12 12a5 5 0 1 0-5-5 5 5 0 0 0 5 5Zm0 2c-5 0-9 2.5-9 5.5V22h18v-2.5C21 16.5 17 14 12 14Z"/></svg>
            <select class="sel" id="role_metier" name="role_metier" required>
              <option value="" disabled <?= empty($_POST['role_metier']) ? 'selected':'' ?>>-- Choisir un métier --</option>
              <?php foreach ($metiers as $metier): ?>
                <option value="<?= htmlspecialchars($metier) ?>" <?= (($_POST['role_metier'] ?? '')===$metier)?'selected':'' ?>>
                  <?= htmlspecialchars($metier) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
        <div class="full">
          <label for="password">Mot de passe</label>
          <div class="field">
            <svg class="icon" viewBox="0 0 24 24" fill="currentColor"><path d="M12 1a5 5 0 0 0-5 5v3H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8a2 2 0 0 0-2-2h-1V6a5 5 0 0 0-5-5Zm-3 8V6a3 3 0 0 1 6 0v3H9Zm3 5a2 2 0 1 1 0 4 2 2 0 0 1 0-4Z"/></svg>
            <input class="inp" type="password" id="password" name="password" placeholder="••••••••" required>
            <button type="button" class="toggle" id="togglePwd" aria-label="Afficher/masquer">👁️</button>
          </div>
        </div>
        <div class="full">
          <button class="btn" type="submit">Créer</button>
        </div>
      </form>
    </div>
  </div>
  <script>
    (function(){
      const btn = document.getElementById('togglePwd');
      const inp = document.getElementById('password');
      if(btn && inp){
        btn.addEventListener('click', ()=>{
          const type = inp.type === 'password' ? 'text' : 'password';
          inp.type = type;
          btn.textContent = (type === 'password') ? '👁️' : '🙈';
        });
      }
    })();
    const procedures = [
      "Installation VPS","Tunnels WireGuard","IPSec NAT-T","Reverse Proxy NGINX",
      "DoMyDesk ID","Sauvegarde continue","Thèmes CSS unifiés","Profils utilisateurs JSON",
      "Gestion des modules","Market Modules","Tailscale","Proxmox API",
      "DOC: profile_edit.php","DOC: site_settings.php","Grille magnétique","Interact.js",
      "Multi-dashboard","Droits & rôles","Exports PDF/CSV","Procédures RH"
    ];
    const modules = [
      "animals","dmdcook","ticketing","folders","pdfviewer","map","dmdyou",
      "gamesmanage","chessai","inventaire","proxv2","social","translator",
      "remote","vm","weather","todolist","management","infra","hoas"
    ];
    const words = [...procedures, ...modules];
    const cloud = document.getElementById('floatCloud');
    function rand(min,max){ return Math.random()*(max-min)+min; }
    const maxWords = Math.min(words.length, 36);
    for(let i=0;i<maxWords;i++){
      const w = document.createElement('span');
      w.className = 'float-word';
      w.textContent = words[i % words.length];
      const y = rand(5,95).toFixed(2)+'vh';
      const xStart = (-20 - rand(0,30)).toFixed(2)+'vw';
      const xEnd   = (120 + rand(0,30)).toFixed(2)+'vw';
      const dur    = rand(28,55).toFixed(2)+'s';
      const delay  = (-rand(0,55)).toFixed(2)+'s';
      const fs     = rand(12,22).toFixed(0)+'px';
      w.style.color = `color-mix(in oklab, var(--primary-color) 40%, white 60%)`;
      w.style.fontSize = fs;
      w.style.setProperty('--y', y);
      w.style.setProperty('--xStart', xStart);
      w.style.setProperty('--xEnd', xEnd);
      w.style.setProperty('--dur', dur);
      w.style.animationDelay = delay;
      cloud.appendChild(w);
    }
    document.addEventListener('pointermove', (e)=>{
      const { innerWidth:w, innerHeight:h } = window;
      const dx = (e.clientX / w - .5) * 6;
      const dy = (e.clientY / h - .5) * 6;
      cloud.style.transform = `translate(${dx}px, ${dy}px)`;
    }, { passive:true });
  </script>
</body>
</html>
