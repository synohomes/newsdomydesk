<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}
$user = $_SESSION['user'];
$users = [];
foreach (glob('users/profiles/*') as $profileDir) {
    if (is_dir($profileDir)) {
        $profileFile = "$profileDir/profile.json";
        if (file_exists($profileFile)) {
            $users[] = json_decode(file_get_contents($profileFile), true);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Utilisateurs</title>
</head>
<body>
    <header>
        <p>Bienvenue, <?php echo $user['first_name']; ?> !</p>
        <a href="logout.php">Se déconnecter</a>
    </header>
    <section>
        <h2>Utilisateurs</h2>
        <ul>
            <?php foreach ($users as $userData) { ?>
                <li><?php echo $userData['first_name'] . ' ' . $userData['last_name']; ?> - <?php echo $userData['email']; ?></li>
            <?php } ?>
        </ul>
    </section>
</body>
</html>
