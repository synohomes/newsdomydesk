<?php
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <title>Installation de DoMyDesk</title>
  <link rel="stylesheet" href="theme/default/style.css">
  <style>
    :root{
      --bg-1:#1f2126;
      --card: rgba(255,255,255,.05);
      --card-border: rgba(255,255,255,.10);
      --ring: rgba(122,162,255,.25);
      --text:#fff;
      --text-dim: rgba(255,255,255,.75);
      --accent:#ff3b30;
    }
    body{
      margin:0; background:var(--bg-1); color:var(--text);
      font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;
      padding:24px;
    }
    form{
      width:min(880px,92vw); margin:40px auto 24px; padding:26px 28px 22px;
      background:var(--card); border:1px solid var(--card-border);
      border-radius:14px;
      box-shadow:0 14px 40px rgba(0,0,0,.35), 0 0 0 1px rgba(255,255,255,.03) inset;
    }
    form h1{ margin:0 0 18px; font-size:clamp(22px,2.6vw,34px); line-height:1.15; font-weight:400; letter-spacing:.3px; }
    form > label{
      display:grid; grid-template-columns:220px 1fr; align-items:center;
      gap:12px; margin:10px 0; font-weight:450;
    }
    form > label > input{
      width:100%; height:42px; padding:10px 12px; border-radius:10px;
      border:1px solid var(--card-border);
      background:rgba(255,255,255,.06); color:var(--text); outline:none;
      transition:border-color .15s, box-shadow .15s, background .15s;
      box-sizing:border-box;
    }
    form > label > input::placeholder{ color:rgba(255,255,255,.45); }
    form > label > input:focus{ border-color:#7aa2ff; box-shadow:0 0 0 3px var(--ring); background:rgba(255,255,255,.08); }
    form > button[type="submit"]{
      margin-top:16px; display:inline-block; padding:12px 18px; border:0; border-radius:12px;
      background:var(--accent); color:#fff; font-weight:750; cursor:pointer;
      box-shadow:0 10px 26px rgba(255,59,48,.28);
      transition:filter .2s, transform .04s;
    }
    form > button[type="submit"]:hover{ filter:brightness(1.05); }
    form > button[type="submit"]:active{ transform:translateY(1px); }
    .flash{ margin:10px 0 14px; padding:10px 12px; border-radius:10px; border:1px solid var(--card-border); background:rgba(255,255,255,.06); }
    .flash.err{ border-color:rgba(255,99,71,.55); }
    .flash.ok{ border-color:rgba(46,204,113,.55); }
    @media (max-width:700px){
      form{ padding:22px 16px; }
      form > label{ grid-template-columns:1fr; gap:6px; margin:8px 0; }
    }
  </style>
</head>
<body>
<?php include 'header.php'; ?>
<?php
if (!empty($_GET['dev'])) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
}
function go_login(string $path = '/domydesk/login.php'): void {
    if (!headers_sent()) {
        header('Location: ' . $path, true, 302);
        exit;
    }
    echo '<script>location.replace(' . json_encode($path) . ');</script>';
    echo '<noscript><meta http-equiv="refresh" content="0;url=' . htmlspecialchars($path, ENT_QUOTES) . '"></noscript>';
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email       = trim($_POST['email'] ?? '');
    $prenom      = trim($_POST['prenom'] ?? '');
    $nom         = trim($_POST['nom'] ?? '');
    $role_system = trim($_POST['role_system'] ?? 'admin');
    $motdepasse  = (string)($_POST['motdepasse'] ?? '');
    if ($email !== '') {
        $userDir = __DIR__ . '/users/profiles/' . $email;
        if (!is_dir($userDir)) { @mkdir($userDir, 0775, true); }

        $initiale = strtolower(substr($prenom !== '' ? $prenom : 'x', 0, 1));
        $annee    = date('y');
        $alea     = strtoupper(substr(str_shuffle('ABCDEFGHJKLMNPQRSTUVWXYZ'), 0, 4));
        $num      = str_pad(random_int(0, 99999999), 8, '0', STR_PAD_LEFT);
        $idclient = "DM1-$initiale-$annee-$alea-$num";
$idFile = __DIR__ . '/data/id_domydesk.txt';
if (!file_exists($idFile)) {
    $aa = date('y');
    $mm = date('m');
    $initNom = strtolower(substr($nom, 0, 1)) ?: 'x';
    $initPrenom = strtolower(substr($prenom, 0, 1)) ?: 'x';
    $rand10 = str_pad(random_int(0, 9999999999), 10, '0', STR_PAD_LEFT);
    $id_dmd = "DmD-$aa-$mm-$initNom$initPrenom-$rand10";
    @mkdir(dirname($idFile), 0775, true);
    file_put_contents($idFile, $id_dmd);
} else {
    $id_dmd = trim(file_get_contents($idFile));
}
        $profil = [
            "email"       => $email,
            "prenom"      => $prenom,
            "nom"         => $nom,
            "pseudo"      => $prenom ?: $email,
            "role_system" => $role_system ?: 'admin',
            "motdepasse"  => $motdepasse !== '' ? password_hash($motdepasse, PASSWORD_DEFAULT) : '',
            "created_at"  => date('Y-m-d H:i:s'),
            "id_client"   => $idclient
        ];
        @file_put_contents("$userDir/profile.json", json_encode($profil, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
        @chmod("$userDir/profile.json", 0664);

        $_SESSION['user'] = [
            'email'       => $email,
            'prenom'      => $prenom,
            'nom'         => $nom,
            'role_system' => $role_system ?: 'admin'
        ];
        go_login('/domydesk/login.php');
    }
}
?>
<form method="POST" action="">
  <h1>Créer le premier utilisateur administrateur</h1>
  <label>Email (utilisé comme identifiant) :
    <input type="email" name="email" placeholder="ex: admin@exemple.com" required>
  </label>
  <label>Prénom :
    <input type="text" name="prenom" placeholder="(optionnel)">
  </label>
  <label>Nom :
    <input type="text" name="nom" placeholder="(optionnel)">
  </label>
<label>Rôle système :
  <input type="text" name="role_system" value="admin" readonly>
</label>
  <label>Mot de passe :
    <input type="password" name="motdepasse" placeholder="(peut être vide)">
  </label>
  <button type="submit">Créer l'utilisateur</button>
  <?php
  function detect_system_type(): string {
      $os_info   = php_uname();
      $etc_issue = @file_get_contents('/etc/issue');
      if (stripos($os_info, 'synology') !== false || is_dir('/volume1/')) return 'synology';
      if (is_dir('/share/') && is_file('/etc/config/uLinux.conf'))      return 'qnap';
      if (stripos($etc_issue, 'ubuntu') !== false || stripos($os_info, 'ubuntu') !== false) return 'ubuntu';
      return 'unknown';
  }
  function set_permissions_recursively($path, $perm = 0777) {
      if (!file_exists($path)) return;
      @chmod($path, $perm);
      if (is_dir($path)) {
          foreach (scandir($path) as $item) {
              if ($item === '.' || $item === '..') continue;
              set_permissions_recursively($path . DIRECTORY_SEPARATOR . $item, $perm);
          }
      }
  }
  $system   = detect_system_type();
  $targetDir = __DIR__;
  switch ($system) {
      case 'synology':
          set_permissions_recursively($targetDir, 0777);
          @file_put_contents($targetDir.'/.htpermissions', "Synology : permissions appliquées le ".date('Y-m-d H:i:s'));
          break;
      case 'qnap':
          set_permissions_recursively($targetDir, 0777);
          @file_put_contents($targetDir.'/.qnap_permissions', "QNAP : permissions appliquées le ".date('Y-m-d H:i:s'));
          break;
      case 'ubuntu':
          set_permissions_recursively($targetDir, 0775);
          @file_put_contents($targetDir.'/.ubuntu_permissions', "Ubuntu : permissions appliquées le ".date('Y-m-d H:i:s'));
          break;
      default:
          error_log("Système non reconnu. Permissions non modifiées automatiquement.");
          break;
  }
  ?>
</form>
</body>
</html>
