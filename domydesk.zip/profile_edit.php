<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
$message = $message ?? '';
$themesCatalogUrl = 'https://raw.githubusercontent.com/synohomes/newsdomydesk/main/theme.json';
$message = $message ?? '';
$themesCatalogUrl = 'https://raw.githubusercontent.com/synohomes/newsdomydesk/main/theme.json';
if (isset($_GET['download_theme'])) {
    $themeName   = basename($_GET['download_theme']);
    $themeZipUrl = trim($_GET['theme_url'] ?? '');
    $themeDir    = __DIR__ . '/theme/';
    $logFile     = $themeDir . '_install_log.txt';
    if (!is_dir($themeDir)) { @mkdir($themeDir, 0775, true); }
    $errors = [];
    $notes  = [];
    if ($themeName === '')      { $errors[] = 'Nom de thème vide.'; }
    if ($themeZipUrl === '')    { $errors[] = 'URL du ZIP manquante.'; }
    if (!is_dir($themeDir))     { $errors[] = "Dossier theme/ introuvable: " . $themeDir; }
    if (!is_writable($themeDir)){ $errors[] = "Dossier theme/ non inscriptible: " . $themeDir; }
    $notes[] = 'GET=' . json_encode($_GET);
    $notes[] = 'themeDir=' . realpath($themeDir);
    $notes[] = 'allow_url_fopen=' . (ini_get('allow_url_fopen') ? '1':'0');
    $notes[] = 'curl=' . (function_exists('curl_init') ? '1':'0');
    $notes[] = 'ZipArchive=' . (class_exists('ZipArchive') ? '1':'0');
    if (!$errors) {
        $zipPath = $themeDir . $themeName . '.zip';
        $downloadOk = false;
        $httpCode   = null;
        if (function_exists('curl_init')) {
            $notes[] = 'Try cURL (strict SSL)';
            $ch = curl_init($themeZipUrl);
            $fp = @fopen($zipPath, 'w');
            if ($fp) {
                curl_setopt_array($ch, [
                    CURLOPT_FILE => $fp,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_SSL_VERIFYPEER => true,
                    CURLOPT_CONNECTTIMEOUT => 15,
                    CURLOPT_TIMEOUT => 60,
                    CURLOPT_USERAGENT => 'domydesk-theme-installer'
                ]);
                $downloadOk = curl_exec($ch) !== false;
                $httpCode   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                fclose($fp);
                $downloadOk = $downloadOk && ($httpCode === 200);
            } else {
                $errors[] = 'Impossible d’ouvrir le fichier local pour écrire le ZIP.';
            }
        }
        if (!$downloadOk && function_exists('curl_init')) {
            $notes[] = 'Retry cURL (SSL_VERIFYPEER=0)';
            $ch = curl_init($themeZipUrl);
            $fp = @fopen($zipPath, 'w');
            if ($fp) {
                curl_setopt_array($ch, [
                    CURLOPT_FILE => $fp,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_CONNECTTIMEOUT => 15,
                    CURLOPT_TIMEOUT => 60,
                    CURLOPT_USERAGENT => 'domydesk-theme-installer'
                ]);
                $downloadOk = curl_exec($ch) !== false;
                $httpCode   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                fclose($fp);
                $downloadOk = $downloadOk && ($httpCode === 200);
            }
        }
        if (!$downloadOk && ini_get('allow_url_fopen')) {
            $notes[] = 'Try file_get_contents';
            $data = @file_get_contents($themeZipUrl);
            if ($data !== false) {
                $downloadOk = (@file_put_contents($zipPath, $data) !== false);
                $httpCode   = $downloadOk ? 200 : $httpCode;
            }
        }
        if (!$downloadOk) {
            $errors[] = 'Téléchargement échoué. HTTP=' . var_export($httpCode, true);
        } else {
            if (!is_file($zipPath) || filesize($zipPath) < 100) {
                $errors[] = 'ZIP téléchargé trop petit (corrompu ?).';
            }
        }
        if (!$errors) {
            if (!class_exists('ZipArchive')) {
                $errors[] = 'ZipArchive indisponible sur le serveur.';
            } else {
                $zip = new ZipArchive;
                if ($zip->open($zipPath) === true) {
                    $roots = [];
                    for ($i=0; $i<$zip->numFiles; $i++) {
                        $n = ltrim($zip->getNameIndex($i), '/');
                        if ($n === '') continue;
                        $roots[explode('/', $n)[0] ?? ''] = true;
                    }
                    $hasSingleRoot = (count($roots) === 1);
                    $target = $themeDir . $themeName . '/';
                    if ($hasSingleRoot) {
                        $only = array_keys($roots)[0];
                        if ($only && $only === $themeName) {
                            $target = $themeDir;
                        }
                    }
                    if (!is_dir($target)) { @mkdir($target, 0775, true); }

                    $ok = $zip->extractTo($target);
                    $zip->close();
                    @unlink($zipPath);

                    if (!$ok) {
                        $errors[] = 'Erreur pendant extraction ZIP.';
                    } else {
                        $cssA = $themeDir . $themeName . '/style.css';
                        $cssB = $themeDir . $themeName . '/css/style.css';
                        if (!is_file($cssA) && !is_file($cssB)) {
                            $notes[] = 'Alerte: style.css introuvable à l’endroit attendu.';
                        }
                        $message .= ($message?'<br>':'') . "✅ Thème <b>" . htmlspecialchars($themeName) . "</b> installé.";
                    }
                } else {
                    @unlink($zipPath);
                    $errors[] = 'ZIP illisible (open() a échoué).';
                }
            }
        }
    }
    if ($errors) {
        $message .= ($message?'<br>':'') . '❌ Installation échouée: ' . implode(' | ', $errors);
    }
    @file_put_contents($logFile,
        "=== ".date('c')." ===\n".
        "URL: ".$themeZipUrl."\n".
        "THEME: ".$themeName."\n".
        "NOTES: ".implode(' ; ', $notes)."\n".
        "ERRORS: ".implode(' ; ', $errors)."\n\n",
        FILE_APPEND
    );
}
function getUserFolder($email) {
    return 'users/profiles/' . $email . '/';
}
$isAdmin   = isset($_SESSION['user']['role_system']) && $_SESSION['user']['role_system'] === 'admin';
$userEmail = $_SESSION['user']['email'] ?? '';
$email     = (isset($_GET['email']) && $isAdmin) ? $_GET['email'] : $userEmail;
$userFolder = getUserFolder($email);
$profilePath = $userFolder . 'profile.json';
$menuPath    = $userFolder . 'menu.json';
$modulesPath = $userFolder . 'modules.json';
$avatarPath  = $userFolder . 'avatar.png';
$themePath   = $userFolder . 'theme.json';
$installedThemes = array_map('basename', glob(__DIR__ . "/theme/*", GLOB_ONLYDIR) ?: []);
$theme = 'default';
if (file_exists($themePath)) {
    $themeData = json_decode(file_get_contents($themePath), true);
    if (!empty($themeData['theme']) && file_exists(__DIR__ . "/theme/" . $themeData['theme'] . "/style.css")) {
        $theme = basename($themeData['theme']);
    }
}
function findPhpFiles($dir) {
    $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir));
    $files = [];
    foreach ($rii as $file) {
        if ($file->isFile() && $file->getExtension() === 'php') {
            $relPath = str_replace('\\', '/', substr($file->getPathname(), strlen(getcwd()) + 1));
            if (strpos($relPath, '/vendor/') !== false) continue;
            $files[] = ['label' => ucfirst(basename($file, ".php")), 'link' => $relPath];
        }
    }
    return $files;
}
$availablePages = findPhpFiles(__DIR__);
sort($availablePages);
$baseUrl = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
foreach ($availablePages as &$p) {
    $p['link'] = $baseUrl . '/' . ltrim($p['link'], '/');
}
unset($p);
$userData    = file_exists($profilePath) ? json_decode(file_get_contents($profilePath), true) : [];
$menuDataRaw = file_exists($menuPath) ? json_decode(file_get_contents($menuPath), true) : [];
$menuData    = $menuDataRaw['items']['items'] ?? [];

$rolesFile   = 'data/roles_metier.json';
$rolesMetiers = file_exists($rolesFile) ? json_decode(file_get_contents($rolesFile), true) : [];

$modulesList = file_exists($modulesPath) ? json_decode(file_get_contents($modulesPath), true) : [];
$isSelf = ($email === $userEmail);
$existingHash = $userData['motdepasse'] ?? ($userData['password'] ?? null);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['update_profile'])) {
        $userData['prenom']      = $_POST['first_name'] ?? '';
        $userData['nom']         = $_POST['last_name'] ?? '';
        $userData['role_metier'] = $_POST['job_role'] ?? '';
        $userData['adresse']     = $_POST['adresse'] ?? '';
        if (!is_dir($userFolder)) mkdir($userFolder, 0755, true);
        file_put_contents($profilePath, json_encode($userData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $message = "Profil mis à jour avec succès.";
    }
    elseif (isset($_POST['upload_avatar'])) {
        if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
            $allowed = ['png', 'jpg', 'jpeg', 'webp'];
            if (in_array($ext, $allowed)) {
                if (!is_dir($userFolder)) mkdir($userFolder, 0755, true);
                move_uploaded_file($_FILES['avatar']['tmp_name'], $avatarPath);
                $message = "Avatar mis à jour avec succès.";
            } else {
                $message = "❌Format avatar non autorisé.";
            }
        } else {
            $message = "❌Erreur upload avatar.";
        }
    }
    elseif (isset($_POST['update_theme'])) {
        $themeChoice = basename($_POST['theme'] ?? 'default');
        file_put_contents($themePath, json_encode(['theme' => $themeChoice], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $redir = 'profile_edit.php';
        if ($isAdmin && isset($_GET['email'])) {
            $redir .= '?email=' . urlencode($_GET['email']);
        }
        header("Location: $redir");
        exit;
    }
    elseif (isset($_POST['import_theme'])) {
        if (!class_exists('ZipArchive')) {
            $message = "❌ ZipArchive non disponible sur le serveur.";
        } elseif (isset($_FILES['theme_zip']) && is_uploaded_file($_FILES['theme_zip']['tmp_name'])) {
            $zipPath = $_FILES['theme_zip']['tmp_name'];
            $zip = new ZipArchive;
            if ($zip->open($zipPath) === TRUE) {
                $folderName = basename($_FILES['theme_zip']['name'], '.zip');
                $extractPath = __DIR__ . "/theme/" . $folderName;
                if (!is_dir("theme")) mkdir("theme", 0755, true);
                if (!is_dir($extractPath)) mkdir($extractPath, 0755, true);
                $zip->extractTo($extractPath);
                $zip->close();
                $message = "Thème importé avec succès.";
            } else {
                $message = "❌ Impossible d’ouvrir le fichier ZIP.";
            }
        } else {
            $message = "❌ Erreur lors de l’import du fichier ZIP.";
        }
    }
    elseif (isset($_POST['update_menu'])) {
        $menuJson = $_POST['menu_json'] ?? '';
        $decodedMenu = json_decode($menuJson, true);
        if (is_array($decodedMenu)) {
            foreach ($decodedMenu as &$item) {
                if (($item['type'] ?? '') === 'page' && isset($item['link']) && strpos($item['link'], '/domydesk/') !== 0) {
                    $item['link'] = '/domydesk/' . ltrim($item['link'], '/');
                }
                if (!empty($item['submenu']) && is_array($item['submenu'])) {
                    foreach ($item['submenu'] as &$sub) {
                        if (($sub['type'] ?? '') === 'page' && isset($sub['link']) && strpos($sub['link'], '/domydesk/') !== 0) {
                            $sub['link'] = '/domydesk/' . ltrim($sub['link'], '/');
                        }
                    }
                }
            }
            $fullMenu = ['items' => ['items' => $decodedMenu]];
            if (!is_dir($userFolder)) mkdir($userFolder, 0755, true);
            file_put_contents($menuPath, json_encode($fullMenu, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            $menuData = $decodedMenu;
            $message = "✅ Menu latéral mis à jour.";
        } else {
            $message = "❌ Format JSON du menu invalide.";
        }
    }
elseif (isset($_POST['change_password'])) {
    $new1 = $_POST['new_password'] ?? '';
    $new2 = $_POST['new_password_confirm'] ?? '';
    $old  = $_POST['current_password'] ?? '';

    if (strlen($new1) < 8) {
        $message = "❌ Nouveau mot de passe trop court (min 8 caractères).";
    } elseif ($new1 !== $new2) {
        $message = "❌ La confirmation ne correspond pas.";
    } else {
        $changingOwn = ($email === $userEmail) || !$isAdmin;


        if ($changingOwn && !empty($existingHash)) {
            if (!password_verify($old, $existingHash)) {
                $message = "❌ Ancien mot de passe incorrect.";
               
                goto end_change_pwd;
            }
        }
        $newHash = password_hash($new1, PASSWORD_DEFAULT);
        $userData['motdepasse'] = $newHash;
        $userData['password'] = $newHash;
        if (isset($userData['password_hash'])) unset($userData['password_hash']);

        if (!is_dir($userFolder)) mkdir($userFolder, 0755, true);
        file_put_contents($profilePath, json_encode($userData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

        $message = $changingOwn ? "✅ Mot de passe mis à jour." : "✅ Mot de passe réinitialisé pour l’utilisateur.";
    }
    end_change_pwd: ;
}
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>DoMyDesk - Settings</title>
<?php
$themeFile = __DIR__ . "/theme/$theme/style.css";
$baseUrl   = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$themeHref = $baseUrl . "/theme/" . rawurlencode($theme) . "/style.css";
if (is_file($themeFile)) {
    $themeHref .= '?v=' . filemtime($themeFile);
}
?>
    <link rel="stylesheet" href="<?= htmlspecialchars($themeHref) ?>">
    <style>
        .profile-edit { margin: 0 auto; }
        .profile-edit .spacer { height: 25px; }
        .profile-edit .accordion-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(320px, 1fr));
            gap: 16px;
            align-items: start;
        }
        @media (max-width: 1100px) {
            .profile-edit .accordion-grid { grid-template-columns: 1fr; }
        }
        .profile-edit .accordion {
            border-radius: 12px;
            box-shadow: 0 4px 16px rgba(0,0,0,.25);
            overflow: hidden;
            background: var(--card-bg, rgba(0,0,0,0.2));
            border: 1px solid var(--primary-dark, rgba(255,255,255,0.08));
        }
        .profile-edit .accordion summary {
            list-style: none;
            cursor: pointer;
            padding: 14px 16px;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            background: linear-gradient(0deg, rgba(0,0,0,0.08), rgba(255,255,255,0.06));
            user-select: none;
        }
        .profile-edit .accordion summary::-webkit-details-marker { display: none; }
        .profile-edit .accordion .chevron { transition: transform .25s ease; font-size: 1.8em; opacity: .85; }
        .profile-edit details[open] .chevron { transform: rotate(180deg); }
        .profile-edit .accordion .content {
            padding: 16px;
            border-top: 1px solid rgba(255,255,255,0.06);
            animation: accordionIn .2s ease;
        }
        @keyframes accordionIn { from { opacity: 0; transform: translateY(-4px); } to { opacity: 1; transform: translateY(0); } }
        .profile-edit form > label { display:block; margin: 8px 0 4px; }
        .profile-edit form > input[type="text"],
        .profile-edit form > input[type="password"],
        .profile-edit form > select,
        .profile-edit form > input[type="file"] { width: 100%; }
        .profile-edit .avatar { width: 96px; height: 96px; border-radius: 50%; object-fit: cover; display:block; margin: 6px 0 12px 0; border: 1px solid rgba(255,255,255,0.08); }
        .profile-edit .theme-preview-section { margin-top: 10px; }
        .profile-edit .theme-preview-box { width: 100%; max-width: 380px; aspect-ratio: 16/9; border: 1px dashed rgba(255,255,255,0.2); display:flex; align-items:center; justify-content:center; border-radius: 10px; overflow:hidden; }
        .profile-edit #theme-preview-img { max-width:100%; max-height:100%; display:block; }
        .profile-edit .message { margin: 12px 0; padding: 10px 12px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.15); background: rgba(0,0,0,0.25); }
        .profile-edit .menu-list, .profile-edit .submenu-list { list-style: none; padding-left: 0; }
        .profile-edit .menu-list > li, .profile-edit .submenu-list > li {
            display: flex; flex-wrap: wrap; gap: 8px; align-items: center;
            padding: 8px; margin: 6px 0; border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; background: rgba(0,0,0,0.15);
        }
        .profile-edit .btn-sm { padding: 6px 10px; border-radius: 8px; border: none; cursor: pointer; background: var(--primary-color, #555); color: #fff; }
        .profile-edit .btn-add { opacity: .9; }
        .profile-edit .btn-del { background: #b33; }
        .profile-edit .sections-modules { margin-top: 50px; padding-top: 10px; }
        .profile-edit .cfg-break-title { font-size: 1.8em; font-weight: 600; letter-spacing: 0.5px; margin: 0 0 20px; text-align: center; display: flex; justify-content: center; align-items: center; gap: 6px; opacity: 0.85; }
        .profile-edit .module-cfg-wrap {
            border: 1px solid rgba(255,255,255,0.10);
            border-radius: 14px;
            padding: 10px 12px;
            margin-bottom: 22px;
            background: rgba(0,0,0,0.15);
            box-shadow: 0 0 0 2px rgba(255,255,255,0.04) inset, 0 10px 24px rgba(0,0,0,0.35);
            transition: box-shadow .2s ease, border-color .2s ease;
        }
        .profile-edit .module-cfg-wrap:hover { box-shadow: 0 0 0 2px rgba(255,255,255,0.08) inset, 0 12px 28px rgba(0,0,0,0.45); border-color: rgba(255,255,255,0.16); }
    </style>
</head>
<body>
<div class="profile-edit container">
    <?php include 'header.php'; ?>
    <div class="spacer"></div>
    <?php if ($message): ?>
    <div class="message"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
 <h2 class="cfg-break-title">Configurations</h2>
    <div class="accordion-grid">
<details class="accordion" data-acc-key="pe_profile">
  <summary>
    <span>>> Votre profil</span>
  </summary>
  <div class="content">
    <form method="POST" autocomplete="off">
      <input type="hidden" name="update_profile" value="1">
      <label>Prénom :</label>
      <input type="text" name="first_name" value="<?= htmlspecialchars($userData['prenom'] ?? '') ?>" required>
      <label>Nom :</label>
      <input type="text" name="last_name" value="<?= htmlspecialchars($userData['nom'] ?? '') ?>" required>
      <label>Rôle Métier :</label>
      <select name="job_role" required>
        <option value="">-- Sélectionner --</option>
        <?php foreach ($rolesMetiers as $role):
          $val = is_array($role) ? ($role['label'] ?? $role['value'] ?? '') : $role;
          $selected = ($userData['role_metier'] ?? '') === $val ? 'selected' : ''; ?>
          <option value="<?= htmlspecialchars($val) ?>" <?= $selected ?>><?= htmlspecialchars($val) ?></option>
        <?php endforeach; ?>
      </select>
      <label>Adresse :</label>
      <input type="text" name="adresse" value="<?= htmlspecialchars($userData['adresse'] ?? '') ?>">
      <button type="submit">Enregistrer</button>
    </form>
  </div>
</details>
<details class="accordion" data-acc-key="pe_security">
  <summary>
    <span>>> Mot de passe</span>
  </summary>
  <div class="content">
    <form method="POST" autocomplete="off">
      <input type="hidden" name="change_password" value="1">
      <?php if ($isSelf || !$isAdmin || $email === $userEmail): ?>
        <?php if (!empty($existingHash)): ?>
          <label>Ancien mot de passe :</label>
          <input type="password" name="current_password" placeholder="Ancien mot de passe" required>
        <?php else: ?>
          <p style="opacity:.8;margin:0 0 8px 0;">Aucun mot de passe défini encore pour ce compte.</p>
        <?php endif; ?>
      <?php else: ?>
        <p style="opacity:.8;margin:0 0 8px 0;">Administrateur : réinitialisation sans ancien mot de passe pour <b><?= htmlspecialchars($email) ?></b>.</p>
      <?php endif; ?>
      <label>Nouveau mot de passe :</label>
      <input type="password" name="new_password" placeholder="Min 8 caractères" minlength="8" required>
      <label>Confirmer le nouveau mot de passe :</label>
      <input type="password" name="new_password_confirm" placeholder="Répétez le mot de passe" minlength="8" required>
      <button type="submit">Mettre à jour le mot de passe</button>
    </form>
  </div>
</details>
<details class="accordion" data-acc-key="pe_avatar_theme">
            <summary>
             <span>>> Avatar & Thème</span>
                
            </summary>
            <div class="content">
                <?php
                $hasBackup = false;
                foreach ($modulesList as $mod) {
                    if (!empty($mod['enabled']) && $mod['id'] === 'savev.1') { $hasBackup = true; break; }
                }
                ?>
                <?php if ($hasBackup): ?>
                    <p style="margin:0 0 8px 0;">
                        <a href="modules/savev.1/download.php" title="Sauvegarder mon profil" style="text-decoration:none;">
                            >> 📥 <span style="font-size:12px; opacity:.12;"></span>
                        </a>
                    </p>
                <?php endif; ?>
                <?php if (file_exists($avatarPath)): ?>
                    <img class="avatar" src="<?= htmlspecialchars($avatarPath) ?>?t=<?= time() ?>" alt="Avatar">
                <?php else: ?>
                    <p>Aucun avatar défini</p>
                <?php endif; ?>
                <form method="POST" enctype="multipart/form-data" style="margin-bottom:12px;">
                    <input type="hidden" name="upload_avatar" value="1">
                    <label>Changer d'avatar :</label>
                    <input type="file" name="avatar" accept="image/*" required>
                    <button type="submit">Mettre à jour</button>
                </form>
                <form method="POST" style="margin-bottom:12px;">
                    <input type="hidden" name="update_theme" value="1">
                    <label>Choisir un thème :</label>
                    <select name="theme">
                        <?php foreach (glob("theme/*", GLOB_ONLYDIR) as $dir):
                            $dirName  = basename($dir);
                            $selected = $theme === $dirName ? 'selected' : ''; ?>
                            <option value="<?= $dirName ?>" <?= $selected ?>><?= ucfirst($dirName) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit">Changer le thème</button>
                    <button type="button" id="openThemesGallery" style="margin-left:8px">Parcourir les thèmes (Bientôt)</button>
                    <div class="theme-preview-section">
                        <label>Aperçu du thème sélectionné :</label>
                        <div class="theme-preview-box">
                            <img id="theme-preview-img" src="" alt="Aperçu du thème" />
                        </div>
                    </div>
                </form>
                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="import_theme" value="1">
                    <label>Importer un thème (.zip) :</label>
                    <input type="file" name="theme_zip" accept=".zip" required>
                    <button type="submit">Importer</button>
                </form>
            </div>
        </details>
        <details class="accordion" data-acc-key="pe_menu">
            <summary>
             <span>>> Menu vertical</span>
            </summary>
            <div class="content">
                <form method="POST" onsubmit="prepareMenuJson();">
                    <input type="hidden" name="update_menu" value="1">
                    <input type="hidden" id="menu_json" name="menu_json">
                    <ul class="menu-list" id="menuList"></ul>
                    <button type="button" class="btn-sm btn-add" onclick="addMenuItem()">+ Ajouter un élément</button><br><br>
                    <button type="submit">Enregistrer le menu</button>
                </form>
            </div>
        </details>
        <?php if ($isAdmin): ?>
        <details class="accordion" data-acc-key="pe_admin_news">
            <summary>
                <span>>> Actualités</span>
            </summary>
            <div class="content">
                <div class="section section-col" style="margin:0;">
                    <?php include __DIR__ . "/data/news/newscfg.php"; ?>
                </div>
            </div>
        </details>
        <?php endif; ?>
    </div>
<div class="sections-modules" id="modules">
  <h2 class="cfg-break-title">Configuration des modules</h2>
  <?php
  $cards = [];
  if (!empty($modulesList) && is_array($modulesList)) {
    foreach ($modulesList as $mod) {
      if (!empty($mod['enabled']) && !empty($mod['id'])) {
        $mid = basename($mod['id']);
        $cfg = __DIR__."/modules/$mid/{$mid}cfg.php";
        if (is_file($cfg)) $cards[] = ['id'=>$mid, 'name'=>strtoupper($mid)];
      }
    }
  }
  ?>
  <?php if (empty($cards)): ?>
    <div class="message">Aucun module configurable.</div>
  <?php else: ?>
    <div class="mod-grid" id="mod-grid">
      <?php foreach ($cards as $c): ?>
        <button type="button" class="mod-card" data-mod="<?= htmlspecialchars($c['id']) ?>">
          <span class="mod-card-title"><?= htmlspecialchars($c['name']) ?></span>
          <span style="opacity:.75"></span>
        </button>
      <?php endforeach; ?>
    </div>
    <div id="mod-host" class="mod-host" style="display:none;">
      <div class="mod-host-bar">
        <h3 id="mod-host-title" class="mod-host-title">Configuration</h3>
        <div class="mod-host-actions">
          <button type="button" id="mod-close" class="btn-sm">Fermer</button>
         <a id="mod-open" class="" href="" target="_blank" rel="noopener"></a>
        </div>
      </div>
      <iframe id="mod-iframe" title="Module config" loading="lazy"></iframe>
    </div>
  <?php endif; ?>
</div>
</div>
<style>
.mod-grid{
  display:grid; grid-template-columns:repeat(auto-fill,minmax(220px,1fr));
  gap:14px; margin-bottom:14px;
}
.mod-card{
  display:flex; flex-direction:column; gap:6px; padding:12px 14px;
  border:1px solid rgba(255,255,255,.10); border-radius:12px;
  background:rgba(0,0,0,.18); cursor:pointer; text-align:left;
  color:inherit; text-decoration:none; transition:box-shadow .2s, border-color .2s;
}
.mod-card:hover{ border-color:rgba(255,255,255,.22); box-shadow:0 10px 24px rgba(0,0,0,.35); }
.mod-card-title{ font-weight:700; }

.mod-host{ margin-top:14px; border:1px solid rgba(255,255,255,.14); border-radius:12px; background:rgba(0,0,0,.12); }
.mod-host-bar{ display:flex; align-items:center; justify-content:space-between; gap:8px; padding:10px 14px; border-bottom:1px solid rgba(255,255,255,.12); }
.mod-host-title{ margin:0; font-weight:700; letter-spacing:.3px; }
.mod-host-actions{ display:flex; gap:8px; }
#mod-iframe{ width:100%; border:0; display:block; }
</style>
<script>
const availablePages = <?= json_encode($availablePages, JSON_UNESCAPED_UNICODE) ?>;
const menuData = <?= json_encode($menuData, JSON_UNESCAPED_UNICODE) ?>;
const normLink = (s) => (s || '')
  .replace(/^\/+/, '')         
  .replace(/^domydesk\//, ''); 
function createMenuItem(item = {}) {
    const li = document.createElement('li');
    const input = document.createElement('input');
    input.type = 'text';
    input.placeholder = 'Libellé';
    input.value = item.label || '';
    const selectType = document.createElement('select');
    selectType.innerHTML = `
        <option value="none">Pas de lien</option>
        <option value="page">Page</option>
        <option value="link">Lien externe</option>
    `;
    selectType.value = item.type || 'none';
    const selectPage = document.createElement('select');
    selectPage.innerHTML = [
        `<option value="">-- choisir une page --</option>`,
        ...availablePages.map(p =>
            `<option value="${p.link}" ${normLink(p.link) === normLink(item.link) ? 'selected' : ''}>${p.label}</option>`
        )
    ].join('');
    selectPage.style.display = item.type === 'page' ? 'inline-block' : 'none';
    const inputLink = document.createElement('input');
    inputLink.type = 'text';
    inputLink.placeholder = 'https://...';
    inputLink.value = item.type === 'link' ? (item.link || '') : '';
    inputLink.style.display = item.type === 'link' ? 'inline-block' : 'none';
    selectType.onchange = () => {
        if (selectType.value === 'page') {
            selectPage.style.display = 'inline-block';
            inputLink.style.display = 'none';
        } else if (selectType.value === 'link') {
            selectPage.style.display = 'none';
            inputLink.style.display = 'inline-block';
        } else {
            selectPage.style.display = 'none';
            inputLink.style.display = 'none';
        }
    };
    const addSubBtn = document.createElement('button');
    addSubBtn.type = 'button';
    addSubBtn.textContent = '+';
    addSubBtn.className = 'btn-sm btn-add';
    const subList = document.createElement('ul');
    subList.className = 'submenu-list';
    (item.submenu || []).forEach(sub => subList.appendChild(createSubItem(sub)));
    addSubBtn.onclick = () => subList.appendChild(createSubItem());
    const delBtn = document.createElement('button');
    delBtn.type = 'button';
    delBtn.textContent = '×';
    delBtn.className = 'btn-sm btn-del';
    delBtn.onclick = () => li.remove();
    li.append(input, selectType, selectPage, inputLink, addSubBtn, delBtn, subList);
    return li;
}
function createSubItem(sub = {}) {
    const li = document.createElement('li');
    const input = document.createElement('input');
    input.type = 'text';
    input.placeholder = 'Sous-libellé';
    input.value = sub.label || '';
    const selectType = document.createElement('select');
    selectType.innerHTML = `
        <option value="none">Pas de lien</option>
        <option value="page">Page</option>
        <option value="link">Lien externe</option>
    `;
    selectType.value = sub.type || 'none';

    const selectPage = document.createElement('select');
    selectPage.innerHTML = [
        `<option value="">-- choisir une page --</option>`,
        ...availablePages.map(p =>
            `<option value="${p.link}" ${normLink(p.link) === normLink(sub.link) ? 'selected' : ''}>${p.label}</option>`
        )
    ].join('');
    selectPage.style.display = sub.type === 'page' ? 'inline-block' : 'none';
    const inputLink = document.createElement('input');
    inputLink.type = 'text';
    inputLink.placeholder = 'https://...';
    inputLink.value = sub.type === 'link' ? (sub.link || '') : '';
    inputLink.style.display = sub.type === 'link' ? 'inline-block' : 'none';
    selectType.onchange = () => {
        if (selectType.value === 'page') {
            selectPage.style.display = 'inline-block';
            inputLink.style.display = 'none';
        } else if (selectType.value === 'link') {
            selectPage.style.display = 'none';
            inputLink.style.display = 'inline-block';
        } else {
            selectPage.style.display = 'none';
            inputLink.style.display = 'none';
        }
    };
    const delBtn = document.createElement('button');
    delBtn.type = 'button';
    delBtn.textContent = '×';
    delBtn.className = 'btn-sm btn-del';
    delBtn.onclick = () => li.remove();
    li.append(input, selectType, selectPage, inputLink, delBtn);
    return li;
}
function addMenuItem() {
    document.getElementById('menuList').appendChild(createMenuItem());
}
function prepareMenuJson() {
    const items = [];
    document.querySelectorAll('#menuList > li').forEach(li => {
        const label = li.querySelector('input[type=text]')?.value.trim();
        const selects = li.querySelectorAll('select');
        const type   = selects[0]?.value;
        const link   = (type === 'page')
            ? selects[1]?.value
            : (type === 'link') ? li.querySelector('input[placeholder="https://..."]')?.value.trim() : '';
        const submenu = [];
        li.querySelectorAll('.submenu-list > li').forEach(sub => {
            const subLabel = sub.querySelector('input[type=text]')?.value.trim();
            const subSelects = sub.querySelectorAll('select');
            const subType = subSelects[0]?.value;
            const subLink = (subType === 'page')
                ? subSelects[1]?.value
                : (subType === 'link') ? sub.querySelector('input[placeholder="https://..."]')?.value.trim() : '';
            if (subLabel) submenu.push({ label: subLabel, type: subType, link: subLink, submenu: [] });
        });
        if (label) items.push({ label, type, link, submenu });
    });
    document.getElementById('menu_json').value = JSON.stringify(items, null, 2);
}
window.addEventListener('DOMContentLoaded', () => {
    (menuData || []).forEach(item => document.getElementById('menuList').appendChild(createMenuItem(item)));
    const select = document.querySelector('select[name="theme"]');
    const previewImg = document.getElementById('theme-preview-img');
    function updatePreview() {
        const theme = select.value;
        previewImg.src = `theme/${theme}/theme.png`;
    }
    if (select && previewImg) {
        select.addEventListener('change', updatePreview);
        updatePreview();
    }
    document.querySelectorAll('.accordion').forEach(details => {
        const key = details.getAttribute('data-acc-key');
        const saved = localStorage.getItem(key);
        if (saved === 'closed') details.removeAttribute('open');
        if (saved === 'open') details.setAttribute('open', 'open');
        details.addEventListener('toggle', () => {
            localStorage.setItem(key, details.open ? 'open' : 'closed');
        });
    });
});
</script>
<div id="themesPopup" class="th-popup-overlay" style="display:none;">
  <div class="th-popup">
    <div class="th-popup-header">
      <h2 style="margin:0;display:flex;align-items:center;gap:8px;"> Thèmes</h2>
      <button type="button" id="closeThemesPopup" class="th-btn">✖</button>
    </div>
    <div class="th-popup-body">
      <div class="th-hint" style="margin-bottom:10px;opacity:.85;">
        Survolez la <strong>loupe</strong>pour voir la miniature.
        <span style="margin-left:10px;">✅ = installé, ⬇️ = disponible</span>
      </div>
      <table class="th-table" id="themesTable">
        <thead>
          <tr>
            <th>Nom</th>
            <th>Description</th>
            <th style="width:110px;">Aperçu</th>
            <th style="width:110px;">Statut</th>
            <th style="width:120px;">Action</th>
          </tr>
        </thead>
        <tbody></tbody>
      </table>
      <div id="previewFloat" class="th-preview-float" style="display:none;">
        <img id="previewImg" src="" alt="preview">
      </div>
    </div>
  </div>
</div>
<style>
.th-popup-overlay{ position:fixed; inset:0; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,.65); z-index:9999; }
.th-popup{ width:min(1000px, 96vw); max-height:88vh; overflow:auto; background:rgba(0,0,0,.25); border:1px solid rgba(255,255,255,.12); border-radius:12px; box-shadow:0 20px 60px rgba(0,0,0,.45); }
.th-popup-header{ display:flex; align-items:center; justify-content:space-between; gap:8px; padding:12px 14px; border-bottom:1px solid rgba(255,255,255,.08); background: linear-gradient(0deg, rgba(255,255,255,.04), rgba(255,255,255,.06)); }
.th-popup-body{ padding:14px; }

.th-table{ width:100%; border-collapse:collapse; color:inherit; }
.th-table th, .th-table td{ border-bottom:1px solid rgba(255,255,255,.08); padding:10px; vertical-align:middle; }
.th-table th{ background:rgba(255,255,255,.06); text-align:left; font-weight:700; }

.th-btn{ background: var(--primary-color, #555); color:#fff; border:none; cursor:pointer; padding:8px 12px; border-radius:8px; }
.th-btn:hover{ filter:brightness(1.1); }

.th-loupe{ cursor:zoom-in; user-select:none; display:inline-flex; align-items:center; gap:6px; }
.th-loupe .icon{ font-size: 18px; }

.th-status{ display:flex; align-items:center; gap:6px; }
.th-action{ display:flex; gap:8px; }

.th-preview-float{ position:fixed; pointer-events:none; z-index:10000; border:1px solid rgba(255,255,255,.2); border-radius:8px; overflow:hidden; box-shadow:0 10px 30px rgba(0,0,0,.5); background:#000; }
.th-preview-float img{ display:block; width:240px; height:auto; }
</style>
<script>
(() => {
  const themeHref = <?= json_encode($themeHref, JSON_UNESCAPED_SLASHES) ?>;
  const grid  = document.getElementById('mod-grid');
  const host  = document.getElementById('mod-host');
  const title = document.getElementById('mod-host-title');
  const btnClose = document.getElementById('mod-close');
  const aOpen = document.getElementById('mod-open');
  const frame = document.getElementById('mod-iframe');
  function openModule(id, label){
    const url = `modules/${id}/${id}cfg.php?embed=1`;
    title.textContent = label || id.toUpperCase();
    aOpen.href = url;
    host.style.display = 'block';
    frame.style.height = '1px';
    frame.src = url;
    host.scrollIntoView({behavior:'smooth', block:'start'});
  }
  let rafToken = null;
  window.addEventListener('message', (ev) => {
    if (!ev || !ev.data || ev.source !== frame.contentWindow) return;
    if (ev.data.type !== 'iframe-size') return;
    const nextH = Math.max(0, Math.min(ev.data.height|0, 50000)); // clamp
    if (rafToken) cancelAnimationFrame(rafToken);
    rafToken = requestAnimationFrame(() => {
      const cur = parseInt(frame.style.height || '0', 10) || 0;
      if (Math.abs(nextH - cur) >= 2) frame.style.height = nextH + 'px';
    });
  }, false);
  frame.addEventListener('load', () => {
    try {
      const doc = frame.contentDocument || frame.contentWindow.document;
      const hasTheme = [...doc.querySelectorAll('link[rel="stylesheet"]')]
                        .some(l => l.href && l.href.includes('/theme/'));
      if (!hasTheme && themeHref){
        const link = doc.createElement('link');
        link.rel = 'stylesheet';
        link.href = themeHref;
        doc.head.appendChild(link);
      }
      const style = doc.createElement('style');
      style.textContent = `html, body { overflow:hidden !important; }`;
      doc.head.appendChild(style);
      const s = doc.createElement('script');
      s.text = `
        (function(){
          function send(){
            try {
              var h = Math.max(
                document.documentElement.scrollHeight || 0,
                document.body ? document.body.scrollHeight : 0
              );
              parent.postMessage({type:'iframe-size', height:h}, '*');
            } catch(e){}
          }
          var ro = window.ResizeObserver ? new ResizeObserver(send) : null;
          if (ro && document.body) ro.observe(document.body);
          var mo = new MutationObserver(function(){ setTimeout(send,0); });
          mo.observe(document.documentElement, {subtree:true, childList:true, attributes:true, characterData:true});
          window.addEventListener('load', function(){
            setTimeout(send,10); setTimeout(send,300); setTimeout(send,1200);
          });
          setTimeout(send, 10);
        })();
      `;
      doc.body.appendChild(s);
    } catch(e) { console.error(e); }
  });
  grid?.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-mod]'); if (!btn) return;
    const id = btn.getAttribute('data-mod');
    const label = btn.querySelector('.mod-card-title')?.textContent || id.toUpperCase();
    openModule(id, label);
  });
  btnClose?.addEventListener('click', () => {
    frame.src = 'about:blank';
    frame.style.height = '1px';
    host.style.display = 'none';
    history.replaceState({}, '', location.pathname);
  });
  const params = new URLSearchParams(location.search);
  const qmod = params.get('mod');
  if (qmod){
    const label = (document.querySelector(`[data-mod="${qmod}"] .mod-card-title`)?.textContent)||qmod.toUpperCase();
    openModule(qmod, label);
  }
})();
</script>
<script>
(() => {
  const THEMES_JSON_URL = <?= json_encode($themesCatalogUrl, JSON_UNESCAPED_SLASHES) ?>;
  const INSTALLED = <?= json_encode($installedThemes, JSON_UNESCAPED_UNICODE) ?>; // ex: ["blue","green",...]
  const btnOpen   = document.getElementById('openThemesGallery');
  const popup     = document.getElementById('themesPopup');
  const btnClose  = document.getElementById('closeThemesPopup');
  const tbody     = document.querySelector('#themesTable tbody');
  const floatPrev = document.getElementById('previewFloat');
  const floatImg  = document.getElementById('previewImg');
  const slugify = (s='') =>
    String(s).toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'');
  const isImage = (url='') => /\.(png|jpe?g|webp|gif|avif|svg)(\?|#|$)/i.test(url);
  const isPdf   = (url='') => /\.pdf(\?|#|$)/i.test(url);
  function openPopup()  { popup.style.display = 'flex'; document.body.style.overflow = 'hidden'; }
  function closePopup() { popup.style.display = 'none'; document.body.style.overflow = ''; }
  function renderRow(item){
    const name = item.name || 'Sans nom';
    const id   = item.id ? String(item.id) : slugify(name);
    const desc = item.description || '';
    const date = item.date ? ` (${item.date})` : '';
    const img  = item.image || '';
    const dl   = item.dl || '';
    const size = item.size ? ` · ${item.size}` : '';
    const installed = INSTALLED.includes(id);
    let previewCell = '';
    if (isImage(img)) {
      previewCell = `
        <span class="th-loupe" data-preview="${img}">
          <span class="icon">🔍</span> Voir
        </span>
      `;
    } else if (isPdf(img)) {
      previewCell = `<a class="th-btn" href="${img}" target="_blank" rel="noopener">Aperçu PDF</a>`;
    } else if (img) {
      previewCell = `<a class="th-btn" href="${img}" target="_blank" rel="noopener">Aperçu</a>`;
    } else {
      previewCell = `<span style="opacity:.6">—</span>`;
    }
    const statusCell = installed
      ? `<div class="th-status">✅ Installé</div>`
      : `<div class="th-status">⬇️ Disponible</div>`;
    const installUrl = `${location.pathname}?download_theme=${encodeURIComponent(id)}&theme_url=${encodeURIComponent(dl)}#themes`;
    const actions = [];
    if (dl) {
      if (!installed) {
        actions.push(`<a class="th-btn" href="${installUrl}">Télécharger & Installer</a>`);
      } else {
        actions.push(`<button class="th-btn" data-apply="${id}">Appliquer</button>`);
      }
    }
    if (!dl) actions.push(`<span style="opacity:.6">Pas de ZIP</span>`);
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${name}</strong>${date}</td>
      <td>${desc}${size}</td>
      <td style="width:110px">${previewCell}</td>
      <td style="width:110px">${statusCell}</td>
      <td style="width:120px" class="th-action">${actions.join(' ')}</td>
    `;
    const loupe = tr.querySelector('.th-loupe');
    if (loupe) {
      loupe.addEventListener('mouseenter', (e) => {
        const url = loupe.getAttribute('data-preview');
        if (!url) return;
        floatImg.src = url;
        floatPrev.style.display = 'block';
        positionFloat(e);
      });
      loupe.addEventListener('mousemove', positionFloat);
      loupe.addEventListener('mouseleave', () => {
        floatPrev.style.display = 'none';
        floatImg.src = '';
      });
    }
    tr.querySelectorAll('[data-apply]').forEach(btn => {
      btn.addEventListener('click', () => {
        const themeSelect = document.querySelector('select[name="theme"]');
        if (!themeSelect) return;
        themeSelect.value = btn.getAttribute('data-apply'); 
        const form = themeSelect.closest('form');
        if (form) {
          let hidden = form.querySelector('input[name="update_theme"]');
          if (!hidden) {
            hidden = document.createElement('input');
            hidden.type = 'hidden';
            hidden.name = 'update_theme';
            hidden.value = '1';
            form.appendChild(hidden);
          }
          form.submit();
        }
      });
    });

    return tr;
  }
  function positionFloat(e){
    const pad = 16;
    floatPrev.style.left = (e.clientX + pad) + 'px';
    floatPrev.style.top  = (e.clientY + pad) + 'px';
  }
  async function loadThemes(){
    tbody.innerHTML = `<tr><td colspan="5" style="opacity:.7">Chargement…</td></tr>`;
    try {
      const res = await fetch(THEMES_JSON_URL, {cache:'no-store'});
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();

      const items = Array.isArray(data) ? data : (Array.isArray(data.items) ? data.items : []);
      if (!items.length) {
        tbody.innerHTML = `<tr><td colspan="5" style="opacity:.7">Aucun thème dans le catalogue.</td></tr>`;
        return;
      }
      tbody.innerHTML = '';
      items.forEach(item => tbody.appendChild(renderRow(item)));
    } catch (err) {
      console.error(err);
      tbody.innerHTML = `<tr><td colspan="5" style="color:#f66">Erreur de chargement du catalogue.</td></tr>`;
    }
  }
  btnOpen?.addEventListener('click', () => {
    btnOpen.textContent = 'Parcourir les thèmes';
    openPopup();
    loadThemes();
  });
  btnClose?.addEventListener('click', closePopup);
  popup?.addEventListener('click', (e) => {
    if (e.target === popup) closePopup(); // clic hors de la fenêtre
  });
})();
</script>
<div id="themesPopup" class="th-popup-overlay" style="display:none;">
  <div class="th-popup">
    <div class="th-popup-header">
      <h2 style="margin:0;display:flex;align-items:center;gap:8px;">🎨 Galerie des thèmes</h2>
      <button type="button" id="closeThemesPopup" class="th-btn">✖</button>
    </div>
    <div class="th-popup-body">
      <div class="th-hint" style="margin-bottom:10px;opacity:.85;">
        Survolez la <strong>loupe</strong> pour voir la miniature.
        <span style="margin-left:10px;">✅ = installé, ⬇️ = disponible</span>
      </div>
      <table class="th-table" id="themesTable">
        <thead>
          <tr>
            <th>Nom</th>
            <th>Description</th>
            <th style="width:110px;">Aperçu</th>
            <th style="width:110px;">Statut</th>
            <th style="width:140px;">Action</th>
          </tr>
        </thead>
        <tbody></tbody>
      </table>
      <div id="previewFloat" class="th-preview-float" style="display:none;">
        <img id="previewImg" src="" alt="preview">
      </div>
    </div>
  </div>
</div>
<style>
.th-popup-overlay{ position:fixed; inset:0; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,.65); z-index:9999; }
.th-popup{ width:min(1000px, 96vw); max-height:88vh; overflow:auto; background:rgba(0,0,0,.25); border:1px solid rgba(255,255,255,.12); border-radius:12px; box-shadow:0 20px 60px rgba(0,0,0,.45); }
.th-popup-header{ display:flex; align-items:center; justify-content:space-between; gap:8px; padding:12px 14px; border-bottom:1px solid rgba(255,255,255,.08); background: linear-gradient(0deg, rgba(255,255,255,.04), rgba(255,255,255,.06)); }
.th-popup-body{ padding:14px; }
.th-table{ width:100%; border-collapse:collapse; color:inherit; }
.th-table th, .th-table td{ border-bottom:1px solid rgba(255,255,255,.08); padding:10px; vertical-align:middle; }
.th-table th{ background:rgba(255,255,255,.06); text-align:left; font-weight:700; }
.th-btn{ background: var(--primary-color, #555); color:#fff; border:none; cursor:pointer; padding:8px 12px; border-radius:8px; }
.th-btn:hover{ filter:brightness(1.1); }
.th-loupe{ cursor:zoom-in; user-select:none; display:inline-flex; align-items:center; gap:6px; }
.th-preview-float{ position:fixed; pointer-events:none; z-index:10000; border:1px solid rgba(255,255,255,.2); border-radius:8px; overflow:hidden; box-shadow:0 10px 30px rgba(0,0,0,.5); background:#000; }
.th-preview-float img{ display:block; width:240px; height:auto; }
</style>
<script>
(() => {
  const THEMES_JSON_URL = <?= json_encode($themesCatalogUrl, JSON_UNESCAPED_SLASHES) ?>;
  const INSTALLED = <?= json_encode($installedThemes, JSON_UNESCAPED_UNICODE) ?>;
  const btnOpen  = document.getElementById('openThemesGallery');
  const popup    = document.getElementById('themesPopup');
  const btnClose = document.getElementById('closeThemesPopup');
  const tbody    = document.querySelector('#themesTable tbody');
  const floatBox = document.getElementById('previewFloat');
  const floatImg = document.getElementById('previewImg');
  const isImg = (u='') => /\.(png|jpe?g|webp|gif|avif|svg)(\?|#|$)/i.test(u);
  const isPdf = (u='') => /\.pdf(\?|#|$)/i.test(u);
  function openPopup(){ popup.style.display = 'flex'; document.body.style.overflow = 'hidden'; }
  function closePopup(){ popup.style.display = 'none'; document.body.style.overflow = ''; }
  function installUrl(id, dl){
    const base = new URL(location.href);
    const p = new URLSearchParams(base.search);
    p.set('download_theme', id);
    p.set('theme_url', dl);
    return `${base.pathname}?${p.toString()}#themes`;
  }
  function renderRow(item){
    const name = item.name || 'Sans nom';
    const id   = String(item.id || name).toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'');
    const desc = item.description || '';
    const date = item.date ? ` (${item.date})` : '';
    const img  = item.image || '';
    const dl   = item.dl || '';
    const size = item.size ? ` · ${item.size}` : '';
    const installed = INSTALLED.includes(id);
    let previewCell = '—';
    if (img) {
      if (isImg(img)) {
        previewCell = `<span class="th-loupe" data-preview="${img}">🔍 Voir</span>`;
      } else if (isPdf(img)) {
        previewCell = `<a class="th-btn" href="${img}" target="_blank" rel="noopener">Aperçu PDF</a>`;
      } else {
        previewCell = `<a class="th-btn" href="${img}" target="_blank" rel="noopener">Aperçu</a>`;
      }
    }
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${name}</strong>${date}</td>
      <td>${desc}${size}</td>
      <td style="width:110px">${previewCell}</td>
      <td style="width:110px">${installed ? '✅ Installé' : '⬇️ Disponible'}</td>
      <td style="width:140px" class="th-action">
        ${dl ? (installed
          ? `<button class="th-btn" data-apply="${id}">Appliquer</button>`
          : `<a class="th-btn" href="${installUrl(id, dl)}">Télécharger & Installer</a>`)
          : `<span style="opacity:.6">Pas de ZIP</span>`
        }
      </td>
    `;
    const loupe = tr.querySelector('.th-loupe');
    if (loupe){
      loupe.addEventListener('mouseenter', (e) => {
        floatImg.src = loupe.getAttribute('data-preview') || '';
        floatBox.style.display = 'block';
        movePreview(e);
      });
      loupe.addEventListener('mousemove', movePreview);
      loupe.addEventListener('mouseleave', () => {
        floatBox.style.display = 'none';
        floatImg.src = '';
      });
    }
    tr.querySelectorAll('[data-apply]').forEach(btn => {
      btn.addEventListener('click', () => {
        const sel = document.querySelector('select[name="theme"]');
        if (!sel) return;
        sel.value = btn.getAttribute('data-apply');
        const form = sel.closest('form');
        if (!form) return;
        let hidden = form.querySelector('input[name="update_theme"]');
        if (!hidden){
          hidden = document.createElement('input');
          hidden.type = 'hidden';
          hidden.name = 'update_theme';
          hidden.value = '1';
          form.appendChild(hidden);
        }
        form.submit();
      });
    });
    return tr;
  }
  function movePreview(e){
    const pad = 16;
    floatBox.style.left = (e.clientX + pad) + 'px';
    floatBox.style.top  = (e.clientY + pad) + 'px';
  }
  async function loadThemes(){
    tbody.innerHTML = `<tr><td colspan="5" style="opacity:.7">Chargement…</td></tr>`;
    try{
      const res = await fetch(THEMES_JSON_URL, {cache:'no-store'});
      if (!res.ok) throw new Error('HTTP '+res.status);
      const data = await res.json();
      const items = Array.isArray(data) ? data : (Array.isArray(data.items) ? data.items : []);
      if (!items.length){
        tbody.innerHTML = `<tr><td colspan="5" style="opacity:.7">Aucun thème dans le catalogue.</td></tr>`;
        return;
      }
      tbody.innerHTML = '';
      items.forEach(it => tbody.appendChild(renderRow(it)));
    }catch(err){
      console.error(err);
      tbody.innerHTML = `<tr><td colspan="5" style="color:#f66">Erreur de chargement du catalogue.</td></tr>`;
    }
  }
  btnOpen?.addEventListener('click', () => { openPopup(); loadThemes(); });
  btnClose?.addEventListener('click', closePopup);
  popup?.addEventListener('click', (e) => { if (e.target === popup) closePopup(); });
})();
</script>
</body>
</html>
