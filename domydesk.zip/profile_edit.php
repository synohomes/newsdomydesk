<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

function getUserFolder($email) {
    return 'users/profiles/' . $email . '/';
}

$isAdmin   = isset($_SESSION['user']['role_system']) && $_SESSION['user']['role_system'] === 'admin';
$userEmail = $_SESSION['user']['email'] ?? '';
$email     = (isset($_GET['email']) && $isAdmin) ? $_GET['email'] : $userEmail;
$userFolder = getUserFolder($email);

$profilePath = $userFolder . 'profile.json';
$menuPath    = $userFolder . 'menu.json';
$modulesPath = $userFolder . 'modules.json';
$avatarPath  = $userFolder . 'avatar.png';
$themePath   = $userFolder . 'theme.json';
$installedThemes = array_map('basename', glob(__DIR__ . "/theme/*", GLOB_ONLYDIR) ?: []);

$theme = 'default';
if (file_exists($themePath)) {
    $themeData = json_decode(file_get_contents($themePath), true);
    if (!empty($themeData['theme']) && file_exists(__DIR__ . "/theme/" . $themeData['theme'] . "/style.css")) {
        $theme = basename($themeData['theme']);
    }
}

function findPhpFiles($dir) {
    $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir));
    $files = [];
    foreach ($rii as $file) {
        if ($file->isFile() && $file->getExtension() === 'php') {
            $relPath = str_replace('\\', '/', substr($file->getPathname(), strlen(getcwd()) + 1));
            // Filtre optionnel: exclure vendor/cache si besoin
            if (strpos($relPath, '/vendor/') !== false) continue;
            $files[] = ['label' => ucfirst(basename($file, ".php")), 'link' => $relPath];
        }
    }
    return $files;
}

$availablePages = findPhpFiles(__DIR__);
sort($availablePages);
$baseUrl = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\'); // ex: /domydesk
foreach ($availablePages as &$p) {
    $p['link'] = $baseUrl . '/' . ltrim($p['link'], '/');
}
unset($p);

$userData    = file_exists($profilePath) ? json_decode(file_get_contents($profilePath), true) : [];
$menuDataRaw = file_exists($menuPath) ? json_decode(file_get_contents($menuPath), true) : [];
$menuData    = $menuDataRaw['items']['items'] ?? [];

$rolesFile   = 'data/roles_metier.json';
$rolesMetiers = file_exists($rolesFile) ? json_decode(file_get_contents($rolesFile), true) : [];

$modulesList = file_exists($modulesPath) ? json_decode(file_get_contents($modulesPath), true) : [];
$message = '';

/* ====== Contexte sécurité ====== */
$isSelf = ($email === $userEmail);
// login.php attend 'motdepasse' (password_hash).
$existingHash = $userData['motdepasse'] ?? ($userData['password'] ?? null);

/* ====== POST HANDLERS ====== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['update_profile'])) {
        $userData['prenom']      = $_POST['first_name'] ?? '';
        $userData['nom']         = $_POST['last_name'] ?? '';
        $userData['role_metier'] = $_POST['job_role'] ?? '';
        $userData['adresse']     = $_POST['adresse'] ?? '';
        if (!is_dir($userFolder)) mkdir($userFolder, 0755, true);
        file_put_contents($profilePath, json_encode($userData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $message = "✅ Profil mis à jour avec succès.";
    }

    elseif (isset($_POST['upload_avatar'])) {
        if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
            $allowed = ['png', 'jpg', 'jpeg', 'webp'];
            if (in_array($ext, $allowed)) {
                if (!is_dir($userFolder)) mkdir($userFolder, 0755, true);
                move_uploaded_file($_FILES['avatar']['tmp_name'], $avatarPath);
                $message = "✅ Avatar mis à jour avec succès.";
            } else {
                $message = "❌ Format avatar non autorisé.";
            }
        } else {
            $message = "❌ Erreur upload avatar.";
        }
    }

    elseif (isset($_POST['update_theme'])) {
        $themeChoice = basename($_POST['theme'] ?? 'default');
        file_put_contents($themePath, json_encode(['theme' => $themeChoice], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $redir = 'profile_edit.php';
        if ($isAdmin && isset($_GET['email'])) {
            $redir .= '?email=' . urlencode($_GET['email']);
        }
        header("Location: $redir");
        exit;
    }

    elseif (isset($_POST['import_theme'])) {
        if (!class_exists('ZipArchive')) {
            $message = "❌ ZipArchive non disponible sur le serveur.";
        } elseif (isset($_FILES['theme_zip']) && is_uploaded_file($_FILES['theme_zip']['tmp_name'])) {
            $zipPath = $_FILES['theme_zip']['tmp_name'];
            $zip = new ZipArchive;
            if ($zip->open($zipPath) === TRUE) {
                $folderName = basename($_FILES['theme_zip']['name'], '.zip');
                $extractPath = __DIR__ . "/theme/" . $folderName;
                if (!is_dir("theme")) mkdir("theme", 0755, true);
                if (!is_dir($extractPath)) mkdir($extractPath, 0755, true);
                $zip->extractTo($extractPath);
                $zip->close();
                $message = "✅ Thème importé avec succès.";
            } else {
                $message = "❌ Impossible d’ouvrir le fichier ZIP.";
            }
        } else {
            $message = "❌ Erreur lors de l’import du fichier ZIP.";
        }
    }

    elseif (isset($_POST['update_menu'])) {
        $menuJson = $_POST['menu_json'] ?? '';
        $decodedMenu = json_decode($menuJson, true);
        if (is_array($decodedMenu)) {
            foreach ($decodedMenu as &$item) {
                if (($item['type'] ?? '') === 'page' && isset($item['link']) && strpos($item['link'], '/domydesk/') !== 0) {
                    $item['link'] = '/domydesk/' . ltrim($item['link'], '/');
                }
                if (!empty($item['submenu']) && is_array($item['submenu'])) {
                    foreach ($item['submenu'] as &$sub) {
                        if (($sub['type'] ?? '') === 'page' && isset($sub['link']) && strpos($sub['link'], '/domydesk/') !== 0) {
                            $sub['link'] = '/domydesk/' . ltrim($sub['link'], '/');
                        }
                    }
                }
            }
            $fullMenu = ['items' => ['items' => $decodedMenu]];
            if (!is_dir($userFolder)) mkdir($userFolder, 0755, true);
            file_put_contents($menuPath, json_encode($fullMenu, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            $menuData = $decodedMenu;
            $message = "✅ Menu latéral mis à jour.";
        } else {
            $message = "❌ Format JSON du menu invalide.";
        }
    }

    /* ====== SEC: changement / reset mot de passe ====== */
elseif (isset($_POST['change_password'])) {
    $new1 = $_POST['new_password'] ?? '';
    $new2 = $_POST['new_password_confirm'] ?? '';
    $old  = $_POST['current_password'] ?? '';

    if (strlen($new1) < 8) {
        $message = "❌ Nouveau mot de passe trop court (min 8 caractères).";
    } elseif ($new1 !== $new2) {
        $message = "❌ La confirmation ne correspond pas.";
    } else {
        $changingOwn = ($email === $userEmail) || !$isAdmin;

        // Si l'utilisateur change son propre mot de passe et qu'un hash existe, on vérifie l'ancien
        if ($changingOwn && !empty($existingHash)) {
            if (!password_verify($old, $existingHash)) {
                $message = "❌ Ancien mot de passe incorrect.";
                // on stoppe ici
                goto end_change_pwd;
            }
        }

        // Hash au format attendu par login.php
        $newHash = password_hash($new1, PASSWORD_DEFAULT);

        // Écritures compatibles :
        // - clé lue par login.php
        $userData['motdepasse'] = $newHash;
        // - compat éventuelle si d'autres scripts lisaient 'password'
        $userData['password'] = $newHash;
        // - on supprime l'ancienne clé erronée si elle existait
        if (isset($userData['password_hash'])) unset($userData['password_hash']);

        if (!is_dir($userFolder)) mkdir($userFolder, 0755, true);
        file_put_contents($profilePath, json_encode($userData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

        $message = $changingOwn ? "✅ Mot de passe mis à jour." : "✅ Mot de passe réinitialisé pour l’utilisateur.";
    }
    end_change_pwd: ;
}

}

/* ====== INSTALL THEME VIA GET (déjà présent) ====== */
if (isset($_GET['download_theme'])) {
    $themeName = basename($_GET['download_theme']);
    $themeZipUrl = $_GET['theme_url'] ?? '';
    $themeDir = __DIR__ . "/theme/";

    if (!is_dir($themeDir)) { mkdir($themeDir, 0775, true); }

    $zipPath = $themeDir . $themeName . ".zip";
    if ($themeZipUrl) {
        @file_put_contents($zipPath, @file_get_contents($themeZipUrl));
        $zip = new ZipArchive;
        if ($zip->open($zipPath) === TRUE) {
            $zip->extractTo($themeDir);
            $zip->close();
            @unlink($zipPath);
            echo "<div class='message' style='color:lime;'>✅ Thème <b>$themeName</b> installé avec succès.</div>";
        } else {
            echo "<div class='message' style='color:red;'>❌ Erreur lors de l'installation du thème.</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Paramètres utilisateur</title>
<?php
$themeFile = __DIR__ . "/theme/$theme/style.css";
$baseUrl   = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$themeHref = $baseUrl . "/theme/" . rawurlencode($theme) . "/style.css";
if (is_file($themeFile)) {
    $themeHref .= '?v=' . filemtime($themeFile);
}
?>
    <link rel="stylesheet" href="<?= htmlspecialchars($themeHref) ?>">

    <!-- Styles SCOPÉS pour la page de profil (respecte le thème) -->
    <style>
        .profile-edit { margin: 0 auto; }
        .profile-edit .spacer { height: 25px; }

        .profile-edit .accordion-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(320px, 1fr));
            gap: 16px;
            align-items: start;
        }
        @media (max-width: 1100px) {
            .profile-edit .accordion-grid { grid-template-columns: 1fr; }
        }

        .profile-edit .accordion {
            border-radius: 12px;
            box-shadow: 0 4px 16px rgba(0,0,0,.25);
            overflow: hidden;
            background: var(--card-bg, rgba(0,0,0,0.2));
            border: 1px solid var(--primary-dark, rgba(255,255,255,0.08));
        }
        .profile-edit .accordion summary {
            list-style: none;
            cursor: pointer;
            padding: 14px 16px;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            background: linear-gradient(0deg, rgba(0,0,0,0.08), rgba(255,255,255,0.06));
            user-select: none;
        }
        .profile-edit .accordion summary::-webkit-details-marker { display: none; }
        .profile-edit .accordion .chevron { transition: transform .25s ease; font-size: 1.8em; opacity: .85; }
        .profile-edit details[open] .chevron { transform: rotate(180deg); }

        .profile-edit .accordion .content {
            padding: 16px;
            border-top: 1px solid rgba(255,255,255,0.06);
            animation: accordionIn .2s ease;
        }
        @keyframes accordionIn { from { opacity: 0; transform: translateY(-4px); } to { opacity: 1; transform: translateY(0); } }

        .profile-edit form > label { display:block; margin: 8px 0 4px; }
        .profile-edit form > input[type="text"],
        .profile-edit form > input[type="password"],
        .profile-edit form > select,
        .profile-edit form > input[type="file"] { width: 100%; }

        .profile-edit .avatar { width: 96px; height: 96px; border-radius: 50%; object-fit: cover; display:block; margin: 6px 0 12px 0; border: 1px solid rgba(255,255,255,0.08); }

        .profile-edit .theme-preview-section { margin-top: 10px; }
        .profile-edit .theme-preview-box { width: 100%; max-width: 380px; aspect-ratio: 16/9; border: 1px dashed rgba(255,255,255,0.2); display:flex; align-items:center; justify-content:center; border-radius: 10px; overflow:hidden; }
        .profile-edit #theme-preview-img { max-width:100%; max-height:100%; display:block; }

        .profile-edit .message { margin: 12px 0; padding: 10px 12px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.15); background: rgba(0,0,0,0.25); }

        .profile-edit .menu-list, .profile-edit .submenu-list { list-style: none; padding-left: 0; }
        .profile-edit .menu-list > li, .profile-edit .submenu-list > li {
            display: flex; flex-wrap: wrap; gap: 8px; align-items: center;
            padding: 8px; margin: 6px 0; border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; background: rgba(0,0,0,0.15);
        }
        .profile-edit .btn-sm { padding: 6px 10px; border-radius: 8px; border: none; cursor: pointer; background: var(--primary-color, #555); color: #fff; }
        .profile-edit .btn-add { opacity: .9; }
        .profile-edit .btn-del { background: #b33; }

        .profile-edit .sections-modules { margin-top: 50px; padding-top: 10px; }
        .profile-edit .cfg-break-title { font-size: 1.8em; font-weight: 600; letter-spacing: 0.5px; margin: 0 0 20px; text-align: center; display: flex; justify-content: center; align-items: center; gap: 6px; opacity: 0.85; }

        .profile-edit .module-cfg-wrap {
            border: 1px solid rgba(255,255,255,0.10);
            border-radius: 14px;
            padding: 10px 12px;
            margin-bottom: 22px;
            background: rgba(0,0,0,0.15);
            box-shadow: 0 0 0 2px rgba(255,255,255,0.04) inset, 0 10px 24px rgba(0,0,0,0.35);
            transition: box-shadow .2s ease, border-color .2s ease;
        }
        .profile-edit .module-cfg-wrap:hover { box-shadow: 0 0 0 2px rgba(255,255,255,0.08) inset, 0 12px 28px rgba(0,0,0,0.45); border-color: rgba(255,255,255,0.16); }
    </style>
</head>

<body>
<div class="profile-edit container">
    <?php include 'header.php'; ?>
    <div class="spacer"></div>

    <?php if ($message): ?>
        <div class="message"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
 <h2 class="cfg-break-title">🆔 Configurationde votre profile</h2>
    <!-- === PARAMÉTRAGES DU PROFIL : Accordions en 2 colonnes === -->
    <div class="accordion-grid">

        <!-- Profil -->
<!-- Profil -->
<details class="accordion" data-acc-key="pe_profile">
  <summary>
    <span>👤 Votre profil</span>
  </summary>
  <div class="content">
    <form method="POST" autocomplete="off">
      <input type="hidden" name="update_profile" value="1">

      <label>Prénom :</label>
      <input type="text" name="first_name" value="<?= htmlspecialchars($userData['prenom'] ?? '') ?>" required>

      <label>Nom :</label>
      <input type="text" name="last_name" value="<?= htmlspecialchars($userData['nom'] ?? '') ?>" required>

      <label>Rôle Métier :</label>
      <select name="job_role" required>
        <option value="">-- Sélectionner --</option>
        <?php foreach ($rolesMetiers as $role):
          $val = is_array($role) ? ($role['label'] ?? $role['value'] ?? '') : $role;
          $selected = ($userData['role_metier'] ?? '') === $val ? 'selected' : ''; ?>
          <option value="<?= htmlspecialchars($val) ?>" <?= $selected ?>><?= htmlspecialchars($val) ?></option>
        <?php endforeach; ?>
      </select>

      <label>Adresse :</label>
      <input type="text" name="adresse" value="<?= htmlspecialchars($userData['adresse'] ?? '') ?>">

      <button type="submit">Enregistrer</button>
    </form>
  </div>
</details>

<!-- Sécurité & Mot de passe -->
<details class="accordion" data-acc-key="pe_security">
  <summary>
    <span>🔒 Sécurité & Mot de passe</span>
  </summary>
  <div class="content">
    <form method="POST" autocomplete="off">
      <input type="hidden" name="change_password" value="1">

      <?php if ($isSelf || !$isAdmin || $email === $userEmail): ?>
        <?php if (!empty($existingHash)): ?>
          <label>Ancien mot de passe :</label>
          <input type="password" name="current_password" placeholder="Ancien mot de passe" required>
        <?php else: ?>
          <p style="opacity:.8;margin:0 0 8px 0;">Aucun mot de passe défini encore pour ce compte.</p>
        <?php endif; ?>
      <?php else: ?>
        <p style="opacity:.8;margin:0 0 8px 0;">Administrateur : réinitialisation sans ancien mot de passe pour <b><?= htmlspecialchars($email) ?></b>.</p>
      <?php endif; ?>

      <label>Nouveau mot de passe :</label>
      <input type="password" name="new_password" placeholder="Min 8 caractères" minlength="8" required>

      <label>Confirmer le nouveau mot de passe :</label>
      <input type="password" name="new_password_confirm" placeholder="Répétez le mot de passe" minlength="8" required>

      <button type="submit">Mettre à jour le mot de passe</button>
    </form>
  </div>
</details>

        <!-- Avatar + Thème -->
        <details class="accordion" data-acc-key="pe_avatar_theme">
            <summary>
                <span>🖼️ Avatar & Thème</span>
                
            </summary>
            <div class="content">
                <?php
                $hasBackup = false;
                foreach ($modulesList as $mod) {
                    if (!empty($mod['enabled']) && $mod['id'] === 'savev.1') { $hasBackup = true; break; }
                }
                ?>
                <?php if ($hasBackup): ?>
                    <p style="margin:0 0 8px 0;">
                        <a href="modules/savev.1/download.php" title="Sauvegarder mon profil" style="text-decoration:none;">
                            📥 <span style="font-size:12px; opacity:.8;"></span>
                        </a>
                    </p>
                <?php endif; ?>

                <?php if (file_exists($avatarPath)): ?>
                    <img class="avatar" src="<?= htmlspecialchars($avatarPath) ?>?t=<?= time() ?>" alt="Avatar">
                <?php else: ?>
                    <p>Aucun avatar défini</p>
                <?php endif; ?>

                <form method="POST" enctype="multipart/form-data" style="margin-bottom:12px;">
                    <input type="hidden" name="upload_avatar" value="1">
                    <label>Changer d'avatar :</label>
                    <input type="file" name="avatar" accept="image/*" required>
                    <button type="submit">Mettre à jour</button>
                </form>

                <form method="POST" style="margin-bottom:12px;">
                    <input type="hidden" name="update_theme" value="1">
                    <label>Choisir un thème :</label>
                    <select name="theme">
                        <?php foreach (glob("theme/*", GLOB_ONLYDIR) as $dir):
                            $dirName  = basename($dir);
                            $selected = $theme === $dirName ? 'selected' : ''; ?>
                            <option value="<?= $dirName ?>" <?= $selected ?>><?= ucfirst($dirName) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit">Changer le thème</button>
                    <button type="button" id="openThemesGallery" style="margin-left:8px">📂 Parcourir les thèmes</button>

                    <div class="theme-preview-section">
                        <label>Aperçu du thème sélectionné :</label>
                        <div class="theme-preview-box">
                            <img id="theme-preview-img" src="" alt="Aperçu du thème" />
                        </div>
                    </div>
                </form>

                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="import_theme" value="1">
                    <label>Importer un thème (.zip) :</label>
                    <input type="file" name="theme_zip" accept=".zip" required>
                    <button type="submit">Importer</button>
                </form>
            </div>
        </details>
        <!-- Menu vertical -->
        <details class="accordion" data-acc-key="pe_menu">
            <summary>
                <span>📝 Menu vertical</span>
                
            </summary>
            <div class="content">
                <form method="POST" onsubmit="prepareMenuJson();">
                    <input type="hidden" name="update_menu" value="1">
                    <input type="hidden" id="menu_json" name="menu_json">
                    <ul class="menu-list" id="menuList"></ul>
                    <button type="button" class="btn-sm btn-add" onclick="addMenuItem()">+ Ajouter un élément</button><br><br>
                    <button type="submit">Enregistrer le menu</button>
                </form>
            </div>
        </details>

        <?php if ($isAdmin): ?>
        <!-- Zone ADMIN des actualités -->
        <details class="accordion" data-acc-key="pe_admin_news">
            <summary>
                <span>🛠️ Actualités</span>
                
            </summary>
            <div class="content">
                <div class="section section-col" style="margin:0;">
                    <?php include __DIR__ . "/data/news/newscfg.php"; ?>
                </div>
            </div>
        </details>
        <?php endif; ?>
    </div>
    <!-- === /PARAMÉTRAGES DU PROFIL === -->

<!-- ==== MODULES CFG ==== -->
<div class="sections-modules" id="modules">
  <h2 class="cfg-break-title">🧩 Configurations des modules</h2>

  <?php
  // Recense les modules qui ont un {id}cfg.php
  $cards = [];
  if (!empty($modulesList) && is_array($modulesList)) {
    foreach ($modulesList as $mod) {
      if (!empty($mod['enabled']) && !empty($mod['id'])) {
        $mid = basename($mod['id']);
        $cfg = __DIR__."/modules/$mid/{$mid}cfg.php";
        if (is_file($cfg)) $cards[] = ['id'=>$mid, 'name'=>strtoupper($mid)];
      }
    }
  }
  ?>

  <?php if (empty($cards)): ?>
    <div class="message">Aucun module configurable.</div>
  <?php else: ?>
    <div class="mod-grid" id="mod-grid">
      <?php foreach ($cards as $c): ?>
        <button type="button" class="mod-card" data-mod="<?= htmlspecialchars($c['id']) ?>">
          <span class="mod-card-title"><?= htmlspecialchars($c['name']) ?></span>
          <span style="opacity:.75"></span>
        </button>
      <?php endforeach; ?>
    </div>

    <!-- Hôte de l'iframe (un seul scroll, thème injecté) -->
    <div id="mod-host" class="mod-host" style="display:none;">
      <div class="mod-host-bar">
        <h3 id="mod-host-title" class="mod-host-title">Configuration</h3>
        <div class="mod-host-actions">
          <button type="button" id="mod-close" class="btn-sm">Fermer</button>
         <a id="mod-open" class="" href="" target="_blank" rel="noopener"></a>

        </div>
      </div>
      <iframe id="mod-iframe" title="Module config" loading="lazy"></iframe>
    </div>
  <?php endif; ?>
</div>

</div> <!-- /.profile-edit -->
<style>
/* --- Grille de tuiles modules --- */
.mod-grid{
  display:grid; grid-template-columns:repeat(auto-fill,minmax(220px,1fr));
  gap:14px; margin-bottom:14px;
}
.mod-card{
  display:flex; flex-direction:column; gap:6px; padding:12px 14px;
  border:1px solid rgba(255,255,255,.10); border-radius:12px;
  background:rgba(0,0,0,.18); cursor:pointer; text-align:left;
  color:inherit; text-decoration:none; transition:box-shadow .2s, border-color .2s;
}
.mod-card:hover{ border-color:rgba(255,255,255,.22); box-shadow:0 10px 24px rgba(0,0,0,.35); }
.mod-card-title{ font-weight:700; }

.mod-host{ margin-top:14px; border:1px solid rgba(255,255,255,.14); border-radius:12px; background:rgba(0,0,0,.12); }
.mod-host-bar{ display:flex; align-items:center; justify-content:space-between; gap:8px; padding:10px 14px; border-bottom:1px solid rgba(255,255,255,.12); }
.mod-host-title{ margin:0; font-weight:700; letter-spacing:.3px; }
.mod-host-actions{ display:flex; gap:8px; }
#mod-iframe{ width:100%; border:0; display:block; }

</style>
<!-- Scripts -->
<script>
const availablePages = <?= json_encode($availablePages, JSON_UNESCAPED_UNICODE) ?>;
const menuData = <?= json_encode($menuData, JSON_UNESCAPED_UNICODE) ?>;

/* === NORMALISATION DES LIENS ===
   Permet de faire "matcher" /domydesk/xxx.php avec xxx.php, etc. */
const normLink = (s) => (s || '')
  .replace(/^\/+/, '')         // vire les / au début
  .replace(/^domydesk\//, ''); // vire le préfixe domydesk/

function createMenuItem(item = {}) {
    const li = document.createElement('li');

    const input = document.createElement('input');
    input.type = 'text';
    input.placeholder = 'Libellé';
    input.value = item.label || '';

    const selectType = document.createElement('select');
    selectType.innerHTML = `
        <option value="none">Pas de lien</option>
        <option value="page">Page</option>
        <option value="link">Lien externe</option>
    `;
    selectType.value = item.type || 'none';

    const selectPage = document.createElement('select');
    // IMPORTANT : placeholder + comparaison normalisée
    selectPage.innerHTML = [
        `<option value="">-- choisir une page --</option>`,
        ...availablePages.map(p =>
            `<option value="${p.link}" ${normLink(p.link) === normLink(item.link) ? 'selected' : ''}>${p.label}</option>`
        )
    ].join('');
    selectPage.style.display = item.type === 'page' ? 'inline-block' : 'none';

    const inputLink = document.createElement('input');
    inputLink.type = 'text';
    inputLink.placeholder = 'https://...';
    inputLink.value = item.type === 'link' ? (item.link || '') : '';
    inputLink.style.display = item.type === 'link' ? 'inline-block' : 'none';

    selectType.onchange = () => {
        if (selectType.value === 'page') {
            selectPage.style.display = 'inline-block';
            inputLink.style.display = 'none';
        } else if (selectType.value === 'link') {
            selectPage.style.display = 'none';
            inputLink.style.display = 'inline-block';
        } else {
            selectPage.style.display = 'none';
            inputLink.style.display = 'none';
        }
    };

    const addSubBtn = document.createElement('button');
    addSubBtn.type = 'button';
    addSubBtn.textContent = '+';
    addSubBtn.className = 'btn-sm btn-add';
    const subList = document.createElement('ul');
    subList.className = 'submenu-list';

    (item.submenu || []).forEach(sub => subList.appendChild(createSubItem(sub)));
    addSubBtn.onclick = () => subList.appendChild(createSubItem());

    const delBtn = document.createElement('button');
    delBtn.type = 'button';
    delBtn.textContent = '×';
    delBtn.className = 'btn-sm btn-del';
    delBtn.onclick = () => li.remove();

    li.append(input, selectType, selectPage, inputLink, addSubBtn, delBtn, subList);
    return li;
}

function createSubItem(sub = {}) {
    const li = document.createElement('li');

    const input = document.createElement('input');
    input.type = 'text';
    input.placeholder = 'Sous-libellé';
    input.value = sub.label || '';

    const selectType = document.createElement('select');
    selectType.innerHTML = `
        <option value="none">Pas de lien</option>
        <option value="page">Page</option>
        <option value="link">Lien externe</option>
    `;
    selectType.value = sub.type || 'none';

    const selectPage = document.createElement('select');
    // IMPORTANT : placeholder + comparaison normalisée
    selectPage.innerHTML = [
        `<option value="">-- choisir une page --</option>`,
        ...availablePages.map(p =>
            `<option value="${p.link}" ${normLink(p.link) === normLink(sub.link) ? 'selected' : ''}>${p.label}</option>`
        )
    ].join('');
    selectPage.style.display = sub.type === 'page' ? 'inline-block' : 'none';

    const inputLink = document.createElement('input');
    inputLink.type = 'text';
    inputLink.placeholder = 'https://...';
    inputLink.value = sub.type === 'link' ? (sub.link || '') : '';
    inputLink.style.display = sub.type === 'link' ? 'inline-block' : 'none';

    selectType.onchange = () => {
        if (selectType.value === 'page') {
            selectPage.style.display = 'inline-block';
            inputLink.style.display = 'none';
        } else if (selectType.value === 'link') {
            selectPage.style.display = 'none';
            inputLink.style.display = 'inline-block';
        } else {
            selectPage.style.display = 'none';
            inputLink.style.display = 'none';
        }
    };

    const delBtn = document.createElement('button');
    delBtn.type = 'button';
    delBtn.textContent = '×';
    delBtn.className = 'btn-sm btn-del';
    delBtn.onclick = () => li.remove();

    li.append(input, selectType, selectPage, inputLink, delBtn);
    return li;
}

function addMenuItem() {
    document.getElementById('menuList').appendChild(createMenuItem());
}

function prepareMenuJson() {
    const items = [];
    document.querySelectorAll('#menuList > li').forEach(li => {
        const label = li.querySelector('input[type=text]')?.value.trim();
        const selects = li.querySelectorAll('select');
        const type   = selects[0]?.value;
        const link   = (type === 'page')
            ? selects[1]?.value
            : (type === 'link') ? li.querySelector('input[placeholder="https://..."]')?.value.trim() : '';

        const submenu = [];
        li.querySelectorAll('.submenu-list > li').forEach(sub => {
            const subLabel = sub.querySelector('input[type=text]')?.value.trim();
            const subSelects = sub.querySelectorAll('select');
            const subType = subSelects[0]?.value;
            const subLink = (subType === 'page')
                ? subSelects[1]?.value
                : (subType === 'link') ? sub.querySelector('input[placeholder="https://..."]')?.value.trim() : '';
            if (subLabel) submenu.push({ label: subLabel, type: subType, link: subLink, submenu: [] });
        });

        if (label) items.push({ label, type, link, submenu });
    });

    document.getElementById('menu_json').value = JSON.stringify(items, null, 2);
}

/* ===== Pré-chargement menu et aperçu thème ===== */
window.addEventListener('DOMContentLoaded', () => {
    // Menu existant
    (menuData || []).forEach(item => document.getElementById('menuList').appendChild(createMenuItem(item)));

    // Aperçu du thème
    const select = document.querySelector('select[name="theme"]');
    const previewImg = document.getElementById('theme-preview-img');
    function updatePreview() {
        const theme = select.value;
        previewImg.src = `theme/${theme}/theme.png`;
    }
    if (select && previewImg) {
        select.addEventListener('change', updatePreview);
        updatePreview();
    }

    // Mémoire état des volets
    document.querySelectorAll('.accordion').forEach(details => {
        const key = details.getAttribute('data-acc-key');
        const saved = localStorage.getItem(key);
        if (saved === 'closed') details.removeAttribute('open');
        if (saved === 'open') details.setAttribute('open', 'open');
        details.addEventListener('toggle', () => {
            localStorage.setItem(key, details.open ? 'open' : 'closed');
        });
    });
});
</script>

<!-- ============ POPUP GALERIE DES THÈMES ============ -->
<div id="themesPopup" class="th-popup-overlay" style="display:none;">
  <div class="th-popup">
    <div class="th-popup-header">
      <h2 style="margin:0;display:flex;align-items:center;gap:8px;">🎨 Galerie des thèmes</h2>
      <button type="button" id="closeThemesPopup" class="th-btn">✖</button>
    </div>

    <div class="th-popup-body">
      <div class="th-hint" style="margin-bottom:10px;opacity:.85;">
        Survolez la <strong>loupe</strong> 🔍 pour voir la miniature.
        <span style="margin-left:10px;">✅ = installé, ⬇️ = disponible</span>
      </div>

      <table class="th-table" id="themesTable">
        <thead>
          <tr>
            <th>Nom</th>
            <th>Description</th>
            <th style="width:110px;">Aperçu</th>
            <th style="width:110px;">Statut</th>
            <th style="width:120px;">Action</th>
          </tr>
        </thead>
        <tbody></tbody>
      </table>

      <div id="previewFloat" class="th-preview-float" style="display:none;">
        <img id="previewImg" src="" alt="preview">
      </div>
    </div>
  </div>
</div>

<style>
.th-popup-overlay{ position:fixed; inset:0; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,.65); z-index:9999; }
.th-popup{ width:min(1000px, 96vw); max-height:88vh; overflow:auto; background:rgba(0,0,0,.25); border:1px solid rgba(255,255,255,.12); border-radius:12px; box-shadow:0 20px 60px rgba(0,0,0,.45); }
.th-popup-header{ display:flex; align-items:center; justify-content:space-between; gap:8px; padding:12px 14px; border-bottom:1px solid rgba(255,255,255,.08); background: linear-gradient(0deg, rgba(255,255,255,.04), rgba(255,255,255,.06)); }
.th-popup-body{ padding:14px; }

.th-table{ width:100%; border-collapse:collapse; color:inherit; }
.th-table th, .th-table td{ border-bottom:1px solid rgba(255,255,255,.08); padding:10px; vertical-align:middle; }
.th-table th{ background:rgba(255,255,255,.06); text-align:left; font-weight:700; }

.th-btn{ background: var(--primary-color, #555); color:#fff; border:none; cursor:pointer; padding:8px 12px; border-radius:8px; }
.th-btn:hover{ filter:brightness(1.1); }

.th-loupe{ cursor:zoom-in; user-select:none; display:inline-flex; align-items:center; gap:6px; }
.th-loupe .icon{ font-size: 18px; }

.th-status{ display:flex; align-items:center; gap:6px; }
.th-action{ display:flex; gap:8px; }

.th-preview-float{ position:fixed; pointer-events:none; z-index:10000; border:1px solid rgba(255,255,255,.2); border-radius:8px; overflow:hidden; box-shadow:0 10px 30px rgba(0,0,0,.5); background:#000; }
.th-preview-float img{ display:block; width:240px; height:auto; }
</style>

<script>
(() => {
  const themeHref = <?= json_encode($themeHref, JSON_UNESCAPED_SLASHES) ?>;
  const grid  = document.getElementById('mod-grid');
  const host  = document.getElementById('mod-host');
  const title = document.getElementById('mod-host-title');
  const btnClose = document.getElementById('mod-close');
  const aOpen = document.getElementById('mod-open');
  const frame = document.getElementById('mod-iframe');

  function openModule(id, label){
    const url = `modules/${id}/${id}cfg.php?embed=1`;
    title.textContent = label || id.toUpperCase();
    aOpen.href = url;
    host.style.display = 'block';
    frame.style.height = '1px';      // reset pour éviter d’hériter d’une grande hauteur
    frame.src = url;
    host.scrollIntoView({behavior:'smooth', block:'start'});
  }

  // ---- Réception des tailles envoyées par l'iframe
  let rafToken = null;
  window.addEventListener('message', (ev) => {
    if (!ev || !ev.data || ev.source !== frame.contentWindow) return;
    if (ev.data.type !== 'iframe-size') return;
    const nextH = Math.max(0, Math.min(ev.data.height|0, 50000)); // clamp

    if (rafToken) cancelAnimationFrame(rafToken);
    rafToken = requestAnimationFrame(() => {
      const cur = parseInt(frame.style.height || '0', 10) || 0;
      if (Math.abs(nextH - cur) >= 2) frame.style.height = nextH + 'px';
    });
  }, false);

  // ---- Au load de l'iframe : injection thème + script qui poste la hauteur
  frame.addEventListener('load', () => {
    try {
      const doc = frame.contentDocument || frame.contentWindow.document;

      // injecte le thème si absent
      const hasTheme = [...doc.querySelectorAll('link[rel="stylesheet"]')]
                        .some(l => l.href && l.href.includes('/theme/'));
      if (!hasTheme && themeHref){
        const link = doc.createElement('link');
        link.rel = 'stylesheet';
        link.href = themeHref;
        doc.head.appendChild(link);
      }

      // évite le scroll interne de l'iframe
      const style = doc.createElement('style');
      style.textContent = `html, body { overflow:hidden !important; }`;
      doc.head.appendChild(style);

      // script interne qui envoie la hauteur réelle au parent
      const s = doc.createElement('script');
      s.text = `
        (function(){
          function send(){
            try {
              var h = Math.max(
                document.documentElement.scrollHeight || 0,
                document.body ? document.body.scrollHeight : 0
              );
              parent.postMessage({type:'iframe-size', height:h}, '*');
            } catch(e){}
          }
          var ro = window.ResizeObserver ? new ResizeObserver(send) : null;
          if (ro && document.body) ro.observe(document.body);
          var mo = new MutationObserver(function(){ setTimeout(send,0); });
          mo.observe(document.documentElement, {subtree:true, childList:true, attributes:true, characterData:true});
          window.addEventListener('load', function(){
            setTimeout(send,10); setTimeout(send,300); setTimeout(send,1200);
          });
          setTimeout(send, 10);
        })();
      `;
      doc.body.appendChild(s);
    } catch(e) { console.error(e); }
  });

  // événements UI
  grid?.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-mod]'); if (!btn) return;
    const id = btn.getAttribute('data-mod');
    const label = btn.querySelector('.mod-card-title')?.textContent || id.toUpperCase();
    openModule(id, label);
  });

  btnClose?.addEventListener('click', () => {
    frame.src = 'about:blank';
    frame.style.height = '1px';
    host.style.display = 'none';
    history.replaceState({}, '', location.pathname);
  });

  // prise en charge de ?mod=xxx
  const params = new URLSearchParams(location.search);
  const qmod = params.get('mod');
  if (qmod){
    const label = (document.querySelector(`[data-mod="${qmod}"] .mod-card-title`)?.textContent)||qmod.toUpperCase();
    openModule(qmod, label);
  }
})();
</script>



</body>
</html>
