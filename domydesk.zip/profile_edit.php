<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$message = $message ?? '';
$themesCatalogUrl = 'https://raw.githubusercontent.com/synohomes/newsdomydesk/main/theme.json';

/* ==========================================================
   Installation thème depuis catalogue distant
   ========================================================== */

if (isset($_GET['download_theme'])) {
    $themeName   = basename($_GET['download_theme']);
    $themeZipUrl = trim($_GET['theme_url'] ?? '');
    $themeDir    = __DIR__ . '/theme/';
    $logFile     = $themeDir . '_install_log.txt';

    if (!is_dir($themeDir)) {
        @mkdir($themeDir, 0775, true);
    }

    $errors = [];
    $notes  = [];

    if ($themeName === '') {
        $errors[] = 'Nom de thème vide.';
    }

    if ($themeZipUrl === '') {
        $errors[] = 'URL du ZIP manquante.';
    }

    if (!is_dir($themeDir)) {
        $errors[] = "Dossier theme/ introuvable: " . $themeDir;
    }

    if (!is_writable($themeDir)) {
        $errors[] = "Dossier theme/ non inscriptible: " . $themeDir;
    }

    $notes[] = 'GET=' . json_encode($_GET);
    $notes[] = 'themeDir=' . realpath($themeDir);
    $notes[] = 'allow_url_fopen=' . (ini_get('allow_url_fopen') ? '1' : '0');
    $notes[] = 'curl=' . (function_exists('curl_init') ? '1' : '0');
    $notes[] = 'ZipArchive=' . (class_exists('ZipArchive') ? '1' : '0');

    if (!$errors) {
        $zipPath = $themeDir . $themeName . '.zip';
        $downloadOk = false;
        $httpCode   = null;

        if (function_exists('curl_init')) {
            $notes[] = 'Try cURL strict SSL';

            $ch = curl_init($themeZipUrl);
            $fp = @fopen($zipPath, 'w');

            if ($fp) {
                curl_setopt_array($ch, [
                    CURLOPT_FILE => $fp,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_SSL_VERIFYPEER => true,
                    CURLOPT_CONNECTTIMEOUT => 15,
                    CURLOPT_TIMEOUT => 60,
                    CURLOPT_USERAGENT => 'domydesk-theme-installer'
                ]);

                $downloadOk = curl_exec($ch) !== false;
                $httpCode   = curl_getinfo($ch, CURLINFO_HTTP_CODE);

                curl_close($ch);
                fclose($fp);

                $downloadOk = $downloadOk && ($httpCode === 200);
            } else {
                $errors[] = 'Impossible d’ouvrir le fichier local pour écrire le ZIP.';
            }
        }

        if (!$downloadOk && function_exists('curl_init')) {
            $notes[] = 'Retry cURL SSL_VERIFYPEER=0';

            $ch = curl_init($themeZipUrl);
            $fp = @fopen($zipPath, 'w');

            if ($fp) {
                curl_setopt_array($ch, [
                    CURLOPT_FILE => $fp,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_CONNECTTIMEOUT => 15,
                    CURLOPT_TIMEOUT => 60,
                    CURLOPT_USERAGENT => 'domydesk-theme-installer'
                ]);

                $downloadOk = curl_exec($ch) !== false;
                $httpCode   = curl_getinfo($ch, CURLINFO_HTTP_CODE);

                curl_close($ch);
                fclose($fp);

                $downloadOk = $downloadOk && ($httpCode === 200);
            }
        }

        if (!$downloadOk && ini_get('allow_url_fopen')) {
            $notes[] = 'Try file_get_contents';

            $data = @file_get_contents($themeZipUrl);

            if ($data !== false) {
                $downloadOk = (@file_put_contents($zipPath, $data) !== false);
                $httpCode   = $downloadOk ? 200 : $httpCode;
            }
        }

        if (!$downloadOk) {
            $errors[] = 'Téléchargement échoué. HTTP=' . var_export($httpCode, true);
        } elseif (!is_file($zipPath) || filesize($zipPath) < 100) {
            $errors[] = 'ZIP téléchargé trop petit ou corrompu.';
        }

        if (!$errors) {
            if (!class_exists('ZipArchive')) {
                $errors[] = 'ZipArchive indisponible sur le serveur.';
            } else {
                $zip = new ZipArchive;

                if ($zip->open($zipPath) === true) {
                    $roots = [];

                    for ($i = 0; $i < $zip->numFiles; $i++) {
                        $n = ltrim($zip->getNameIndex($i), '/');

                        if ($n === '') {
                            continue;
                        }

                        $roots[explode('/', $n)[0] ?? ''] = true;
                    }

                    $hasSingleRoot = (count($roots) === 1);
                    $target = $themeDir . $themeName . '/';

                    if ($hasSingleRoot) {
                        $only = array_keys($roots)[0];

                        if ($only && $only === $themeName) {
                            $target = $themeDir;
                        }
                    }

                    if (!is_dir($target)) {
                        @mkdir($target, 0775, true);
                    }

                    $ok = $zip->extractTo($target);
                    $zip->close();

                    @unlink($zipPath);

                    if (!$ok) {
                        $errors[] = 'Erreur pendant extraction ZIP.';
                    } else {
                        $cssA = $themeDir . $themeName . '/style.css';
                        $cssB = $themeDir . $themeName . '/css/style.css';

                        if (!is_file($cssA) && !is_file($cssB)) {
                            $notes[] = 'Alerte: style.css introuvable à l’endroit attendu.';
                        }

                        $message .= ($message ? '<br>' : '') . "✅ Thème <b>" . htmlspecialchars($themeName) . "</b> installé.";
                    }
                } else {
                    @unlink($zipPath);
                    $errors[] = 'ZIP illisible.';
                }
            }
        }
    }

    if ($errors) {
        $message .= ($message ? '<br>' : '') . '❌ Installation échouée: ' . implode(' | ', $errors);
    }

    @file_put_contents(
        $logFile,
        "=== " . date('c') . " ===\n" .
        "URL: " . $themeZipUrl . "\n" .
        "THEME: " . $themeName . "\n" .
        "NOTES: " . implode(' ; ', $notes) . "\n" .
        "ERRORS: " . implode(' ; ', $errors) . "\n\n",
        FILE_APPEND
    );
}

/* ==========================================================
   Fonctions
   ========================================================== */

function getUserFolder($email) {
    return 'users/profiles/' . $email . '/';
}

function findPhpFiles($dir) {
    $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir));
    $files = [];

    foreach ($rii as $file) {
        if ($file->isFile() && $file->getExtension() === 'php') {
            $relPath = str_replace('\\', '/', substr($file->getPathname(), strlen(getcwd()) + 1));

            if (strpos($relPath, '/vendor/') !== false) {
                continue;
            }

            $files[] = [
                'label' => ucfirst(basename($file, ".php")),
                'link'  => $relPath
            ];
        }
    }

    return $files;
}

/* ==========================================================
   Session / chemins
   ========================================================== */

$isAdmin   = isset($_SESSION['user']['role_system']) && in_array($_SESSION['user']['role_system'], ['admin', 'superadmin'], true);
$userEmail = $_SESSION['user']['email'] ?? '';
$email     = (isset($_GET['email']) && $isAdmin) ? $_GET['email'] : $userEmail;

$userFolder = getUserFolder($email);

$profilePath = $userFolder . 'profile.json';
$menuPath    = $userFolder . 'menu.json';
$modulesPath = $userFolder . 'modules.json';
$avatarPath  = $userFolder . 'avatar.png';
$themePath   = $userFolder . 'theme.json';

$installedThemes = array_map('basename', glob(__DIR__ . "/theme/*", GLOB_ONLYDIR) ?: []);

$theme = 'default';

if (file_exists($themePath)) {
    $themeData = json_decode(file_get_contents($themePath), true);

    if (!empty($themeData['theme']) && file_exists(__DIR__ . "/theme/" . basename($themeData['theme']) . "/style.css")) {
        $theme = basename($themeData['theme']);
    }
}

$availablePages = findPhpFiles(__DIR__);
sort($availablePages);

$baseUrl = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');

foreach ($availablePages as &$p) {
    $p['link'] = $baseUrl . '/' . ltrim($p['link'], '/');
}

unset($p);

$userData    = file_exists($profilePath) ? json_decode(file_get_contents($profilePath), true) : [];
$menuDataRaw = file_exists($menuPath) ? json_decode(file_get_contents($menuPath), true) : [];
$menuData    = $menuDataRaw['items']['items'] ?? [];

$rolesFile    = 'data/roles_metier.json';
$rolesMetiers = file_exists($rolesFile) ? json_decode(file_get_contents($rolesFile), true) : [];

$modulesList = file_exists($modulesPath) ? json_decode(file_get_contents($modulesPath), true) : [];

$hasProfileExport = false;

if (!empty($modulesList) && is_array($modulesList)) {
    foreach ($modulesList as $mod) {
        if (!empty($mod['enabled']) && (($mod['id'] ?? '') === 'savev.1')) {
            $hasProfileExport = true;
            break;
        }
    }
}

$isSelf = ($email === $userEmail);
$existingHash = $userData['motdepasse'] ?? ($userData['password'] ?? null);

/* ==========================================================
   POST
   ========================================================== */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['update_profile'])) {
        $userData['prenom']      = $_POST['first_name'] ?? '';
        $userData['nom']         = $_POST['last_name'] ?? '';
        $userData['role_metier'] = $_POST['job_role'] ?? '';
        $userData['adresse']     = $_POST['adresse'] ?? '';

        if (!is_dir($userFolder)) {
            mkdir($userFolder, 0755, true);
        }

        file_put_contents($profilePath, json_encode($userData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $message = "Profil mis à jour avec succès.";
    }

    elseif (isset($_POST['upload_avatar'])) {
        if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
            $allowed = ['png', 'jpg', 'jpeg', 'webp'];

            if (in_array($ext, $allowed, true)) {
                if (!is_dir($userFolder)) {
                    mkdir($userFolder, 0755, true);
                }

                move_uploaded_file($_FILES['avatar']['tmp_name'], $avatarPath);
                $message = "Avatar mis à jour avec succès.";
            } else {
                $message = "❌ Format avatar non autorisé.";
            }
        } else {
            $message = "❌ Erreur upload avatar.";
        }
    }

    elseif (isset($_POST['update_theme'])) {
        $themeChoice = basename($_POST['theme'] ?? 'default');

        file_put_contents($themePath, json_encode(['theme' => $themeChoice], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

        $redir = 'profile_edit.php';

        if ($isAdmin && isset($_GET['email'])) {
            $redir .= '?email=' . urlencode($_GET['email']);
        }

        header("Location: $redir");
        exit;
    }

    elseif (isset($_POST['import_theme'])) {
        if (!class_exists('ZipArchive')) {
            $message = "❌ ZipArchive non disponible sur le serveur.";
        } elseif (isset($_FILES['theme_zip']) && is_uploaded_file($_FILES['theme_zip']['tmp_name'])) {
            $zipPath = $_FILES['theme_zip']['tmp_name'];
            $zip = new ZipArchive;

            if ($zip->open($zipPath) === true) {
                $folderName = basename($_FILES['theme_zip']['name'], '.zip');
                $extractPath = __DIR__ . "/theme/" . $folderName;

                if (!is_dir("theme")) {
                    mkdir("theme", 0755, true);
                }

                if (!is_dir($extractPath)) {
                    mkdir($extractPath, 0755, true);
                }

                $zip->extractTo($extractPath);
                $zip->close();

                $message = "Thème importé avec succès.";
            } else {
                $message = "❌ Impossible d’ouvrir le fichier ZIP.";
            }
        } else {
            $message = "❌ Erreur lors de l’import du fichier ZIP.";
        }
    }

    elseif (isset($_POST['update_menu'])) {
        $menuJson = $_POST['menu_json'] ?? '';
        $decodedMenu = json_decode($menuJson, true);

        if (is_array($decodedMenu)) {
            foreach ($decodedMenu as &$item) {
                if (($item['type'] ?? '') === 'page' && isset($item['link']) && strpos($item['link'], '/domydesk/') !== 0) {
                    $item['link'] = '/domydesk/' . ltrim($item['link'], '/');
                }

                if (!empty($item['submenu']) && is_array($item['submenu'])) {
                    foreach ($item['submenu'] as &$sub) {
                        if (($sub['type'] ?? '') === 'page' && isset($sub['link']) && strpos($sub['link'], '/domydesk/') !== 0) {
                            $sub['link'] = '/domydesk/' . ltrim($sub['link'], '/');
                        }
                    }
                }
            }

            unset($item, $sub);

            $fullMenu = ['items' => ['items' => $decodedMenu]];

            if (!is_dir($userFolder)) {
                mkdir($userFolder, 0755, true);
            }

            file_put_contents($menuPath, json_encode($fullMenu, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

            $menuData = $decodedMenu;
            $message = "✅ Menu latéral mis à jour.";
        } else {
            $message = "❌ Format JSON du menu invalide.";
        }
    }

    elseif (isset($_POST['change_password'])) {
        $new1 = $_POST['new_password'] ?? '';
        $new2 = $_POST['new_password_confirm'] ?? '';
        $old  = $_POST['current_password'] ?? '';
        $forceReset = !empty($_POST['reset_without_old']);

        if (strlen($new1) < 8) {
            $message = "❌ Nouveau mot de passe trop court, minimum 8 caractères.";
        } elseif ($new1 !== $new2) {
            $message = "❌ La confirmation ne correspond pas.";
        } else {
            $changingOwn = ($email === $userEmail) || !$isAdmin;

            if ($changingOwn && !empty($existingHash) && !$forceReset) {
                if ($old === '' || !password_verify($old, $existingHash)) {
                    $message = "❌ Ancien mot de passe incorrect. Cochez la réinitialisation si vous l’avez oublié.";
                    goto end_change_pwd;
                }
            }

            $newHash = password_hash($new1, PASSWORD_DEFAULT);

            $userData['motdepasse'] = $newHash;
            $userData['password'] = $newHash;

            if (isset($userData['password_hash'])) {
                unset($userData['password_hash']);
            }

            if (!is_dir($userFolder)) {
                mkdir($userFolder, 0755, true);
            }

            file_put_contents($profilePath, json_encode($userData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

            $message = $changingOwn ? "✅ Mot de passe mis à jour." : "✅ Mot de passe réinitialisé pour l’utilisateur.";
        }

        end_change_pwd: ;
    }
}

/* ==========================================================
   Modules configurables
   ========================================================== */

$moduleCards = [];

if (!empty($modulesList) && is_array($modulesList)) {
    foreach ($modulesList as $mod) {
        if (!empty($mod['enabled']) && !empty($mod['id'])) {
            $mid = basename($mod['id']);
            $cfg = __DIR__ . "/modules/$mid/{$mid}cfg.php";

            if (is_file($cfg)) {
                $moduleCards[] = [
                    'id' => $mid,
                    'name' => $mod['name'] ?? strtoupper($mid),
                    'description' => $mod['description'] ?? 'Module configurable'
                ];
            }
        }
    }
}

$themeFile = __DIR__ . "/theme/$theme/style.css";
$themeHref = $baseUrl . "/theme/" . rawurlencode($theme) . "/style.css";

if (is_file($themeFile)) {
    $themeHref .= '?v=' . filemtime($themeFile);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>DoMyDesk - Profil</title>
<link rel="stylesheet" href="<?= htmlspecialchars($themeHref) ?>">
</head>

<body>
<?php include 'header.php'; ?>

<div class="pe-page">
    <div class="pe-head">
        <div>
            <h1 class="pe-title">Configuration du profil</h1>
            <p class="pe-subtitle">Configuration de votre compte, vos menus, vos modules.</p>
        </div>

        <div class="pe-head-right">
            <?php if (file_exists($avatarPath)): ?>
                <img class="pe-head-avatar" src="<?= htmlspecialchars($avatarPath) ?>?t=<?= time() ?>" alt="Photo de profil">
            <?php else: ?>
                <div class="pe-head-avatar-empty">
                    <?= htmlspecialchars(strtoupper(substr(trim(($userData['prenom'] ?? 'U')), 0, 1))) ?>
                </div>
            <?php endif; ?>

            <div class="pe-user-pill"><?= htmlspecialchars($email) ?></div>
        </div>
    </div>

    <?php if ($message): ?>
        <div class="message pe-message"><?= $message ?></div>
    <?php endif; ?>

    <h2 class="pe-section-title">Vos paramètres</h2>

    <div class="pe-grid">
        <button type="button" class="pe-card" data-popup-open="popup-profile">
            <span class="pe-card-main">
                <span class="pe-card-title">Votre profil</span>
                <span class="pe-card-desc">Nom, prénom, rôle métier et adresse</span>
            </span>
            <span class="pe-card-icon">›</span>
        </button>

        <button type="button" class="pe-card" data-popup-open="popup-security">
            <span class="pe-card-main">
                <span class="pe-card-title">Sécurité</span>
                <span class="pe-card-desc">Modifier ou réinitialiser le mot de passe</span>
            </span>
            <span class="pe-card-icon">›</span>
        </button>

        <button type="button" class="pe-card" data-popup-open="popup-avatar">
            <span class="pe-card-main">
                <span class="pe-card-title">Avatar</span>
                <span class="pe-card-desc">Image du profil utilisateur</span>
            </span>
            <span class="pe-card-icon">›</span>
        </button>

        <button type="button" class="pe-card" data-popup-open="popup-theme">
            <span class="pe-card-main">
                <span class="pe-card-title">Thème</span>
                <span class="pe-card-desc">Choix, aperçu, import et catalogue</span>
            </span>
            <span class="pe-card-icon">›</span>
        </button>

        <button type="button" class="pe-card" data-popup-open="popup-menu">
            <span class="pe-card-main">
                <span class="pe-card-title">Menu vertical</span>
                <span class="pe-card-desc">Organisation du menu utilisateur</span>
            </span>
            <span class="pe-card-icon">›</span>
        </button>

        <?php if ($isAdmin): ?>
            <button type="button" class="pe-card" data-popup-open="popup-news">
                <span class="pe-card-main">
                    <span class="pe-card-title">Actualités</span>
                    <span class="pe-card-desc">Configuration des actualités DoMyDesk</span>
                </span>
                <span class="pe-card-icon">›</span>
            </button>
        <?php endif; ?>
    </div>

    <h2 class="pe-section-title">Vos modules</h2>

    <?php if (empty($moduleCards)): ?>
        <div class="message">Aucun module configurable.</div>
    <?php else: ?>
        <div class="pe-module-search">
            <input type="text" id="moduleSearch" placeholder="Recherche...">
        </div>

        <div class="pe-module-grid" id="moduleGrid">
            <?php foreach ($moduleCards as $c): ?>
                <button
                    type="button"
                    class="pe-card"
                    data-module-card
                    data-name="<?= htmlspecialchars(strtolower($c['name'] . ' ' . $c['id'])) ?>"
                    data-mod="<?= htmlspecialchars($c['id']) ?>"
                    data-label="<?= htmlspecialchars($c['name']) ?>"
                >
                    <span class="pe-card-main">
                        <span class="pe-card-title"><?= htmlspecialchars($c['name']) ?></span>
                        <span class="pe-card-desc"><?= htmlspecialchars($c['id']) ?> · cliquer pour configurer</span>
                    </span>
                    <span class="pe-card-icon">›</span>
                </button>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<div id="popup-profile" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window">
        <div class="pe-popup-head">
            <h2>Votre profil</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>

        <div class="pe-popup-body">
            <form method="POST" autocomplete="off" class="pe-form">
                <input type="hidden" name="update_profile" value="1">

                <div class="pe-form-row">
                    <div>
                        <label>Prénom</label>
                        <input type="text" name="first_name" value="<?= htmlspecialchars($userData['prenom'] ?? '') ?>" required>
                    </div>

                    <div>
                        <label>Nom</label>
                        <input type="text" name="last_name" value="<?= htmlspecialchars($userData['nom'] ?? '') ?>" required>
                    </div>
                </div>

                <div class="pe-form-row">
                    <div>
                        <label>Rôle métier</label>
                        <select name="job_role" required>
                            <option value="">-- Sélectionner --</option>
                            <?php foreach ($rolesMetiers as $role): ?>
                                <?php
                                    $val = is_array($role) ? ($role['label'] ?? $role['value'] ?? '') : $role;
                                    $selected = ($userData['role_metier'] ?? '') === $val ? 'selected' : '';
                                ?>
                                <option value="<?= htmlspecialchars($val) ?>" <?= $selected ?>>
                                    <?= htmlspecialchars($val) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label>Adresse</label>
                        <input type="text" name="adresse" value="<?= htmlspecialchars($userData['adresse'] ?? '') ?>">
                    </div>
                </div>

                <div class="pe-actions">
                    <button type="submit">Enregistrer</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="popup-security" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window">
        <div class="pe-popup-head">
            <h2>Sécurité</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>

        <div class="pe-popup-body">
            <form method="POST" autocomplete="off" class="pe-form">
                <input type="hidden" name="change_password" value="1">

                <?php if ($isSelf || !$isAdmin || $email === $userEmail): ?>
                    <?php if (!empty($existingHash)): ?>
                        <div>
                            <label>Ancien mot de passe</label>
                            <input type="password" name="current_password" placeholder="Facultatif si vous cochez la réinitialisation">
                        </div>

                        <label class="pe-check-line">
                            <input type="checkbox" name="reset_without_old" value="1">
                            Je ne connais plus l’ancien mot de passe, réinitialiser quand même
                        </label>
                    <?php else: ?>
                        <p class="pe-note">Aucun mot de passe défini encore pour ce compte.</p>
                        <input type="hidden" name="reset_without_old" value="1">
                    <?php endif; ?>
                <?php else: ?>
                    <p class="pe-note">
                        Administrateur : réinitialisation sans ancien mot de passe pour
                        <strong><?= htmlspecialchars($email) ?></strong>.
                    </p>
                    <input type="hidden" name="reset_without_old" value="1">
                <?php endif; ?>

                <div class="pe-form-row">
                    <div>
                        <label>Nouveau mot de passe</label>
                        <input type="password" name="new_password" placeholder="Min 8 caractères" minlength="8" required>
                    </div>

                    <div>
                        <label>Confirmation</label>
                        <input type="password" name="new_password_confirm" placeholder="Répétez le mot de passe" minlength="8" required>
                    </div>
                </div>

                <div class="pe-actions">
                    <button type="submit">Mettre à jour</button>
                </div>
            </form>

            <?php if ($hasProfileExport): ?>
                <hr>

                <div class="pe-form">
                    <div>
                        <label>Export du profil</label>
                        <p class="pe-note">
                            Télécharge une sauvegarde complète de votre dossier utilisateur DoMyDesk.
                        </p>
                    </div>

                    <div class="pe-actions">
                        <a href="modules/savev.1/download.php" class="btn">
                            Exporter son profil complet
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div id="popup-avatar" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window">
        <div class="pe-popup-head">
            <h2>Avatar</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>

        <div class="pe-popup-body">
            <div class="pe-avatar-line">
                <?php if (file_exists($avatarPath)): ?>
                    <img class="pe-avatar" src="<?= htmlspecialchars($avatarPath) ?>?t=<?= time() ?>" alt="Avatar">
                <?php else: ?>
                    <div class="pe-avatar-empty">?</div>
                <?php endif; ?>

                <div>
                    <p class="pe-note">Avatar actuel du compte.</p>
                </div>
            </div>

            <form method="POST" enctype="multipart/form-data" class="pe-form">
                <input type="hidden" name="upload_avatar" value="1">

                <div>
                    <label>Changer d'avatar</label>
                    <input type="file" name="avatar" accept="image/*" required>
                </div>

                <div class="pe-actions">
                    <button type="submit">Mettre à jour</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="popup-theme" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window">
        <div class="pe-popup-head">
            <h2>Thème</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>

        <div class="pe-popup-body">
            <form method="POST" class="pe-form">
                <input type="hidden" name="update_theme" value="1">

                <div>
                    <label>Choisir un thème</label>
                    <select name="theme">
                        <?php foreach (glob("theme/*", GLOB_ONLYDIR) as $dir): ?>
                            <?php
                                $dirName = basename($dir);
                                $selected = $theme === $dirName ? 'selected' : '';
                            ?>
                            <option value="<?= htmlspecialchars($dirName) ?>" <?= $selected ?>>
                                <?= htmlspecialchars(ucfirst($dirName)) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="pe-actions">
                    <button type="submit">Changer le thème</button>
                    <button type="button" id="openThemesGallery">Parcourir les thèmes</button>
                </div>

                <div class="pe-theme-preview">
                    <label>Aperçu du thème sélectionné</label>
                    <div class="pe-theme-preview-box">
                        <img id="theme-preview-img" src="" alt="Aperçu du thème">
                    </div>
                </div>
            </form>

            <hr>

            <form method="POST" enctype="multipart/form-data" class="pe-form">
                <input type="hidden" name="import_theme" value="1">

                <div>
                    <label>Importer un thème ZIP</label>
                    <input type="file" name="theme_zip" accept=".zip" required>
                </div>

                <div class="pe-actions">
                    <button type="submit">Importer</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="popup-menu" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2>Menu vertical</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>

        <div class="pe-popup-body">
            <form method="POST" onsubmit="prepareMenuJson();" class="pe-form">
                <input type="hidden" name="update_menu" value="1">
                <input type="hidden" id="menu_json" name="menu_json">

                <ul class="pe-menu-list" id="menuList"></ul>

                <div class="pe-actions">
                    <button type="button" class="btn-add" onclick="addMenuItem()">Ajouter un élément</button>
                    <button type="submit">Enregistrer le menu</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($isAdmin): ?>
    <div id="popup-news" class="pe-popup" aria-hidden="true">
        <div class="pe-popup-window pe-popup-wide">
            <div class="pe-popup-head">
                <h2>Actualités</h2>
                <button type="button" data-popup-close>Fermer</button>
            </div>

            <div class="pe-popup-body">
                <?php include __DIR__ . "/data/news/newscfg.php"; ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<div id="popup-module" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2 id="mod-host-title">Configuration</h2>
            <button type="button" id="mod-close" data-popup-close>Fermer</button>
        </div>

        <div class="pe-popup-body">
            <iframe id="mod-iframe" title="Configuration du module" loading="lazy"></iframe>
        </div>
    </div>
</div>

<div id="themesPopup" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2>Galerie des thèmes</h2>
            <button type="button" id="closeThemesPopup">Fermer</button>
        </div>

        <div class="pe-popup-body">
            <p class="pe-note">Survolez la loupe pour voir la miniature. ✅ = installé, ⬇️ = disponible.</p>

            <div class="table-wrap">
                <table class="th-table" id="themesTable">
                    <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Description</th>
                        <th>Aperçu</th>
                        <th>Statut</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>

            <div id="previewFloat" class="pe-preview-float">
                <img id="previewImg" src="" alt="preview">
            </div>
        </div>
    </div>
</div>

<script>
const availablePages = <?= json_encode($availablePages, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const menuData = <?= json_encode($menuData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const themeHref = <?= json_encode($themeHref, JSON_UNESCAPED_SLASHES) ?>;

const normLink = (s) => (s || '').replace(/^\/+/, '').replace(/^domydesk\//, '');

function escapeHtml(str) {
    return String(str ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function escapeAttr(str) {
    return escapeHtml(str);
}

function createOptionList(currentLink) {
    return [
        `<option value="">-- choisir une page --</option>`,
        ...availablePages.map(p => `<option value="${escapeAttr(p.link)}" ${normLink(p.link) === normLink(currentLink) ? 'selected' : ''}>${escapeHtml(p.label)}</option>`)
    ].join('');
}

function setVisibility(el, visible) {
    if (!el) {
        return;
    }

    el.hidden = !visible;
}

function createMenuItem(item = {}) {
    const li = document.createElement('li');

    const input = document.createElement('input');
    input.type = 'text';
    input.placeholder = 'Libellé';
    input.value = item.label || '';

    const selectType = document.createElement('select');
    selectType.innerHTML = `<option value="none">Pas de lien</option><option value="page">Page</option><option value="link">Lien externe</option>`;
    selectType.value = item.type || 'none';

    const selectPage = document.createElement('select');
    selectPage.innerHTML = createOptionList(item.link);

    const inputLink = document.createElement('input');
    inputLink.type = 'text';
    inputLink.placeholder = 'https://...';
    inputLink.value = item.type === 'link' ? (item.link || '') : '';

    function updateLinkFields() {
        setVisibility(selectPage, selectType.value === 'page');
        setVisibility(inputLink, selectType.value === 'link');
    }

    selectType.onchange = updateLinkFields;
    updateLinkFields();

    const addSubBtn = document.createElement('button');
    addSubBtn.type = 'button';
    addSubBtn.textContent = '+';
    addSubBtn.className = 'btn-sm btn-add';

    const delBtn = document.createElement('button');
    delBtn.type = 'button';
    delBtn.textContent = '×';
    delBtn.className = 'btn-sm btn-del';
    delBtn.onclick = () => li.remove();

    const subList = document.createElement('ul');
    subList.className = 'pe-submenu-list';

    (item.submenu || []).forEach(sub => subList.appendChild(createSubItem(sub)));

    addSubBtn.onclick = () => subList.appendChild(createSubItem());

    li.append(input, selectType, selectPage, inputLink, addSubBtn, delBtn, subList);

    return li;
}

function createSubItem(sub = {}) {
    const li = document.createElement('li');

    const input = document.createElement('input');
    input.type = 'text';
    input.placeholder = 'Sous-libellé';
    input.value = sub.label || '';

    const selectType = document.createElement('select');
    selectType.innerHTML = `<option value="none">Pas de lien</option><option value="page">Page</option><option value="link">Lien externe</option>`;
    selectType.value = sub.type || 'none';

    const selectPage = document.createElement('select');
    selectPage.innerHTML = createOptionList(sub.link);

    const inputLink = document.createElement('input');
    inputLink.type = 'text';
    inputLink.placeholder = 'https://...';
    inputLink.value = sub.type === 'link' ? (sub.link || '') : '';

    function updateLinkFields() {
        setVisibility(selectPage, selectType.value === 'page');
        setVisibility(inputLink, selectType.value === 'link');
    }

    selectType.onchange = updateLinkFields;
    updateLinkFields();

    const delBtn = document.createElement('button');
    delBtn.type = 'button';
    delBtn.textContent = '×';
    delBtn.className = 'btn-sm btn-del';
    delBtn.onclick = () => li.remove();

    li.append(input, selectType, selectPage, inputLink, delBtn);

    return li;
}

function addMenuItem() {
    document.getElementById('menuList')?.appendChild(createMenuItem());
}

function prepareMenuJson() {
    const items = [];

    document.querySelectorAll('#menuList > li').forEach(li => {
        const label = li.querySelector('input[type=text]')?.value.trim();
        const selects = li.querySelectorAll('select');
        const type = selects[0]?.value;

        const link = (type === 'page')
            ? selects[1]?.value
            : (type === 'link')
                ? li.querySelector('input[placeholder="https://..."]')?.value.trim()
                : '';

        const submenu = [];

        li.querySelectorAll('.pe-submenu-list > li').forEach(sub => {
            const subLabel = sub.querySelector('input[type=text]')?.value.trim();
            const subSelects = sub.querySelectorAll('select');
            const subType = subSelects[0]?.value;

            const subLink = (subType === 'page')
                ? subSelects[1]?.value
                : (subType === 'link')
                    ? sub.querySelector('input[placeholder="https://..."]')?.value.trim()
                    : '';

            if (subLabel) {
                submenu.push({
                    label: subLabel,
                    type: subType,
                    link: subLink,
                    submenu: []
                });
            }
        });

        if (label) {
            items.push({
                label,
                type,
                link,
                submenu
            });
        }
    });

    document.getElementById('menu_json').value = JSON.stringify(items, null, 2);
}

function openPopup(id) {
    const pop = document.getElementById(id);

    if (!pop) {
        return;
    }

    pop.classList.add('is-open');
    pop.setAttribute('aria-hidden', 'false');
    document.body.classList.add('noscroll');
}

function closePopup(pop) {
    if (!pop) {
        return;
    }

    pop.classList.remove('is-open');
    pop.setAttribute('aria-hidden', 'true');

    if (!document.querySelector('.pe-popup.is-open')) {
        document.body.classList.remove('noscroll');
    }
}

window.addEventListener('DOMContentLoaded', () => {
    const menuList = document.getElementById('menuList');

    if (menuList) {
        (menuData || []).forEach(item => menuList.appendChild(createMenuItem(item)));
    }

    const select = document.querySelector('select[name="theme"]');
    const previewImg = document.getElementById('theme-preview-img');

    function updatePreview() {
        if (select && previewImg) {
            previewImg.src = `theme/${select.value}/theme.png`;
        }
    }

    select?.addEventListener('change', updatePreview);
    updatePreview();

    document.querySelectorAll('[data-popup-open]').forEach(btn => {
        btn.addEventListener('click', () => openPopup(btn.dataset.popupOpen));
    });

    document.querySelectorAll('.pe-popup').forEach(pop => {
        pop.addEventListener('click', e => {
            if (e.target === pop) {
                closePopup(pop);
            }
        });
    });

    document.querySelectorAll('[data-popup-close]').forEach(btn => {
        btn.addEventListener('click', () => closePopup(btn.closest('.pe-popup')));
    });

    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') {
            document.querySelectorAll('.pe-popup.is-open').forEach(closePopup);
        }
    });
});
</script>

<script>
(() => {
    const frame = document.getElementById('mod-iframe');
    const title = document.getElementById('mod-host-title');
    const search = document.getElementById('moduleSearch');

    function openModule(id, label) {
        const url = `modules/${id}/${id}cfg.php?embed=1`;

        title.textContent = label || id.toUpperCase();
        frame.src = url;

        openPopup('popup-module');
    }

    window.addEventListener('message', (ev) => {
        if (!frame || !ev || !ev.data || ev.source !== frame.contentWindow || ev.data.type !== 'iframe-size') {
            return;
        }

        const h = Math.max(520, Math.min(ev.data.height | 0, 50000));
        frame.height = h;
    });

    frame?.addEventListener('load', () => {
        try {
            const doc = frame.contentDocument || frame.contentWindow.document;
            const hasTheme = [...doc.querySelectorAll('link[rel="stylesheet"]')].some(l => l.href && l.href.includes('/theme/'));

            if (!hasTheme && themeHref) {
                const link = doc.createElement('link');
                link.rel = 'stylesheet';
                link.href = themeHref;
                doc.head.appendChild(link);
            }

            const s = doc.createElement('script');
            s.text = `(function(){
                function send(){
                    try {
                        var h = Math.max(
                            document.documentElement.scrollHeight || 0,
                            document.body ? document.body.scrollHeight : 0
                        );
                        parent.postMessage({type:'iframe-size',height:h},'*');
                    } catch(e) {}
                }

                var ro = window.ResizeObserver ? new ResizeObserver(send) : null;

                if (ro && document.body) {
                    ro.observe(document.body);
                }

                var mo = new MutationObserver(function(){
                    setTimeout(send,0);
                });

                mo.observe(document.documentElement,{
                    subtree:true,
                    childList:true,
                    attributes:true,
                    characterData:true
                });

                window.addEventListener('load',function(){
                    setTimeout(send,10);
                    setTimeout(send,300);
                    setTimeout(send,1200);
                });

                setTimeout(send,10);
            })();`;

            doc.body.appendChild(s);
        } catch(e) {
            console.error(e);
        }
    });

    document.getElementById('moduleGrid')?.addEventListener('click', (e) => {
        const btn = e.target.closest('[data-mod]');

        if (!btn) {
            return;
        }

        openModule(btn.getAttribute('data-mod'), btn.getAttribute('data-label'));
    });

    document.getElementById('mod-close')?.addEventListener('click', () => {
        frame.src = 'about:blank';
        frame.removeAttribute('height');
    });

    search?.addEventListener('input', () => {
        const q = search.value.trim().toLowerCase();

        document.querySelectorAll('[data-module-card]').forEach(card => {
            card.hidden = !(card.getAttribute('data-name') || '').includes(q);
        });
    });
})();
</script>

<script>
(() => {
    const THEMES_JSON_URL = <?= json_encode($themesCatalogUrl, JSON_UNESCAPED_SLASHES) ?>;
    const INSTALLED = <?= json_encode($installedThemes, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;

    const btnOpen = document.getElementById('openThemesGallery');
    const popup = document.getElementById('themesPopup');
    const btnClose = document.getElementById('closeThemesPopup');
    const tbody = document.querySelector('#themesTable tbody');
    const floatBox = document.getElementById('previewFloat');
    const floatImg = document.getElementById('previewImg');

    const isImg = (u = '') => /\.(png|jpe?g|webp|gif|avif|svg)(\?|#|$)/i.test(u);
    const isPdf = (u = '') => /\.pdf(\?|#|$)/i.test(u);

    function slugify(s = '') {
        return String(s)
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '');
    }

    function installUrl(id, dl) {
        const base = new URL(location.href);
        const p = new URLSearchParams(base.search);

        p.set('download_theme', id);
        p.set('theme_url', dl);

        return `${base.pathname}?${p.toString()}#themes`;
    }

    function movePreview(e) {
        floatBox.style.left = (e.clientX + 16) + 'px';
        floatBox.style.top = (e.clientY + 16) + 'px';
    }

    function renderRow(item) {
        const name = item.name || 'Sans nom';
        const id = item.id ? String(item.id) : slugify(name);
        const desc = item.description || '';
        const date = item.date ? ` (${item.date})` : '';
        const img = item.image || '';
        const dl = item.dl || '';
        const size = item.size ? ` · ${item.size}` : '';
        const installed = INSTALLED.includes(id);

        const tr = document.createElement('tr');

        tr.innerHTML = `
            <td><strong>${escapeHtml(name)}</strong>${escapeHtml(date)}</td>
            <td>${escapeHtml(desc + size)}</td>
            <td></td>
            <td>${installed ? '✅ Installé' : '⬇️ Disponible'}</td>
            <td></td>
        `;

        const tdPreview = tr.children[2];
        const tdAction = tr.children[4];

        if (img && isImg(img)) {
            const span = document.createElement('span');

            span.className = 'th-loupe';
            span.textContent = '🔍 Voir';
            span.dataset.preview = img;

            span.addEventListener('mouseenter', e => {
                floatImg.src = span.dataset.preview || '';
                floatBox.classList.add('is-visible');
                movePreview(e);
            });

            span.addEventListener('mousemove', movePreview);

            span.addEventListener('mouseleave', () => {
                floatBox.classList.remove('is-visible');
                floatImg.src = '';
            });

            tdPreview.appendChild(span);
        } else if (img) {
            const a = document.createElement('a');

            a.className = 'btn-sm';
            a.href = img;
            a.target = '_blank';
            a.rel = 'noopener';
            a.textContent = isPdf(img) ? 'Aperçu PDF' : 'Aperçu';

            tdPreview.appendChild(a);
        } else {
            tdPreview.textContent = '—';
        }

        if (dl && installed) {
            const btn = document.createElement('button');

            btn.type = 'button';
            btn.textContent = 'Appliquer';

            btn.addEventListener('click', () => {
                const sel = document.querySelector('select[name="theme"]');

                if (sel) {
                    sel.value = id;
                    sel.closest('form')?.submit();
                }
            });

            tdAction.appendChild(btn);
        } else if (dl) {
            const a = document.createElement('a');

            a.className = 'btn-sm';
            a.href = installUrl(id, dl);
            a.textContent = 'Télécharger';

            tdAction.appendChild(a);
        } else {
            tdAction.textContent = 'Pas de ZIP';
        }

        return tr;
    }

    async function loadThemes() {
        if (!tbody) {
            return;
        }

        tbody.innerHTML = `<tr><td colspan="5">Chargement…</td></tr>`;

        try {
            const res = await fetch(THEMES_JSON_URL, {
                cache: 'no-store'
            });

            if (!res.ok) {
                throw new Error('HTTP ' + res.status);
            }

            const data = await res.json();
            const items = Array.isArray(data) ? data : (Array.isArray(data.items) ? data.items : []);

            if (!items.length) {
                tbody.innerHTML = `<tr><td colspan="5">Aucun thème dans le catalogue.</td></tr>`;
                return;
            }

            tbody.innerHTML = '';

            items.forEach(item => tbody.appendChild(renderRow(item)));
        } catch (err) {
            console.error(err);
            tbody.innerHTML = `<tr><td colspan="5">Erreur de chargement du catalogue.</td></tr>`;
        }
    }

    btnOpen?.addEventListener('click', () => {
        openPopup('themesPopup');
        loadThemes();
    });

    btnClose?.addEventListener('click', () => closePopup(popup));
})();
</script>

</body>
</html>