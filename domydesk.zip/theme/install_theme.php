<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Méthode non autorisée.');
}
$url = $_POST['url'] ?? '';
$id  = basename($_POST['id'] ?? ''); // nom du dossier cible
if (!$url) exit('❌ URL manquante.');
if (!$id) {
    // si non fourni, on devine depuis le nom du zip
    $id = pathinfo(parse_url($url, PHP_URL_PATH), PATHINFO_FILENAME);
    $id = preg_replace('~[^a-zA-Z0-9._-]+~', '-', $id);
}
if (!$id) exit('❌ ID de thème invalide.');
$themesDir = __DIR__ . '/theme';
$targetDir = $themesDir . '/' . $id;
if (!is_dir($themesDir) && !mkdir($themesDir, 0755, true)) {
    exit('❌ Impossible de créer le dossier /theme.');
}
if (is_dir($targetDir)) {
    exit('✅ Déjà installé.');
}
$tmp = tempnam(sys_get_temp_dir(), 'thm_');
if (!$tmp) exit('❌ Impossible de créer un fichier temporaire.');
function fetch_to_file($url, $dest){
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        $fp = fopen($dest, 'wb');
        curl_setopt_array($ch, [
            CURLOPT_FILE => $fp,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $ok = curl_exec($ch);
        $err = $ok ? null : curl_error($ch);
        curl_close($ch);
        fclose($fp);
        return $ok ? true : $err;
    }
    $data = @file_get_contents($url);
    if ($data === false) return 'Téléchargement impossible.';
    return file_put_contents($dest, $data) !== false;
}
$dl = fetch_to_file($url, $tmp);
if ($dl !== true) {
    @unlink($tmp);
    exit('❌ Téléchargement échoué: ' . (is_string($dl) ? $dl : ''));
}
if (!class_exists('ZipArchive')) {
    @unlink($tmp);
    exit('❌ ZipArchive non disponible sur le serveur.');
}
$zip = new ZipArchive();
if ($zip->open($tmp) !== true) {
    @unlink($tmp);
    exit('❌ Impossible d’ouvrir le ZIP.');
}
$tmpExtract = sys_get_temp_dir() . '/thm_' . uniqid();
if (!mkdir($tmpExtract, 0755, true)) {
    @unlink($tmp);
    exit('❌ Impossible de préparer l’extraction.');
}
$zip->extractTo($tmpExtract);
$zip->close();
@unlink($tmp);
$entries = array_values(array_filter(scandir($tmpExtract), fn($e)=>$e !== '.' && $e !== '..'));
$root = $tmpExtract;
if (count($entries) === 1 && is_dir($tmpExtract . '/' . $entries[0])) {
    $root = $tmpExtract . '/' . $entries[0];
}
if (!rename($root, $targetDir)) {
    function rcopy($src, $dst){
        if (is_dir($src)) {
            if (!is_dir($dst)) mkdir($dst, 0755, true);
            foreach (scandir($src) as $f) {
                if ($f === '.' || $f === '..') continue;
                rcopy("$src/$f", "$dst/$f");
            }
        } else {
            copy($src, $dst);
        }
    }
    rcopy($root, $targetDir);
}
function rrmdir($dir){
    if (!is_dir($dir)) return;
    foreach (scandir($dir) as $f) {
        if ($f === '.' || $f === '..') continue;
        $p = "$dir/$f";
        is_dir($p) ? rrmdir($p) : @unlink($p);
    }
    @rmdir($dir);
}
rrmdir($tmpExtract);
echo '✅ Thème installé avec succès.';
