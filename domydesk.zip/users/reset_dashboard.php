<?php
// users/reset_dashboard.php
session_start();
header('Content-Type: application/json; charset=utf-8');
// Anti-cache côté client/proxy
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

if (!isset($_SESSION['user']['email'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'err' => 'unauthorized']);
    exit;
}

$email   = $_SESSION['user']['email'];
$baseDir = __DIR__ . "/profiles/$email";

// Sanitize du nom de dashboard (évite ../ etc.)
$dashboardName = $_GET['dashboard'] ?? 'dashboard';
if (!preg_match('~^[a-zA-Z0-9._-]{1,64}$~', $dashboardName)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'err' => 'bad_name']);
    exit;
}

if (!is_dir($baseDir)) {
    // On tente de créer le dossier si besoin
    @mkdir($baseDir, 0775, true);
    if (!is_dir($baseDir)) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'err' => 'profile_dir_missing']);
        exit;
    }
}

$dashboardFile = "$baseDir/$dashboardName.json";

// Ecrit un tableau vide proprement, avec verrou
$data = json_encode([], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
$ok = @file_put_contents($dashboardFile, $data, LOCK_EX);

if ($ok === false) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'err' => 'write_failed']);
    exit;
}

// Petit "touch" pour forcer certaines couches à invalider le cache
@touch($dashboardFile, time());

echo json_encode(['ok' => true, 'file' => basename($dashboardFile)]);
