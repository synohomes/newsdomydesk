<?php
session_start();
if (!isset($_SESSION['user']['email'])) exit;
$email = $_SESSION['user']['email'];
$userDir = __DIR__ . "/profiles/$email";
$dashboardName = $_GET['dashboard'] ?? 'dashboard';
$dashboardFile = "$userDir/$dashboardName.json";
$data = json_decode(file_get_contents('php://input'), true);
if (!is_array($data)) exit;
file_put_contents($dashboardFile, json_encode($data, JSON_PRETTY_PRINT));
