<?php
session_start();
if(!isset($_SESSION['user']['email']))exit;
$d=json_decode(file_get_contents('php://input'),true);$n=trim($d['name']??'');
if(!$n)exit;$uid=$_SESSION['user']['email'];$dir=__DIR__."/profiles/$uid";
$list="$dir/dashboards.json";$dash=json_decode(file_get_contents($list),true);
if(count($dash)>=5 || in_array($n,$dash))exit;
$dash[]=$n;file_put_contents($list,json_encode($dash,JSON_PRETTY_PRINT));
file_put_contents("$dir/$n.json",'[]');
