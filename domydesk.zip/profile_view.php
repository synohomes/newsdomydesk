<?php
session_start();

// Sécurité minimale: accès connecté
if (!isset($_SESSION['user']['email'])) {
    header('Location: login.php');
    exit;
}

/* ===== Thème = celui de l'utilisateur connecté (affichage) ===== */
$viewerEmail = $_SESSION['user']['email'];
$viewerRole  = $_SESSION['user']['role_system'] ?? ''; // ✅ AJOUT pour gérer l'affichage admin
$viewerDir   = __DIR__ . '/users/profiles/' . $viewerEmail . '/';
$themeJson   = $viewerDir . 'theme.json';
$theme       = 'default';
if (file_exists($themeJson)) {
    $themeData = json_decode(file_get_contents($themeJson), true);
    if (!empty($themeData['theme']) && file_exists(__DIR__ . "/theme/" . $themeData['theme'] . "/style.css")) {
        $theme = basename($themeData['theme']);
    }
}

/* ===== Cible = paramètre ?user= (ou soi-même par défaut) ===== */
$targetEmail = isset($_GET['user']) ? urldecode($_GET['user']) : $viewerEmail;

/* Anti-traversal basique sans transformer l'email */
if (strpos($targetEmail, '..') !== false || strpos($targetEmail, '/') !== false || strpos($targetEmail, '\\') !== false) {
    die('Paramètre utilisateur invalide.');
}

$targetDir   = __DIR__ . '/users/profiles/' . $targetEmail . '/';
$profilePath = $targetDir . 'profile.json';
$avatarPath  = $targetDir . 'avatar.png';
$modulesPath = $targetDir . 'modules.json';

if (!file_exists($profilePath)) {
    die('File not found.');
}

$profile = json_decode(file_get_contents($profilePath), true);
$modules = file_exists($modulesPath) ? json_decode(file_get_contents($modulesPath), true) : [];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <title>Profil de <?php echo htmlspecialchars(($profile['prenom'] ?? '') . ' ' . ($profile['nom'] ?? ''), ENT_QUOTES); ?></title>
    <link rel="stylesheet" href="theme/<?php echo htmlspecialchars($theme, ENT_QUOTES); ?>/style.css">
    <style>
        /* Scope local: héritage du thème uniquement */
        .profile-scope { --accent: currentColor; }

        .profile-scope h1 {
            text-align: center;
            margin: 24px 0 12px;
            font-size: 2rem;
        }

        .profile-scope .section {
            max-width: 900px;
            margin: 20px auto 30px;
        }

        .profile-container {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 16px;
        }

        .avatar-container { position: relative; }

        .avatar {
            width: 200px; height: 200px; border-radius: 50%;
            object-fit: cover; border: 2px solid var(--accent); display: block;
        }
        .avatar.fallback {
            display:flex; align-items:center; justify-content:center;
            background: transparent; color: inherit; font-weight: 700;
            width: 200px; height: 200px; border-radius: 50%; border: 2px solid var(--accent);
        }

        .edit-icon {
            position: absolute; top: 10px; right: 10px;
            border: 1px solid color-mix(in srgb, var(--accent) 55%, transparent);
            background: color-mix(in srgb, var(--accent) 35%, transparent);
            border-radius: 10px; padding: 6px 10px; color: inherit; font-size: 12px; font-weight: 700;
            text-decoration: none; box-shadow: none; transition: opacity .2s, transform .12s, background .2s;
            opacity: 0; z-index: 2;
        }
        .avatar-container:hover .edit-icon { opacity: 1; }
        .edit-icon:hover { transform: translateY(-1px); }

        .info p { margin: 6px 0; font-size: 1.05rem; }

        .modules { margin-top: 16px; }
        .modules h2 { margin-bottom: 10px; font-size: 1.2rem; }

        /* Liste modules en 3 colonnes */
        .modules ul {
            list-style: none; padding: 0; margin: 0;
            display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px 20px;
        }
        .modules li {
            padding: 6px 8px; border: 1px solid var(--accent); border-radius: 6px;
            text-align: center; background: color-mix(in srgb, var(--accent) 10%, transparent);
        }

        /* Boutons de retour */
        .back-links { display:flex; justify-content:center; gap:14px; margin: 0 0 24px; }
        .back-link {
            display:inline-block; font-weight:700; text-decoration:none; padding:8px 12px;
            border:1px solid color-mix(in srgb, var(--accent) 50%, transparent);
            border-radius:10px; background: color-mix(in srgb, var(--accent) 18%, transparent); color: inherit;
        }
        .back-link:hover { background: color-mix(in srgb, var(--accent) 28%, transparent); }
    </style>
</head>
<body>
<?php include 'header.php'; ?>

<div class="profile-scope">
    <h1>Fiche utilisateur</h1>

    <div class="section">
        <div class="profile-container">
            <div class="avatar-container">
                <?php if (file_exists($avatarPath)) { ?>
                    <img src="users/profiles/<?php echo htmlspecialchars($targetEmail, ENT_QUOTES); ?>/avatar.png?t=<?php echo time(); ?>" alt="Avatar" class="avatar">
                <?php } else { ?>
                    <div class="avatar fallback">N/A</div>
                <?php } ?>

                <?php if ($targetEmail === $viewerEmail || $viewerRole === 'admin') { ?>
                    <a href="profile_edit.php?email=<?= urlencode($targetEmail) ?>" class="edit-icon" title="Modifier le profil">✏️ Modifier</a>
                <?php } ?>
            </div>

            <div class="info">
                <p><strong>Prénom :</strong> <?php echo htmlspecialchars($profile['prenom'] ?? '', ENT_QUOTES); ?></p>
                <p><strong>Nom :</strong> <?php echo htmlspecialchars($profile['nom'] ?? '', ENT_QUOTES); ?></p>
                <p><strong>Email :</strong> <?php echo htmlspecialchars($profile['email'] ?? $targetEmail, ENT_QUOTES); ?></p>
                <p><strong>Rôle système :</strong> <?php echo htmlspecialchars($profile['role_system'] ?? '', ENT_QUOTES); ?></p>
                <p><strong>Rôle métier :</strong> <?php echo htmlspecialchars($profile['role_metier'] ?? '', ENT_QUOTES); ?></p>
            </div>
        </div>

        <div class="modules">
            <h2>Modules activés :</h2>
            <?php
            $enabledModules = array_filter($modules, fn($m) => !empty($m['enabled']));
            if (!empty($enabledModules)) { ?>
                <ul>
                    <?php foreach ($enabledModules as $module) {
                        echo '<li>' . htmlspecialchars($module['name'] ?? $module['id'] ?? 'Module', ENT_QUOTES) . '</li>';
                    } ?>
                </ul>
            <?php } else { ?>
                <p>Aucun module activé.</p>
            <?php } ?>
        </div>
    </div>

    <div class="back-links">
        <a class="back-link" href="dashboard.php">← Retour au dashboard</a>
        <a class="back-link" href="members.php">← Retour à la liste des membres</a>
    </div>
</div>

<script>
/* Récupère la couleur de bordure de .section (thème) et l’injecte en --accent */
document.addEventListener('DOMContentLoaded', function () {
  const scope = document.querySelector('.profile-scope');
  const section = scope?.querySelector('.section');
  if (!scope || !section) return;
  const cs = getComputedStyle(section);
  const accent = cs.borderTopColor || cs.borderColor;
  if (accent) scope.style.setProperty('--accent', accent);
});
</script>

</body>
</html>
