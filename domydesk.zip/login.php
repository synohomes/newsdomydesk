<?php
session_start();
if (isset($_SESSION['user'])) {
    header('Location: index.php');
    exit;
}
$error = '';
$email = '';
$theme = 'default';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'] ?? '';
    if (!$email) {
        $error = "Email invalide.";
    } else {
        $userDir     = __DIR__ . '/users/profiles/' . $email . '/';
        $profilePath = $userDir . 'profile.json';
        $themePath   = $userDir . 'theme.json';
        if (file_exists($themePath)) {
            $themeData = json_decode(file_get_contents($themePath), true);
            if (!empty($themeData['theme']) && file_exists(__DIR__ . "/theme/{$themeData['theme']}/style.css")) {
                $theme = basename($themeData['theme']);
            }
        }
        if (file_exists($profilePath)) {
            $profile = json_decode(file_get_contents($profilePath), true);
            if ($profile && isset($profile['motdepasse']) && password_verify($password, $profile['motdepasse'])) {
                $_SESSION['user'] = [
                    'email'        => $profile['email'] ?? $email,
                    'prenom'       => $profile['prenom'] ?? '',
                    'nom'          => $profile['nom'] ?? '',
                    'role_system'  => $profile['role_system'] ?? '',
                    'role_metier'  => $profile['role_metier'] ?? ''
                ];
                header('Location: dashboard.php');
                exit;
            } else {
                $error = "Mot de passe incorrect.";
            }
        } else {
            $error = "Utilisateur non trouvé.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <title>Se connecter</title>
    <link rel="stylesheet" href="theme/<?= htmlspecialchars($theme) ?>/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
      *, *::before, *::after { box-sizing: border-box; }
      :root{
        --primary-color: var(--primary-color, #3ea2ff);
        --primary-dark:  var(--primary-dark,  #1b2634);
        --bg-deep:       var(--bg-deep, #0b0f14);
        --text:          var(--text, #e8f0ff);
        --muted:         var(--muted, #a7b4c7);
      }
      html,body{height:100%;margin:0}
      body{
        font-family: 'Segoe UI', Roboto, Arial, sans-serif;
        color: var(--text);
        background:
          radial-gradient(60rem 60rem at 10% 10%, rgba(255,255,255,0.03), transparent 40%),
          radial-gradient(60rem 60rem at 90% 20%, rgba(255,255,255,0.03), transparent 45%),
          linear-gradient(180deg, rgba(0,0,0,0.4), rgba(0,0,0,0.6)),
          var(--bg-deep);
        overflow: hidden;
      }
      .float-cloud{
        position: fixed; inset: 0; pointer-events: none; overflow: hidden; z-index: 0;
        mask-image: radial-gradient(60% 60% at 50% 50%, #000 65%, transparent 100%);
      }
      .float-word{
        position: absolute; font-weight: 600; white-space: nowrap; opacity: .08;
        transform: translate(-50%,-50%); user-select: none;
        filter: drop-shadow(0 0 1px rgba(0,0,0,.15));
        animation: drift var(--dur) linear infinite;
      }
      .float-word::before{ content:"• "; opacity:.4 }
      @keyframes drift{
        0%{   transform: translate(var(--xStart), var(--y)); }
        100%{ transform: translate(var(--xEnd),   var(--y)); }
      }
      .corner-badge{
        position: fixed; top: 18px; right: 18px; z-index: 3;
        background: linear-gradient(180deg, rgba(255,255,255,0.08), rgba(255,255,255,0.04));
        backdrop-filter: blur(6px);
        border: 1px solid rgba(255,255,255,0.12);
        border-radius: 14px;
        box-shadow: 0 8px 24px rgba(0,0,0,.35);
        padding: 10px 12px; display: flex; align-items: center; gap: 10px;
      }
      .corner-badge img{
        width: 34px; height: 34px; object-fit: contain; border-radius: 8px;
        background: rgba(0,0,0,.15);
      }
      .corner-badge .txt{ line-height:1.1; font-size: .9rem; color:#dfe7ff; }
      .wrap{ position: relative; z-index: 2; min-height: 100%;
        display: grid; place-items: center; padding: clamp(16px,2vw,32px);
      }
      .login-card{
        width: min(600px, 92vw);
        background: linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02));
        backdrop-filter: blur(8px);
        border-radius: 18px;
        border: 1px solid rgba(255,255,255,0.08);
        box-shadow: 0 10px 30px rgba(0,0,0,0.35), 0 0 0 1px rgba(255,255,255,0.03) inset;
        padding: 28px;
        overflow: hidden;           
      }
      .brand{
        display:flex; align-items:center; gap:12px; justify-content:center; margin-bottom:14px;
      }
      .brand img{
        width: 38px; height: 38px; object-fit: contain; border-radius: 10px;
        background: rgba(0,0,0,.15); border: 1px solid rgba(255,255,255,.12);
        box-shadow: 0 2px 10px rgba(0,0,0,.35);
      }
      .brand h1{ margin:0; letter-spacing:.3px; font-size:1.35rem; }
      .brand a{ color:#fff; text-decoration:none; }
      .brand a:hover{ text-decoration:underline; text-underline-offset:3px; }
      .subtitle{ text-align:center; color: var(--muted); font-size:.95rem; margin-bottom:18px; }
      .divider{ height:1px; width:100%; background: linear-gradient(90deg, transparent, rgba(255,255,255,0.12), transparent); margin: 14px 0 18px; }
      form{ display:block; margin:0; }
      form label{ display:block; font-size:.9rem; color:#dfe8ff; margin-bottom:6px; }
      .field{
        position: relative; margin-bottom: 14px;
        overflow: hidden; 
        isolation: isolate; 
        min-width: 0; 
      }
      .inp{
        display:block;
        width: 100%;
        max-width: 100%;
        padding: 12px 44px;
        font-size: .98rem; color: #eaf2ff;
        background: rgba(255,255,255,.06);
        border: 1px solid rgba(255,255,255,.12);
        border-radius: 12px; outline: none;
        transition: border-color .2s, box-shadow .2s, background .2s;
        box-sizing: border-box;
      }
      .inp::placeholder{ color: rgba(255,255,255,.45); }
      .field:focus-within .inp{
        border-color: color-mix(in oklab, var(--primary-color) 70%, white 0%);
        box-shadow: 0 0 0 4px color-mix(in oklab, var(--primary-color) 15%, transparent 85%);
        background: rgba(255,255,255,.08);
      }
      .icon{
        position:absolute; left:12px; top:50%; transform:translateY(-50%);
        width:22px; height:22px; opacity:.85; pointer-events:none;
      }
      .toggle{
        position:absolute; right:12px; top:50%; transform:translateY(-50%);
        display:inline-flex; align-items:center; justify-content:center;
        width:26px; height:26px; border:none; background:transparent; color:#cfe2ff;
        cursor:pointer; padding:0; border-radius:6px; opacity:.9;
      }
      .toggle:hover{ opacity: 1; }
      .field .act, .field button:not(.toggle):not([type="submit"]){ display:none !important; }
      .row{ display:flex; align-items:center; justify-content:space-between; gap:10px; margin-top:4px; margin-bottom:12px; }
      .row label.inline{ display:flex; align-items:center; gap:8px; color:#cfe2ff; cursor:pointer; font-size:.92rem; }
      .row input[type="checkbox"]{ width:16px; height:16px; accent-color: var(--primary-color); }
      .btn{
        width:100%; padding:12px 16px; font-weight:700; letter-spacing:.2px;
        border:none; cursor:pointer; border-radius:12px; color:#0a1018;
        background: radial-gradient(120% 150% at 20% 0%, rgba(255,255,255,.35), transparent 40%),
                    linear-gradient(90deg, color-mix(in oklab, var(--primary-dark) 20%, var(--primary-color) 80%), var(--primary-color));
        box-shadow: 0 10px 24px rgba(0,0,0,.35);
        transition: transform .08s ease, filter .2s ease, box-shadow .2s ease;
      }
      .btn:hover{ filter: brightness(1.06) saturate(1.05); box-shadow: 0 12px 26px rgba(0,0,0,.45); }
      .btn:active{ transform: translateY(1px); }

      .links{ display:flex; justify-content:space-between; margin-top:12px; }
      .links a{ color:#d0e4ff; text-decoration:none; font-size:.93rem; opacity:.9; }
      .links a:hover{ text-decoration:underline; opacity:1; }
      .error{
        background: rgba(255,65,65,.12);
        border: 1px solid rgba(255,65,65,.25);
        color: #ffd4d4; padding:10px 12px; border-radius:10px; margin-bottom:12px; font-weight:600; text-align:center;
      }
      .footnote{ margin-top:14px; text-align:center; color:#98abc5; font-size:.85rem; opacity:.9; }
      .footnote strong{ color:#dbe7ff; }
      @media (max-width:420px){
        .brand h1{ font-size:1.2rem; }
        .subtitle{ font-size:.9rem; }
      }
    </style>
</head>
<body>
  <a class="corner-badge" href="https://domydesk.com" target="_blank" rel="noopener" title="domydesk.com">
    <img src="data/Logo.png" alt="Logo DoMyDesk" onerror="this.style.display='none'">
    <div class="txt">DoMyDesk</div>
  </a>
  <div class="float-cloud" aria-hidden="true" id="floatCloud"></div>
  <div class="wrap">
    <div class="login-card" role="dialog" aria-labelledby="ttl">
      <div class="brand">
        <img src="data/Logo.png" alt="Logo" onerror="this.style.display='none'">
        <h1 id="ttl">
          <a href="https://domydesk.com" target="_blank" rel="noopener noreferrer" title="Ouvrir domydesk.com">Se connecter:</a>
        </h1>
      </div>
      <div class="subtitle">Votre espace de travail modulaire, privé et élégant.</div>
      <div class="divider"></div>
      <?php if (!empty($error)): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>
      <form method="post" action="" autocomplete="on" novalidate>
        <label for="email">Adresse e-mail</label>
        <div class="field">
          <svg class="icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2Zm0 4-8 5L4 8V6l8 5 8-5v2Z"/></svg>
          <input class="inp" type="email" id="email" name="email" placeholder="vous@exemple.com" value="<?= htmlspecialchars($email) ?>" required>
        </div>
        <label for="password">Mot de passe</label>
        <div class="field">
          <svg class="icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 1a5 5 0 0 0-5 5v3H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8a2 2 0 0 0-2-2h-1V6a5 5 0 0 0-5-5Zm-3 8V6a3 3 0 0 1 6 0v3H9Zm3 5a2 2 0 1 1 0 4 2 2 0 0 1 0-4Z"/></svg>
          <input class="inp" type="password" id="password" name="password" placeholder="••••••••" required>
          <button type="button" class="toggle" id="togglePwd" aria-label="Afficher/masquer">👁️</button>
        </div>
        <button class="btn" type="submit">Se connecter</button>
        <div class="links">
          <a href="register.php">Créer un compte</a>
        </div>
        <div class="footnote">
          Accès réservé • <strong>DoMyDesk</strong> — Modular Private Workspace
        </div>
      </form>
    </div>
  </div>
  <script>
    (function(){
      const btn = document.getElementById('togglePwd');
      const inp = document.getElementById('password');
      if(btn && inp){
        btn.addEventListener('click', ()=>{
          const type = inp.getAttribute('type') === 'password' ? 'text' : 'password';
          inp.setAttribute('type', type);
          btn.textContent = (type === 'password') ? '👁️' ;
        });
      }
    })();
    const procedures = [
      "Installation VPS","Tunnels WireGuard","IPSec NAT-T","Reverse Proxy NGINX",
      "DoMyDesk ID","Sauvegarde continue","Thèmes CSS unifiés","Profils utilisateurs JSON",
      "Gestion des modules","Market Modules","Tailscale","Proxmox API",
      "DOC: profile_edit.php","DOC: site_settings.php","Grille magnétique","Interact.js",
      "Multi-dashboard","Droits & rôles","Exports PDF/CSV","Procédures RH"
    ];
    const modules = [
      "animals","dmdcook","ticketing","folders","pdfviewer","map","dmdyou",
      "gamesmanage","chessai","inventaire","proxv2","social","translator",
      "remote","vm","weather","todolist","management","infra","hoas"
    ];
    const words = [...procedures, ...modules];
    const cloud = document.getElementById('floatCloud');
    function rand(min, max){ return Math.random()*(max-min)+min; }
    const maxWords = Math.min(words.length, 36);
    for(let i=0;i<maxWords;i++){
      const w = document.createElement('span');
      w.className = 'float-word';
      w.textContent = words[i % words.length];
      const y = rand(5,95).toFixed(2)+'vh';
      const xStart = (-20 - rand(0,30)).toFixed(2)+'vw';
      const xEnd = (120 + rand(0,30)).toFixed(2)+'vw';
      const dur = rand(28,55).toFixed(2)+'s';
      const delay = (-rand(0,55)).toFixed(2)+'s';
      const fs = rand(12,22).toFixed(0)+'px';
      w.style.color = `color-mix(in oklab, var(--primary-color) 40%, white 60%)`;
      w.style.fontSize = fs;
      w.style.setProperty('--y', y);
      w.style.setProperty('--xStart', xStart);
      w.style.setProperty('--xEnd', xEnd);
      w.style.setProperty('--dur', dur);
      w.style.animationDelay = delay;
      cloud.appendChild(w);
    }
    document.addEventListener('pointermove', (e)=>{
      const { innerWidth:w, innerHeight:h } = window;
      const dx = (e.clientX / w - .5) * 6;
      const dy = (e.clientY / h - .5) * 6;
      cloud.style.transform = `translate(${dx}px, ${dy}px)`;
    }, { passive:true });
  </script>
</body>
</html>
