<?php
session_start();
// Si déjà connecté, redirige vers dashboard
if (isset($_SESSION['user'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$email = '';
$theme = 'default';

// Tenter de récupérer le thème de l'utilisateur s'il a commencé à se connecter
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'] ?? '';

    if (!$email) {
        $error = "Email invalide.";
    } else {
        $userDir = __DIR__ . '/users/profiles/' . $email . '/';
        $profilePath = $userDir . 'profile.json';
        $themePath = $userDir . 'theme.json';

        // Charger le thème même si la connexion échoue
        if (file_exists($themePath)) {
            $themeData = json_decode(file_get_contents($themePath), true);
            if (!empty($themeData['theme']) && file_exists(__DIR__ . "/theme/{$themeData['theme']}/style.css")) {
                $theme = basename($themeData['theme']);
            }
        }

        if (file_exists($profilePath)) {
            $profile = json_decode(file_get_contents($profilePath), true);
            if ($profile && isset($profile['motdepasse']) && password_verify($password, $profile['motdepasse'])) {
    // Connexion réussie
    $_SESSION['user'] = [
        'email' => $profile['email'] ?? $email,
        'prenom' => $profile['prenom'] ?? '',
        'nom' => $profile['nom'] ?? '',
        'role_system' => $profile['role_system'] ?? '',
        'role_metier' => $profile['role_metier'] ?? ''
    ];
    header('Location: dashboard.php');
    exit;
} else {
    $error = "Mot de passe incorrect.";
}

        } else {
            $error = "Utilisateur non trouvé.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <title>Connexion - DoMyDesk</title>
    <link rel="stylesheet" href="theme/<?= htmlspecialchars($theme) ?>/style.css">
    <style>
    /* === STYLES SPÉCIFIQUES AU FORMULAIRE DE CONNEXION === */
    .login-wrapper {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        background-color: var(--primary-dark, #174d7c);
    }

    .login-box {
        background-color: white;
        border-radius: 12px;
        box-shadow: 0 0 20px rgba(0,0,0,0.2);
        padding: 30px;
        width: 300px;
        max-width: 90%;
    }

    .login-box h1 {
        margin-bottom: 20px;
        color: var(--primary-color, #1965a8);
        text-align: center;
    }

    .login-box label {
        font-weight: bold;
        margin-top: 12px;
        display: block;
    }

    .login-box input {
        width: 100%;
        padding: 8px;
        margin-top: 4px;
        margin-bottom: 12px;
        border: 1px solid #ccc;
        border-radius: 6px;
        box-sizing: border-box;
    }

    .login-box .error-message {
        color: red;
        font-weight: bold;
        text-align: center;
        margin-bottom: 15px;
    }

    .login-box button {
        width: 100%;
        background-color: var(--primary-color, #1965a8);
        color: white;
        padding: 10px;
        border: none;
        border-radius: 6px;
        font-weight: bold;
        cursor: pointer;
    }

    .login-box button:hover {
        background-color: var(--primary-dark, #174d7c);
    }

    .register-link {
        display: block;
        text-align: center;
        margin-top: 12px;
        font-size: 0.9em;
        color: #1577d3;
        text-decoration: none;
    }

    .register-link:hover {
        text-decoration: underline;
    }
    </style>
</head>
<body class="login-wrapper">

<div class="login-box">
    <h1>Connexion</h1>

    <?php if ($error): ?>
        <div class="error-message"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post" action="">
        <label for="email">Email :</label>
        <input type="email" name="email" id="email" value="<?= htmlspecialchars($email) ?>" required>

        <label for="password">Mot de passe :</label>
        <input type="password" name="password" id="password" required>

        <button type="submit">Se connecter</button>
    </form>

    <a class="register-link" href="register.php">Créer un compte</a>
</div>

</body>
</html>
