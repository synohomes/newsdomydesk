<?php
function writeLog(string $message, string $type = 'INFO'): void {
    $logDir = __DIR__ . '/logs';
    if (!is_dir($logDir)) {
        mkdir($logDir, 0755, true);
    }
    $filename = $logDir . '/' . date('Y-m-d_H-i') . '.txt';
    $logMessage = sprintf("[%s][%s] %s\n", date('Y-m-d H:i:s'), strtoupper($type), $message);
    file_put_contents($filename, $logMessage, FILE_APPEND | LOCK_EX);
}
