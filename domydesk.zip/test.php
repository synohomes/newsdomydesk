<?php
$base = 'https://172.150.150.9:8006/api2/json';
$tid  = 'root@pam!desk';                 // <= token_id EXACT créé étape A
$sec  = 'LE-SECRET-COPIÉ-ICI';           // <= secret EXACT

function call($url,$tid,$sec){
  $ch=curl_init($url);
  curl_setopt_array($ch,[
    CURLOPT_RETURNTRANSFER=>true,
    CURLOPT_HEADER=>true,
    CURLOPT_SSL_VERIFYPEER=>false,
    CURLOPT_SSL_VERIFYHOST=>false,
    CURLOPT_HTTPHEADER=>[
      'Accept: application/json',
      "Authorization: PVEAPIToken={$tid}={$sec}",
    ],
  ]);
  $raw=curl_exec($ch);
  $code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);
  $hsize=(int)curl_getinfo($ch,CURLINFO_HEADER_SIZE);
  $err=curl_error($ch);
  curl_close($ch);
  $headers=substr($raw,0,$hsize);
  $body=substr($raw,$hsize);
  header('Content-Type:text/plain; charset=utf-8');
  echo "/nodes -> $code\n\nHEADERS:\n$headers\n\nBODY:\n$body\n\ncURL error: $err\n";
}
call("$base/nodes",$tid,$sec);
