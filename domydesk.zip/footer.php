<footer style="
    width: 100%;
    text-align: center;
    padding: 10px 20px;
    background-color: var(--primary-dark, #111);
    color: white;
    font-size: 13px;
    margin-top: auto;
    box-shadow: 0 -2px 8px rgba(0,0,0,0.3);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
">
    <div>
        &copy; 2024 DoMyDesk by SynoHomes
        <a href='https://synohomes.com' style='color: var(--primary-color, #6cf); text-decoration: none; margin: 0 5px;'>Dev</a> -
        <a href='https://youtube.com' style='color: var(--primary-color, #6cf); text-decoration: none; margin: 0 5px;'>Aide</a>
    </div>
    <ul style="list-style: none; padding: 0; margin: 5px 0 0 0;">
    </ul>
</footer>
