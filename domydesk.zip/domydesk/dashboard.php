<?php
session_start();
if (!isset($_SESSION['user']['email'])) {
    header('Location: login.php');
    exit;
}

$userEmail = $_SESSION['user']['email'];
$userDir   = __DIR__ . "/users/profiles/$userEmail";

/* ---------- MULTI-DASHBOARD ---------- */
$listFile = "$userDir/dashboards.json";
if (!file_exists($listFile)) file_put_contents($listFile, json_encode(["dashboard"]));
$dashboards = json_decode(file_get_contents($listFile), true);

$currentDashboard = $_GET['dashboard'] ?? $dashboards[0];
$dashboardFile    = "$userDir/$currentDashboard.json";
if (!file_exists($dashboardFile)) file_put_contents($dashboardFile, json_encode([]));

/* ---------- Thème utilisateur -------- */
$profileFile = "$userDir/profile.json";
$theme = 'default';
if (file_exists($profileFile)) {
    $profileData = json_decode(file_get_contents($profileFile), true);
    if (!empty($profileData['theme'])) $theme = basename($profileData['theme']);
}

/* ---------- Modules dispo ------------ */
$modulesUserFile = "$userDir/modules.json";
$availableModules = [];
if (file_exists($modulesUserFile)) {
    $enabledModules = json_decode(file_get_contents($modulesUserFile), true);
    foreach ($enabledModules as $m)
        if (!empty($m['enabled']) && !empty($m['id']) && !empty($m['name']))
            $availableModules[$m['id']] = $m['name'];
}

/* ---------- Dashboard JSON ----------- */
$dashboard = [];
$json = file_get_contents($dashboardFile);
$dashboard = json_decode($json, true) ?? [];

function shapeToFrench($s) {
    return match($s) {
        'square'  => 'Carré',
        'rounded' => 'Arrondi',
        default   => 'Carré',
    };
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Tableau de bord</title>
<link rel="stylesheet" href="theme/<?= htmlspecialchars($theme) ?>/style.css">
<style>
body {
  margin: 0;                 
  font-family: Arial, sans-serif;
  color: #eee;
}

.wrapper {
  display: flex;
  flex-direction: column;
  height: 100vh;
  min-height: 0;            
}

main {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-height: 0;             
}

#dashboard {
  flex: 1 1 auto;
  position: relative;
  overflow: auto;
    padding: 0;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  min-width: 0;  
  min-height: 0;  
}
/* Évite les "micro" scrollbars et masque tout quand c'est vide */
#dashboard { scrollbar-gutter: stable; }
#dashboard.empty {
  overflow: hidden;
  padding: 0;
}

/* === MODULES === */
.module {
  position: absolute;
  border-radius: 8px;
  padding: 10px;            
  box-sizing: border-box;
}

.module.square  { border-radius: 0; }
.module.rounded { border-radius: 10px; }
.module.circle  {
  border-radius: 50%;
  justify-content: center;
  align-items: center;
  text-align: center;
}

.module-header {
  font-weight: bold;
  display: flex;
  justify-content: space-between;
  align-items: center;
  cursor: move;
  user-select: none;
  -webkit-user-select: none;
}

.module.circle .module-header {
  flex-direction: column;
  align-items: flex-end;
}

.module-content {
  overflow-y: auto;
  height: 100%;
}

/* === PETITE CROIX DE FERMETURE === */
.module-close {
  font-size: 14px;
  color: #f44;
  background: none;
  border: none;
  cursor: pointer;
  padding: 0;
  margin-left: 8px;
}

/* === AUTRES === */
.shape-select {
  font-size: .8em;
  background: #222;
  border: 1px solid #444;
  color: #ccc;
  border-radius: 4px;
  margin-top: 2px;
}

.resize-handle {
  width: 12px;
  height: 12px;
  background: #666;
  position: absolute;
  right: 2px;
  bottom: 2px;
  cursor: se-resize;
}

.mod-icon {
  position: absolute;
  top: -10px;
  left: -10px;
  width: 68px;
  height: 68px;
  z-index: 2;
}

.popup {
  position: absolute;
  background: #2a2a2a;
  border: 1px solid #555;
  border-radius: 8px;
  padding: 10px;
  display: none;
  z-index: 1000;
}

.popup button {
  margin: 5px;
}

#controls {
  display: flex;
  align-items: center;
  gap: 3px;
  padding: 5px 5px;
  background-color: #121212;
  border-bottom: 1px solid #333;
  font-size: 12px;
  height: 32px;
  box-sizing: border-box;
}


#controls select,
#controls button {
  height: 24px !important;
  font-size: 10px !important;
  padding: 0 6px !important;
  min-width: 30px !important;
  max-width: 140px !important;
  background: #222 !important;
  color: #ccc !important;
  border: 1px solid #444 !important;
  border-radius: 3px !important;
  box-shadow: none !important;
  line-height: 1 !important;
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  margin: 0 2px !important;
}
body.noscroll {
  overflow: hidden;
}
</style>
<script src="https://cdn.jsdelivr.net/npm/interactjs/dist/interact.min.js"></script>
</head>
<body>

<div class="wrapper">
<?php include 'header.php'; ?>

<main>
<!-- ===== BARRE DE CONTRÔLE ===== -->
<div id="controls">
    <!-- Sélecteur de dashboards -->
    <select id="dashSelect" onchange="location.href='?dashboard='+this.value">
        <?php foreach ($dashboards as $d): ?>
            <option value="<?= htmlspecialchars($d) ?>" <?= $d===$currentDashboard?'selected':'' ?>>
                <?= htmlspecialchars($d) ?>
            </option>
        <?php endforeach; ?>
    </select>
    <button class="add" onclick="createDash()">➕</button>
    <button class="rename" onclick="renameDash()">✏️</button>
    <button class="delete" onclick="deleteDash()">🗑️</button>

    <!-- Modules -->
    <select id="addModuleSelect">
        <option value="">-- Ajouter un module --</option>
        <?php foreach ($availableModules as $id=>$name): ?>
            <option value="<?= htmlspecialchars($id) ?>"><?= htmlspecialchars($name) ?></option>
        <?php endforeach; ?>
    </select>
    <button id="resetBtn">Réinitialiser</button>
</div>

<!-- Popup reset -->
<div class="popup" id="confirmPopup">
    <p>Confirmer la réinitialisation ?</p>
    <button onclick="confirmReset()">Oui</button>
    <button onclick="hidePopup()">Non</button>
</div>

<!-- Zone modules -->
<div id="dashboard"></div>

</main>
</div><!-- wrapper -->

<script>
/* ========== Canvas auto (agrandit et peut rétrécir) ========== */
function expandCanvasLT() {
  const ws = document.getElementById('dashboard');
  const mods = ws.querySelectorAll('.module');

if (mods.length === 0) {
  ws.classList.add('empty');
  document.body.classList.add('noscroll'); // ← coupe le scroll global quand vide
  ws.style.minWidth  = '';
  ws.style.minHeight = '';
  ws.style.width     = '';
  ws.style.height    = '';
  ws.scrollTo(0, 0);
  return;
}
// il y a du contenu
ws.classList.remove('empty');
document.body.classList.remove('noscroll'); // ← réactive le scroll normal

  ws.classList.remove('empty');

  let maxRight = 0, maxBottom = 0;
  mods.forEach(el => {
    const left   = parseFloat(el.style.left) || 0;
    const top    = parseFloat(el.style.top)  || 0;
    const right  = left + el.offsetWidth;
    const bottom = top  + el.offsetHeight;
    if (right  > maxRight)  maxRight  = right;
    if (bottom > maxBottom) maxBottom = bottom;
  });

  const pad = 24;
  ws.style.minWidth  = (maxRight  + pad) + 'px';
  ws.style.minHeight = (maxBottom + pad) + 'px';
}


/* ========== Forme module ========== */
function changeShape(sel){
  const m=sel.closest('.module');
  m.classList.remove('square','rounded');
  m.classList.add(sel.value);
  saveDashboard();
}

/* ========== Drag/Resize ========== */
function enableInteract(el){
  interact(el)
    .draggable({
      allowFrom: '.module-header',
      listeners: {
        move(e){
          const t = e.target;
          const x = (parseFloat(t.style.left) || 0) + e.dx;
          const y = (parseFloat(t.style.top)  || 0) + e.dy;
          t.style.left = x + 'px';
          t.style.top  = y + 'px';
          expandCanvasLT();
          saveDashboard();
        }
      }
    })
    .resizable({
      edges: { left:true, right:true, bottom:true, top:true },
      listeners: {
        move(e){
          const t = e.target;
          const x = parseFloat(t.style.left) || 0;
          const y = parseFloat(t.style.top)  || 0;
          t.style.width  = e.rect.width  + 'px';
          t.style.height = e.rect.height + 'px';
          t.style.left   = (x + e.deltaRect.left) + 'px';
          t.style.top    = (y + e.deltaRect.top)  + 'px';
          expandCanvasLT();
          saveDashboard();
        }
      }
    });
}

/* ========== Charger contenu module ========== */
function loadModuleContent(modEl, id) {
  setTimeout(() => {
    modEl.style.height = modEl.scrollHeight + 'px';
  }, 100);
  fetch(`modules/${id}/${id}.php`, { cache: 'no-store' })
    .then(r => r.text())
    .then(html => {
      const container = modEl.querySelector('.module-content');
      container.innerHTML = html;
      container.querySelectorAll("script").forEach(oldScript => {
        const s = document.createElement("script");
        if (oldScript.src) s.src = oldScript.src; else s.textContent = oldScript.textContent;
        container.appendChild(s);
      });
    })
    .catch(err => console.error(`[${id}]`, err));
}

/* ========== Sauvegarde ========== */
function saveDashboard(){
  const mods=[...document.querySelectorAll('.module')].map(m=>({
    id:m.dataset.id,
    title:m.querySelector('.module-title').textContent,
    content:m.querySelector('.module-content').textContent,
    x:parseInt(m.style.left)||0, y:parseInt(m.style.top)||0,
    width:parseInt(m.style.width)||200, height:parseInt(m.style.height)||200
  }));
  fetch('users/save_dashboard.php?dashboard=<?= urlencode($currentDashboard) ?>',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify(mods)
  });
}

/* ========== Fermeture module (GLOBAL) ========== */
function closeModule(btn) {
  const m = btn.closest('.module');
  if (!m) return;
  m.remove();
  expandCanvasLT();
  saveDashboard();
}

/* Délégation de clic robuste pour toutes les croix */
document.addEventListener('click', (e) => {
  if (e.target.classList.contains('module-close')) {
    closeModule(e.target);
  }
});

/* ========== Ajout d’un module ========== */
document.getElementById('addModuleSelect').addEventListener('change',function(){
  const id=this.value; if(!id) return;
  const dash=document.getElementById('dashboard');
  const mod=document.createElement('div');
  mod.className='module square'; mod.dataset.id=id;
  Object.assign(mod.style,{left:'250px',top:'280px',width:'280px',height:'280px'});
  mod.innerHTML=`<img class="mod-icon" src="modules/${id}/modicone.png" onerror="this.style.display='none'">
    <div class="module-header">
      <span class="module-title">${id}</span>
      <select class="shape-select" onchange="changeShape(this)">
        <option value="square">Carré</option>
        <option value="rounded">Arrondi</option>
      </select>
      <span class="module-close">&times;</span>
    </div>
    <div class="module-content">Contenu du module ${id}</div>
    <div class="resize-handle"></div>`;
  dash.appendChild(mod);
  expandCanvasLT();
  enableInteract(mod);
  loadModuleContent(mod, id);
  saveDashboard();
  this.value = "";
});

/* ========== Reset (vide DOM + sauvegarde vide + cache-buster) ========== */
document.getElementById('resetBtn').addEventListener('click',e=>{
  const p=document.getElementById('confirmPopup');p.style.display='block';
  const r=e.target.getBoundingClientRect();p.style.top=r.bottom+window.scrollY+'px';p.style.left=r.left+window.scrollX+'px';
});
function confirmReset(){
  const url = 'users/reset_dashboard.php?dashboard=<?= urlencode($currentDashboard) ?>';
  fetch(url, { method:'POST', cache:'no-store' })
    .then(() => {
      hidePopup();
      const dash = document.getElementById('dashboard');
      dash.innerHTML = '';          // 1) vide l'UI
      expandCanvasLT();             // 2) remet la taille naturelle
      saveDashboard();              // 3) écrit [] dans le JSON
      location.replace('?dashboard=<?= urlencode($currentDashboard) ?>&r=' + Date.now()); // 4) recharge propre
    })
    .catch(() => {
      hidePopup();
      const dash = document.getElementById('dashboard');
      dash.innerHTML = '';
      expandCanvasLT();
      saveDashboard();
      location.replace('?dashboard=<?= urlencode($currentDashboard) ?>&r=' + Date.now());
    });
}
function hidePopup(){document.getElementById('confirmPopup').style.display='none';}

/* ========== Chargement du dashboard ========== */
window.addEventListener('DOMContentLoaded',()=>{loadDash("<?= addslashes($currentDashboard) ?>");});
function loadDash(name){
  fetch('users/profiles/<?= addslashes($userEmail) ?>/'+encodeURIComponent(name)+'.json', { cache: 'no-store' })
    .then(r=>r.json())
    .then(mods=>{
      const dash=document.getElementById('dashboard');
      dash.innerHTML='';
      (mods||[]).forEach(d=>{
        const m=document.createElement('div');
        m.className=`module ${d.shape||'square'}`; m.dataset.id=d.id;
        Object.assign(m.style,{left:d.x+'px',top:d.y+'px',width:d.width+'px',height:d.height+'px'});
        m.innerHTML=`<img class="mod-icon" src="modules/${d.id}/modicone.png" onerror="this.style.display='none'">
          <div class="module-header">
            <span class="module-title">${d.title}</span>
            <select class="shape-select" onchange="changeShape(this)">
              <option value="square"${d.shape==='square'?' selected':''}>Carré</option>
              <option value="rounded"${d.shape==='rounded'?' selected':''}>Arrondi</option>
            </select>
            <span class="module-close">&times;</span>
          </div>
          <div class="module-content">${d.content}</div>
          <div class="resize-handle"></div>`;
        dash.appendChild(m);
        enableInteract(m);
        loadModuleContent(m, d.id);
      });
      expandCanvasLT();
    });
}

/* ========== CRUD tableaux ========== */
function createDash(){
  const n=prompt("Nom du nouveau tableau :"); if(!n) return;
  fetch('users/create_dashboard.php',{
    method:'POST', headers:{'Content-Type':'application/json'},
    body:JSON.stringify({name:n})
  }).then(()=>location.href='?dashboard='+encodeURIComponent(n));
}
function renameDash(){
  const n=prompt("Nouveau nom :", "<?= addslashes($currentDashboard) ?>"); if(!n) return;
  fetch('users/rename_dashboard.php',{
    method:'POST', headers:{'Content-Type':'application/json'},
    body:JSON.stringify({old:"<?= addslashes($currentDashboard) ?>",name:n})
  }).then(()=>location.href='?dashboard='+encodeURIComponent(n));
}
function deleteDash(){
  if(!confirm("Supprimer ce tableau ?")) return;
  fetch('users/delete_dashboard.php',{
    method:'POST', headers:{'Content-Type':'application/json'},
    body:JSON.stringify({name:"<?= addslashes($currentDashboard) ?>"})
  }).then(()=>location.href='?dashboard=<?= urlencode($dashboards[0]) ?>');
}
</script>
</body>
</html>
