<?php
session_start();
if (!isset($_SESSION['user']['email'])) exit;

$email = $_SESSION['user']['email'];
$userDir = __DIR__ . "/profiles/$email";

// === Récupérer le nom du dashboard depuis l'URL (GET)
$dashboardName = $_GET['dashboard'] ?? 'dashboard';
$dashboardFile = "$userDir/$dashboardName.json";

// === Lire la requête POST (JSON)
$data = json_decode(file_get_contents('php://input'), true);
if (!is_array($data)) exit;

// === Sauvegarde
file_put_contents($dashboardFile, json_encode($data, JSON_PRETTY_PRINT));
