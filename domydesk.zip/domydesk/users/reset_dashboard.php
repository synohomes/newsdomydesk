<?php
session_start();
if (!isset($_SESSION['user']['email'])) exit;

$email = $_SESSION['user']['email'];
$userDir = __DIR__ . "/profiles/$email";

// === Récupérer le nom du dashboard
$dashboardName = $_GET['dashboard'] ?? 'dashboard';
$dashboardFile = "$userDir/$dashboardName.json";

// === Écrase avec tableau vide
file_put_contents($dashboardFile, json_encode([]));
