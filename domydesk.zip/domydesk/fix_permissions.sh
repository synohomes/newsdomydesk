#!/bin/bash

# 🔧 Chemin absolu vers DoMyDesk — MODIFIE ICI
DOMYDESK_PATH="/var/www/html/domydesk"

echo "🚀 CORRECTION DES DROITS : TOUS MODULES ($DOMYDESK_PATH/modules)"

# Appliquer 777 aux dossiers dans /modules
find "$DOMYDESK_PATH/modules" -type d -exec chmod 777 {} \;

# Appliquer 666 à tous les fichiers dans /modules
find "$DOMYDESK_PATH/modules" -type f -exec chmod 666 {} \;

echo "✅ TOUS LES MODULES SONT MAINTENANT ACCESSIBLES SANS LIMITE (777/666 APPLIQUÉS)"
