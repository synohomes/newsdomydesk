<?php
// Fonction pour récupérer le profil de l'utilisateur à partir du fichier JSON
function getUserProfile($email) {
    $profilePath = "users/profiles/" . $email . "/profile.json";
    if (file_exists($profilePath)) {
        $profileJson = file_get_contents($profilePath);
        return json_decode($profileJson, true);
    } else {
        return null;
    }
}

// Fonction pour vérifier si un utilisateur est connecté
function isLoggedIn() {
    return isset($_SESSION['user']) && isset($_SESSION['user']['email']);
}

// Fonction pour rediriger si l'utilisateur n'est pas connecté
function redirectIfNotLoggedIn() {
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit;
    }
}

// Fonction pour gérer la déconnexion
function logout() {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit;
}
?>
