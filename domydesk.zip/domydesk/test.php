<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $target = __DIR__ . '/users/profiles/test_' . basename($_FILES['file']['name']);
    if (move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
        chmod($target, 0644);
        echo "✅ Upload OK vers : $target";
    } else {
        echo "⛔ move_uploaded_file() a échoué.";
    }
}
?>

<form method="post" enctype="multipart/form-data">
    <input type="file" name="file">
    <button type="submit">TESTER UPLOAD</button>
</form>
