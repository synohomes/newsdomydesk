
<?php
session_start();
$email = $_SESSION['user']['email'] ?? null;
$theme = 'default';
// 📛 Chargement de l'ID unique DoMyDesk
$idDoMyDesk = '';
$idFile = __DIR__ . '/../data/id_domydesk.txt';
if (file_exists($idFile)) {
    $idDoMyDesk = trim(file_get_contents($idFile));
}

if ($email) {
    $themePath = __DIR__ . "/../users/profiles/$email/theme.json";
    if (file_exists($themePath)) {
        $data = json_decode(file_get_contents($themePath), true);
        if (!empty($data['theme']) && file_exists(__DIR__ . "/../theme/" . $data['theme'] . "/style.css")) {
            $theme = basename($data['theme']);
        }
    }
}
/*********************/
/*  P H P   I N I T  */
/*********************/
// Chargement sécurisé des rôles métier
$baseDir = dirname(__DIR__, 2); // /var/www/html/domydesk
$metiers = [];
$rolesFile = "$baseDir/data/roles_metier.json";

if (file_exists($rolesFile)) {
    $json = file_get_contents($rolesFile);
    $decoded = json_decode($json, true);
    if (is_array($decoded)) {
        $metiers = $decoded;
    } else {
        $metiers = []; // fallback pour éviter NULL
    }
}
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role_system'] !== 'admin') {
    header('Location: ../login.php'); exit;
}

$theme        = $_SESSION['user']['theme'] ?? 'default';
$baseDir      = dirname(__DIR__);
$settingsFile = "$baseDir/adm/settings.json";
$accessFile   = "$baseDir/adm/menus/access_per_user.json";
$profilesDir  = "$baseDir/users/profiles/";

/* --------- lecture / sauvegarde settings --------- */
$settings = file_exists($settingsFile) ? json_decode(file_get_contents($settingsFile), true) : [];
$success  = false;   // message OK
$errors   = [];      // tableaux d’erreurs
/* -----------------------------------------------------------------
   Fonction utilitaire : applique chmod récursif  (dossiers 0775, fichiers 0664)
   ----------------------------------------------------------------- */
if (!function_exists('setPermissions')) {
    function setPermissions(string $path): void {
        if (!file_exists($path)) return;

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($path, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($iterator as $item) {
            @chmod($item, $item->isDir() ? 0775 : 0664);
        }
        // racine du dossier
        @chmod($path, 0775);
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	
	// --------- suppression d’un module ---------
if (isset($_POST['delete_module'])) {
    $mod = basename($_POST['delete_module']);
    $modPath = "$baseDir/modules/$mod";
    if (is_dir($modPath)) {
        $it = new RecursiveDirectoryIterator($modPath, RecursiveDirectoryIterator::SKIP_DOTS);
        $ri = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($ri as $file) {
            $file->isDir() ? rmdir($file) : unlink($file);
        }
        rmdir($modPath);
        $success = true;
    }
}

// 🔧 Mise à jour rôle système et métier depuis le tableau "Gestion des rôles"
if (isset($_POST['update_user_roles'])) {
    $email       = trim($_POST['user_email'] ?? '');
    $roleSystem  = trim($_POST['new_role_system'] ?? '');
    $roleMetier  = trim($_POST['new_role_metier'] ?? '');

    $profileFile = $profilesDir . $email . '/profile.json';
    if (is_file($profileFile)) {
        $data = json_decode(file_get_contents($profileFile), true) ?: [];

        if (in_array($roleSystem, ['admin', 'user'], true)) {
            $data['role_system'] = $roleSystem;
        }

        if (in_array($roleMetier, $metiers ?? [], true)) {
            $data['role_metier'] = $roleMetier;
        }

        file_put_contents($profileFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $success = true;
    }
}


// 🔧 Mise à jour du rôle système et rôle métier
if (isset($_POST['update_user_roles'])) {
    $email = trim($_POST['user_email'] ?? '');
    $roleSystem = trim($_POST['new_role_system'] ?? '');
    $roleMetier = trim($_POST['new_role_metier'] ?? '');

    $profileFile = $profilesDir . $email . '/profile.json';

    if (is_file($profileFile)) {
        $data = json_decode(file_get_contents($profileFile), true);

        if (!is_array($data)) $data = [];

        if (in_array($roleSystem, ['admin', 'user'], true)) {
            $data['role_system'] = $roleSystem;
        }

        if (in_array($roleMetier, $metiers, true)) {
            $data['role_metier'] = $roleMetier;
        }

        file_put_contents($profileFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $success = true;
    }
}
/* ─────────────────  RÔLES MÉTIER  ───────────────── */
$rolesFile = "$baseDir/data/roles_metier.json";

/* (1)  S'assurer que le fichier existe */
if (!file_exists($rolesFile)) {
    file_put_contents($rolesFile, json_encode([], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

/* (2)  Fonction utilitaire – lecture */
function loadMetiers($file) {
    $arr = json_decode(file_get_contents($file), true);
    return is_array($arr) ? $arr : [];
}

/* (3)  Fonction utilitaire – écriture */
function saveMetiers($file, array $arr) {
    file_put_contents($file, json_encode(array_values(array_unique($arr)),
                     JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

/*  zawsze disponible dans le reste de la page */
$metiers = loadMetiers($rolesFile);

/* ==========  TRAITEMENT POST  ========== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /* ➕  Ajout d’un rôle métier */
    if (isset($_POST['add_metier'])) {
        $new = trim($_POST['new_metier'] ?? '');
        if ($new !== '' && !in_array($new, $metiers, true)) {
            $metiers[] = $new;
            saveMetiers($rolesFile, $metiers);
        }
    }

    /* 🗑️  Suppression d’un rôle métier */
    if (isset($_POST['delete_metier'])) {
        $del = $_POST['del_metier'] ?? '';
        $metiers = array_filter($metiers, fn($m) => $m !== $del);
        saveMetiers($rolesFile, $metiers);
    }
}


// --------- création d’un nouvel utilisateur depuis admin ---------
if (isset($_POST['add_user'])) {
    $prenom       = trim($_POST['prenom'] ?? '');
    $nom          = trim($_POST['nom'] ?? '');
    $email        = trim($_POST['email'] ?? '');
    $role_metier  = trim($_POST['role_metier'] ?? '');
    $role_system  = trim($_POST['role_system'] ?? 'user');
    $password     = $_POST['password'] ?? '';

    if (!$prenom || !$nom || !$email || !$role_metier || !$password || !$role_system) {
        $message = "❌ Tous les champs sont obligatoires.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "❌ Email invalide.";
    } elseif (!in_array($role_metier, $metiers ?? [], true)) {
        $message = "❌ Rôle métier invalide.";
    } elseif (!in_array($role_system, ['user', 'admin'], true)) {
        $message = "❌ Rôle système invalide.";
    } else {
        $folder = $profilesDir . $email . '/';
        if (file_exists($folder)) {
            $message = "❌ L'utilisateur existe déjà.";
        } else {
            mkdir($folder, 0755, true);
            $data = [
                'prenom'       => $prenom,
                'nom'          => $nom,
                'email'        => $email,
                'role_system'  => $role_system,
                'role_metier'  => $role_metier,
                'password'     => password_hash($password, PASSWORD_DEFAULT)
            ];
            file_put_contents($folder . 'profile.json', json_encode($data, JSON_PRETTY_PRINT));
            file_put_contents($folder . 'dashboard.json', json_encode([], JSON_PRETTY_PRINT));
            file_put_contents($folder . 'menu.json', json_encode([], JSON_PRETTY_PRINT));
            copy("$baseDir/data/Logo_2025_Mini.png", $folder . 'avatar.png');
            setPermissions($folder);
            $message = "✅ Utilisateur ajouté avec succès.";
        }
    }
}

    /* --------- enregistrement paramètres généraux --------- */
    if (isset($_POST['save_site'])) {
        $settings['site_name']      = $_POST['site_name']      ?? 'DoMyDesk';
        $settings['menu_vertical']  = $_POST['menu_vertical']  ?? '';
        if (!empty($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
            $ext    = pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION);
            $target = "uploads/logo.$ext";
            move_uploaded_file($_FILES['logo']['tmp_name'], $target);
            $settings['logo_path'] = $target;
        }
        file_put_contents($settingsFile, json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $success = true;
    }

    /* --------- promotion / rétrogradation utilisateurs --------- */
    if (isset($_POST['set_role_admin']) || isset($_POST['set_role_user'])) {
        $email       = $_POST['user_email'] ?? '';
        $profileFile = "$profilesDir/$email/profile.json";
        if (is_file($profileFile)) {
            $profile                = json_decode(file_get_contents($profileFile), true);
            $profile['role_system'] = isset($_POST['set_role_admin']) ? 'admin' : 'user';
            file_put_contents($profileFile, json_encode($profile, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }
    }

    /* --------- gestion des accès aux pages --------- */
    if (isset($_POST['manage_access'])) {
        $email  = $_POST['user']  ?? '';
        $pages  = $_POST['pages'] ?? [];
        $rights = file_exists($accessFile) ? json_decode(file_get_contents($accessFile), true) : [];
        $rights[$email] = $pages;
        file_put_contents($accessFile, json_encode($rights, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    /* --------- suppression d’un utilisateur --------- */
    if (isset($_POST['delete_user'])) {
        $email  = $_POST['user_email'] ?? '';
        $folder = "$profilesDir/$email";
        if ($email !== $_SESSION['user']['email'] && is_dir($folder)) {
            // fonction récursive
            $it = new RecursiveDirectoryIterator($folder, RecursiveDirectoryIterator::SKIP_DOTS);
            $fi = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);
            foreach ($fi as $f) $f->isDir() ? rmdir($f) : unlink($f);
            rmdir($folder);
            // retirer également ses droits
            if (is_file($accessFile)) {
                $rights = json_decode(file_get_contents($accessFile), true);
                unset($rights[$email]);
                file_put_contents($accessFile, json_encode($rights, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            }
            $success = true;
        } else {
            $errors[] = "Impossible de supprimer l'utilisateur courant ou le dossier est introuvable.";
        }
    }
}

/* --------- préparation données affichage --------- */
$userRoles = $users = [];
foreach (glob("$profilesDir*", GLOB_ONLYDIR) as $folder) {
    $mail = basename($folder);
    $users[]          = $mail;
    $profileFile      = "$folder/profile.json";
    $data             = is_file($profileFile) ? json_decode(file_get_contents($profileFile), true) : [];
    $userRoles[$mail] = $data['role_system'] ?? 'user';
}

/* --------- purge accès si utilisateurs supprimés --------- */
$accessRights = file_exists($accessFile) ? json_decode(file_get_contents($accessFile), true) : [];
$accessRights = array_intersect_key($accessRights, array_flip($users)); // garde seulement users existants
file_put_contents($accessFile, json_encode($accessRights, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

/* --------- scan des pages PHP --------- */
$pagesScan = [];
$dirs = ['', 'adm']; // pas "modules"
foreach ($dirs as $sub) {
    foreach (glob($baseDir . ($sub ? "/$sub" : '') . '/*.php') as $f) {
        $rel = str_replace("$baseDir/", '', $f);
        // filtre les fichiers techniques
        if (preg_match('/(?:cfg|inc|ajax|api)\.php$/i', $rel)) continue;
        $pagesScan[] = $rel;
    }
}
/* --------- Chargement cfg modules activés --------- */
$modulesDir = __DIR__ . '/../modules/';
foreach (glob($modulesDir . '*/*cfg.php') as $cfgFile) {
    $moduleName = basename(dirname($cfgFile));
    if ($isAdmin && in_array($moduleName, array_column($modulesActifs, 'id'))) {
        include $cfgFile;
    }
}
?>

<?php
// [Dynamique] Chargement des blocs de configuration des modules activés
$modulesEnabledPath = "users/profiles/$email/modules.json";
if (file_exists($modulesEnabledPath)) {
    $enabledModules = json_decode(file_get_contents($modulesEnabledPath), true);
    foreach ($enabledModules as $mod) {
        $modName = is_array($mod) ? ($mod['id'] ?? '') : $mod;
        $cfgPath = "modules/$modName/{$modName}cfg.php";
        if (is_file($cfgPath)) {
            include $cfgPath;
        }
    }
}

$scriptDir = "/var/www/html/domydesk/adm/domybox/";
$enable   = $scriptDir . "enable_web_access.sh";
$disable  = $scriptDir . "disable_web_access.sh";
$rename   = $scriptDir . "rename_box.sh";
$chgpass  = $scriptDir . "change_pass.sh";
$setwifi  = $scriptDir . "set_wifi.sh";
$installSamba = $scriptDir . "install_samba.sh";
$shareFolderScript = $scriptDir . "create_share.sh";
$shareError = "";
$shareSuccess = "";


/* ── (A)  Ajout ou mise à jour d’un RÔLE MÉTIER ─────────────────── */
if (isset($_POST['add_metier'])) {
    $newMetier = trim($_POST['new_metier'] ?? '');

    if ($newMetier !== '' && !in_array($newMetier, $metiers, true)) {
        $metiers[] = $newMetier;
        file_put_contents($rolesFile, json_encode($metiers, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
}

/* ── (B)  Mise à jour des rôles d’un utilisateur ────────────────── */
if (isset($_POST['update_user_roles'])) {
    $email       = trim($_POST['user_email'] ?? '');
    $roleSys     = trim($_POST['new_role_system']  ?? 'user');
    $roleMetier  = trim($_POST['new_role_metier'] ?? '');

    $profileFile = $profilesDir . $email . '/profile.json';
    if (is_file($profileFile)) {
        $data = json_decode(file_get_contents($profileFile), true) ?: [];

        if (in_array($roleSys, ['admin','user'], true))     $data['role_system'] = $roleSys;
        if (in_array($roleMetier, $metiers, true))          $data['role_metier'] = $roleMetier;

        file_put_contents($profileFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
}

/* ── (C)  Création d’un UTILISATEUR ─────────────────────────────── */
if (isset($_POST['add_user'])) {
    // … garde ton code actuel, mais remplace la vérif métier par :
    if (!in_array($role_metier, $metiers, true)) {
        $message = "❌ Rôle métier invalide.";
    }
  
}

$modulesPath = __DIR__ . '/../modules/';
$enabledModulesFile = "users/profiles/$email/modules.json";
$enabledModules = file_exists($enabledModulesFile) ? json_decode(file_get_contents($enabledModulesFile), true) : [];

foreach ($enabledModules as $mod) {
    if (!empty($mod['enabled']) && !empty($mod['id'])) {
        $cfgFile = $modulesPath . $mod['id'] . '/' . $mod['id'] . 'cfg.php';
        if (file_exists($cfgFile)) {
            echo '<div class="section" style="flex:1 1 48%;">';
            include $cfgFile;
            echo '</div>';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Administration système</title>
<?php
$themeFile = __DIR__ . "/../theme/$theme/style.css";
$baseUrl   = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\'); // /domydesk/adm -> base /domydesk
$themeHref = $baseUrl . "/theme/" . rawurlencode($theme) . "/style.css";
if (is_file($themeFile)) {
    $themeHref .= '?v=' . filemtime($themeFile);
}
?>
<link rel="stylesheet" href="<?= htmlspecialchars($themeHref) ?>">
<style>
body {
  background-color: var(--background-color, #121212);
  color: var(--text-color, #ccc);
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
}

.section {
  background: var(--section-bg, #1e1e1e);
  border: 1px solid var(--border-color, #333);
  border-radius: 10px;
  box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
  padding: 20px;
  margin: 20px auto;
  max-width: 900px;
}

.section h2 {
  margin-top: 0;
  color: var(--primary-color, #ffaa00);
  border-bottom: 1px solid var(--border-color, #333);
  padding-bottom: 5px;
}

input[type="text"],
input[type="email"],
input[type="password"],
select,
textarea {
  width: 50%;
  padding: 8px 10px;
  margin-top: 5px;
  margin-bottom: 10px;
  border: 1px solid var(--border-color, #444);
  border-radius: 5px;
  background-color: var(--input-bg, #222);
  color: var(--text-color, #ccc);
  box-sizing: border-box;
}

button {
  background-color: var(--button-bg, #222);
  color: var(--text-color, #ccc);
  border: 1px solid var(--border-color, #444);
  border-radius: 5px;
  padding: 6px 14px;
  cursor: pointer;
  font-size: 13px;
  margin-right: 5px;
}

button:hover {
  background-color: var(--button-hover, #333);
}

label {
  font-weight: bold;
  display: block;
  margin-bottom: 4px;
  color: var(--text-color, #ccc);
}

input[type="checkbox"] {
  margin-right: 8px;
  transform: scale(1.1);
}

.row {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
}

.col {
  flex: 1;
  min-width: 280px;
}

hr {
  border: none;
  border-top: 1px solid var(--border-color, #444);
  margin: 30px 0;
}

.warning {
  color: var(--danger-color, red);
  font-weight: bold;
}
</style>

</head>
<body>
<?php include "$baseDir/header.php"; ?>
<div class="container">
  <div class="settings-wrapper">
  <div class="left-settings">
    <!-- bloc paramètres -->
<h2>⚙️ Paramètres DoMyDesk
<?php if ($idDoMyDesk): ?>
  <span style="font-size:0.7em; font-weight:normal; margin-left:10px; color:#ccc;"
        title="⚠️ Sauvegardez cet identifiant précieusement. Il est nécessaire pour récupérer vos modules premium en cas de crash ou lors d’une assistance.">
    🆔 Votre ID DoMyDesk : <code style="color:#ffaa00"><?= htmlspecialchars($idDoMyDesk) ?></code>
    <a href="/domydesk/data/id_domydesk.txt" download
       title="💾 Télécharger votre ID (à conserver dans un endroit sûr)"
       style="margin-left:8px; text-decoration:none; font-size:1.1em;">💾</a>
  </span>
<?php endif; ?>
</h2>
      <details>
      <?php if($success):?><div class="msg-ok">Modifications enregistrées.</div><?php endif;?>
      <?php if($errors):?><div class="msg-err"><?php foreach($errors as $e) echo htmlspecialchars($e)."<br>";?></div><?php endif;?>
<br><a href="../adm/fix_all_rights.php" target="_blank" class="btn btn-nolink">📂🔐 Accorder les permissions (Windows)</a><br>
      <form method="post" enctype="multipart/form-data">
        <label>Nom du site:<br>
          <input type="text" name="site_name" value="<?=htmlspecialchars($settings['site_name'] ?? '')?>">
        </label>

       <br> <label>Logo actuel<br>
          <?php if(isset($settings['logo_path']) && is_file(__DIR__.'/'.$settings['logo_path'])):?>
            <img class="logo-preview" src="<?=htmlspecialchars($settings['logo_path'])?>" alt="Logo">
          <br><?php else:?>Aucun logo<?php endif;?>
        </label>

       <br><label>Changer de logo:<br>    
          <input type="file" name="logo" accept=".png,.jpg,.jpeg,.gif,.svg">
        </label>

       <br><label>HTML du menu horizontal<br>
          <textarea name="menu_vertical" rows="5"><?=htmlspecialchars($settings['menu_vertical'] ?? '')?></textarea>
        </label>

      <br>  <button name="save_site">💾 Enregistrer</button>
      </form>
    </details>

<!-- bloc rôles -->

<h2>👥 Gestion des rôles</h2>
<details>


  <style>
    .roles-table select,
    .roles-table button {
      font-size: 0.8em;
      padding: 4px 6px;
    }
    .roles-table td, .roles-table th {
      padding: 4px 8px;
      vertical-align: middle;
    }
    .roles-table form {
      display: inline-flex;
      gap: 6px;
      flex-wrap: wrap;
      align-items: center;
    }
    .roles-table input[type="text"], .roles-table select {
      max-width: 160px;
    }
    .roles-table input[type="text"] {
      height: 28px;
    }
    .roles-table button {
      height: 28px;
    }
	details {
  margin-bottom: 5px;
  border: 1px solid var(--primary-dark);
  border-radius: 10px;
  background-color: #1c1c1c;
  padding: 10px;
}

details summary h2 {
  margin: 0;
  color: var(--primary-color);
  cursor: pointer;
}

fieldset {
  background-color: #ffff;
}
  </style>

  <table class="roles-table">
    <tbody>
      <?php foreach($userRoles as $mail => $roleSys): 
        $profileFile = $profilesDir . $mail . '/profile.json';
        $prenom = $mail;
        $roleMetier = 'N/A';
        if (is_file($profileFile)) {
          $data = json_decode(file_get_contents($profileFile), true);
          $prenom = $data['prenom'] ?? $mail;
          $roleMetier = $data['role_metier'] ?? 'N/A';
        }
      ?>
      <tr>
        <td>
          <?= htmlspecialchars($prenom) ?>
          <a href="/domydesk/profile_view.php?email=<?= urlencode($mail) ?>" title="Voir profil">👁️</a>
        </td>
        <td><?= ($mail === $_SESSION['user']['email']) ? '👑 Vous' : ($roleSys === 'admin' ? '🛡️ Admin' : '👤 User') ?></td>
        <td><?= htmlspecialchars($roleMetier) ?></td>
        <td>
          <form method="post">
            <input type="hidden" name="user_email" value="<?= htmlspecialchars($mail) ?>">

            <select name="new_role_system">
              <option value="user"  <?= $roleSys === 'user' ? 'selected' : '' ?>>Utilisateur</option>
              <option value="admin" <?= $roleSys === 'admin' ? 'selected' : '' ?>>Administrateur</option>
            </select>

            <select name="new_role_metier">
              <?php foreach ($metiers as $m): ?>
                <option value="<?= htmlspecialchars($m) ?>" <?= $m === $roleMetier ? 'selected' : '' ?>>
                  <?= htmlspecialchars($m) ?>
                </option>
              <?php endforeach; ?>
            </select>

            <button name="update_user_roles">💾</button>
            <?php if ($mail !== $_SESSION['user']['email']): ?>
              <button name="delete_user" onclick="return confirm('Supprimer définitivement <?= htmlspecialchars($mail) ?> ?')">🗑️</button>
            <?php endif; ?>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <form method="post" style="margin-top:10px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
    <label style="font-size:0.9em">➕ Nouveau rôle métier :
      <input type="text" name="new_metier" required placeholder="ex: Technicien, RH, etc." style="height:28px">
    </label>
    <button name="add_metier" style="height:28px">Ajouter</button>
  </form>

  <?php if (!empty($metiers)): ?>
  <form method="post" style="margin-top:6px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
    <label style="font-size:0.9em">🗑️ Supprimer un rôle métier :
      <select name="del_metier" required style="height:28px">
        <option value="">-- Choisir un rôle --</option>
        <?php foreach ($metiers as $m): ?>
          <option value="<?= htmlspecialchars($m) ?>"><?= htmlspecialchars($m) ?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <button name="delete_metier" style="height:28px">Supprimer</button>
  </form>
  <?php endif; ?>
</details>


<!-- bloc modules -->
<!-- bloc modules -->
<h2>🧩 Modules</h2>
<details>

<?php
/* ===== Contexte ===== */
$isAdmin = isset($_SESSION['user']['role_system']) && $_SESSION['user']['role_system'] === 'admin';
$baseDir = $baseDir ?? dirname(__DIR__);

/* (Optionnel) Suppression d’un module — si déjà géré plus haut, enlève ce bloc */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_module'])) {
    $mod = basename($_POST['delete_module']);
    $modPath = "$baseDir/modules/$mod";
    if (is_dir($modPath)) {
        $it = new RecursiveDirectoryIterator($modPath, RecursiveDirectoryIterator::SKIP_DOTS);
        $ri = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($ri as $file) {
            $file->isDir() ? @rmdir($file) : @unlink($file);
        }
        @rmdir($modPath);
    }
}
?>

<style>
  .mods-toolbar{
    display:flex; gap:8px; align-items:center; justify-content:flex-end; margin:6px 0 14px;
  }
  .btn-pill{
    display:inline-flex; align-items:center; gap:8px; padding:8px 12px; border-radius:999px;
    text-decoration:none; border:1px solid var(--border-color,#444); background:var(--button-bg,#222);
    color:var(--text-color,#ddd); font-weight:600; cursor:pointer;
  }
  .btn-pill:hover{ filter:brightness(1.1); }

  /* ---- Grille de vignettes ---- */
  .mods-grid{
    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(340px,1fr)); /* largeur confortable pour lire les noms */
    gap:14px;
  }
  .mod-card{
    background:var(--section-bg,#1e1e1e); border:1px solid var(--border-color,#333);
    border-radius:12px; padding:12px; display:flex; gap:12px; align-items:flex-start;
    box-shadow:0 4px 14px rgba(0,0,0,.25);
  }
  .mod-thumb{
    width:52px; height:52px; border-radius:10px; flex:0 0 52px; object-fit:cover;
    border:1px solid rgba(255,255,255,.1); background:rgba(255,255,255,.05);
    display:flex; align-items:center; justify-content:center; font-size:26px;
  }
  .mod-meta{ flex:1 1 auto; min-width:0; }

  /* Nom bien lisible, 2 lignes max + tooltip avec l’id complet */
  .mod-name{
    font-size:1.05rem; font-weight:700; line-height:1.25;
    white-space:normal; word-break:break-word;
    display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;
  }

  .mod-actions{ display:flex; gap:6px; align-items:center; }
  .mod-actions form{ margin:0; }
  .btn-del{
    padding:6px 8px; border-radius:8px; border:1px solid var(--border-color,#444);
    background:#3a1f1f; color:#ffb3b3; cursor:pointer;
  }
  .btn-del:hover{ filter:brightness(1.1); }

  /* ---- Pagination ---- */
  .mods-pager{ margin-top:12px; text-align:center; display:flex; gap:8px; justify-content:center; }
  .mods-pager a, .mods-pager strong{ padding:6px 10px; border-radius:8px; border:1px solid var(--border-color,#444); }
  .mods-pager strong{ background:var(--button-bg,#222); }

  /* ---- Popup market (loupe) ---- */
  .market-overlay{ position:fixed; inset:0; display:none; align-items:center; justify-content:center;
    background:rgba(0,0,0,.65); z-index:9999; }
  .market-modal{ width:min(1100px,96vw); height:min(80vh, 800px); background:#111; border:1px solid rgba(255,255,255,.12);
    border-radius:12px; overflow:hidden; display:flex; flex-direction:column; }
  .market-head{ display:flex; align-items:center; justify-content:space-between; padding:8px 10px;
    border-bottom:1px solid rgba(255,255,255,.08); }
  .market-body{ flex:1 1 auto; }
  .market-body iframe{ width:100%; height:100%; border:0; }
</style>

<!-- Barre d’actions -->
<div class="mods-toolbar">

  <!-- <a href="../adm/market/marketmodules.php" class="btn-pill" title="Installer un module">➕ Installer</a>
  <!-- “Loupe” -> montre la liste installable dans une popup -->
  <button type="button" class="btn-pill" id="open-market" title="Voir les modules installables">🔍 Voir la liste</button>
</div>

<?php
/* --------- liste des modules installés + pagination --------- */
$modDir        = "$baseDir/modules";
$allModules    = array_values(array_filter(glob("$modDir/*"), 'is_dir')); // dossiers = modules
$totalModules  = count($allModules);
$perPage       = 12;
$page          = max(1, (int)($_GET['mpage'] ?? 1));
$start         = ($page - 1) * $perPage;
$modulesPage   = array_slice($allModules, $start, $perPage);
?>

<div class="mods-grid">
  <?php foreach ($modulesPage as $path): 
    $mod = basename($path);

    // Nom lisible : "savev.1" -> "Savev 1", "my_module-test" -> "My Module Test"
    $displayName = ucwords(trim(preg_replace('/[_\.\-]+/', ' ', $mod)));

    // Cherche une icône
    $icon = '';
    foreach (['icon.png','logo.png','icon.jpg','icon.webp','logo.webp'] as $f) {
      if (is_file("$path/$f")) { $icon = "../modules/$mod/$f"; break; }
    }
  ?>
    <div class="mod-card">
      <?php if ($icon): ?>
        <img src="<?= htmlspecialchars($icon) ?>" alt="" class="mod-thumb">
      <?php else: ?>
        <div class="mod-thumb">🧩</div>
      <?php endif; ?>

      <div class="mod-meta">
        <div class="mod-name" title="<?= htmlspecialchars($mod) ?>">
          <?= htmlspecialchars($displayName) ?>
        </div>
      </div>

      <div class="mod-actions">
        <?php if ($isAdmin): ?>
          <form method="post" onsubmit="return confirm('Supprimer définitivement le module <?= htmlspecialchars($mod) ?> ?');">
            <input type="hidden" name="delete_module" value="<?= htmlspecialchars($mod) ?>">
            <button type="submit" class="btn-del" title="Supprimer">🗑️</button>
          </form>
        <?php endif; ?>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<?php
/* --------- pagination --------- */
$pages = max(1, ceil($totalModules / $perPage));
if ($pages > 1): ?>
  <div class="mods-pager">
    <?php for ($i = 1; $i <= $pages; $i++): ?>
      <?php if ($i == $page): ?>
        <strong><?= $i ?></strong>
      <?php else: ?>
        <a href="?mpage=<?= $i ?>#modules"><?= $i ?></a>
      <?php endif; ?>
    <?php endfor; ?>
  </div>
<?php endif; ?>

<!-- Popup loupe -->
<div class="market-overlay" id="marketOverlay">
  <div class="market-modal">
    <div class="market-head">
      <strong style="display:flex;align-items:center;gap:6px;">🔍 Modules installables</strong>
      <button type="button" class="btn-pill" id="close-market">✖ Fermer</button>
    </div>
    <div class="market-body">
      <iframe src="../adm/market/marketmodules.php"></iframe>
    </div>
  </div>
</div>

<script>
  const openBtn  = document.getElementById('open-market');
  const closeBtn = document.getElementById('close-market');
  const overlay  = document.getElementById('marketOverlay');

  openBtn?.addEventListener('click', ()=> overlay.style.display='flex');
  closeBtn?.addEventListener('click', ()=> overlay.style.display='none');
  overlay?.addEventListener('click', (e)=>{ if(e.target===overlay) overlay.style.display='none'; });
  document.addEventListener('keydown', (e)=>{ if(e.key==='Escape') overlay.style.display='none'; });
</script>

</details>	<!-- ---------- -->
    <!-- bloc accès -->
	<!-- ---------- -->
<?php
/* ===== Accès aux pages : lecture/sauvegarde par utilisateur ===== */
$pagesScan = [];
foreach (['', 'adm'] as $sub) { // pas "modules"
    foreach (glob($baseDir . ($sub ? "/$sub" : '') . '/*.php') as $f) {
        $pagesScan[] = str_replace("$baseDir/", '', $f);
    }
}
sort($pagesScan);

/* Lit users/profiles/<mail>/pages.json */
$userPagesMap = [];
foreach (glob($profilesDir . '*', GLOB_ONLYDIR) as $folder) {
    $mail = basename($folder);
    $file = $folder . '/pages.json';
    if (is_file($file)) {
        $arr = json_decode(file_get_contents($file), true);
        if (is_array($arr)) $userPagesMap[$mail] = $arr;
    }
}

/* Sauvegarde */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_user_pages'])) {
    $emailSel = trim($_POST['user_email'] ?? '');
    $picked   = isset($_POST['pages']) && is_array($_POST['pages']) ? $_POST['pages'] : [];
    $picked   = array_values(array_intersect($pagesScan, $picked));

    if ($emailSel && is_dir($profilesDir . $emailSel)) {
        $dest = $profilesDir . $emailSel . '/pages.json';
        file_put_contents($dest, json_encode($picked, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $userPagesMap[$emailSel] = $picked; // pour réaffichage
        $success = true;
    } else {
        $errors[] = "Utilisateur invalide pour la sauvegarde des accès.";
    }
}
?>
<h2>🔐 Accès aux pages</h2>
<details>
  

  <style>
    .access-wrap{
  display:flex;
  flex-direction: column;
  gap:16px;
  align-items: stretch;
}
.access-left{
  width:100%; 
  max-width:420px;
}
.access-right{ width:100%; } 
    .access-left label { display:block; font-weight:600; margin-bottom:6px; }
    .access-left select { width:100%; }

    /* --- Tableau 4 colonnes --- */
    table.pages-matrix { width:100%; border-collapse:collapse; }
    table.pages-matrix th, table.pages-matrix td {
      border-bottom:1px solid var(--border-color, #333);
      padding:8px 10px;
      vertical-align:top;
      width:25%;
    }
    table.pages-matrix th { text-align:left; font-weight:700; }

    .page-cell {
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:10px;
      min-height:32px;
    }
    .page-info { display:flex; align-items:center; gap:8px; overflow:hidden; }
    .page-name {
      white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
      max-width: 260px;
    }

    .dot { width:10px; height:10px; border-radius:50%; display:inline-block; }
    .dot.green { background:#2ecc71; box-shadow:0 0 0 2px rgba(46,204,113,.15); }
    .dot.red   { background:#e74c3c; box-shadow:0 0 0 2px rgba(231,76,60,.15); }

    .access-actions { margin-top:14px; text-align:right; }
  </style>

  <div class="access-wrap">
    <div class="access-left">
      <label>Utilisateur</label><br>
      <select id="acc-user">
        <option value="">-- Choisir --</option>
        <?php foreach ($users as $u): ?>
          <option value="<?= htmlspecialchars($u) ?>"><?= htmlspecialchars($u) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div style="flex:1 1 auto;">
      <form method="post" id="acc-form">
        <input type="hidden" name="save_user_pages" value="1">
        <input type="hidden" name="user_email" id="acc-user-email">

        <table class="pages-matrix" id="pages-matrix">
          <thead>

          </thead>
          <tbody><!-- rempli en JS --></tbody>
        </table>

        <div class="access-actions">
          <button type="submit">💾 Valider</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    // Données PHP -> JS
    const PAGES_ALL  = <?= json_encode($pagesScan, JSON_UNESCAPED_UNICODE) ?>;
    const USER_PAGES = <?= json_encode($userPagesMap, JSON_UNESCAPED_UNICODE) ?>;

    const selUser = document.getElementById('acc-user');
    const hiddenU = document.getElementById('acc-user-email');
    const tbody   = document.querySelector('#pages-matrix tbody');

    // construit une cellule (dot + nom + checkbox)
    function cellHTML(page, checked){
      if (!page) return '<td></td>';
      const esc = s => s.replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;', "'":'&#39;'}[m]));
      return `
        <td>
          <div class="page-cell">
            <div class="page-info">
              <span class="dot ${checked ? 'green':'red'}"></span>
              <span class="page-name" title="${esc(page)}">${esc(page)}</span>
            </div>
            <input type="checkbox" name="pages[]" value="${esc(page)}" ${checked ? 'checked' : ''}>
          </div>
        </td>`;
    }

    // rend en tableau 4 colonnes
    function renderFor(user){
      tbody.innerHTML = '';
      hiddenU.value = user || '';
      if (!user) return;

      const allowed = new Set(USER_PAGES[user] || []);
      const cols = 4;
      const rows = Math.ceil(PAGES_ALL.length / cols);

      let html = '';
      for (let r = 0; r < rows; r++){
        html += '<tr>';
        for (let c = 0; c < cols; c++){
          const idx = r + c*rows;              // remplissage colonnes équilibrées
          const page = PAGES_ALL[idx] || null;
          html += cellHTML(page, page ? allowed.has(page) : false);
        }
        html += '</tr>';
      }
      tbody.innerHTML = html;
    }

    selUser.addEventListener('change', () => renderFor(selUser.value));

    // Optionnel: pré-sélectionner le premier user pour afficher direct
    if (selUser.options.length > 1) { selUser.selectedIndex = 1; renderFor(selUser.value); }
  </script>
</details>
	
	  	<!-- ---------- -->
		<!-- ADD user -->
		<!-- ---------- -->
<h2>➕ Nouvel utilisateur</h2>
<details>
  <?php if (!empty($message)): ?>
    <div style="color:<?= strpos($message, 'existe') !== false ? 'red' : 'green' ?>;margin-bottom:10px">
      <?= htmlspecialchars($message) ?>
    </div>
  <?php endif; ?>

  <style>
    .user-form {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(420px, 1fr));
      gap: 5px;
      align-items: end;
      max-width: 500px;
      margin: 0 auto;
    }
    .user-form label {
      display: flex;
      flex-direction: column;
      font-weight: 250;
      font-size: 0.95em;
    }
    .user-form input,
    .user-form select {
      padding: 6px 8px;
      border-radius: 4px;
      border: 1px solid var(--border-color, #444);
      background: var(--input-bg, #111);
      color: inherit;
    }
    .user-form button {
      padding: 8px 14px;
      border: none;
      border-radius: 4px;
      background: var(--primary-color, #28a745);
      color: #fff;
      cursor: pointer;
      font-size: 0.95em;
    }
    .user-form button:hover {
      background: var(--primary-dark, #1e7e34);
    }
    .user-form .full {
      grid-column: 1 / -1;
    }
    .user-form-wrap {
      display: flex;
      justify-content: center;
    }
  </style>

  <div class="user-form-wrap">
    <form method="post" class="user-form">
      <label>Prénom
        <input type="text" name="prenom" required>
      </label>

      <label>Nom
        <input type="text" name="nom" required>
      </label>

      <label class="full">Email
        <input type="email" name="email" required>
      </label>

      <label class="full">Rôle métier
        <select name="role_metier" required>
          <option value="" disabled selected>-- Choisir --</option>
          <?php foreach ($metiers as $m): ?>
            <option value="<?= htmlspecialchars($m) ?>"><?= htmlspecialchars($m) ?></option>
          <?php endforeach; ?>
        </select>
      </label>

      <label>Mot de passe
        <input type="password" name="password" required>
      </label>

      <label>Rôle système
        <select name="role_system" required>
          <option value="user">Utilisateur</option>
          <option value="admin">Administrateur</option>
        </select>
      </label>

      <div class="full" style="text-align:right">
        <button type="submit" name="add_user">✅ Ajouter</button>
      </div>
    </form>
  </div>
</details>

  </div>

</html>