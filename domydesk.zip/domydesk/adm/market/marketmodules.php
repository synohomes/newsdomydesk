<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

/* --------------------------------------------------------------
   SÉCURITÉ
-------------------------------------------------------------- */
if (!isset($_SESSION['user']['email'])) { header('Location: ../../login.php'); exit; }
$email   = $_SESSION['user']['email'];
$isAdmin = (($_SESSION['user']['role_system'] ?? '') === 'admin');

/* --------------------------------------------------------------
   BASE & THÈME
-------------------------------------------------------------- */
$baseDir = realpath(__DIR__ . '/../../') ?: __DIR__ . '/../../';   // .../domydesk
$userDir = $baseDir . '/users/profiles/' . $email . '/';
$theme   = 'default';
$themeJson = $userDir . 'theme.json';
if (is_file($themeJson)) {
  $td = json_decode(@file_get_contents($themeJson), true) ?: [];
  if (!empty($td['theme']) && is_file($baseDir . "/theme/{$td['theme']}/style.css")) {
    $theme = basename($td['theme']);
  }
}

/* --------------------------------------------------------------
   CHEMINS
-------------------------------------------------------------- */
$uploadDir  = $baseDir . '/uploads/';
$modulesDir = $baseDir . '/modules/';
$listFile   = $modulesDir . 'list.json';
$cfgFile    = $baseDir . '/data/market/marketcfg.json'; // <-- ICI on stocke l’URL du catalogue
@mkdir($uploadDir, 0775, true);
@mkdir(dirname($cfgFile), 0775, true);

$messages = [];

/* --------------------------------------------------------------
   HELPERS
-------------------------------------------------------------- */
function slugify($s){ $s=preg_replace('~[^a-zA-Z0-9._-]+~','-',(string)$s); return trim($s,'-'); }
function load_json($path){ $t=@file_get_contents($path); if($t===false)return []; $j=json_decode($t,true); return is_array($j)?$j:[]; }
function save_json($path,$data){ @mkdir(dirname($path),0775,true); file_put_contents($path,json_encode($data,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)); @chmod($path,0666); }
function rrmdir_recursive($dir){ if(!is_dir($dir))return; foreach(array_diff(scandir($dir),['.','..']) as $i){ $p="$dir/$i"; if(is_dir($p)) rrmdir_recursive($p); else @unlink($p);} @rmdir($dir); }
function github_to_raw($url){
  $url = trim((string)$url);
  if ($url === '') return $url;

  // retirer la query (?token=...)
  $url = preg_replace('~\?.*$~','',$url);

  // 0) règle générale : si "refs/heads/<branch>/" apparaît, on le remplace par "<branch>/"
  $url = preg_replace('~/refs/heads/([^/]+)/~','/$1/',$url);

  // 1) github.com/.../blob/<branch>/path -> raw.githubusercontent.com/user/repo/branch/path
  if (preg_match('~^https?://github\.com/([^/]+)/([^/]+)/blob/([^/]+)/(.*)$~i',$url,$m)) {
    return "https://raw.githubusercontent.com/{$m[1]}/{$m[2]}/{$m[3]}/{$m[4]}";
  }

  // 2) github.com/.../raw/<branch>/path -> raw.githubusercontent.com/user/repo/branch/path
  if (preg_match('~^https?://github\.com/([^/]+)/([^/]+)/raw/([^/]+)/(.*)$~i',$url,$m)) {
    return "https://raw.githubusercontent.com/{$m[1]}/{$m[2]}/{$m[3]}/{$m[4]}";
  }

  // 3) raw.githubusercontent.com/... : après la règle générale, l'URL est déjà bonne
  return $url;
}


function http_download($url,$dest,&$why=null){
  $why='';
  $url = github_to_raw($url);
  // cURL
  if(function_exists('curl_init')){
    $ch = curl_init($url);
    $fp = fopen($dest,'wb');
    curl_setopt_array($ch,[
      CURLOPT_FILE=>$fp,
      CURLOPT_FOLLOWLOCATION=>true,
      CURLOPT_MAXREDIRS=>10,
      CURLOPT_USERAGENT=>'DoMyDesk-Market/1.0',
      CURLOPT_CONNECTTIMEOUT=>15,
      CURLOPT_TIMEOUT=>60,
    ]);
    $ok = curl_exec($ch);
    $code = curl_getinfo($ch,CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch); fclose($fp);
    if(!$ok || $code<200 || $code>=300){ @unlink($dest); $why="HTTP $code via cURL".($err? " ($err)" : ""); return false; }
    if(!filesize($dest)){ @unlink($dest); $why='Fichier vide après cURL'; return false; }
    return true;
  }
  // fallback
  $ctx = stream_context_create(['http'=>['header'=>"User-Agent: DoMyDesk-Market/1.0\r\n",'timeout'=>60]]);
  $data = @file_get_contents($url,false,$ctx);
  if($data===false){ $why='file_get_contents a échoué'; return false; }
  if(!strlen($data)){ $why='Réponse vide'; return false; }
  if(file_put_contents($dest,$data)===false){ $why="Écriture impossible: $dest"; return false; }
  return true;
}

function http_get_body($url, &$why = null) {
    $why = '';
    // 1) cURL si dispo (recommandé)
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_USERAGENT      => 'DoMyDesk-Market/1.0',
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT        => 30,
            // ⚠️ NE PAS décommenter en prod. À n’utiliser qu’en dernier recours si ton CA SSL est cassé :
            // CURLOPT_SSL_VERIFYPEER => false,
            // CURLOPT_SSL_VERIFYHOST => 0,
        ]);
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($body === false || $code < 200 || $code >= 300) {
            $why = $body === false ? ("cURL error: ".$err) : ("HTTP $code");
            return false;
        }
        return $body;
    }

    // 2) fallback: file_get_contents + UA
    $ctx = stream_context_create(['http'=>[
        'header' => "User-Agent: DoMyDesk-Market/1.0\r\n",
        'timeout'=> 30
    ]]);
    $body = @file_get_contents($url, false, $ctx);
    if ($body === false) { $why = 'file_get_contents a échoué (allow_url_fopen ?)'; return false; }
    return $body;
}

/* --------------------------------------------------------------
   LIRE CONFIG (URL DU CATALOGUE)
-------------------------------------------------------------- */
$cfg = load_json($cfgFile);
if (empty($cfg['catalog_url'])) {
  // valeur par défaut si rien
  $cfg['catalog_url'] = 'https://raw.githubusercontent.com/synohomes/marketmodules/refs/heads/main/modulesmarket.json';
  save_json($cfgFile,$cfg);
}

$catalogUrl = github_to_raw($cfg['catalog_url']);

// update via formulaire
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_catalog_url']) && $isAdmin){
  $u = github_to_raw($_POST['catalog_url'] ?? '');
  if ($u==='') {
    $messages[] = ['type'=>'error','text'=>'❌ URL de catalogue vide.'];
  } else {
    $cfg['catalog_url'] = $u;
    save_json($cfgFile,$cfg);
    $messages[] = ['type'=>'success','text'=>'✅ URL du catalogue enregistrée.'];
    // recharger la bonne valeur
    $catalogUrl = $u;
  }
}

/* --------------------------------------------------------------
   ACTION : INSTALLER DEPUIS URL (depuis le tableau)
-------------------------------------------------------------- */
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['download_url'], $_POST['module_id'])) {
  $url = trim($_POST['download_url']);
  $id  = slugify($_POST['module_id']);
  if ($url && $id) {
    $zipTmp = $uploadDir . $id . '.zip';
    if (!http_download($url, $zipTmp, $why)) {
      $messages[] = ['type'=>'error','text'=>"❌ Téléchargement échoué : ".htmlspecialchars($why)." — URL : ".htmlspecialchars($url)];
    } else {
      $zip = new ZipArchive();
      if ($zip->open($zipTmp) === TRUE) {
        $extractDir = $modulesDir . $id . '/';
        @mkdir($extractDir, 0777, true);
        $zip->extractTo($extractDir);
        $zip->close();
        @unlink($zipTmp);

        // permissions souples
        $rii = new RecursiveIteratorIterator(
          new RecursiveDirectoryIterator($extractDir, FilesystemIterator::SKIP_DOTS),
          RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($rii as $f) { if ($f->isDir()) @chmod($f->getPathname(),0777); else @chmod($f->getPathname(),0666); }
        @chmod($extractDir,0777);

        // ajouter dans modules/list.json s'il n'existe pas
        $list = load_json($listFile);
        $exists = false; foreach ($list as $e){ if (strtolower($e['id']??'')===strtolower($id)) { $exists=true; break; } }
        if (!$exists) {
          $list[] = ['id'=>$id,'name'=>ucfirst($id),'description'=>"Module $id installé via URL",'icon'=>"modules/$id/icon.png",'enabled'=>false];
          save_json($listFile,$list);
        }
        $messages[] = ['type'=>'success','text'=>"✅ Module <strong>$id</strong> installé."];
      } else {
        @unlink($zipTmp);
        $messages[] = ['type'=>'error','text'=>"❌ Impossible d’ouvrir le ZIP pour <strong>$id</strong>."];
      }
    }
  } else {
    $messages[] = ['type'=>'error','text'=>"❌ Paramètres invalides pour l’installation."];
  }
}

/* --------------------------------------------------------------
   ACTION : UPLOAD ZIP MANUEL
-------------------------------------------------------------- */
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_FILES['module_zip'])) {
  if ($_FILES['module_zip']['error'] === UPLOAD_ERR_OK) {
    $zipPath = $uploadDir . basename($_FILES['module_zip']['name']);
    $id = slugify(pathinfo($zipPath, PATHINFO_FILENAME));
    if (move_uploaded_file($_FILES['module_zip']['tmp_name'], $zipPath)) {
      $zip = new ZipArchive();
      if ($zip->open($zipPath) === TRUE) {
        $extractDir = $modulesDir . $id . '/';
        @mkdir($extractDir, 0777, true);
        $zip->extractTo($extractDir);
        $zip->close();
        @unlink($zipPath);

        $rii = new RecursiveIteratorIterator(
          new RecursiveDirectoryIterator($extractDir, FilesystemIterator::SKIP_DOTS),
          RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($rii as $f) { if ($f->isDir()) @chmod($f->getPathname(),0777); else @chmod($f->getPathname(),0666); }
        @chmod($extractDir,0777);

        $list = load_json($listFile);
        $exists = false; foreach ($list as $e){ if (strtolower($e['id']??'')===strtolower($id)) { $exists=true; break; } }
        if (!$exists) { $list[] = ['id'=>$id,'name'=>ucfirst($id),'description'=>"Module $id ajouté manuellement",'icon'=>"modules/$id/icon.png",'enabled'=>false]; save_json($listFile,$list); }
        $messages[] = ['type'=>'success','text'=>"✅ Module <strong>$id</strong> installé depuis un ZIP."];
      } else {
        $messages[] = ['type'=>'error','text'=>"❌ Erreur ouverture ZIP."];
      }
    } else {
      $messages[] = ['type'=>'error','text'=>"❌ Échec de l’upload du ZIP."];
    }
  } else {
    $messages[] = ['type'=>'error','text'=>"❌ Code d’erreur upload : " . (int)$_FILES['module_zip']['error']];
  }
}

/* --------------------------------------------------------------
   LISTE DES MODULES INSTALLÉS
-------------------------------------------------------------- */
$installed = [];
if (is_dir($modulesDir)) {
  foreach (scandir($modulesDir) as $f) {
    if ($f[0] === '.') continue;
    if (is_dir($modulesDir.$f)) $installed[] = $f;
  }
}

/* --------------------------------------------------------------
   RENDU
-------------------------------------------------------------- */
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Market des Modules</title>
<link rel="stylesheet" href="../../theme/<?= htmlspecialchars($theme) ?>/style.css">
<style>
.market-wrapper{max-width:1300px;margin:30px auto;padding:10px;}
.grid-columns{display:grid;grid-template-columns:1fr 1fr;gap:20px;}
@media (max-width:1100px){.grid-columns{grid-template-columns:1fr;}}
.message{margin:10px 0;padding:10px;border-radius:8px;background:rgba(0,0,0,.2);}
.message.success::before{content:"✅ ";}
.message.error::before{content:"❌ ";}
.modules-table{width:100%;border-collapse:collapse;}
.modules-table th,.modules-table td{padding:10px;border-bottom:1px solid currentColor;text-align:left;}
.upload-section{margin-top:20px;padding:16px;border:1px dashed currentColor;border-radius:12px;}
.small{opacity:.75;font-size:12px;}
</style>
</head>
<body>
<div class="market-wrapper container">
  <h1>🛒 Market des Modules</h1>

  <?php foreach ($messages as $m): ?>
    <div class="message <?= htmlspecialchars($m['type']) ?>"><?= $m['text'] ?></div>
  <?php endforeach; ?>

  <?php if ($isAdmin): ?>
  
  <?php endif; ?>

  <div class="grid-columns">
    <!-- COLONNE 1 : MARKET (GitHub) -->
    <div class="section">
      <h2>📥 Modules installables (catalogue)</h2>
      <?php
      // Charger le JSON du catalogue
$why = '';
$raw = http_get_body($catalogUrl, $why);
if ($raw === false) {
    echo "<div class='message error'>Impossible de charger le catalogue : "
        . htmlspecialchars($catalogUrl)
        . "<br><span class='small'>Détail : " . htmlspecialchars($why) . "</span></div>";
} else {
    $marketModules = json_decode($raw, true);
    if (!is_array($marketModules)) {
        echo "<div class='message error'>Catalogue JSON invalide."
           . "<br><span class='small'>Taille reçue : ".strlen($raw)." octets</span></div>";
    } else {
          echo "<table class='modules-table'><tr><th>Nom</th><th>Description</th><th>Action</th></tr>";
          foreach ($marketModules as $mod) {
            $id   = slugify($mod['id'] ?? ($mod['name'] ?? 'module'));
            $name = $mod['name'] ?? $id;
            $desc = $mod['description'] ?? '';
            // on accepte plusieurs clés possibles, et on normalise l’URL
            $dl   = $mod['download_url'] ?? $mod['download'] ?? $mod['url'] ?? $mod['zip'] ?? null;
            if ($dl) $dl = github_to_raw($dl);

            echo "<tr>";
            echo "<td>".htmlspecialchars($name)."</td>";
            echo "<td>".htmlspecialchars($desc)."</td>";
            echo "<td>";
            if ($dl) {
              echo "<form method='post' style='display:inline-block;margin:0;'>
                      <input type='hidden' name='download_url' value='".htmlspecialchars($dl)."'>
                      <input type='hidden' name='module_id' value='".htmlspecialchars($id)."'>
                      <button type='submit'>Installer</button>
                    </form>";
            } else {
              echo "<span class='small'>Lien manquant</span>";
            }
            echo "</td></tr>";
          }
          echo "</table>";
        }
      }
      ?>
    </div>

    <!-- COLONNE 2 : INSTALLÉS -->
    <div class="section">
      <h2>✅ Modules déjà installés</h2>
      <?php
      if (!empty($installed)) {
        echo "<table class='modules-table'><tr><th>Nom</th></tr>";
        foreach ($installed as $mod) {
          echo "<tr><td>".htmlspecialchars($mod)."</td></tr>";
        }
        echo "</table>";
      } else {
        echo "<p>Aucun module installé.</p>";
      }
      ?>

      <div class="upload-section">
        <h3>🗂 Ajouter un module ZIP</h3>
        <form method="post" enctype="multipart/form-data" style="margin:0;">
          <input type="file" name="module_zip" accept=".zip" required>
          <br><br>
          <button type="submit">Uploader le module ZIP</button>
        </form>
      </div>
    </div>
  </div>
</div>
</body>
</html>
