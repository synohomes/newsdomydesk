<?php
// log.php

// Fonction pour écrire un message dans un fichier log horodaté dans /logs
function writeLog(string $message, string $type = 'INFO'): void {
    // Dossier logs (créé s'il n'existe pas)
    $logDir = __DIR__ . '/logs';
    if (!is_dir($logDir)) {
        mkdir($logDir, 0755, true);
    }

    // Nom fichier avec date et heure (ex: 2025-05-22_15-30.txt)
    $filename = $logDir . '/' . date('Y-m-d_H-i') . '.txt';

    // Format du message log : [date heure][type] message
    $logMessage = sprintf("[%s][%s] %s\n", date('Y-m-d H:i:s'), strtoupper($type), $message);

    // Écriture en ajout dans le fichier (mode "a")
    file_put_contents($filename, $logMessage, FILE_APPEND | LOCK_EX);
}
